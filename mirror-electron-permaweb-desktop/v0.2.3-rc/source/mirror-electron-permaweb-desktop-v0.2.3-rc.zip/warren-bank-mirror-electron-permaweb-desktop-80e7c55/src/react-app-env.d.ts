/// <reference types="react-scripts" />

declare module 'react-semantic-toasts'
