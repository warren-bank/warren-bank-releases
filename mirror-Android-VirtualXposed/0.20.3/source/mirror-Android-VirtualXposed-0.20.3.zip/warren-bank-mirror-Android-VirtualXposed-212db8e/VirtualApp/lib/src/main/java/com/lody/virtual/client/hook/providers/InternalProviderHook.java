package com.lody.virtual.client.hook.providers;

/**
 * @author Lody
 */

public class InternalProviderHook extends ProviderHook {

    public InternalProviderHook(Object base) {
        super(base);
    }

}
