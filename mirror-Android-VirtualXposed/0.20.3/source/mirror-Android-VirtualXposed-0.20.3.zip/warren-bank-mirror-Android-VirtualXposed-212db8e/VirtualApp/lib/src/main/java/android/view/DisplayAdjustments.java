package android.view;

/**
 * @author weishu
 * @date 2020/11/23.
 */

// https://cs.android.com/android/platform/superproject/+/master:frameworks/base/core/java/android/view/DisplayAdjustments.java;drc=master;l=184
public class DisplayAdjustments {
    public static class FixedRotationAdjustments {}
}
