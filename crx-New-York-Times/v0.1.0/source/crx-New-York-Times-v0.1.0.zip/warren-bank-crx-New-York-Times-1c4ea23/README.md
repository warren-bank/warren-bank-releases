### [Chromium browser extension for The New York Times](https://github.com/warren-bank/crx-New-York-Times)

Read articles on [_The New York Times_ website](https://www.nytimes.com/) without a paywall.

#### Legal:

* copyright: [Warren Bank](https://github.com/warren-bank)
* license: [GPL-2.0](https://www.gnu.org/licenses/old-licenses/gpl-2.0.txt)
