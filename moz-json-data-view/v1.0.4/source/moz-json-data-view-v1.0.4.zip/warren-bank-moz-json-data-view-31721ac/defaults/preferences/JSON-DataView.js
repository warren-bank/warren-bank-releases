pref('extensions.JSON_DataView.syntax_highlighter.enabled', true);
pref('extensions.JSON_DataView.syntax_highlighter.theme', 'solarized_dark');
