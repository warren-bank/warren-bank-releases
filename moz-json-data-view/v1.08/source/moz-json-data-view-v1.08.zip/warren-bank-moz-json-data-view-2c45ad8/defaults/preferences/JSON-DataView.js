pref('extensions.JSON_DataView.syntax_highlighter.enabled', true);
pref('extensions.JSON_DataView.syntax_highlighter.theme', 'solarized_dark');
pref('extensions.JSON_DataView.syntax_highlighter.expand_all_nodes', false);

pref('extensions.JSON_DataView.css.tree.font_family', '');
pref('extensions.JSON_DataView.css.tree.font_size', 13);
pref('extensions.JSON_DataView.css.tree.line_height', 2);
pref('extensions.JSON_DataView.css.tree.padding', 1);
pref('extensions.JSON_DataView.css.subtree.white_space_indentation', 1);
