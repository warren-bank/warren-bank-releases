zip -r JSON-DataView.xpi chrome.manifest install.rdf LICENSE README.md chrome components defaults
