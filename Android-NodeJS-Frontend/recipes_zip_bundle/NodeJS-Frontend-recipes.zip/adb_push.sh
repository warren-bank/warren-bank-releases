#!/usr/bin/env bash
adb push './npm_v8.19.4/' '/storage/emulated/0/Node.js/'
adb push './npm_v8.19.4.json' '/storage/emulated/0/Node.js/npm_v8.19.4.json'
adb push './serve_v130002.18.6/' '/storage/emulated/0/Node.js/'
adb push './serve_v130002.18.6.json' '/storage/emulated/0/Node.js/serve_v130002.18.6.json'
adb push './hls-proxy_v3.5.4/' '/storage/emulated/0/Node.js/'
adb push './hls-proxy_v3.5.4.json' '/storage/emulated/0/Node.js/hls-proxy_v3.5.4.json'
adb push './widevine-license-proxy_v2.0.2/' '/storage/emulated/0/Node.js/'
adb push './widevine-license-proxy_v2.0.2.json' '/storage/emulated/0/Node.js/widevine-license-proxy_v2.0.2.json'
