#!/usr/bin/env bash
adb push './npm_v8.19.4/' '/storage/emulated/0/Node.js/'
adb push './npm_v8.19.4.json' '/storage/emulated/0/Node.js/npm_v8.19.4.json'
adb push './serve_v130002.18.5/' '/storage/emulated/0/Node.js/'
adb push './serve_v130002.18.5.json' '/storage/emulated/0/Node.js/serve_v130002.18.5.json'
adb push './hls-proxy_v3.5.0/' '/storage/emulated/0/Node.js/'
adb push './hls-proxy_v3.5.0.json' '/storage/emulated/0/Node.js/hls-proxy_v3.5.0.json'
