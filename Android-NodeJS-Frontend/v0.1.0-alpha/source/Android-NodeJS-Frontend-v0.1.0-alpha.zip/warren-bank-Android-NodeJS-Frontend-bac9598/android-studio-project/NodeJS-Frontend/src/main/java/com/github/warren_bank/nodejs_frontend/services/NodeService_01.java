package com.github.warren_bank.nodejs_frontend.services;

public class NodeService_01 extends AbstractNodeService {

  protected String getId() {
    return "01";
  }

}
