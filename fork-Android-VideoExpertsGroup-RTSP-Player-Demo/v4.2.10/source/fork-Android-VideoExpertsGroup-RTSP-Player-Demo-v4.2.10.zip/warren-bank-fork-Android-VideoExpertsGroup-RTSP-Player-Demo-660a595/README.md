# RTSP Player for Android
  
  THIS PLAYER IS BASED ON A TRIAL VERSION OF VXG PLAYER SDK FOR ANDROID. PLAYBACK IS LIMITED TO 2 MINS.

  READ MORE ABOUT VXG PLAYER SDK HERE: https://www.videoexpertsgroup.com/player-sdk/
  
  RTSP Player is a very simple IP camera viewer.
  Fast application to playback network stream from IP cameras, video servers and surveillance systems. 

  Key features: 
*  Supported types of streaming: RTSP, RTP, UDP (Multicast stream support),HTTP-HLS, RTMP, MMS
* Recording from live camera
*  Digital zoom and picture shifting 
*  Thumbnails for live streams
*  Support M3U channel list
*  Easy streams list control – add, delete and modify your streams
*  Preview video while browsing in camera list 
*  Replay for live HLS stream
*  Hardware decoder using hardware acceleration with processor optimization – high speed rendering for modern platform
*  Multi-core decoding provides the dual-core device’s performance 


<img src="http://www.videoexpertsgroup.com/git/sample1.png" alt="RTSP player sample1" width="500">

<img src="http://www.videoexpertsgroup.com/git/sample2.png" alt="RTSP player sample1" width="500">

<img src="http://www.videoexpertsgroup.com/git/sample4.png" alt="RTSP player sample1" width="800">
