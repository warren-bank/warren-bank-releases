## AOSP Patches
This folder contains patches made to AOSP, we use those patches to build our custom gsid.