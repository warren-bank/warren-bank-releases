package vegabobo.dsusideloader.ui.theme

import androidx.compose.ui.graphics.Color

val Blue80 = Color(0xFFACC7FF)
val BlueGrey80 = Color(0xFFBEC6DC)
val Purplish80 = Color(0xFFDEBCDF)

val Blue40 = Color(0xFF275CAF)
val BlueGrey40 = Color(0xFF565E71)
val Purplish40 = Color(0xFF715574)
