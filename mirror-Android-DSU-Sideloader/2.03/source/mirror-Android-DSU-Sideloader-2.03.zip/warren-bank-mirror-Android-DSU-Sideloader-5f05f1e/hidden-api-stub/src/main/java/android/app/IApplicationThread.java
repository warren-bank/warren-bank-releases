package android.app;

public class IApplicationThread {
}
