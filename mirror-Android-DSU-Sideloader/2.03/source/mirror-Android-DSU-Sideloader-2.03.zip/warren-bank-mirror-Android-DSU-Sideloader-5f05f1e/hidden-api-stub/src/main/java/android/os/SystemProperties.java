package android.os;

public class SystemProperties {
    public static void set(String key, String val) {}
}
