package android.app;

public class ProfilerInfo {
}
