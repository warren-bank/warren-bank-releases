#!/bin/sh
echo "- Installing DSU Sideloader..."
pm install $MODPATH/system/priv-app/DSUSideloader/ReleaseDSUSideloader.apk
setprop persist.sys.fflag.override.settings_dynamic_system true
