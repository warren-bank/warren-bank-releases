_17-Aug-2023_
# Project Status

I was holding back releases, because I was re-writing the whole structure of the app. But I think this is taking too long.
It is only natural that users will grow impatient for an update, thats why I will be releasing new versions soon.

## Why the delay:
- I had exams and submissions in my college
- I am really unwell mentally
- I was not able to create a solid structure for the new backend

## What now?
- Next release will be on **19-Aug**, and will contain many bug fixes and stability improvements.
- All the [progress](https://github.com/Droid-ify/client/pull/309) made in past months is still here and will help in future.
- We will be missing on the new index format introduced by fdroid for some future releases.
