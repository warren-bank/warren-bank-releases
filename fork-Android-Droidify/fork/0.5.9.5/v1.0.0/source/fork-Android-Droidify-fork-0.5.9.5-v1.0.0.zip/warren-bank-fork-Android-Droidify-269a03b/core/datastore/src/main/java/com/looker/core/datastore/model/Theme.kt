package com.looker.core.datastore.model

enum class Theme {
    SYSTEM,
    SYSTEM_BLACK,
    LIGHT,
    DARK,
    AMOLED
}
