package com.looker.core.datastore.model

enum class AutoSync {
    ALWAYS,
    WIFI_ONLY,
    WIFI_PLUGGED_IN,
    NEVER
}
