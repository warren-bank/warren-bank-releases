package com.looker.core.datastore.model

enum class ProxyType {
    DIRECT,
    HTTP,
    SOCKS
}
