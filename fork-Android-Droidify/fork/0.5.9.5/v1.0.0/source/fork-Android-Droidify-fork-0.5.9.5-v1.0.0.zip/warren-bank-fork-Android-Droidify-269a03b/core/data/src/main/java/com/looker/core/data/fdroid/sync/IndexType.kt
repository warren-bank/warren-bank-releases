package com.looker.core.data.fdroid.sync

enum class IndexType {
    INDEX_V1,
    ENTRY
}
