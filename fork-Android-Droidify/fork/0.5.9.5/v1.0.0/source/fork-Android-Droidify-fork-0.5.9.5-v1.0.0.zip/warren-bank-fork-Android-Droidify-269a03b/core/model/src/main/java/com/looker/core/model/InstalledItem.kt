package com.looker.core.model

class InstalledItem(
    val packageName: String,
    val version: String,
    val versionCode: Long,
    val signature: String
)
