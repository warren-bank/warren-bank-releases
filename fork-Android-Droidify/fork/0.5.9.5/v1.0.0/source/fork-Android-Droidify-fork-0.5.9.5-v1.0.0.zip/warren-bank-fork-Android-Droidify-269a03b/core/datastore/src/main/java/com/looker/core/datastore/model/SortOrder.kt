package com.looker.core.datastore.model

// todo: Add Support for sorting by size
enum class SortOrder {
    UPDATED,
    ADDED,
    NAME
}
