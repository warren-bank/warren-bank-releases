package com.looker.core.model.newer

interface DataFile {
    val name: String
    val hash: String
    val size: Long
}
