package nl.asymmetrics.droidshows.common;

public class Constants {
  public static final String LOG_TAG = "DroidShows";
}
