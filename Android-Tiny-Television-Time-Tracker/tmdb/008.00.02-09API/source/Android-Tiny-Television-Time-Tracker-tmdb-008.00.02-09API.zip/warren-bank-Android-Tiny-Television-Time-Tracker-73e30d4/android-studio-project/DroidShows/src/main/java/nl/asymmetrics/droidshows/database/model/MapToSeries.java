package nl.asymmetrics.droidshows.database.model;

public class MapToSeries {
  public int serieId;

  protected MapToSeries(int serieId) {
    this.serieId = serieId;
  }
}
