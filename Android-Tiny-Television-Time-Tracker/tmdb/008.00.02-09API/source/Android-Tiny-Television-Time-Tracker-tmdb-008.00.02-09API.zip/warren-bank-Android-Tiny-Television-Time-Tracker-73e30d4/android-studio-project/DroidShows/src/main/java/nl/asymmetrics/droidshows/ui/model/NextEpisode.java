package nl.asymmetrics.droidshows.ui.model;

import java.util.Date;

public class NextEpisode extends BaseEpisode {
  public NextEpisode(int serieId, int season, int episode, String firstAired, Date firstAiredDate) {
    super(serieId, season, episode, firstAired, firstAiredDate);
  }
}
