/*
 * Created on May 9, 2012
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package android.util;

public class Log {

  public static final int VERBOSE = 2;
  public static final int DEBUG = 3;
  public static final int INFO = 4;
  public static final int WARN = 5;
  public static final int ERROR = 6;
  public static final int ASSERT = 7;

  public static void i(String string, String sql) {
  }

  public static void v(String string, String sql) {
  }

  public static void e(String string, String sql) {
  }

  public static void w(String string, String sql) {
  }

  public static void d(String string, String sql) {
  }

  public static void e(String string, String string2, Exception e) {
  }

  public static void w(String string, String string2, Exception e) {
  }

  public static void d(String string, String string2, Exception e) {
  }

}
