/*
 * Created on May 9, 2012
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package android.database;

public class SQLException extends RuntimeException {
  
  public SQLException(String string) {
    super(string);
  }


}
