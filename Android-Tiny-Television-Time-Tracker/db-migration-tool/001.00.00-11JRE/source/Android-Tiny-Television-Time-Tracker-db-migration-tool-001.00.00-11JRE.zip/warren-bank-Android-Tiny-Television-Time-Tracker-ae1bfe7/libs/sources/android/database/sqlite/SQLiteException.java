/*
 * Created on May 9, 2012
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package android.database.sqlite;

import android.database.SQLException;

public class SQLiteException extends SQLException {

  public SQLiteException(String string) {
    super(string);
  }

}
