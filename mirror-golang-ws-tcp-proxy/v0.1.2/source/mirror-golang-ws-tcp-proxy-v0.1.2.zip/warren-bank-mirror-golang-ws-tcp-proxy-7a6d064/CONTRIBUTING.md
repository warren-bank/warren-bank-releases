# Contributing Guidelines

## Rules

There are a few basic ground-rules for contributors to `ws-tcp-proxy`:

1. When doing refactors make sure to discuss it in an issue prior to PR.
3. Use gofmt on all files.
4. Profit!
