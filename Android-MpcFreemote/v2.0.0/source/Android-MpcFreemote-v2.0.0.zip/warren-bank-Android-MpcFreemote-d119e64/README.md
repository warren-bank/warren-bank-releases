### [_MpcFreemote_](https://github.com/warren-bank/Android-MpcFreemote)

Control [_MPC-HC_](https://github.com/mpc-hc/mpc-hc) from an Android device. Fully compatible with [_ExoAirPlayer_](https://github.com/warren-bank/Android-ExoPlayer-AirPlay-Receiver).

Forked from [_VlcFreemote_](https://github.com/nicolasbrailo/VlcFreemote/tree/93f6eb0aa8e71e44249a097f45f672310372271f).

#### Legal:

* copyright:
  - mostly: [Nico Brailovsky](https://github.com/nicolasbrailo)
  - partly: [Warren Bank](https://github.com/warren-bank)
* license: [GPL-3.0](https://www.gnu.org/licenses/gpl-3.0.txt)
