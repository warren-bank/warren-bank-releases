package consoleinput

//go:generate go run github.com/zetamatta/go-importconst/
//	<windows.h>
//	FOCUS_EVENT
//	KEY_EVENT
//	MENU_EVENT
//	MOUSE_EVENT
//	WINDOW_BUFFER_SIZE_EVENT
//	ENABLE_WINDOW_INPUT
//	WAIT_ABANDONED
//	WAIT_OBJECT_0
//	WAIT_TIMEOUT
//	WAIT_FAILED
//	ENABLE_MOUSE_INPUT
