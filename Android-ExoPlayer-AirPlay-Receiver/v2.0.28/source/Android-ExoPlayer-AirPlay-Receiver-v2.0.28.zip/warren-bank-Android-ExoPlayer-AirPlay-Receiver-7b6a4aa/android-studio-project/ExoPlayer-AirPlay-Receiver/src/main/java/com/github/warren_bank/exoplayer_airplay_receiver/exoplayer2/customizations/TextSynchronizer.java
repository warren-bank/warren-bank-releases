package com.github.warren_bank.exoplayer_airplay_receiver.exoplayer2.customizations;

public interface TextSynchronizer {

  public long getTextOffset();

  public void setTextOffset(long value);

  public void addTextOffset(long value);

}
