package com.github.warren_bank.exoplayer_airplay_receiver.exoplayer2;

import com.google.android.exoplayer2.Player;

import androidx.annotation.Nullable;

public interface SetPlayer {

  public void setPlayer(@Nullable Player player);

}
