#### [Notify SMS_SENT](https://github.com/warren-bank/Android-Broadcast-SMS_SENT/tree/sample-receiver-app)

Android app that receives 'SMS_SENT' broadcasts and displays notifications.

#### Overview:

* this is a sample application that can be used to:
  * test that [Broadcast SMS_SENT](https://github.com/warren-bank/Android-Broadcast-SMS_SENT) works on a device
  * serve as a template

#### Notes:

* minimum supported version of Android:
  * Android 4.1 (API 16)

#### Legal:

* copyright: [Warren Bank](https://github.com/warren-bank)
* license: [GPL-2.0](https://www.gnu.org/licenses/old-licenses/gpl-2.0.txt)
