zip -r modify-response-headers.xpi chrome.manifest install.rdf install.js chrome components defaults
