package org.fdroid.fdroid.nearby;

public class LocalRepoManager {
    public static final String[] WEB_ROOT_ASSET_FILES = {};
}
