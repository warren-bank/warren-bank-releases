package org.fdroid.fdroid.views.main;

import android.content.Context;

class NearbyViewBinder {
    static void updateUsbOtg(Context context) {
        throw new IllegalStateException("unimplemented");
    }
    static void updateExternalStorageViews(Context context) {
    }
}
