package org.fdroid.fdroid.compat;

public class CursorAdapterCompat {

    public static final int FLAG_AUTO_REQUERY = 0x01;

}
