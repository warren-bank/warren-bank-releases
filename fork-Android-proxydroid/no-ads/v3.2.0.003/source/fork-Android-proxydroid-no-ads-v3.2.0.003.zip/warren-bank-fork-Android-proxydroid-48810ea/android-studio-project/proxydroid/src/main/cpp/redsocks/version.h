#ifndef VERSION_H_SUN_NOV_27_03_22_30_2011
#define VERSION_H_SUN_NOV_27_03_22_30_2011

const char* redsocks_version = "0.4";

#endif // VERSION_H_SUN_NOV_27_03_22_30_2011
