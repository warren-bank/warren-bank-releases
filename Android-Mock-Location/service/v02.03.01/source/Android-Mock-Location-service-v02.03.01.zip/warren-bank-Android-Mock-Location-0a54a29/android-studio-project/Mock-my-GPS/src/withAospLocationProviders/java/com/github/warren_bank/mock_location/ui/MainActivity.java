package com.github.warren_bank.mock_location.ui;

public class MainActivity extends AospMainActivity {
}
