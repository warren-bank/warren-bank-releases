package com.github.warren_bank.mock_location.event_hooks;

public interface ISharedPrefsListener {

    void onSharedPrefsChange(short diff_fields);

}
