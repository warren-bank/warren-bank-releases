### [kodi-PlutoTV](https://github.com/warren-bank/kodi-PlutoTV)

#### Summary

* Forked from: [Lunatixz/XBMC_Addons](https://github.com/Lunatixz/XBMC_Addons/tree/master/plugin.video.plutotv)
* the `17_krypton` branch is a verbatim copy of the official stable release for v1.0.7
  * source of release: [https://kodi.tv/addon/plugins-video-add-ons/plutotv](http://mirrors.kodi.tv/addons/krypton/plugin.video.plutotv/plugin.video.plutotv-1.0.7.zip)
* the `16_jarvis` branch applies a few minor patches that allow the addon to run in Kodi 16.x (Jarvis)
* [releases](https://github.com/warren-bank/kodi-PlutoTV/releases) contains compressed .zip file archives that can be installed in Kodi

#### Copyright

* belongs entirely to [Lunatixz](https://github.com/Lunatixz)
