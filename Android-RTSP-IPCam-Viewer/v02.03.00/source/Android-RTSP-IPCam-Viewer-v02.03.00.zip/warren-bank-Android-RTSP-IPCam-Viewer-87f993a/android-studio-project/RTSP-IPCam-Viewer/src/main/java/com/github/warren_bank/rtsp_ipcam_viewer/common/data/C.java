package com.github.warren_bank.rtsp_ipcam_viewer.common.data;

public final class C {
    public static final int INDEX_UNSET = -1;
}
