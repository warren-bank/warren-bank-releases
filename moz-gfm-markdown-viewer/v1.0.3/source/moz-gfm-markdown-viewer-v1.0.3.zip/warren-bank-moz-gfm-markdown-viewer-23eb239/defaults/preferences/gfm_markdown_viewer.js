pref('extensions.gfm_markdown_viewer.syntax_highlighter.enabled', true);
pref('extensions.gfm_markdown_viewer.syntax_highlighter.theme', 'github');
