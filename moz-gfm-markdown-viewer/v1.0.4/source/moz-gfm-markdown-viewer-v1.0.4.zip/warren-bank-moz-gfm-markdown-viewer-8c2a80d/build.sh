zip -r gfm_markdown_viewer.xpi chrome.manifest install.rdf LICENSE README.md chrome components defaults
