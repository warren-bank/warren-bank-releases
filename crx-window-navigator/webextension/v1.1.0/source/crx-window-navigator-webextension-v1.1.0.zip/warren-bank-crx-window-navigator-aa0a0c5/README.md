### [window.navigator](https://github.com/warren-bank/crx-window-navigator/tree/webextension)

Browser WebExtension having the purpose to:
* modify [`window.navigator`](https://developer.mozilla.org/en-US/docs/Web/API/Navigator) property values

#### Legal:

* copyright: [Warren Bank](https://github.com/warren-bank)
* license: [GPL-2.0](https://www.gnu.org/licenses/old-licenses/gpl-2.0.txt)
