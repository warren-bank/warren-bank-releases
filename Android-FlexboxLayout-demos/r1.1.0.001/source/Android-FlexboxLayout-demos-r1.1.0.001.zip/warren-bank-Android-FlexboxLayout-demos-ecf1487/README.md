### [Android FlexboxLayout demos](https://github.com/warren-bank/Android-FlexboxLayout-demos)

#### what:

* [FlexboxLayout r1.1.0](https://github.com/google/flexbox-layout/releases/tag/1.1.0) demos:
  * [playground](https://github.com/google/flexbox-layout/tree/1.1.0/demo-playground/src/main)
  * [cat gallery](https://github.com/google/flexbox-layout/tree/1.1.0/demo-cat-gallery/src/main)

#### why:

* remove dependency on FlexboxLayout source code
* attach release builds of APKs to tagged [releases](https://github.com/warren-bank/Android-FlexboxLayout-demos/releases)
