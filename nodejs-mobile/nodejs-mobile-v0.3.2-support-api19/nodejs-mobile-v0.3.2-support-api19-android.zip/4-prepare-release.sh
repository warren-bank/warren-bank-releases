#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

DIR_OUTPUT="${DIR}/nodejs-mobile/out_android"
if [ ! -d "$DIR_OUTPUT" ]; then
  echo 'output directory from build script not found'
  exit 0
fi

DIR_RELEASE="${DIR}/release"
[ -d "$DIR_RELEASE" ] && rm -rf "$DIR_RELEASE"
mkdir "$DIR_RELEASE"
mkdir "${DIR_RELEASE}/libnode"
cd "${DIR_RELEASE}/libnode"

# download header files for the correct version of node
curl -L https://github.com/JaneaSystems/nodejs-mobile/releases/download/nodejs-mobile-v0.3.2/nodejs-mobile-v0.3.2-android.zip -o nodejs-mobile.zip
unzip nodejs-mobile.zip
# ----------
# remove downloaded archive
rm -f nodejs-mobile.zip
# ----------
# remove downloaded binaries
rm -rf bin

# copy directories containing compiled binaries for each platform
mkdir bin
cp -R "$DIR_OUTPUT"/* bin

# copy bash scripts
cp "$DIR"/*.sh "$DIR_RELEASE"

# make compressed zip archive
cd "$DIR_RELEASE"
zip -r "${DIR}/nodejs-mobile-v0.3.2-support-api19-android.zip" ./*

# remove uncompressed directory
cd "$DIR"
rm -rf "$DIR_RELEASE"
