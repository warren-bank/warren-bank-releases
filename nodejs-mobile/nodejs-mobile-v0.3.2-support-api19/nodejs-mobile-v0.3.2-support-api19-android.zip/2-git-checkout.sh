#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

cd "${DIR}/nodejs-mobile"

git rm -rf .
git checkout -f 'v0.3.2-support-api19'
