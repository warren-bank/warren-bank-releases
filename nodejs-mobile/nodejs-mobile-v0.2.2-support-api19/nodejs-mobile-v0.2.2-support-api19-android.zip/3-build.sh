#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DIR_NDK=~/bin/android-ndk-r21b

cd "${DIR}/nodejs-mobile"

./tools/android_build.sh "$DIR_NDK"
