#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

sudo apt-get update
sudo apt-get install -y build-essential git python
sudo apt-get install -y curl unzip

# https://github.com/JaneaSystems/nodejs-mobile/issues/207
sudo apt-get install gcc-multilib g++-multilib

# install ndk (if not already there)
DIR_NDK=~/bin/android-ndk-r21b
if [ ! -d "$DIR_NDK" ]; then
  cd $(dirname "$DIR_NDK")
  curl https://dl.google.com/android/repository/android-ndk-r21b-linux-x86_64.zip -o ndk.zip
  unzip ndk.zip
  rm -f ndk.zip
fi

# clone git repo (if not already there)
DIR_REPO="${DIR}/nodejs-mobile"
if [ ! -d "$DIR_REPO" ]; then
  cd "$DIR"
  git clone 'https://github.com/warren-bank/nodejs-mobile.git'
fi
