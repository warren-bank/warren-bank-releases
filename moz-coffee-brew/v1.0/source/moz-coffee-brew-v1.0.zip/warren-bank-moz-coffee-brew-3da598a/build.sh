zip -r CoffeeBrew.xpi chrome.manifest install.rdf LICENSE README.md chrome components defaults
