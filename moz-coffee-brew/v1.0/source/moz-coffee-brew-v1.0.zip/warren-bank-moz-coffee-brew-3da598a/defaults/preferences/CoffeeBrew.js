pref('extensions.CoffeeBrew.syntax_highlighter.enabled', true);
pref('extensions.CoffeeBrew.syntax_highlighter.theme', 'solarized_dark');
