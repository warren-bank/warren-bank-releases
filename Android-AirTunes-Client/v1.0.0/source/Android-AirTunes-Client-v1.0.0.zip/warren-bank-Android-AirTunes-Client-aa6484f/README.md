# [Peeler](https://github.com/warren-bank/Android-AirTunes-Client)
> <small>forked from: <a href="https://github.com/danielcavanagh/peeler/tree/12dbbc448ea64bb708d220707484ec04ec661387">danielcavanagh/peeler v1.0</a></small>

AirTunes (version 1) client for Android

- - - -

#### Legal:

* copyright: [Daniel Cavanagh](https://github.com/danielcavanagh)
* license: [MIT](https://github.com/danielcavanagh/peeler/blob/12dbbc448ea64bb708d220707484ec04ec661387/LICENSE)
