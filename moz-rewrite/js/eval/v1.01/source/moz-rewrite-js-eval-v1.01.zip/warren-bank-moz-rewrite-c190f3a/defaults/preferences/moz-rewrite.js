pref("extensions.Moz-Rewrite.request.enabled",true);
pref("extensions.Moz-Rewrite.request.rules_file.path","");
pref("extensions.Moz-Rewrite.request.rules_file.watch_interval",0);

pref("extensions.Moz-Rewrite.response.enabled",true);
pref("extensions.Moz-Rewrite.response.rules_file.path","");
pref("extensions.Moz-Rewrite.response.rules_file.watch_interval",0);

pref("extensions.Moz-Rewrite.debug",false);
pref("extensions.Moz-Rewrite.log_file.path","");
