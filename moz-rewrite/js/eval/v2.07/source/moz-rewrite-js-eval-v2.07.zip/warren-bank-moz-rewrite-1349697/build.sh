zip -r moz-rewrite.xpi chrome.manifest install.rdf LICENSE README.md chrome components defaults
