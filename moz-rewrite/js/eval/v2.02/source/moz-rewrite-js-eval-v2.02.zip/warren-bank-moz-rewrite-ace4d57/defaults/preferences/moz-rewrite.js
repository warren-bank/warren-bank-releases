pref("extensions.Moz-Rewrite.debug",false);

pref("extensions.Moz-Rewrite.request.enabled",true);
pref("extensions.Moz-Rewrite.request.rules_file.path","");
pref("extensions.Moz-Rewrite.request.rules_file.watch_interval",0);

pref("extensions.Moz-Rewrite.response.enabled",true);
pref("extensions.Moz-Rewrite.response.rules_file.path","");
pref("extensions.Moz-Rewrite.response.rules_file.watch_interval",0);

pref("extensions.Moz-Rewrite.request_persistence.enabled",false);
pref("extensions.Moz-Rewrite.request_persistence.save_file.path","");
pref("extensions.Moz-Rewrite.request_persistence.save_file.maximum_capacity",10);
pref("extensions.Moz-Rewrite.request_persistence.replay.download_directory.path","{DfltDwnld}");
pref("extensions.Moz-Rewrite.request_persistence.replay.run.wget.executable_file.path","/usr/bin/wget");
pref("extensions.Moz-Rewrite.request_persistence.replay.run.wget.options","-c -nd --content-disposition --no-http-keep-alive --no-check-certificate -e robots=off --progress=dot:binary");
