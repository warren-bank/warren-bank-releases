zip -r moz-rewrite-js.xpi chrome.manifest install.rdf LICENSE README.md chrome components defaults
