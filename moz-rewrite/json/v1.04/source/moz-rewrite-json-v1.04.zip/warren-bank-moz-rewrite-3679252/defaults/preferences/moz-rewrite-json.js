pref("extensions.Moz-Rewrite-JSON.request.enabled",true);
pref("extensions.Moz-Rewrite-JSON.request.rules_file.path","");
pref("extensions.Moz-Rewrite-JSON.request.rules_file.watch_interval",0);

pref("extensions.Moz-Rewrite-JSON.response.enabled",true);
pref("extensions.Moz-Rewrite-JSON.response.rules_file.path","");
pref("extensions.Moz-Rewrite-JSON.response.rules_file.watch_interval",0);

pref("extensions.Moz-Rewrite-JSON.debug",false);
