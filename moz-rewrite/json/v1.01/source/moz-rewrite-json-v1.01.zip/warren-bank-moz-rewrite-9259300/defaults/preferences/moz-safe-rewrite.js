pref("extensions.Moz-Safe-Rewrite.request.enabled",true);
pref("extensions.Moz-Safe-Rewrite.request.rules_file.path","");
pref("extensions.Moz-Safe-Rewrite.request.rules_file.watch_interval",0);

pref("extensions.Moz-Safe-Rewrite.response.enabled",true);
pref("extensions.Moz-Safe-Rewrite.response.rules_file.path","");
pref("extensions.Moz-Safe-Rewrite.response.rules_file.watch_interval",0);

pref("extensions.Moz-Safe-Rewrite.debug",false);
