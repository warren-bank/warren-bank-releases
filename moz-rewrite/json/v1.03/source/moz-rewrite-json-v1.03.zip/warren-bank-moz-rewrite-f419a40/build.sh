zip -r rewrite-http-headers.xpi chrome.manifest install.rdf LICENSE README.md chrome components defaults
