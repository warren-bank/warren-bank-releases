//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VirtualDesktop.rc
//
#define IDD_DLG_OPTION                  101
#define IDI_VD1                         102
#define IDI_VD2                         103
#define IDI_VD3                         104
#define IDI_VD4                         105
#define IDI_VD5                         106
#define IDI_VD6                         107
#define IDI_VD7                         108
#define IDI_VD8                         109
#define IDR_MENU_TRAY                   111
#define IDD_DLG_ARRANGE                 112
#define IDR_MENU_ARRANGE                113
#define IDC_CHECK_ENABLE                1000
#define IDC_EDIT_COUNT                  1001
#define IDC_EDIT_D1                     1002
#define IDC_EDIT_D2                     1003
#define IDC_EDIT_D3                     1004
#define IDC_EDIT_D4                     1005
#define IDC_EDIT_D5                     1006
#define IDC_EDIT_D6                     1007
#define IDC_EDIT_D7                     1008
#define IDC_EDIT_D8                     1009
#define IDC_CHECK_TRAY                  1010
#define IDC_TAB_VD                      1011
#define ID_SETACTIVE                    1012
#define IDC_LIST_VDITEM                 1014
#define ID_OPTION                       40001
#define ID_HIDETRAY                     40002
#define ID_LIST                         40003
#define ID_ARRANGE                      40004
#define ID_DISABLE                      40005
#define ID_ST_ALLVD                     40006
#define ID_VDLIST                       40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
