//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CDControl.rc
//
#define IDD_CDC                         101
#define IDC_CHK_AUTOCLOSE               1000
#define IDC_COMBO_TIME                  1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
