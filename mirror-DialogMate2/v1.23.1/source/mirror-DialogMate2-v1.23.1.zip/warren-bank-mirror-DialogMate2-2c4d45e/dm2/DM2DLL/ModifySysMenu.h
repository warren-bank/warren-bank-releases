BOOL CALLBACK ModifyWndCaptionMenuCallback(HWND hwnd, LPARAM lParam);
void ModifyWndCaptionMenu(HWND hwnd, BOOL modify);