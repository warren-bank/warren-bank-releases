extern LRESULT CALLBACK MouseHookProc(int code, WPARAM wParam, LPARAM lParam);
extern LRESULT CALLBACK ProcMenuRetHookProc(int code, WPARAM wParam, LPARAM lParam);
extern LRESULT CALLBACK GetMsgHookProc(int code, WPARAM wParam, LPARAM lParam);
extern LRESULT CALLBACK dlgHookProc(int code, WPARAM wParam, LPARAM lParam);
