
extern LRESULT WINAPI DM2WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
void AdjustWindowOpacity(HWND, BOOL, int);
void UpdataToolTip();
void DetectCloseWindow();
