package black.android.content;


import top.niunaijun.blackreflection.annotation.BClassName;

@BClassName("android.content.IContentProvider")
public interface IContentProvider {
}
