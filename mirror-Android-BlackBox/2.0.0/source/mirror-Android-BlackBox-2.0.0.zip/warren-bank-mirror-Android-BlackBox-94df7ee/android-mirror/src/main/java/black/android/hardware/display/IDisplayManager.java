package black.android.hardware.display;


import top.niunaijun.blackreflection.annotation.BClassName;

@BClassName("android.hardware.display.IDisplayManager")
public interface IDisplayManager {
}
