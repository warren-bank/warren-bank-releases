//
// Created by Milk on 2020/8/18.
//

#ifndef SPEED_HEXDUMP_H
#define SPEED_HEXDUMP_H


class HexDump {

};
void HexDump(char *buf, int len, int addr);

#endif //SPEED_HEXDUMP_H
