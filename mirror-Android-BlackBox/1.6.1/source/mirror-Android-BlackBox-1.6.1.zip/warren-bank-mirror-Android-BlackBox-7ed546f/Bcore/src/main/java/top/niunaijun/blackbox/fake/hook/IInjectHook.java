package top.niunaijun.blackbox.fake.hook;

/**
 * Created by Milk on 3/30/21.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * 此处无Bug
 */
public interface IInjectHook {
    void injectHook();

    boolean isBadEnv();
}
