package black.android.app;

import android.os.IBinder;

import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BConstructor;

@BClassName("android.app.PendingIntent")
public interface PendingIntentO {
    @BConstructor
    PendingIntentO _new(IBinder IBinder0, Object Object1);
}
