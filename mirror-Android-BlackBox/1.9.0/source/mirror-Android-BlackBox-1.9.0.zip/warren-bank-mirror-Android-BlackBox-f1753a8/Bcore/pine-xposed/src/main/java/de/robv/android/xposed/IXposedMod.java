package de.robv.android.xposed;

/** Marker interface for Xposed modules. Cannot be implemented directly. */
/* package */ public interface IXposedMod {}
