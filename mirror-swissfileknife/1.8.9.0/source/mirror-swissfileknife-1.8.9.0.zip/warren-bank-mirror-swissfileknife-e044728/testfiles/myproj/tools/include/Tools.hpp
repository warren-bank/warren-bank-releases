// general tool functions 
