// the myproj config 
