
#ifndef SFK_JUST_OSE

#define USE_DCACHE
#define USE_SFT
#define REDUCE_CACHE_FILE_NAMES

#if !defined(VER_STR_OS) && defined(_WIN32)
 #define _WIN32_WINNT 0x0400 // for copyFileEx
#endif

#include "sfkbase.hpp"

#define SFKMATCH_IMPORTED
#include "sfkmatch.hpp"

// in case of linking problems concerning libsocket etc.,
// you may out-comment this to compile without tcp support:
#ifndef USE_SFK_BASE
 #define WITH_TCP
 #define SFK_FTP_TIMEOUT "30" // seconds, as string
#endif // USE_SFK_BASE

// just close on a socket is not enough.
// myclosesocket also does the shutdown().
#define closesocket myclosesocket

#ifdef _WIN32
 #ifdef SFK_MEMTRACE
  #define  MEMDEB_JUST_DECLARE
  #include "memdeb.cpp"
 #endif
#endif

#include "sfkext.hpp"

#ifndef SO_REUSEPORT
 #define SO_REUSEPORT 15
#endif

extern struct CommandStats gs;
extern struct CommandStats cs;

extern int nGlblFunc;

extern unsigned char abBuf[MAX_ABBUF_SIZE+100];

int perr(const char *pszFormat, ...);
int pwarn(const char *pszFormat, ...);
int pinf(const char *pszFormat, ...);
int printx(const char *pszFormat, ...);
int esys(const char *pszContext, const char *pszFormat, ...);
int myfseek(FILE *f, num nOffset, int nOrigin);
bool endsWithExt(char *pname, char *pszextin);
int copyFile(char *pszSrc, char *pszDst, char *pszShDst, uchar *pWorkBuf, num nBufSize, uint nflags);
bool endsWithArcExt(char *pname, int iTraceFrom);
extern cchar *arcExtList[];
void tellMemLimitInfo();
int quietMode();
char *getHTTPUserAgent();
int createOutDirTree(char *pszOutFile);
size_t myfwrite(uchar *pBuf, size_t nBytes, FILE *fout, num nMaxInfo=0, num nCur=0, SFKMD5 *pmd5=0);
int getTwoDigitHex(char *psz);
int sfkmemcmp2(uchar *psrc1, uchar *psrc2, num nlen, bool bGlobalCase, uchar *pFlags);
void myfgets_init    ( );
int myfgets         (char *pszOutBuf, int nOutBufLen, FILE *fin, bool *rpBinary=0, char *pAttrBuf=0);
extern char *ipAsString(struct sockaddr_in *pAddr, char *pszBuffer, int iBufferSize, uint uiFlags=0);
int encode64(uchar *psrc, int nsrc, uchar *pdst, int nmaxdst, int nlinechars);
void printCopyCompleted(char *pszName, uint nflags);
FILE *myfopen(char *pszName, cchar *pszMode);
void myfclose(FILE *f);
void setTextColor(int n, bool bStdErr=0, bool bVerbose=0);
bool endsWithColon(char *pszPath);
int getFileMD5NoCache(char *pszFile, uchar *abOut16, bool bSilent);
char *relName(char *pszRoot, char *pszAbs);
int cloneAttributes(char *pszSrc, char *pszDst, int nTraceLine);
bool isAbsolutePath(char *psz1);
bool equalFileContent(char *pszFile1, char *pszFile2, uchar *psrcmd5=0, uchar *pdstmd5=0);
bool canWriteFile(char *pszName, bool bTryCreate);
int setWriteEnabled(char *pszFile);
num getFileAge(char *pszName);
int getFileMD5(char *pszFile, SFKMD5 &md5, bool bSilent=0, bool bInfoCycle=0);
int getFileMD5(char *pszFile, uchar *abOut16);
void oprintf(cchar *pszFormat, ...);
void oprintf(StringPipe *pOutData, cchar *pszFormat, ...);
int copyFromFormText(char *pSrc, int iMaxSrc, char *pDstIn, int iMaxDst, uint nflags=0);
bool iseol(char c);

extern bool bGlblEscape;
extern num  nGlblMemLimit;
extern num  nGlblBytes;
extern int nGlblActiveFileAgeLimit;

extern bool bGlblGrepLineNum    ;
extern bool bGlblHtml           ;
extern bool bGlblAllowAllPlusPosFile;
extern char *pszGlblSinceDir    ;
extern bool bGlblSinceDirIncRef ;
extern int nGlblMissingRefDirs  ;
extern int nGlblMatchingRefDirs ;
extern int nGlblSinceMode       ;
extern bool bGlblIgnoreTime     ;
extern bool bGlblIgnore3600     ;
extern bool bGlblHexDumpWide    ;
extern int nGlblHexDumpForm     ;
extern num  nGlblHexDumpOff     ;
extern num  nGlblHexDumpLen     ;
extern char  *pszGlblCopySrc    ;
extern char  *pszGlblCopyDst    ;
extern uchar *pGlblWorkBuf      ;
extern num    nGlblWorkBufSize  ;
extern int   nGlblCopyStyle     ;
extern int   nGlblCopyShadows   ;
extern num   nGlblShadowSizeLimit;
extern bool  bGlblUseCopyCache  ;
extern bool  bGlblShowSyncDiff  ;
extern bool  bGlblHavePlusDirMasks;
extern num   nGlblMemLimit      ;
extern bool  bGlblMemLimitWasSet ;
extern bool  bGlblNoMemCheck     ;
extern bool  bGlblSFKCreateFiles ;
extern char  *pGlblCurrentScript ;

extern bool bGlblUseColor      ;
extern bool bGlblUseHelpColor  ;
extern int nGlblHeadColor      ;
extern int nGlblExampColor     ;
extern int nGlblFileColor      ;
extern int nGlblLinkColor      ;
extern int nGlblHitColor       ;
extern int nGlblRepColor       ;
extern int nGlblErrColor       ;
extern int nGlblWarnColor      ;
extern int nGlblPreColor       ;
extern int nGlblTimeColor      ;
extern int nGlblTraceIncColor  ;
extern int nGlblTraceExcColor  ;

extern char szLineBuf[MAX_LINE_LEN+10];
extern char szLineBuf2[MAX_LINE_LEN+10];
extern char szLineBuf3[MAX_LINE_LEN+10];
extern char szAttrBuf[MAX_LINE_LEN+10];
extern char szAttrBuf2[MAX_LINE_LEN+10];
extern char szAttrBuf3[MAX_LINE_LEN+10];
extern char szRefNameBuf[MAX_LINE_LEN+10];
extern char szRefNameBuf2[MAX_LINE_LEN+10];

// internal
int iGlblWebCnt=0;
FILE *fGlblWebDump=0;

KeyMap glblSFKVar;

struct SFKVarHead {
   int iDataLen;
};

bool sfkhavevars( )
{
   return glblSFKVar.size() ? 1 : 0;
}

int sfksetvar(char *pname, uchar *pdata, int idata)
{
   for (char *psz=pname; *psz; psz++)
   {
      if (isalpha(*psz))
         continue;
      if (isdigit(*psz)!=0 && psz>pname)
         continue;
      if (*psz=='_' && psz>pname)
         continue;

      perr("invalid variable name: %s",pname);
      pinf("must start with a-z, then a-z0-9_\n");
      return 9;
   }

   if (cs.debug) {
      if (memchr(pdata, 0, idata))
         printf("[setvar %s = (binary)]\n",pname);
      else
         printf("[setvar %s = %.*s]\n",pname,idata,(char*)pdata);
   }

   struct SFKVarHead ohead;
   int iHeadSize = sizeof(struct SFKVarHead);

   uchar *pcopy = new uchar[iHeadSize+idata+1];
   if (!pcopy)
      return 9+perr("outofmem");

   ohead.iDataLen = idata;
   memcpy(pcopy, &ohead, iHeadSize);

   memcpy(pcopy+iHeadSize, pdata, idata);
   pcopy[iHeadSize+idata] = '\0'; // safety

   uchar *pold = (uchar*)glblSFKVar.get(pname);
   if (pold)
      delete [] pold;

   glblSFKVar.put(pname, pcopy);

   return 0;
}

uchar *sfkgetvar(char *pname, int *plen)
{
   struct SFKVarHead ohead;
   int iHeadSize = sizeof(struct SFKVarHead);

   // sfk1813: env variable access
   if (!strncmp(pname, "env.", 4) && pname[4]) 
   {
      char *psz = getenv(pname+4);
      if (!psz)
         return 0;
      if (plen)
         *plen = strlen(psz);
      return (uchar*)psz;
   }

   uchar *pres = (uchar*)glblSFKVar.get(pname);

   if (!pres) {
      if (cs.debug)
         printf("[getvar %s finds nothing]\n",pname);
      return 0;
   }

   memcpy(&ohead, pres, iHeadSize);

   pres += iHeadSize;

   if (plen)
      *plen = ohead.iDataLen;

   if (cs.debug)
      printf("[getvar %s returns %d bytes]\n",pname,ohead.iDataLen);

   return pres;
}

uchar *sfkgetvar(int i, char **ppname, int *plen)
{
   struct SFKVarHead ohead;
   int iHeadSize = sizeof(struct SFKVarHead);

   uchar *pres = (uchar*)glblSFKVar.iget(i, ppname);
   if (!pres)
      return 0;

   memcpy(&ohead, pres, iHeadSize);

   pres += iHeadSize;

   if (plen)
      *plen = ohead.iDataLen;

   return pres;
}

void sfkfreevars()
{
   for (int i=0; i<glblSFKVar.size(); i++)
   {
      uchar *pold = (uchar*)glblSFKVar.iget(i);
      if (pold)
         delete [] pold;
   }
   glblSFKVar.reset();
}

#ifndef USE_SFK_BASE
UDPIO sfkNetIO;
UDPIO sfkNetSrc;
#endif // USE_SFK_BASE

#ifdef _WIN32
char *winSysError()
{
   static CHAR szPrintBuffer[512];

   LPVOID lpvMessageBuffer;
 
   FormatMessage(
          FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM,
          NULL, GetLastError(),
          MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
          (LPTSTR)&lpvMessageBuffer, 0, NULL);
 
   wsprintf(szPrintBuffer, " (%d, %s)", GetLastError(), (char *)lpvMessageBuffer);
 
   LocalFree(lpvMessageBuffer);

   return szPrintBuffer;
}
#endif

#ifdef VFILEBASE

// vfile processing caches
CoiMap glblVCache;      // downloaded zip's cache
ConCache glblConCache;  // ftp and http connection cache

#define COI_CAPABILITY_NET (1UL<<0)
uint nGlblCoiConfig = 0xFFFFUL;

class DiskCacheConfig {
public:
   DiskCacheConfig ( );

   char *getPath   ( );
   int  setPath   (char *ppath);

   bool  getActive ( );
   void  setActive (bool byesno);

   char szPath[SFK_MAX_PATH+10];
   bool bactive;
};

DiskCacheConfig::DiskCacheConfig() 
{
   memset(this, 0, sizeof(*this));
   // is active by default,
   // but TEMP will be accessed on demand.
   bactive = 1;
}

// guarantees non-void pointer
char *DiskCacheConfig::getPath( ) 
{
   if (szPath[0]) return szPath;

   char *ptmp = getenv("TEMP");

   if (!ptmp)
         ptmp = getenv("TMP");

   if (!ptmp) {
      bactive = 0;
      static bool btold1 = 0;
      if (!btold1) {
         btold1 = 1;
         if (infoAllowed())
            pinf("cannot cache to disk: no TEMP variable found.\n"); 
      }
      return szPath; // i.e. return empty
   }

   // set: "c:\temp\00-sfk-cache\"
   snprintf(szPath, sizeof(szPath)-10, "%s%c00-sfk-cache", ptmp, glblPathChar);

   /*
   static bool bFirstCall = 1;
   if (bFirstCall) {
      bFirstCall = 0;
      if (infoAllowed())
         pinf("using cache %s\n", szPath);
   }
   */

   return szPath;
}

int DiskCacheConfig::setPath(char *ppath)
{
   strcopy(szPath, ppath);

   char szSubName[100];
   sprintf(szSubName, "%c00-sfk-cache", glblPathChar);
   int nsublen = strlen(szSubName);

   // always force "00-sfk-cache" as subdir:
   int nlen = strlen(szPath);
   if (nlen >= nsublen && !strcmp(szPath+nlen-nsublen, szSubName))
      return 0;

   if (nlen > 0 && szPath[nlen-1] == '/' ) szPath[nlen-1] = '\0';
   if (nlen > 0 && szPath[nlen-1] == '\\') szPath[nlen-1] = '\0';

   nlen = strlen(szPath);
   int nrem = (sizeof(szPath)-10)-nlen;
   if (nrem < nsublen)
      return 9+perr("cache path too long: %s", ppath); 

   strcat(szPath, szSubName);

   return 0;
}

void DiskCacheConfig::setActive(bool byesno) { bactive = byesno; }
bool DiskCacheConfig::getActive( ) { return bactive; }

DiskCacheConfig glblDiskCache;

// optional query callback on first download
bool (*pGlblDiskCacheAskSave)() = 0;

void  setDiskCacheActive(bool b) { glblDiskCache.setActive(b); }
bool  getDiskCacheActive( )      { return glblDiskCache.getActive(); }
void  setDiskCachePath(char *p)  { glblDiskCache.setPath(p); }
// guarantees non-void pointer: on error, path is "".
char *getDiskCachePath( )        { return glblDiskCache.getPath(); }

CoiMap::CoiMap( ) 
{
   #ifdef USE_DCACHE_EXT
   nClDAlloc   = 0;
   nClDUsed    = 0;
   apClDMeta   = 0;
   apClDFifo   = 0;
   #endif // USE_DCACHE_EXT

   nClByteSize = 0;
   nClBytesMax = 0;
   nClDropped  = 0;

   reset(0, "ct");
}

CoiMap::~CoiMap( ) {
   reset(0, "dt");
}

void CoiMap::reset(bool bWithDiskCache, const char *pszFromInfo)
{__
   mtklog(("CoiMap-reset diskcache=%d from %s", bWithDiskCache, pszFromInfo));

   // delete all clFifo entries
   ListEntry *pcur  = clFifo.first();
   ListEntry *pnext = 0;
   for (;pcur; pcur=pnext)
   {
      Coi *pcoi = (Coi *)pcur->data;
      if (pcoi->refcnt() > 1) { // 1: managed only by us
         if (!bGlblEscape) {
            pinf("cannot drop cache entry with %d refs: %s (%p)\n", pcoi->refcnt(), pcoi->name(), pcoi);
         }
      } else {
         nClByteSize -= pcoi->getUsedBytes();
         pcoi->decref();
         delete pcoi;
      }
      pnext = pcur->next();
      delete pcur;
   }
   // is now ready for flat reset
   clFifo.reset();

   extern int (*pGlblSFKStatusCallBack)(int nMsgType, char *pmsg);

   KeyMap::reset();
   if (nClByteSize != 0) {
      // TODO: so far, the bytesize is just an approximate value.
      nClByteSize = 0;
   } 

   #ifdef USE_DCACHE_EXT
   if (bWithDiskCache)
   {
      mtklog(("dcache.release alloc=%d used=%d",nClDAlloc,nClDUsed));
      if (apClDMeta) { delete [] apClDMeta; apClDMeta = 0; }
      if (apClDFifo) { delete [] apClDFifo; apClDFifo = 0; }
      nClDAlloc = 0;
      nClDUsed  = 0;
   }
   #endif // USE_DCACHE_EXT
}

int CoiMap::tellByteSizeChange(Coi *pcoi, num nOldSize, num nNewSize)
{
   if (!pcoi || !pcoi->bClInCache) return 9;

   nClByteSize += (nNewSize - nOldSize);

   if (nClByteSize > nClBytesMax)
       nClBytesMax = nClByteSize;

   return 0;
}

num CoiMap::byteSize(bool bCalcFromList)
{
   if (!bCalcFromList)
      return nClByteSize;

   // expensive recalc:
   int nelem  = size();
   num  nbytes = 0;
   for (int i=0; i<nelem; i++) {
      Coi *pcoi = (Coi*)iget(i);
      if (!pcoi) { perr("int. #108281302"); break; }
      if (pcoi->hasData())
         nbytes += pcoi->getUsedBytes();
   }
   return nbytes;
}

num CoiMap::bytesMax( )     { return nClBytesMax; }
num CoiMap::filesDropped( ) { return nClDropped; }

int CoiMap::put(char *pkey, Coi *pcoi, const char *pTraceFrom, int nmode)
{__
   if (!pkey) return 9+perr("int. #208290634");
   if (!pcoi) return 9+perr("int. #208290635");

   bool bSkipDiskCache = (nmode & 1) ? 1 : 0;

   mtklog(("cache: put %s from=%s coiname=%s", pkey, pTraceFrom, pcoi->name()));

   if (pcoi->bClInCache)
      return 1+pwarn("cache-put twice, ignoring: %s", pkey);

   num nAddSize = pcoi->getUsedBytes();

   // drop cache entries due to memlimit?
   while (nClByteSize + nAddSize > nGlblMemLimit)
   {
      // drop first entry with refcnt == 1.
      // scan first 1000 cache entries, then bail out.
      // list is CHANGED below, therefore have always to re-run from start.
      ListEntry *plx = clFifo.first();
      int nbail = 1000;
      for (; plx; plx = plx->next()) {
         Coi *pxcoi = (Coi*)plx->data;
         if (pxcoi && pxcoi->refcnt() <= 1) break;
         if (nbail-- <= 0) break;
      }

      if (!plx) {
         bool btold = 0;
         if (!btold) { btold = 1;
            pwarn("cache overflow (%d), try to increase -memlimit (current=%d).\n", (int)size(), (int)(nGlblMemLimit/1000000));
         }
      }
      else 
      {
         Coi *pxcoi = (Coi*)plx->data;
         if (!pxcoi) break;
   
         char *pxkey = pxcoi->name();
         // int nkeylen = strlen(pxkey);
   
         if (!quietMode()) 
         {
            char szAddInfo[100];
            snprintf(szAddInfo, sizeof(szAddInfo)-10, "%u files %u mb", size(), (uint)(nClByteSize/1000000UL));
            info.setAddInfoWidth(strlen(szAddInfo));
            info.setStatus("free", pxkey, szAddInfo, eKeepAdd);
            // pinf("cache-drop: %d %d %.50s\n", ndropmb, ncachmb, pxinfo);
         }
   
         mtklog(("cache-drop: %s", pxkey));
   
         // successful remove will DELETE pxcoi AND pxkey!
         if (remove(pxkey))
            { perr("int. #258282159 on cache drop"); break; }

         nClDropped++;
      }
   }

   // overwriting an existing cache entry?
   if (KeyMap::isset(pkey)) {
      // CoiMap::remove takes care of references
      mtklog(("cache-drop: %s (existing)", pkey));
      remove(pkey);
      nClDropped++;
   }

   int nrc = KeyMap::put(pkey, pcoi);
   if (!nrc) {
      // base put ok, add also in fifo list
      ListEntry *pentry = new ListEntry();
      pentry->data = pcoi;
      clFifo.add(pentry);
   }

   // INCREMENT THE REFCNT.
   pcoi->incref("cput");

   pcoi->bClInCache = 1;

   nClByteSize += pcoi->getUsedBytes();

   if (nClByteSize > nClBytesMax)
       nClBytesMax = nClByteSize;

   #ifdef USE_DCACHE
   // cache only net files
   if (   !bSkipDiskCache && pcoi->isNet()
       && pcoi->isKnownArc() && !pcoi->isZipSubEntry()
       && pcoi->hasContent()
      )
   {
      // no matter if active or not, if this is set
      if (pGlblDiskCacheAskSave)
      {
         // then ask back on first download
         bool nrc = pGlblDiskCacheAskSave();
         glblDiskCache.setActive(nrc);
         pGlblDiskCacheAskSave = 0;
      }

      if (glblDiskCache.getActive()) {
         putDiskCache(pkey, pcoi, pTraceFrom);
      } else {
         mtklog(("cache-put : no disk caching (active=%d cont=%d)", glblDiskCache.bactive, pcoi->hasContent()));
      }
   }
   else
   {
      mtklog(("cache-put: skip disk, bskip=%d isnet=%d isarc=%d issub=%d cont=%d",
         bSkipDiskCache, pcoi->isNet(), pcoi->isKnownArc(),
         pcoi->isZipSubEntry(), pcoi->hasContent()
         ));
   }
   #endif // USE_DCACHE

   return nrc;
}

int md5FromString(char *psz, num &rsumhi, num &rsumlo)
{
   SFKMD5 md5;
   md5.update((uchar*)psz, strlen(psz));
   uchar *pdig = md5.digest();
   num nlo=0, nhi=0;
   memcpy(&nhi, pdig+0, 8);
   memcpy(&nlo, pdig+8, 8);
   rsumhi = nhi;
   rsumlo = nlo;
   return 0;
}

#ifdef USE_DCACHE
char *Coi::cacheName(char *pnamein, char *pbuf, int nmaxbuf, int *pDirPartLen)
{__
   char *prel = pnamein;

   // only cache net files to disk.
   cchar *pprot = "";
   if (strBegins(prel, "http://"))
      { pprot="http"; prel += strlen("http://"); }
   else
   if (strBegins(prel, "https://"))
      { pprot="https"; prel += strlen("https://"); }
   else
   if (strBegins(prel, "ftp://"))
      { pprot="ftp"; prel += strlen("ftp://"); }
   else {
      // local file: do NOT cache to disk
      return 0;
   }

   //  in: http://foo.com/sub/dir/get.php?a=1&b=5&sess=c9352ff7
   // out: c:\temp\00-sfk-cache\foo.com\subdirget.phpa1b5sessc9352ff7
   char *pCacheDir = glblDiskCache.getPath();
   if (!pCacheDir) return 0; // error was told

   if (nmaxbuf < 100) {
      static bool btold2 = 0;
      if (!btold2) { btold2=1; pwarn("cannot cache to disk: name buffer too small.\n"); }
      return 0;
   }

   nmaxbuf -= 10; // safety

   // add: "c:\temp\00-sfk-cache" and "\"
   mystrcopy(pbuf, pCacheDir, nmaxbuf);
   strcat(pbuf, glblPathStr);

   // also add protocol to allow rebuild of url
   strcat(pbuf, pprot);
   strcat(pbuf, glblPathStr);

   char *pdst = pbuf + strlen(pbuf);
   int  nrem = nmaxbuf - strlen(pbuf);

   if (pDirPartLen) *pDirPartLen = strlen(pbuf);

   // prel: foo.com/sub/dir/get.php?a=1&b=5&sess=c9352ff7
   char *prel2 = strchr(prel, '/');
   if (!prel2) return 0; // wrong name format
   int ndomlen = prel2 - prel;
   prel2++;

   // prel2: sub/dir/get.php?a=1&b=5&sess=c9352ff7
   // add: "foo.com\"
   if (ndomlen >= nrem) {
      pwarn("cannot cache to disk, name too long: %s\n", pnamein); 
      return 0;
   }
   memcpy(pdst, prel, ndomlen);
   pdst += ndomlen; nrem -= ndomlen;
   *pdst++ = glblPathChar; nrem--;
   *pdst = '\0';

   // convert and add rest of url.
   // be very careful on name reductions,
   // to avoid mixup with archive sub entries
   // when retrieving stuff from the cache later.

   // http: $-_.+!*'(),
   char szBuf[10];
   char *psrc = prel2;
   while (*psrc && (nrem > 0)) 
   {
      char c = *psrc++;
      if (isalnum(c))
         { *pdst++ = c; nrem--; continue; }

      #ifdef REDUCE_CACHE_FILE_NAMES
      // if finding ".zip?parm=..." then stop here.
      // but make sure ".zip\\" or ".zip//" is never stripped,
      // to avoid mixup with sub entries later.
      if (c == '.') 
      {
         // scan for the longest .tar.gz etc. extension.
         // arcExtList is sorted by reverse length.
         for (int i=0; arcExtList[i]; i++) 
         {
            if (!mystrnicmp(psrc-1, arcExtList[i], strlen(arcExtList[i]))) 
            {
               // an extension match is found, but how does it continue?
               int nextlen = strlen(arcExtList[i]);
               if (nextlen < 1) break; // safety
               char *pcont  = psrc - 1 + nextlen;

               // never strip sub archive identifiers
               if (!strncmp(pcont, "\\\\", 2)) continue;
               if (!strncmp(pcont, "//", 2))   continue;

               memcpy(pdst, arcExtList[i], nextlen);
               pdst[nextlen] = '\0';

               // EARLY EXIT: archive extension found
               mtklog(("cache: built aext name: %s", pbuf));
               return pbuf;
            }
         }
      }
      #endif

      switch (c) 
      {
         case '-': case '+': case '.': case '_':
            *pdst++ = c; nrem--; continue;

         // case '_':
         //    *pdst++ = '-'; nrem--; continue;

         // case '/':
         // case '\\':
         //    *pdst++ = '_'; nrem--; continue;
      }
      sprintf(szBuf, "%%%02X", (unsigned)c);
      *pdst++ = szBuf[0];
      *pdst++ = szBuf[1];
      *pdst++ = szBuf[2];
      nrem -= 3;
   }
   *pdst = '\0';

   if (nrem <= 0) {
      pwarn("cannot cache to disk, name too long: %s\n", pnamein); 
      return 0;
   }
   
   return pbuf;
}

// make sure coi has cached data before calling this
int CoiMap::putDiskCache(char *pkey, Coi *pcoi, const char *pTraceFrom)
{__
   char szCacheName[SFK_MAX_PATH+10];

   uchar *pdata = pcoi->data().src.data;
   num    nsize = pcoi->data().src.size;

   if (!pdata) return 9+perr("int. 35291439");

   // the coi may have been redirected. in that case,
   // the dstname is different from the srcname.
   char *psrcname = pkey;
   char *pdstname = pcoi->name();

   int  nCacheDirLen = 0;
   char *pszCacheName = Coi::cacheName(pdstname, szCacheName, SFK_MAX_PATH, &nCacheDirLen);
   if (!pszCacheName) return 0;

   if (createOutDirTree(pszCacheName))
      return 5+pwarn("cannot create caching dir for: %s", pszCacheName);

   if (infoAllowed())
      pinf("saving %s\n", pszCacheName);

   FILE *fout = fopen(pszCacheName, "wb");
   if (!fout)
      return 5+pwarn("cannot write cache file: %s", pszCacheName);

   mtklog(("cache: disk: write pdata=%p size=%d", pdata, (int)nsize));

   if (myfwrite(pdata, nsize, fout) != nsize) {
      fclose(fout);
      return 5+pwarn("failed to write cache file, probably disk full: %s", pszCacheName);
   }

   fclose(fout);

   // if the coi was redirected, also store the source info.
   if (strcmp(psrcname, pdstname))
   {
      pszCacheName = Coi::cacheName(psrcname, szCacheName, SFK_MAX_PATH, &nCacheDirLen);
      if (!pszCacheName) return 0;
   
      if (createOutDirTree(pszCacheName))
         return 5+pwarn("cannot create caching dir for: %s", pszCacheName);
   
      if (infoAllowed())
         pinf("saving %s\n", pszCacheName);
   
      FILE *fout = fopen(pszCacheName, "wb");
      if (!fout)
         return 5+pwarn("cannot write cache meta file: %s", pszCacheName);

      fprintf(fout, "[sfk-cache-redirect]\n%s\n", pdstname);
   
      fclose(fout);
   }

   mtklog(("cache: put on disk: %s (%s)", pkey, pszCacheName));

   return 0;
}
#endif // USE_DCACHE

#ifdef USE_DCACHE_EXT
// rc =0:found_and_index_set
// rc <0:insert_before_index
// rc >0:insert_after_index
int CoiMap::bfindDMeta(num nsumlo,num nsumhi,int &rindex)
{__
   // binary search for key, or insert position
   uint nbot=0,ndist=0,nhalf=0,imid=0;
   uint ntop=nClArrayUsed; // exclusive

   num   ntmphi=0,ntmplo=0;

   int    ncmp=-1;   // if empty, insert before index 0

   while (1)
   {
      if (nbot > ntop) // shouldn't happen
         { perr("int. 187281850"); ncmp=-1; break; }

      ndist = ntop - nbot;
      // mtklog(("dist %d bot %d top %d",ndist,nbot,ntop));
      if (ndist == 0) break; // nothing left
      nhalf = ndist >> 1;
      imid  = nbot + nhalf;

      ntmphi= apClDMeta[imid].sumhi;
      ntmplo= apClDMeta[imid].sumlo;

      // 128 bit comparison
      if (nsumhi < ntmphi) ncmp = -1;
      else
      if (nsumhi > ntmphi) ncmp =  1;
      else
      if (nsumlo < ntmplo) ncmp = -1;
      else
      if (nsumlo > ntmplo) ncmp =  1;
      else
         ncmp = 0;

      if (ncmp < 0) {
         // select lower half, if any
         // mtklog((" take lower %xh %xh %d",nval,ntmp,imid));
         if (ntop == imid) break; // safety
         ntop = imid;
      }
      else
      if (ncmp > 0) {
         // select upper half, if any
         // mtklog((" take upper %xh %xh %d",nval,ntmp,imid));
         if (nbot == imid+1) break; // required
         nbot = imid+1;
      } else {
         // straight match
         mtklog(("%d = indexof(%xh) used=%u",imid,(uint)nsumhi,nClDAlloc));
         break; // found
      }
   }

   rindex = imid;
   return ncmp;
}

int CoiMap::putDiskCache(char *pkey, Coi *pcoi)
{__
   int nfree = nClDAlloc - nClDUsed;
   if (nfree < 10) {
      // expand arrays: alloc new
      int nAllocNew = nClDAlloc + (nClDAlloc ? nClDAlloc : 100);
      DMetaEntry *pdnew = new DMetaEntry[nAllocNew+10];
      DFifoEntry *pfnew = new DFifoEntry[nAllocNew+10];
      if (nClDUsed) {
         memcpy(pdnew, apClDMeta, sizeof(DMetaEntry)*nClDUsed);
         memcpy(pfnew, apClDFifo, sizeof(DFifoEntry)*nClDUsed);
      }
      // then free old and swap
      delete [] apClDMeta;
      delete [] apClDFifo;
      apClDMeta = pdnew;
      apClDFifo = pfnew;
      nClDAlloc = nAllocNew;
      nfree = nClDAlloc - nClDUsed;
   }
   // put basic infos into (mem) cached meta data
   num nsumlo=0,nsumhi=0;
   md5FromString(pkey,nsumlo,nsumhi);

   // find insert position
   int nindex = 0;
   int nrc = bfindDMeta(nsumlo,nsumhi,nindex);
   if (!nrc) return 1;  // already in cache

   if (nrc < 0) {
      // insert before index
   } else {
      // insert after index
      nindex++;
   }
   int ntomove = nClDUsed - nindex;
   if (ntomove > 0)
      memmove(&apClDMeta[nindex+1], &apClDMeta[nindex+0],
         sizeof(DMetaEntry) * ntomove);
   // now, set at index
   DMetaEntry *pdmet = &apClDMeta[nindex];
   pdmet->sumhi = nsumhi;
   pdmet->sumlo = nsumlo;
   pdmet->size  = pcoi->getSize();
   pdmet->time  = pcoi->getTime();
   // append key entry to fifo
   DFifoEntry *pdfif = &apClDFifo[nClDUsed];
   pdfif->sumhi = nsumhi;
   pdfif->sumlo = nsumlo;
   // finally, count new entry
   nClDUsed++;
   mtklog("dcache.insert at %d of %d: sumlo=%s key=%s", nindex, nClDUsed,
      numtohex(nsumlo), pkey);
   return 0;
}
#endif // USE_DCACHE_EXT

// caller MUST release object after use!
Coi *CoiMap::get(char *pkey) 
{__
   Coi *pcoi = (Coi*)KeyMap::get(pkey);
   if (pcoi) {
      pcoi->incref("cget");
      mtklog(("cache: %p = cache.get( %s )",pcoi,pkey));
      return pcoi;
   }

   #ifdef USE_DCACHE

   // disk cache is yet used only for net files
   if (   !strBegins(pkey, "http://")
       && !strBegins(pkey, "https://") 
       && !strBegins(pkey, "ftp://"))
      return 0;

   // not yet in mem cache, but maybe in disk cache?
   if (!glblDiskCache.bactive) return 0;

   mtklog(("cache: cache.get( %s ) begin",pkey));

   char szCachePathBuf[SFK_MAX_PATH+10];
   char szCacheReDirBuf[SFK_MAX_PATH+10];
   char *pszDiskCacheFile = Coi::cacheName(pkey, szCachePathBuf, SFK_MAX_PATH, 0);

   if (!pszDiskCacheFile) {
      mtklog(("cache: no disk name: %s",pkey));
      return 0;
   }

   num nFileSize = getFileSize(pszDiskCacheFile);
   if (nFileSize < 0) {
      return 0;
   }

   // reject cache files beyond the memory limit
   if (nFileSize > nGlblMemLimit) {
      pinf("cache file too large, cannot load: %s\n", pszDiskCacheFile);
      return 0;
   }

   if (infoAllowed())
      pinf("using cache file %s\n", pszDiskCacheFile);

   // exists in disk cache: create a memory coi in mem cache.
   uchar *pdata = loadBinaryFile(pszDiskCacheFile, nFileSize);
   if (!pdata) {
      pinf("failed to load cache file: %s\n", pszDiskCacheFile);
      return 0;
   }

   mtklog(("cache: loaded, size=%d: %s",(int)nFileSize,pszDiskCacheFile));

   if (strBegins((char*)pdata, "[sfk-cache-redirect]"))
   {
      // have to load another file with actual content
      char *pdstname = (char*)pdata + strlen("[sfk-cache-redirect]");
      while (*pdstname && (*pdstname != '\n')) pdstname++;
      if (*pdstname) pdstname++;
      char *psz2 = pdstname;
      while (*psz2 && *psz2 != '\r' && *psz2 != '\n') psz2++;
      *psz2 = '\0';

      strcopy(szCacheReDirBuf, pdstname);
      pdstname = szCacheReDirBuf;

      // target name isolated, clear temporary:
      delete [] pdata; pdata = 0;
      // ptr will be reused immediately

      // now holding the virtual filename in pdstname (http://...)
      // build cache name from that.
      pszDiskCacheFile = Coi::cacheName(pdstname, szCachePathBuf, SFK_MAX_PATH, 0);
      if (!pszDiskCacheFile) {
         mtklog(("cache: no cache name for: %s", pdstname));
         return 0;
      }

      pinf("using cache file %s\n", pszDiskCacheFile);

      pdata = loadBinaryFile(pszDiskCacheFile, nFileSize);
      if (!pdata) {
         pinf("failed to load cache file: %s\n", pszDiskCacheFile);
         return 0;
      }

      mtklog(("cache: loaded redir, size=%d: %s",(int)nFileSize,pszDiskCacheFile));
   }

   // the cacheName function must make sure that keys for subentries
   // never return a cache file name pointing to the overall .zip.
   // i.e. if the name is reduced, reduction shall not strip sub infos,
   // otherwise we retrieve wrong data (and coi names) here.
   pcoi = new Coi(pszDiskCacheFile, 0);

   pcoi->setContent(pdata, nFileSize);

   mtklog(("cache: put entry: key=%s", pkey));
   mtklog(("cache: put entry: coi=%s", pcoi->name()));

   put(pkey, pcoi, "dcache", 1); // skipping disk cache write
   // TODO: what to do if memCachePut fails after diskCacheLoad?

   // put() sets the refcnt to 1.
   // but as get() was originally called,
   // we must return refcnt==2:
   pcoi->incref("cget2");

   #endif // USE_DCACHE

   return pcoi;
}

int CoiMap::remove(char *pkey) 
{
   // get coi, need it for fifo search
   // do NOT use CoiMap::get() as it increments the ref!
   Coi *pcoi = (Coi*)KeyMap::get(pkey);
   if (!pcoi) return 1; // not found

   // remove map entry
   int nrc = KeyMap::remove(pkey);

   // remove from fifo list as well
   ListEntry *plx = clFifo.first();
   for (;plx; plx=plx->next())
      if (plx->data == pcoi)
         break;

   // no list entry should NOT happen
   if (plx) {
      clFifo.remove(plx);
      delete plx;
      plx = 0; 
   } else {
      perr("int. 187282050");
   }

   // finally, delete the managed coi
   if (pcoi->refcnt() > 1) { // 1: managed only by us
      if (!bGlblEscape) {
         pinf("cannot drop cache entry with %d refs: %s", pcoi->refcnt(), pcoi->name());
      }
   }
   else 
   {
      nClByteSize -= pcoi->getUsedBytes();

      pcoi->bClInCache = 0;

      pcoi->decref();

      delete pcoi;
   }

   return nrc;
}

void setWebConfig(int iWhat, char *pszValue)
{
   int iValue = atoi(pszValue);

   switch (iWhat) 
   {
      case 1: 
         if (iValue < 200)
            return;
         gs.maxwebwait = cs.maxwebwait = atoi(pszValue);
         mtklog(("setWebConfig: timeout=%d", gs.maxwebwait));
         break;
      case 2: 
         if (iValue < 1)
            return;
         gs.maxwebsize = cs.maxwebsize = atoi(pszValue) * 1000000; 
         mtklog(("setWebConfig: limit=%d", (int)(gs.maxwebsize/1000000)));
         break;
      case 3: {
         char szBuf[200];
         char *pproxy = pszValue;
         strcopy(szBuf, pproxy);
         char *psz1 = szBuf;
         while (*psz1 && *psz1 != ':') psz1++;
         if (*psz1) *psz1++ = '\0';
         int nport = atol(psz1);
         if (!nport) nport = 80;
         TCPCore::setProxy(szBuf, nport);
         mtklog(("setWebConfig: proxy %s port %u",szBuf,nport));
      }
   }
}

bool TCPCore::bSysInitDone = 0;

ConAutoClose::ConAutoClose(TCPCore *pcore, TCPCon **ppcon, int nTraceLine) 
{
   nClTraceLine = nTraceLine;
   pClCore  =  pcore;
   ppClCon  = ppcon;
}

ConAutoClose::~ConAutoClose( ) {
   TCPCon *pcon = *ppClCon;
   if (pcon) {
      // closes con AND deletes the object
      pClCore->close(pcon);
      *ppClCon = 0;
   } else {
      perr("unexpected NULL ptr on ConAutoClose, line %d", nClTraceLine);
   }
}

ConCache::ConCache( ) {
}

ConCache::~ConCache( ) 
{
   // no uncontrolled cleanup on exit
   //    reset("cc");
}

void ConCache::closeConnections( ) 
{__
   // close all connections, but keep
   // the http/ftp clients available.
   void *praw=0;
   for (int i=0; i<size(); i++) {
      if ((praw = iget(i))) {
         TCPCore *pcore = (TCPCore *)praw;
         pcore->closeConnections();
      }
   }
}

// NOTE: so far to be called only at program end
//       as it can NOT close individual objects
//       while leaving others usable.
// NOTE: glblSFL (and others?) must be shutdown BEFORE this.
//       ~coi > ~coidata > releaseHttp > refcnt 0.
void ConCache::reset(bool bfinal, const char *pszFromInfo) 
{__
   mtklog(("ConCache-Reset size=%d from %s", size(), pszFromInfo));

   if (bfinal == 0) 
   {
      // not allowed as reset can only drop ALL objects
      perr("int. #216718\n");
      return;
   }

   int itry = 0;
   int isuc = 0;

   // does also closeConnections
   void *praw=0;
   for (int i=0; i<size(); i++)
   {
      if ((praw = iget(i))) 
      {
         TCPCore *pcore = (TCPCore *)praw;

         if (pcore->refcnt() > 0)
         {
            if (bfinal) {
               perr("found used tcpcon on exit: %d %p\n", pcore->refcnt(), pcore);
            } else {
               mtklog(("ConCache-Reset skips used=%d %p", pcore->refcnt(), pcore));
            }
            continue;
         }

         itry++;
         if (!closeAndDelete(praw))
            isuc++;
      }
   }

   // remove all invalid entries from keymap:
   KeyMap::reset();
   clFifo.reset();

   mtklog(("ConCache-Reset closed %d (tried %d)", isuc, itry));
}

int ConCache::closeAndDelete(void *praw)
{__
   // identify type of praw:
   TCPCore *pcore = (TCPCore *)praw;

   char *pszID = pcore->getID();

   if (pcore->refcnt() > 1) // 1: managed only by us
   {
      perr("connection in use, cannot close: %s %p %d", pszID, pcore, pcore->refcnt());
      return 9;
   }

   #ifdef USE_WEBCONCACHE
   if (strBegins(pszID, "http://") || strBegins(pszID, "https://")) {
      mtklog(("close-and-delete %p %s", praw, pszID));
      HTTPClient *pcl = (HTTPClient*)praw;
      pcl->close();  // in case curcon is active
      pcl->closeConnections();
      delete pcl;
   }
   else
   #endif
   if (strBegins(pszID, "ftp://")) {
      mtklog(("close-and-delete %p %s", praw, pszID));
      FTPClient *pcl = (FTPClient*)praw;
      pcl->logout(); // in case we're still logged in
      pcl->closeConnections(); // if any remaining
      delete pcl;
   }
   else
      perr("wrong cache entry type: %s %p", pcore->getID(), pcore);

   // stored value pointer is now INVALID,
   // but we're cleanup up all below

   return 0;
}

#ifdef USE_WEBCONCACHE
HTTPClient *ConCache::allocHttpClient(char *pBaseURL) 
{__
   if (   !strBegins(pBaseURL, "http://")
       && !strBegins(pBaseURL, "https://")
      )
      return 0;

   void *praw = get(pBaseURL);

   // use existing client?
   if (praw) {
      mtklog(("concache-reuse %s %p", pBaseURL, praw));
      HTTPClient *pres = (HTTPClient *)praw;
      pres->incref("aht");
      return pres;
   }

   mtklog(("ConCache-alloc %s", pBaseURL));

   // create new, on demand:
   forceCacheLimit();

   HTTPClient *pres = new HTTPClient(pBaseURL);
   if (put(pBaseURL, pres)) return 0;

   // also remember sequence of adding:
   clFifo.put(nAddCnt++, pBaseURL);

   // as it is managed by concache, ref is always >= 1
   pres->incref("aht");

   return pres;
}

int ConCache::releaseClient(HTTPClient *pcln)
{__
   mtklog(("concache-release %p http", pcln));
   pcln->decref("crh");
   return 0;
}
#endif

FTPClient *ConCache::allocFtpClient(char *pBaseURL) 
{
   if (!strBegins(pBaseURL, "ftp://")) return 0;

   mtklog(("ConCache-alloc %s", pBaseURL));

   void *praw = get(pBaseURL);

   // use existing client?
   if (praw) {
      FTPClient *pres = (FTPClient *)praw;
      if (pres->refcnt() > 1) { // 1: managed only by us
         perr("too many locks on connection: %s (%d)", pBaseURL, pres->refcnt());
         return 0;
      }
      pres->incref("aft");
      return pres;
   }

   // create new, on demand:
   forceCacheLimit();

   FTPClient *pres = new FTPClient(pBaseURL);
   if (put(pBaseURL, pres)) return 0;
   mtklog(("concache-put %s done", pBaseURL));

   // also remember sequence of adding:
   clFifo.put(nAddCnt++, pBaseURL);

   // as it is managed by concache, ref is always >= 1
   pres->incref("aft");

   return pres;
}

int ConCache::releaseClient(FTPClient *pcln)
{__
   mtklog(("concache-release %p ftp", pcln));
   pcln->decref("crf");
   return 0;
}

int ConCache::forceCacheLimit()
{__
   if (size() < 10)
   {
      mtklog(("concache-drop not required, size=%d", size()));
      return 0;
   }

   // return 0;

   // max. of 10 connections is kept in cache,
   // so drop the oldest one to keep some space:
   num nAddKey = 0;
   char *pBaseURL = (char*)clFifo.iget(0, &nAddKey);
   if (!pBaseURL) return 9+perr("int. #267281138");
   mtklog(("concache-iget first %s", pBaseURL));

   // fifo only stores keys, get matching tcpcore:
   TCPCore *pcon = (TCPCore *)get(pBaseURL);
   if (!pcon)
   {
      #ifdef SFKINT
      pinf("cache-get failed: %s\n", pBaseURL);
      #endif
      clFifo.remove(nAddKey);
      return 9+perr("int. #267281139");
   }

   // for now, assume the oldest one is unlocked
   if (pcon->refcnt() > 1) // 1: managed only by us
   {
      perr("connection cache overflow, %d %d", size(), pcon->refcnt());
      return 9;
   }

   // can drop the oldest connection
   mtklog(("concache-drop oldest connection %p %s", pcon, pBaseURL));

   // delete connection
   closeAndDelete(pcon);

   // must remove manually
   if (remove(pBaseURL))
      perr("int. #267281208");

   mtklog(("concache-remove done %p remain %d", pcon, size()));

   // also remove from fifo, deletes pBaseURL.
   if (clFifo.remove(nAddKey))
      perr("cannot remove from concache: %llx\n", nAddKey);

   return 0;
}

int TCPCon::nClIOBufSize = 4096;

TCPCon::TCPCon(SOCKET hsock, TCPCore *pcorein, int nTraceIn) 
{__
   mtklog(("  tcpcon ctr %p line %d",this,nTraceIn));
   memset(this, 0, sizeof(*this));
   pClCore = pcorein;
   clSock  = hsock;
   nClTraceLine = nTraceIn;
   nClStartTime = getCurrentTime();
   iClMaxWait   = pClCore->iClMaxWait;
}

TCPCon::~TCPCon( ) 
{__
   mtklog(("  tcpcon dtr %p used %d msec",this,(int)(getCurrentTime() - nClStartTime)));

   if (clSock != INVALID_SOCKET) {
      // close was forgotten. as tcpcon's are managed by the core,
      // this is probably never reached:
      perr("missing close on tcpcon %p hsock %xh line %d", this, (uint)clSock, nClTraceLine);
      rawClose();
   }

   if (pClUserData) delete pClUserData;
   if (pClIOBuf   ) delete [] pClIOBuf;

   memset(this, 0, sizeof(*this));
   clSock = INVALID_SOCKET;
}

void TCPCon::rawClose() 
{__
   if (clSock != INVALID_SOCKET) {
      mtklog(("con %p close socket %u",this,(uint)clSock));
      myclosesocket(clSock);
   }
   clSock = INVALID_SOCKET;
}

static void localSetBlocking(SOCKET hSock, bool bYesNo)
{
   #ifdef _WIN32
   unsigned long ulParm = bYesNo ? 0 : 1;
   ioctlsocket(hSock, FIONBIO, &ulParm);
   #else
   if (bYesNo)
      fcntl(hSock, F_SETFL, (fcntl(hSock,F_GETFL) & ~O_NONBLOCK));
   else
      fcntl(hSock, F_SETFL, (fcntl(hSock,F_GETFL) | O_NONBLOCK));
   #endif
}

void  TCPCon::setBlocking (bool bYesNo) 
{
   // unsigned long ulParm = bYesNo ? 0 : 1;
   // ioctlsocket(clSock, FIONBIO, &ulParm);
   localSetBlocking(clSock, bYesNo); // 169
}

int TCPCon::read(uchar *pBlock, uint nLen) 
{
   // if a foreground thread detects the escape key:
   if (bGlblEscape)
      return 0; // NOT -1, size_t problem

   IOStatusPhase ophase("read tcp");

   num tstart  = getCurrentTime();

   int nTotal   = 0;
   int nRemain  = nLen;
   int nCursor  = 0;
   int nMaxWait = iClMaxWait;
   int nDelays  = 0;
   int nRead    = 0;
   while (nRemain > 0)
   {
      // avoid using doSleep by select
      struct timeval tv;
      fd_set fdvar;
      tv.tv_sec  = 0;
      tv.tv_usec = 20 * 1000; // 20 msec
      FD_ZERO(&fdvar);
      FD_SET(clSock, &fdvar);
      if (nMaxWait > 0 && select(clSock+1, &fdvar, 0, 0, &tv) <= 0) 
      {
         if (getCurrentTime() - tstart > nMaxWait) {
            pinf("read timeout (%d ms).   \n", (int)(getCurrentTime() - tstart));
            nCursor=0;
            break;
         }
         continue;
      }

      nRead = recv(clSock, (char*)pBlock+nCursor, nRemain, 0);

      // mtklog(("%d = tcp.recv(%d,%d) err %d",nRead,clSock,nRemain,netErrno()));

      if (nRead <= 0)
      {
         if (nRead == -1 && netErrno() == WSAEWOULDBLOCK) 
         {
            if (getCurrentTime() - tstart > nMaxWait) 
            {
               pinf("read timeout (%d ms).   \n", (int)(getCurrentTime() - tstart));
               nCursor=0;
               break;
            }
            doSleep(20);
            nDelays++;
            continue;
         }
         break;
      }

      countIOBytes(nRead);

      nTotal  += nRead;
      nRemain -= nRead;
      nCursor += nRead;
   }
   if (nDelays > 0) {
      mtklog(("read using %d delays",nDelays));
   }
   if (nCursor < 1) {
      mtklog(("tcp.read: no data (%d,%d)\n",nRead,netErrno()));
   }

   return nCursor;
}

int TCPCon::send(uchar *pBlock, uint nLen) 
{__
   return ::send(clSock, (char*)pBlock, nLen, 0);
}

char *TCPCon::buffer(int &rbufsize)
{
   if (!pClIOBuf) {
      pClIOBuf = new char[nClIOBufSize+100];
      memset(pClIOBuf, 0, nClIOBufSize+100);
   }
   rbufsize = nClIOBufSize;
   return pClIOBuf;
}

char *TCPCon::readLine(char *poptbuf, uint noptmaxbuf, bool braw) 
{__
   // use which buffer?
   char *pBuf    = poptbuf;
   int  nBufMax = noptmaxbuf;

   // alloc internal buffer on demand:
   if (!pBuf) pBuf = buffer(nBufMax);

   IOStatusPhase ophase("read tcp");

   int nCursor = 0;
   int nRemain = nBufMax;
   pBuf[0] = '\0';

   // switching from readLine mode to readBinary is tricky,
   // therefore read char by char to exactly get the point
   // of CRLF, from which on we may switch to binary.
   while (nRemain > 10) 
   {
      // int nRead = recv(clSock, pBuf+nCursor, 1, 0);
      int nRead = read((uchar*)pBuf+nCursor, 1);
      if (nRead <= 0) {
         mtklog(("< readline: EOD"));
         return 0;
      }
      countIOBytes(nRead);
      nCursor += nRead;
      nRemain -= nRead;
      pBuf[nCursor] = '\0';
      if (nCursor >= 1 && pBuf[nCursor-1]=='\n')
         break;
   }

   // always return lines without CRLF.
   if (!braw)
      removeCRLF(pBuf);
   if (core().verbose())
      printf("< %s\n", pBuf);
   else {
      // mtklog(("< %.200s", pBuf));
   }

   return pBuf;
}

int TCPCon::puts(char *pline) 
{__
   int nBufMax = 0;
   char *pBuf = buffer(nBufMax);
   nBufMax -= 10; // tolerance

   int nlen = strlen(pline);
   if (nlen > nBufMax) {
      perr("string overflow on send: %.200s", pline); 
      return 9;
   }

   strncpy(pBuf, pline, nBufMax);
   pBuf[nBufMax] = '\0';

   // if no CRLF is found at end of string, append it
   nlen = strlen(pBuf);
   if (nlen < 2 || strncmp(pBuf+nlen-2, "\r\n", 2))
      strcat(pBuf, "\r\n");

   IOStatusPhase ophase("send tcp");

   // finally, send it:
   int nsent = send((uchar*)pBuf, strlen(pBuf));
   if (nsent != (int)strlen(pBuf)) return 9;

   mtklog(("> %s", pBuf));

   return 0;
}

int  TCPCon::putf(cchar *pmask, ...) 
{__
   int nBufMax = 0;
   char *pBuf = buffer(nBufMax);
   nBufMax -= 10; // tolerance

   va_list argList;
   va_start(argList, pmask);
   ::vsnprintf(pBuf, nBufMax, pmask, argList);
   pBuf[nBufMax] = '\0';

   // if no CRLF is found at end of string, append it
   int nlen = strlen(pBuf);
   if (nlen < 2 || strncmp(pBuf+nlen-2, "\r\n", 2))
      strcat(pBuf, "\r\n");

   IOStatusPhase ophase("send tcp");

   // finally, send it:
   int nsent = send((uchar*)pBuf, strlen(pBuf));
   if (nsent != (int)strlen(pBuf)) return 9;

   mtklog(("> %s", pBuf));

   return 0;
}

int  TCPCon::setProtocol(char *psz) {
   return 9;
}

int  TCPCon::readReply(int nMinRC, int nMaxRC) {
   return 9;
}

TCPCore &TCPCon::core( ) {
   return *pClCore; 
}

bool TCPCore::verbose( ) {
   return bClVerbose;
}

void TCPCore::wipe() 
{__
   // safe replacement for memset(this)
   // in case that virtualization is used.
   // does NOT free any memory objects!
   pClID       = 0;
   nClCon      = 0;
   mclear(aClCon);
   mclear(clReadSet);
   mclear(clSetCopy);
   bClVerbose  = 0;
   nClRefs     = 0;
}

TCPCore::TCPCore(char *pszID, char cProtocol) 
{__
   mtklog(("tcpcore ctr %p",this));

   if (sizeof(*this) > 10000)
      perr("tcpcore stack sizing problem");

   // sfk wide tcp default: 10 seconds
   iClMaxWait = 10000;

   if (cProtocol == 'h')
      iClMaxWait  = cs.maxwebwait;

   if (cProtocol == 'f')
      iClMaxWait  = cs.maxftpwait;

   wipe();

   pClID = strdup(pszID);
}

TCPCore::~TCPCore( ) 
{__
   mtklog(("tcpcore dtr %p",this));
   if (nClCon > 0)
      perr("missing shutdown() on tcpcore %p",this);
   shutdown();
   delete [] pClID;
   wipe();
}

char *TCPCore::getID( ) {
   return pClID;
}

char TCPCore::szClProxyHost[100];
int TCPCore::nClProxyPort = -1;
bool TCPCore::bClProxySet  =  0;

// this may also be called BEFORE sysInit().
int TCPCore::setProxy(char *phost, int nport) 
{__
   strcopy(szClProxyHost, phost);
   nClProxyPort = nport;
   bClProxySet = 1;
   return 0;
}

int TCPCore::incref(cchar *pTraceFrom)
{
   mtklog(("tcp-ref-inc %p %d from %s", this, nClRefs+1, pTraceFrom));
   return ++nClRefs; 
}

int TCPCore::decref(cchar *pTraceFrom)
{
   mtklog(("tcp-ref-dec %p %d from %s", this, nClRefs-1, pTraceFrom));
   return --nClRefs; 
}

int TCPCore::refcnt( )  { return nClRefs;   }

int TCPCore::lastError( ) 
{
   #ifdef _WIN32
   return WSAGetLastError();
   #else
   return errno;
   #endif
}

int TCPCore::sysInit( ) 
{__
   #ifdef _WIN32
   if (!bSysInitDone) {
      // done once per process
      WORD wVersionRequested = MAKEWORD(1,1);
      WSADATA wsaData;
      if (WSAStartup(wVersionRequested, &wsaData)!=0)
         return 9+perr("WSAStartup failed");
   }
   #endif

   // it is possible that the proxy was set
   // by a call before sysInit().
   if (!bClProxySet) {
      mclear(szClProxyHost);
      nClProxyPort = 0;
      char *pproxy = getenv("SFK_PROXY");
      if (pproxy) {
         char szBuf[200];
         static bool bFirst = 1;
         strcopy(szBuf, pproxy);
         char *psz1 = szBuf;
         while (*psz1 && *psz1 != ':') psz1++;
         if (*psz1) *psz1++ = '\0';
         int nport = atol(psz1);
         if (!nport) nport = 80;
         setProxy(szBuf, nport); // env var
         if (cs.verbose && bFirst) {
            bFirst = 0;
            printf("[using proxy %s port %d]\n", szBuf, nport);
         }
      }
   }

   bSysInitDone = 1;

   return 0;
}

void TCPCore::sysCleanup( ) 
{__
   #ifdef _WIN32
   if (bSysInitDone)
      WSACleanup();
   #endif
   bSysInitDone = 0;
}

void TCPCore::closeConnections( ) 
{__
   mtklog(("tcpcore closecon %p ncon=%d", this, nClCon));
   while (nClCon > 0) {
      TCPCon *pcon = aClCon[0];
      close(pcon);
   }
   memset(aClCon, 0, sizeof(aClCon));
}

void TCPCore::shutdown( ) 
{__
   mtklog(("tcpcore shutdown %p", this));
   for (int i=0; i<nClCon; i++) {
      TCPCon *pcon = aClCon[i];
      delete pcon;
   }
   nClCon = 0;
   memset(aClCon, 0, sizeof(aClCon));
}

int TCPCore::makeServerSocket (int nportin, TCPCon **ppout)
{__
   if (checksys()) return 9;

   if (nClCon >= FD_SETSIZE-2)
      return 9+perr("too many sockets, cannot create server socket\n");

   uint nPort = (uint)nportin;

   struct sockaddr_in ServerAdr;
   socklen_t nSockAdrSize = sizeof(sockaddr_in);

   ServerAdr.sin_family      = AF_INET;
   ServerAdr.sin_addr.s_addr = htonl(INADDR_ANY);
   ServerAdr.sin_port        = htons((unsigned short)nPort);

   SOCKET hServSock = socket(AF_INET, SOCK_STREAM, 0);
   if (hServSock == INVALID_SOCKET)
      return 9+perr("cannot create socket on port %u", nPort);

   if (bind(hServSock, (struct sockaddr *)&ServerAdr, sizeof(sockaddr_in)) == SOCKET_ERROR)
      return 9+perr("cannot bind socket on port %u", nPort);

   int nerr = getsockname(hServSock, (struct sockaddr *)&ServerAdr, &nSockAdrSize);
   if (nerr == SOCKET_ERROR)
      return 9+perr("getsockname failed, %d\n", lastError());

   /*
   bool bTell = (nPort == 0);
   nPort    = (uint)ntohs(ServerAdr.sin_port);
   nNewPort = nPort;
   if (bTell)
      printf("< local port %u (%u, %u)\n", nPort, (nPort>>8), nPort&0xFF);
   */

   // make later accepts non-blocking:
   // unsigned long ulParm = 1;
   // ioctlsocket(hServSock, FIONBIO, &ulParm);
   localSetBlocking(hServSock, 0); // 169

   if (listen(hServSock, 4) == SOCKET_ERROR)
      return 9+perr("cannot listen on port %u", nPort);

   // finally, create and remember the TCPCon
   TCPCon *pcon = new TCPCon(hServSock, this, __LINE__);
   // unblock was done above
   addCon(pcon);
   *ppout = pcon;

   return 0;
}

int TCPCore::addCon(TCPCon *pcon) 
{__
   if (nClCon >= FD_SETSIZE-2)
      return 9+perr("internal: too many connections");

   // add to fdset
   FD_SET(pcon->clSock, &clReadSet);

   // and to pointer table
   aClCon[nClCon++] = pcon;

   return 0;
}

int TCPCore::remCon(TCPCon *pcon) 
{__
   // remove from fdset
   FD_CLR(pcon->clSock, &clReadSet);

   // search in pointer table
   int nAtPos=0;
   for (nAtPos=0; nAtPos<nClCon; nAtPos++)
      if (aClCon[nAtPos] == pcon)
         break;

   if (nAtPos >= nClCon)
      return 9+perr("internal: cannot remove connection %p",this);

   // remove from pointer table
   for (int i=nAtPos; i<nClCon-1; i++)
      aClCon[i] = aClCon[i+1];
   aClCon[nClCon-1] = 0; // just in case

   nClCon--;

   return 0;
}

int TCPCore::accept(TCPCon *pServerCon, TCPCon **ppout) 
{__
   if (checksys()) return 9;

   if (nClCon >= FD_SETSIZE-2)
      return 9+perr("too many sockets, cannot accept more");

   IOStatusPhase ophase("tcp accept");

   struct sockaddr_in ClientAdr;
   socklen_t nSoLen = sizeof(sockaddr_in);
   SOCKET hClient = ::accept(pServerCon->clSock, (struct sockaddr *)&ClientAdr, &nSoLen);
   if (hClient == INVALID_SOCKET)
      return 9+perr("accept failed (%d)", lastError());

   TCPCon *pcon = new TCPCon(hClient, this, __LINE__);
   pcon->setBlocking(0);
   addCon(pcon);
   *ppout = pcon;

   return 0;
}

int TCPCore::checksys( ) {
   if (bSysInitDone) return 0;
   return 9+perr("internal: missing tcp sysinit");
}

void setBlocking(SOCKET hSock, bool bYesNo)
{
   #ifdef _WIN32
   unsigned long ulParm = bYesNo ? 0 : 1;
   ioctlsocket(hSock, FIONBIO, &ulParm);
   #else
   if (bYesNo)
      fcntl(hSock, F_SETFL, (fcntl(hSock,F_GETFL) & ~O_NONBLOCK));
   else
      fcntl(hSock, F_SETFL, (fcntl(hSock,F_GETFL) | O_NONBLOCK));
   #endif
}

bool hasData(SOCKET &hSock, int lTimeoutMS, bool bOnConnect)
{
   struct timeval tv;
   tv.tv_sec  = 0;
   tv.tv_usec = lTimeoutMS * 1000;

   fd_set fds1, fds2, fds3;

   FD_ZERO(&fds1); // read
   FD_ZERO(&fds2); // write
   FD_ZERO(&fds3); // except

   FD_SET(hSock, &fds1);

   if (bOnConnect)
   {
      FD_SET(hSock, &fds2);
      FD_SET(hSock, &fds3);
   }

   return select(hSock+1, &fds1, &fds2, &fds3, &tv) > 0;
}

int myconnect(SOCKET hSock, struct sockaddr *paddr, int naddr, int iMaxWait,
   char *pszVerboseHostInfo, int iPortInfo)
{
   if (iMaxWait == 0)
   {
      mtklog(("myconnect: blocking connect"));
      int isubrc = connect(hSock, paddr, naddr);
      if (isubrc !=0 && pszVerboseHostInfo != 0)
         perr("cannot connect to %s:%u (%s)\n", pszVerboseHostInfo, iPortInfo, netErrStr());
      return isubrc;
   }

   setBlocking(hSock, 0);

   int isubrc = connect(hSock, paddr, naddr);

   num nstart = getCurrentTime();
 
   while (1)
   {
      if (getCurrentTime() - nstart > iMaxWait)
      {
         if (pszVerboseHostInfo)
            perr("cannot connect to %s:%u, timeout (%d ms)\n", 
               pszVerboseHostInfo, iPortInfo, iMaxWait);
         return -1;
      }

      if (hasData(hSock, iMaxWait, 1))
      {
         mtklog(("myconnect: hasdata"));
         break;
      }

      doSleep(50);
   }

   setBlocking(hSock, 1);

   return 0;
}

int TCPCore::connect(char *pszHost, int nportin, TCPCon **ppout)
{__
   mtklog(("tcp.connect: %s %d timeout=%d",pszHost,nportin,iClMaxWait));

   if (checksys())
      return 9;

   if (nClCon >= FD_SETSIZE-2)
      return 9+perr("too many sockets, cannot connect more");

   IOStatusPhase ophase("connect tcp");

   SOCKET hSock = socket(AF_INET, SOCK_STREAM, 0);
   if (hSock == INVALID_SOCKET)
      return 9+perr("cannot create socket");

   mtklog(("tcp.connect: new socket %u",hSock));

   struct sockaddr_in oaddr;
   oaddr.sin_family = AF_INET;
   oaddr.sin_port = htons((unsigned short)nportin);
   if (setaddr(&oaddr,pszHost)) {
      mtklog(("setaddr failed: %s",pszHost));
      return 9;
   }

   int isubrc = myconnect(hSock, (struct sockaddr *)&oaddr, sizeof(oaddr), iClMaxWait, pszHost, nportin);

   mtklog(("tcp.connect: %d = connect(%u) %d",isubrc,hSock,netErrno()));

   if (isubrc == -1)
      return 9;

   TCPCon *pcon = new TCPCon(hSock, this, __LINE__);

   if (iClMaxWait > 0 && nportin != 443)
   {
      mtklog(("tcp.connect: set socket %u non blocking with maxwait=%d", hSock, iClMaxWait));
      pcon->setBlocking(0);
   }
   else
   {
      mtklog(("tcp.connect: use socket %u in blocking mode", hSock));
   }

   addCon(pcon);
   *ppout = pcon;

   return 0;
}

int TCPCore::close(TCPCon *pcon) 
{__
   remCon(pcon);
   mtklog(("tcpcore %p close socket %u",this,(uint)pcon->clSock));
   myclosesocket(pcon->clSock);
   pcon->clSock = INVALID_SOCKET;
   delete pcon;
   return 0;
}

int  TCPCore::selectInput (TCPCon **ppNextActiveCon, TCPCon *pToQuery) 
{__
   mtklog(("tcp-core select on %d connections",nClCon));

   IOStatusPhase ophase("tcp select");

   // fd_set is modified on select, therefore:
   memcpy(&clSetCopy, &clReadSet, sizeof(fd_set));
   int nrc = select(nClCon,
      &clSetCopy,
      NULL, 
      NULL, 
      NULL  // blocking (no timeout)
      );
   if (nrc <= 0)
      return 9+perr("select() failed, %d",lastError());
   // identify connection with input
   mtklog(("tcp-core select rc %d",nrc));
   for (int i=0; i<nClCon; i++)
   {
      TCPCon *pcon = aClCon[i];
      if (FD_ISSET(pcon->clSock, &clSetCopy)) {
         if (pToQuery && (pcon != pToQuery)) {
            mtklog(("tcp-core: con is set: %p - not the query, skipping", pcon));
            continue;
         }
         mtklog(("tcp-core: con is set: %p - returning", pcon));
         *ppNextActiveCon = pcon;
         return 0;
      }
      mtklog(("tcp-core: con not set: %p", pcon));
   }
   return 1; // nothing to do
}

int  TCPCore::registerData(TCPCon *pcon, TCPConData *pUserData) {
   return 9;
}

void  TCPCore::setVerbose  (bool bYesNo) {
   bClVerbose = bYesNo;
}

// - - - http client - - -

HTTPClient::HTTPClient(char *pszID)
 : TCPCore(pszID, 'h')
{__
   wipe();
}

HTTPClient::~HTTPClient( ) 
{__
   if (pClCache) {
      // if (nClCacheUsed)
      //    pwarn("http: %d unused bytes remaining in cache, %p\n",nClCacheUsed,this);
      delete [] pClCache;
   }
   if (pszClLineCache) {
      delete [] pszClLineCache;
   }
   if (pClCurCon)
      perr("http: unclosed connection, %p", this);
   wipe();
}

void HTTPClient::resetCache() 
{__
   nClCacheUsed = 0;
}

void HTTPClient::wipe( ) 
{__
   pClCurCon  = 0;

   mclear(aClURLBuf);
   pClCurPath = 0;

   mclear(aClHeadBuf);
   pClCurVal  = 0;

   mclear(aClJoinBuf);

   mclear(aClIOBuf);

   nClPort    = 80;
   iClWebRC   =  0;

   bClChunked   = 0;
   pClCache     = 0;
   nClCacheAlloc= 0;
   nClCacheUsed = 0;

   bClFirstReq  = 1;
   bClNoHead    = 0;
   bClNoCon     = 0;

   pszClLineCache = 0;

   bClSSL = 0;

   #ifdef WITH_SSL
   pClSSLContext = 0;
   pClSSLSocket = 0;
   #endif // WITH_SSL
}

char *HTTPClient::curname( ) {
   return aClHeadBuf; 
}

char *HTTPClient::curval( ) {
   return pClCurVal ? pClCurVal : (char*)"";
}

bool isAbsoluteURL(char *psz) {
   if (strBegins(psz, "http://")) return 1;
   if (strBegins(psz, "https://")) return 1;
   return 0;
}

// "http://thehost.com/dir1/" + "../rel.txt"
// -> "http://thehost.com/rel.txt"
int HTTPClient::joinURL(char *pabs, char *pref)
{__
   // 1) "image.png"
   // 1) "subdir/the.txt"
   // 2) "/topdir/the.txt"
   // 3) "../../reldir/"
   // 4) "http://other.com/..."
   strcopy(aClJoinBuf, pabs);
   char *pmax = aClJoinBuf + sizeof(aClJoinBuf) - 10;

   // find last valid slash in current dir
   char *psla = strrchr(aClJoinBuf, '/');
   if (!psla) return 9; // shouldn't happen

   // drop junk
   if (!strncmp(pref, "./", 2))
      pref += 2;

   // if not about to step up
   if (strncmp(pref, "../", 3))
      psla++; // past slash

   // 4) external ref?
   if (   strBegins(pref, "http://")
       || strBegins(pref, "https://")
      )
   {
      return 9;
   }
   else
   // 2) "/topdir/the.txt" ?
   if (*pref == '/') {
      // step src
      while (*pref == '/')
         pref++;
      // set dst to host root
      psla  = aClJoinBuf;
      if (!strncmp(psla, "http://", 7))
         psla += 7;
      else
      if (!strncmp(psla, "https://", 8))
         psla += 8;
      else
         return 9;
      while (*psla && *psla != '/') psla++;
      if (!*psla) return 9;
      psla++; // behind http://thehost.com/
   }
   else
   // step slashes up as long as "../"  
   while (!strncmp(pref, "../", 3)) {
      // step src
      pref += 3;
      // step dst
      while (psla > aClJoinBuf && *(psla-1) != '/')
         psla--;
   }

   // now join psla and pref
   *psla = '\0';
   int nreflen = strlen(pref);
   if (psla + nreflen > pmax)
      return 9+perr("url overflow: %.100s",pref);
   memcpy(psla, pref, nreflen);
   psla[nreflen] = '\0';

   mtklog(("join: %s + %s -> %s",pabs,pref,aClJoinBuf));

   if (fGlblWebDump) {
      fprintf(fGlblWebDump, "join.1: %s\n", pabs);
      fprintf(fGlblWebDump, "join.2: %s\n", pref);
      fprintf(fGlblWebDump, "join  > %s\n", aClJoinBuf);
   }

   return 0;
}

char *HTTPClient::curjoin( ) {
   return aClJoinBuf;
}

int HTTPClient::splitURL(char *purl)
{__
   mtklog(("spliturl %s",purl));

   // isolate hostname from url
   aClURLBuf[0] = '\0';

   char *psz1 = purl;

   bClSSL  = 0;
   nClPort = 80;

   #ifdef WITH_SSL
   if (!strncmp(purl, "https://", 8)) {
      psz1 = purl + 8;
      bClSSL = 1;
      nClPort = 443;
   }
   else
   #endif
   if (!strncmp(purl, "http://", 7)) {
      psz1 = purl + 7;
   }
   else
      return 9;

   // copy from thehost.com
   strcopy(aClURLBuf, psz1);
   char *pdst = aClURLBuf;

   // then null the first "/" or ":"
   char *psla = pdst;
   while (*psla != 0 && *psla != '/' && *psla != ':')
      psla++;
   if (*psla == ':') {
      // isolate embedded port number
      *psla++ = '\0';
      char *pport = psla;
      while (*psla && *psla != '/') psla++;
      if (*psla) *psla++ = '\0';
      nClPort = atol(pport);
   } else {
      // no embedded port number
      if (*psla)
         *psla++ = '\0';
   }

   // anything after "/" is the relative path
   pClCurPath = psla;

   mtklog(("host=\"%s\" port=%d path=\"%s\"\n",aClURLBuf,nClPort,psla));

   return 0;
}

char *HTTPClient::curhost( ) {
   return aClURLBuf;
}

char *HTTPClient::curpath( ) {
   return pClCurPath ? pClCurPath : (char*)"";
}

int HTTPClient::splitHeader(char *phead)
{__
   // isolate hostname from url
   aClHeadBuf[0] = '\0';
   pClCurVal = 0;

   // content-type: text/html
   strcopy(aClHeadBuf, phead);

   char *psz1 = aClHeadBuf;
   while (*psz1 && *psz1 != ':') psz1++;
   if (!*psz1) return 9; // wrong header format

   *psz1++ = '\0';
   while (*psz1 && *psz1 == ' ') psz1++;
   pClCurVal = psz1;

   // make header name all lowercase
   for (psz1 = aClHeadBuf; *psz1; psz1++)
      *psz1 = tolower(*psz1);

   return 0;
}

char *HTTPClient::readLine(bool braw)
{
   if (!haveConnection())
      { perr("int. #175291 missing connection"); return 0; }

   #ifdef WITH_SSL

   if (bClSSL && pClSSLSocket)
   {
      SOCKET osock = pClCurCon->clSock;

      char *pBuf   = aClIOBuf;
      int  nBufMax = sizeof(aClIOBuf)-10;
   
      int nCursor = 0;
      int nRemain = nBufMax;
      pBuf[0] = '\0';
   
      int iTimeout = 5000;
    
      num tStart = getCurrentTime();
   
      while (nRemain > 10)
      {
         if (bGlblEscape)
         {
            printf("!HttpClient: Canceling http connect due to stop request (2)\n");
            return 0;
         }

         #if 1
         struct timeval tv;
         fd_set fdvar;
         tv.tv_sec  = 0;
         tv.tv_usec = 20 * 1000; // 200 msec
         FD_ZERO(&fdvar);
         FD_SET(osock, &fdvar);
         if (select(osock+1, &fdvar, 0, 0, &tv) <= 0) {
            if (getCurrentTime() - tStart > iTimeout) {
               printf("!HttpClient: timeout while reading web reply (%s)\n", curhost());
               return 0;
            }
            continue;
         }
         mtklog(("before read on sock %d",osock));
         mtklog(("SSL %p has fd %d",pClSSLSocket,SSL_get_fd(pClSSLSocket)));
         #else
         if (getCurrentTime() > tStart + iTimeout)
         {
            printf("!HttpClient: timeout while reading web reply (%s)\n", curhost());
            return 0;
         }
         #endif
   
         int nRead = SSL_read(pClSSLSocket, pBuf+nCursor, 1);

         if (nRead == 0) // no input yet available
            { doSleep(50); continue; }
   
         if (nRead < 0) { // end of stream, or error
            int ierr = SSL_get_error(pClSSLSocket, nRead);
            mtklog(("ssl.readline error: %d %d %d at %d",nRead,ierr,errno,nCursor));
            return 0;
         }

         nCursor += nRead;
         nRemain -= nRead;
         pBuf[nCursor] = '\0';
         if (nCursor >= 2 && !strncmp(pBuf+nCursor-2, "\r\n", 2))
            break;
         if (nCursor >= 1 && !strncmp(pBuf+nCursor-1, "\n", 1))
            break;
      }
   
      if (!braw)
      {
         char *pcr = strchr(pBuf, '\r'); if (pcr) *pcr = '\0';
               pcr = strchr(pBuf, '\n'); if (pcr) *pcr = '\0';
      }
   
      return pBuf;
   }
   else
   {
      return pClCurCon->readLine(0, 0, braw);
   }

   #else

   return pClCurCon->readLine(0, 0, braw);

   #endif
}

// returns RC
int HTTPClient::sendLine(char *pline)
{
   if (!pClCurCon)
      { perr("int. #175292 missing connection"); return 9; }

   int ires = 0;

   #ifdef WITH_SSL
   if (bClSSL)
   {
      ires = SSL_write(pClSSLSocket, pline, strlen(pline));
   }
   else
   #endif
   {
      ires = pClCurCon->puts(pline);
   }

   return ires;
}

int HTTPClient::list(char *purl, CoiTable **pptable)
{
   return 9;
}

int HTTPClient::getFileHead(char *purl, Coi *pcoi, cchar *pinfo)
{__
   mtklog(("getFileHead %s %s", purl, pinfo));

   if (bClNoCon) {
      mtklog(("http-getfilehead: nocon set, blocked: %s", purl));
      return 9; // error issued before
   }

   if (splitURL(purl))
      return 9+perr("http: wrong url format: %s",purl);

   char *phost = curhost();
   char *pfile = curpath();

   int nport = nClPort;
   if (connectHttp(phost, nport, &pClCurCon)) {
      bClNoCon = 1;
      return 9+perr("http connect failed: %s:%d",phost,nport);
   }

   ConAutoClose ocls(this, &pClCurCon, __LINE__);

   // header field container
   StringMap *pheads = &pcoi->headers(); // gets filled below
   if (!pheads) return 9+perr("out of memory, cannot read head");

   int nbail = 0;

   do
   {
      // send request to return headers.
      // TODO: on first request, check suspicious HEAD replies
      //       like "image/gif" from a root directory.
      int nrc = 0;
      bool bHeadDone = 0;
      if (bClNoHead)
         nrc = sendReq("GET",pfile,phost,nport);
      else {
         nrc = sendReq("HEAD",pfile,phost,nport);
         bHeadDone = 1;
      }
      if (nrc) return nrc;
   
      // read headers on reply stream.
      int nwebrc = 0;
      pheads->reset();
      if (rawReadHeaders(nwebrc, purl, pcoi))
         return 9;
      // this also (re)sets the chunked mode

      // suspicious reply from root directory?
      char *pcont = pheads->get(str("content-type"));
      mtklog(("fr %d hd %d len %d cont %p %s",
         bClFirstReq, bHeadDone, strlen(pfile),
         pcont, pcont ? pcont : "<null>"));
      if (   bClFirstReq && bHeadDone
          && !strlen(pfile)
          && pcont && !strstr(pcont, "text")
         )
      {
         // no text data from root dir: disable HEAD requests
         bClNoHead = 1;
         // then repeat the request
         close();
         if (connectHttp(phost, nport, &pClCurCon))
            return 9+perr("http reconnect failed: %s:%d",phost,nport);
         continue;
      }
 
      if (nwebrc == 200)
         bClFirstReq = 0;

      // http redirect?
      if (nwebrc < 300 || nwebrc >= 400)
         break; // hopefully got the target
      
      // "HTTP/1.1 3xx" redirection
      // "Location: main.html"
      char *ptarg = pheads->get(str("location"));
      if (!ptarg) return 9+perr("rc %d but no Location on %s", nwebrc, curpath());
      mtklog(("redir to %s", ptarg));

      // CHANGE FILENAME OF COI according to redirection:
      char *pabsnew = 0;

      if (strBegins(ptarg, "http:")) {
         // absolute url supplied: use directly
         pabsnew = ptarg; // will be copied
      }
      else
      if (strBegins(ptarg, "https:")) {
         pabsnew = ptarg; // will be copied
      } else {
         // relative url supplied: join with old url
         if (joinURL(purl, ptarg))
            return 9+perr("redirect failed: %s / %s",purl,ptarg);
         pabsnew = curjoin();
      }

      // now holding "http://thehost.com/newfile.txt"
      pcoi->setName(pabsnew); // is copied
      purl = pcoi->name();   // take copy
      pinf("redirected to %s\n", purl);

      // evaluate new url for archive extensions
      if (endsWithArcExt(purl, 7)) {
         mtklog(("hth: archive detected by redirect: %s", purl));
         pcoi->setArc(1);
      }

      // block dup reads
      glblCircleMap.put(purl, 0); // if already set, does nothing

      // have to split this again
      if (splitURL(purl))
         return 9+perr("http: wrong url format: %s",purl);
   
      // take redirected target
      phost = curhost();
      pfile = curpath();

      // repeat the request with the new target.
      // TODO: close and re-open connection in case of GET
      if (!bHeadDone) {
         close();
         if (connectHttp(phost, nport, &pClCurCon))
           return 9+perr("http reconnect failed: %s:%d",phost,nport);
      }
   }
   while (nbail++ < 5); // until no longer redirected, or bail out

   // connection is auto closed
   return 0;
}

char *nextNonBlank(char *psz) {
   while (*psz && *psz != ' ') psz++;
   while (*psz && *psz == ' ') psz++;
   return *psz ? psz : 0;
}

bool HTTPClient::haveConnection( )
{

   if (pClCurCon)
      return 1;

   return 0;
}

// .
int HTTPClient::rawReadHeaders
 (
   int  &rwebrc,
   char    *purl, // for info
   Coi     *pcoi 
 )
{__
   if (!haveConnection())
      { perr("int. #175293 missing connection"); return 9; }

   if (!pcoi) return 9+perr("int. #2167251");

   StringMap *pheads = &pcoi->headers();
   if (!pheads) return 9+perr("out of memory, cannot read headers");

   char *pline  = 0;
   bool  bfirst = 1;
   bool  btext  = 0;

   iClWebRC = 0;

   // always reset chunked flag until we know better
   bClChunked = 0;

   mtklog(("http: begin reading of headers"));

   if (fGlblWebDump)
      fprintf(fGlblWebDump, "-----head.begin-----\n");

   // Note: first line uses RAW reading, keeping CRLF ending
   while ((pline = readLine(bfirst)))
   {
      if (!strlen(pline))
         break; // end of header

      mtklog(("< %s (from %s)", pline, purl));

      if (fGlblWebDump) {
         if (bfirst)
            fprintf(fGlblWebDump, "%s", pline);
         else
            fprintf(fGlblWebDump, "%s\n", pline);
      }

      if (bfirst) 
      {
         bfirst = 0;

         // header-free server?
         char *pprobe = pline;
         while (*pprobe==' ' || *pprobe=='\t') pprobe++;
         if (*pprobe == '<') 
         {
            mtklog(("http: headless reply"));
            // cache first line of content WITH EOL
            if (pszClLineCache) delete [] pszClLineCache;
            pszClLineCache = new char[strlen(pline)+10];
            memcpy(pszClLineCache, pline, strlen(pline)+1);
            // assume this is text/html
            pcoi->setTypeFromContentType(str("text/html"));
            return 0; // "done headers"
         }

         // normal server: strip CRLF
         removeCRLF(pline);

         if (cs.headers & 4) {
            // chain.print('h', 1, "> %s", pline);
            printx("<head>> %s\n", pline);
         }

         // HTTP/1.1 200 OK
         char *psz1 = pline;
         while (*psz1 && *psz1 != ' ') psz1++;
         while (*psz1 && *psz1 == ' ') psz1++;
         iClWebRC = atol(psz1);
         rwebrc = iClWebRC;

         #ifdef USE_404
         // recoverable rc?
         if (iClWebRC == 404) {
            // continue to load the error page,
            // but remember rc for additional info.
            pheads->put("webrc", "404");
            continue;
         }
         #endif // USE_404

         // fatal error?
         if (iClWebRC >= 400) {
            perr("%.40s: %s",pline,purl);
            return 9;
         }

         continue;
      }
      else
      {
         // non first: crlf was stripped
         if (cs.headers & 4) {
            // chain.print('h', 1, "> %s", pline);
            printx("<head>> %s\n", pline);
         }
      }

      if (splitHeader(pline)) {
         perr("wrong http header on object: %s", purl);
         pinf("header line is: %s\n",pline);
         return 9; 
      }

      mtklog(("   head \"%s\" val \"%s\"",curname(),curval()));

      // if map is supplied, store some headers there
      if (pheads) {
         if (   !strcmp(curname(), "location")
             || !strcmp(curname(), "content-type")
            )
            pheads->put(curname(), curval());
      }

      // interpret some headers directly
      // Transfer-Encoding: chunked
      if (   !mystricmp(curname(), "transfer-encoding")
          && !mystricmp(curval(), "chunked")) {
         bClChunked = 1;
         mtklog(("chunked read of reply"));
      }

      // if no coi is given, ignore header contents
      if (!pcoi)
         continue;

      // .gz  application/x-gzip
      // .zip application/x-zip-compressed
      // .bz2 application/x-bzip2
      // .tar application/x-tar
      // .tgz application/x-compressed
      // however, some servers say only "application/octet-stream"
      // for all archive files. in this case, the redirect file name
      // must be evaluated.

      // content-type: text/html, application/zip etc.
      if (!mystricmp(curname(), "content-type"))
      {
         pheads->put(str("content-type"), curval());
         pcoi->setTypeFromContentType(curval());
         continue;
      }

      // content-length: 20000
      if (!mystricmp(curname(), "content-length")) {
         pheads->put(str("content-length"), curval());
         pcoi->setSize(atonum(curval()));
         // for live stat display, if any
         void setIOStatMaxBytes(num n);
         setIOStatMaxBytes(atonum(curval()));
         continue;
      }

      // "Date" or
      // "Last-Modified" val "Tue, 01 Jan 2008 01:01:25 GMT"
      if (   !mystricmp(curname(), "date") 
          || !mystricmp(curname(), "last-modified")
         ) 
      {
         pheads->put(str("last-modified"), curval());
         char *pstr = nextNonBlank(curval()); // skip "Tue, "
         num ntime  = 0;
         // force format "01 Jan 2008 01:01:25 GMT"
         //               012345678901234567890123
         int nlen  = strlen(pstr);
         if (nlen < 20) continue;
         if (pstr[14] != ':' || pstr[17] != ':') continue;
         if (!timeFromString(pstr, ntime, cs.verbose?0:1)) { // http.header
            // mtklog(("coi.mtime: set %u from http header",(uint)ntime));
            pcoi->setTime(ntime); // http header
            if (fGlblWebDump)
               fprintf(fGlblWebDump, "set time: %s %p\n", numtoa(pcoi->nClMTime), pcoi);
         }
         continue;
      }

      #ifndef DVIEW
      // servers that strictly want no console web access may set
      if (!mystricmp(curname(), "console-browse")) {
         if (!mystricmp(curval(), "disable"))
            return 9+pwarn("console web access is disabled by server.\n");
      }
      #endif
   }

   if (bfirst)
   {
      mtklog(("no headers, no data received"));
      if (fGlblWebDump)
         fprintf(fGlblWebDump, "-----head.end----- (no reply)\n");
      #ifdef WITH_SSL
      if (bClSSL && pClSSLSocket && cs.recurl)
         return 9;
      #endif
      return 9+perr("no data: %s", purl);
   }

   if (fGlblWebDump)
      fprintf(fGlblWebDump, "-----head.end-----\n");

   // connection is auto closed.
   return 0;
}

int HTTPClient::connectHttp(char *phostorip, int nport, TCPCon **ppout)
{__
   mtklog(("connect: %s port=%d ssl=%d", phostorip, nport, bClSSL));

   if (nClProxyPort < 0)
      return 9+perr("internal, wrong http initial state\n");

   int isubrc = 0;

   if (szClProxyHost[0])
      isubrc = connect(szClProxyHost, nClProxyPort, ppout);
   else
      isubrc = connect(phostorip, nport, ppout);

   if (isubrc) {
      mtklog(("connect rc %d",isubrc));
      return isubrc;
   }

   #ifdef WITH_SSL
   if (bClSSL && pClCurCon)
   {
      static bool bLocalInit = false;
      if (!bLocalInit)
      {
         bLocalInit = true;
         SSL_load_error_strings();
         SSLeay_add_ssl_algorithms();
      }

      #if 1
      if (!(pClSSLContext = SSL_CTX_new(SSLv23_client_method())))
      #else
      if (!(pClSSLContext = SSL_CTX_new(TLSv1_client_method())))
      #endif
      {
         perr("SSLContext init failed\n");
         close();
         return 9;
      }

      if (!(pClSSLSocket = SSL_new(pClSSLContext)))
      {
         perr("SSLSocket creation failed\n");
         close();
         return 9;
      }
 
      SSL_set_fd(pClSSLSocket, pClCurCon->clSock);

      int iErrCode = SSL_connect(pClSSLSocket);

      if (iErrCode < 0)
      {
         mtklog(("SSLConnect failed (%d)",iErrCode));
         printf("SSLConnect failed (%d)\n",iErrCode);
         close();
         return 9;
      }

      mtklog(("SSL connect done to %s:%d with rc=%d", phostorip, nport, iErrCode));

      if (cs.debug)
         printf("SSL connect done to %s:%d\n", phostorip, nport);
   }
   #endif

   return 0;
}

int HTTPClient::open(char *purl, cchar *pmode, Coi *pcoi)
{__
   if (splitURL(purl))
      return 9+perr("http: wrong url format: %s",purl);

   if (bClNoCon) {
      mtklog(("http::open: nocon set, blocked: %s", purl));
      return 9; // error issued before
   }

   char *phost = curhost();
   char *pfile = curpath();

   if (fGlblWebDump) {
      fprintf(fGlblWebDump, "-----open.url:-----\n");
      fprintf(fGlblWebDump, "%s\n",purl);
      fprintf(fGlblWebDump, "host=%s port=%d\n",phost,nClPort);
      fflush(fGlblWebDump);
   }

   if (connectHttp(phost, nClPort, &pClCurCon)) {
      close();
      bClNoCon = 1;
      if (cs.verbose)
         perr("http connect failed: %s:%d",phost,nClPort);
      return 9;
   }

   // header field container
   StringMap *pheads = &pcoi->headers();
   if (!pheads) {
      close();
      return 9+perr("out of memory, cannot read meta data");
   }

   int nbail = 0;

   do
   {
      // send request to return headers.
      int nrc = sendReq("GET",pfile,phost,nClPort);
      if (nrc) {
         close();
         return 9;
      }

      // read headers on reply stream.
      int nwebrc = 0;
      pheads->reset();
      if (rawReadHeaders(nwebrc, purl, pcoi))
      {
         close();
         return 10;
      }
      // this also (re)sets the chunked mode

      // http redirect?
      if (nwebrc < 300 || nwebrc >= 400)
         break; // hopefully got the target

      // "HTTP/1.1 3xx" redirection
      // "Location: main.html"
      char *ptarg = pheads->get(str("location"));
      if (!ptarg) {
         close();
         return 9+perr("rc %d but no Location on %s", nwebrc, curpath());
      }
      mtklog(("redir to %s", ptarg));

      // CHANGE FILENAME OF COI according to redirection:
      char *pabsnew = 0;

      if (strBegins(ptarg, "http:")) {
         // absolute url supplied: use directly
         pabsnew = ptarg; // will be copied
      }
      else
      if (strBegins(ptarg, "https:")) {
         pabsnew = ptarg; // will be copied
      } else {
         // relative url supplied: join with old url
         if (joinURL(purl, ptarg)) {
            close();
            return 9+perr("redirect failed: %s / %s",purl,ptarg);
         }
         pabsnew = curjoin();
      }

      // now holding "http://thehost.com/newfile.txt"
      pcoi->setName(pabsnew); // is copied
      purl = pcoi->name();   // take copy
      pinf("redirected to %s\n", purl);

      // evaluate new url for archive extensions
      if (endsWithArcExt(purl, 8)) {
         mtklog(("hto: archive detected by redirect: %s", purl));
         pcoi->setArc(1);
      }

      // block dup reads
      glblCircleMap.put(purl, 0); // if already set, does nothing

      // close now as splitURL inits stuff
      close();

      // fix: 1770: reset coi stats on redirect
      pheads->reset();
      pcoi->nClHave = 0;
      pcoi->nClSize = 0;

      // have to split this again
      if (splitURL(purl)) {
         return 9+perr("http: wrong url format: %s",purl);
      }

      // take redirected target
      phost = curhost();
      pfile = curpath();

      // repeat the request with the new target.
      if (connectHttp(phost, nClPort, &pClCurCon)) {
         return 9+perr("http reconnect failed: %s:%d",phost,nClPort);
      }
   }
   while (nbail++ < 5); // until no longer redirected, or bail out

   // connection is auto closed
   return 0;
}

// returns no. of bytes or 0
int HTTPClient::readraw(uchar *pbuf, int nbufsize) 
{__
   if (!pClCurCon)
      { perr("int. #175294 missing connection"); return 0; }

   int ires = 0;

   #ifdef WITH_SSL
   if (bClSSL)
   {
      ires = SSL_read(pClSSLSocket, pbuf, nbufsize);
      mtklog(("%d = ssl_read maxbuf %d",ires,nbufsize));
   }
   else
   #endif
   {
      ires = pClCurCon->read(pbuf, nbufsize);
      mtklog(("%d = readraw maxbuf %d",ires,nbufsize));
   }

   return ires;
}

int HTTPClient::readrawfull(uchar *pBlock, uint nLen)
{
   // if a foreground thread detects the escape key:
   if (bGlblEscape)
      return 0; // NOT -1, size_t problem

   if (!pClCurCon)
      { perr("int. #175294 missing connection"); return 0; }

   SOCKET osock = pClCurCon->clSock;

   IOStatusPhase ophase("read tcp");

   num tstart  = getCurrentTime();

   int nTotal   = 0;
   int nRemain  = nLen;
   int nCursor  = 0;
   int nMaxWait = iClMaxWait;
   while (nRemain > 0)
   {
      struct timeval tv;
      fd_set fdvar;
      tv.tv_sec  = 0;
      tv.tv_usec = 20 * 1000; // 20 msec
      FD_ZERO(&fdvar);
      FD_SET(osock, &fdvar);
      if (nMaxWait > 0 && select(osock+1, &fdvar, 0, 0, &tv) <= 0) 
      {
         if (getCurrentTime() - tstart > nMaxWait) {
            pinf("read timeout (%d ms).   \n", (int)(getCurrentTime() - tstart));
            nCursor=0;
            break;
         }
         continue;
      }

      int nRead = readraw(pBlock+nCursor, nRemain);

      if (nRead <= 0)
         break;

      countIOBytes(nRead);

      nTotal  += nRead;
      nRemain -= nRead;
      nCursor += nRead;
   }

   return nCursor;
}

// .
// TODO: reorg error rc handling
int HTTPClient::read(uchar *pbuf, int nbufmax) 
{__
   mtklog(("http::read max=%d chunked=%d incache=%d lcache=%p", nbufmax, bClChunked, nClCacheUsed, pszClLineCache));

   if (!pClCurCon)
      { perr("int. #175295 missing connection"); return 0; }

   int iprefix = 0;

   // pinf("read upto %d with lcache=%p   \r",nbufmax,pszClLineCache);

   if (pszClLineCache) 
   {
      int nlen = strlen(pszClLineCache);
      int nrem = 0;
      if (nlen > nbufmax) {
         // huge line data was cached
         nrem=nlen-nbufmax;
         nlen=nbufmax;
         mtklog(("http::read use cacheline part len=%d remain=%d",nlen,nrem));
         memcpy(pbuf, pszClLineCache, nlen);
         if (nrem) {
            memmove(pszClLineCache, pszClLineCache+nlen, nrem+1); // WITH term
         } else {
            delete [] pszClLineCache;
            pszClLineCache = 0;
         }
         mtklog((" return linecache %d", nlen));
         return nlen;
      } else {
         // 1770: first line of content was cached, use as data start
         memcpy(pbuf, pszClLineCache, nlen);

         delete [] pszClLineCache;
         pszClLineCache = 0;

         pbuf += nlen;
         nbufmax -= nlen;
         mtklog(("http::read use cacheline prefix len=%d remain=%d",nlen,nbufmax));
         if (nbufmax <= 0)
            return nlen;
         // fall through and fill up
         iprefix = nlen;
      }
   }

   // FROM HERE, MIND PREFIX LEN FOR RC!

   if (!bClChunked)
   {
      int irawlen = readraw(pbuf, nbufmax);

      if (irawlen >= 0)
          irawlen += iprefix;

      return irawlen;
   }

   if (nClCacheUsed <= 0)
   {
      // cache is empty, read next chunk:
   
      // 1. read control line with size of next chunk
      char *pline = readLine(); // 1770, i/o raw readline

      // mtklog(("http next chunk control line \"%.30s\"", pline ? pline : "<null>"));

      if (!pline)
         return 0+perr("http read error, no chunk header");

      int nchunksize = strtol(pline, 0, 0x10);

      // mtklog(("http next chunk %d bytes \"%s\"", nchunksize, pline));

      if (!nchunksize)
         return 0; // EOD flagged by "0" chunk size
   
      // 2. force IOCache to provide enough space
      //    for the whole chunk. note that there may
      //    still be bytes left over from last read.
      int nCacheRemain = nClCacheAlloc - nClCacheUsed;
      if (nchunksize > nCacheRemain) 
      {
         // expand cache
         int nMissing  = nchunksize - nCacheRemain;
         int nAllocNew = nClCacheAlloc + nMissing + 100;
         uchar *pnew = new uchar[nAllocNew+10];
         memcpy(pnew, pClCache, nClCacheUsed);
         // swap new and old
         delete [] pClCache;
         pClCache = pnew;
         nClCacheAlloc = nAllocNew;
         mtklog(("http cache resized to %d", nClCacheAlloc));
         // nClCacheUsed stays unchanged
         nCacheRemain = nClCacheAlloc - nClCacheUsed;
         if (nchunksize > nCacheRemain)
            return 0+perr("int. 167281949");
      }
   
      // 3. read exactly the chunk, adding it to cache
      uchar *pdst = pClCache + nClCacheUsed;
      int nread  = readrawfull(pdst, nchunksize); // 1770
      mtklog(("http read chunk with %d bytes", nread));
      if (nread < nchunksize)
         return 0+perr("http: incomplete chunk read, %d %d",nread,nchunksize);

      // every chunk is followed by CRLF
      readLine(); // 1770

      // fall through to copy from cache
      nClCacheUsed += nread;
   }

   // independent from chunk sizes,
   // return nbufmax OR LESS bytes.
   if (nClCacheUsed <= 0)
      return 0+perr("int. 167281950");

   int ntocopy = nbufmax;
   if (nClCacheUsed < ntocopy)
        ntocopy = nClCacheUsed;

   memcpy(pbuf, pClCache, ntocopy);

   // shrink cache contents
   uchar *psrc = pClCache + ntocopy;
   int   nrem = nClCacheUsed - ntocopy;
   memmove(pClCache, psrc, nrem);
   nClCacheUsed -= ntocopy;

   mtklog(("http cache remain %d alloc %d", nClCacheUsed, nClCacheAlloc));

   return iprefix+ntocopy;
}

void HTTPClient::close( ) 
{__
   mtklog(("http::close: pcon=%p cacheAlloc=%d cacheUsed=%d", pClCurCon, nClCacheAlloc, nClCacheUsed));

   if (pClCurCon)
   {
      TCPCore::close(pClCurCon);
      pClCurCon = 0;
   }

   #ifdef WITH_SSL
   if (pClSSLSocket)
   {
      SSL_free(pClSSLSocket);
      pClSSLSocket = 0;
   }

   if (pClSSLContext)
   {
      SSL_CTX_free(pClSSLContext);
      pClSSLContext = 0;
   }
   #endif

   bClSSL = false;

   nClCacheUsed = 0;
}

// - - - ftp client - - -

FTPClient::FTPClient(char *pszID)
 : TCPCore(pszID, 'f')
{__
   mtklog(("ftpclient ctr %p", this));
   wipe();
}

FTPClient::~FTPClient( ) 
{__
   mtklog(("ftpclient dtr %p", this));
   if (pClCtlCon)
      perr("ftp: unclosed control connection, %p",this);
   if (pClPassive) delete [] pClPassive;
   if (pszClHost ) delete [] pszClHost;
   if (file.name ) delete [] file.name;
   if (file.md5  ) delete file.md5;
   wipe();
}

char  *FTPClient::line( )    { return szClLineBuf; }
int   FTPClient::lineMax( ) { return sizeof(szClLineBuf)-100; }

void FTPClient::wipe( ) 
{__
   pClCtlCon   =  0;
   pClPassive  =  0;
   mclear(aClURLBuf);
   mclear(szClLineBuf);
   pClCurPath  =  0;
   bClLoggedIn =  0;
   pszClHost   =  0;
   nClPort     = 21;
   bClSFT      =  0;
   nClSFTVer   =  0;
   mclear(file);
}

char *FTPClient::curhost( ) { 
   return aClURLBuf;
}

char *FTPClient::curpath( ) { 
   return pClCurPath ? pClCurPath : (char*)"";
}

int FTPClient::curport( ) { return nClPort; }

int FTPClient::splitURL(char *purl)
{__
   // isolate hostname from url
   aClURLBuf[0] = '\0';

   // ftp://thehost.com/thedir/thefile.txt
   if (strncmp(purl, "ftp://", 6)) return 9;
   char *psz1 = purl + 6;

   // copy from thehost.com
   strcopy(aClURLBuf, psz1);
   char *pdst = aClURLBuf;

   // then null the first "/" or ":"
   char *psla = pdst;
   while (*psla && (*psla != '/' && *psla != ':')) psla++;
   if (*psla == ':') {
      // isolate embedded port number
      *psla++ = '\0';
      char *pport = psla;
      while (*psla && *psla != '/') psla++;
      if (*psla) *psla++ = '\0';
      nClPort = atol(pport);
   } else {
      // no embedded port number
      if (*psla) *psla++ = '\0';
   }

   // printf("host \"%s\" port %d path \"%s\"\n",aClURLBuf,nClPort,psla);

   // anything after "/" is the relative path
   pClCurPath = psla;

   return 0;
}

char *FTPClient::readLine( ) {
   return pClCtlCon->readLine();
}

int FTPClient::sendLine(char *pline) {
   return pClCtlCon->puts(pline);
}

// guarantees to set pline, even if empty
int FTPClient::readReply(char **ppline)
{__
   char *pline = str("");
   int ncode = 0;
   while ((pline = readLine())) {
      // e.g. "230-some text" or "230 login done"?
      int nlen = strlen(pline);
      ncode = atol(pline);
      if (nlen < 4) break;
      if (pline[3] != '-') break;
      // else continue reading the reply
      mtklog(("[reply %d continued]",ncode));
   }
   *ppline = pline ? pline : (char*)"";
   return pline ? ncode : 0;
}

int FTPClient::login(char *phostorip, int nport)
{__
   mtklog(("ftp-login %s", phostorip));

   if (pszClHost)  { delete [] pszClHost; pszClHost = 0; }

   if (connect(phostorip, nport, &pClCtlCon))
      return 9+perr("ftp login failed: %s:%d",phostorip,nport);

   char *pline = 0;
   int  ncode = 0;
_
   // expect "220 " or "220-"
   if (!(ncode = readReply(&pline)))
      return 9+perr("ftp: wrong server hello: %s", pline);
_
   // detect sfk ftp server with SFT
   char *psz1 = strstr(pline, ". sft ");
   if (psz1) {
      int nSFTVer = atol(psz1+6);
      if (nSFTVer >= 100) {
         bClSFT = 1;
         if (cs.verbose)
            printf("> server speaks sft %d. mget, mput enabled.\n", nSFTVer);
         nClSFTVer = nSFTVer;
      } else {
         printf("> unexpected sft info \"%s\"\n", psz1);
      }
   }
_
   if (sendLine(str("USER anonymous"))) return 9;
   if (!readLine()) return 9; // 331
   if (sendLine(str("PASS sft102@"))) return 9;
_
   // expect "230 login done"
   if (!(ncode = readReply(&pline)))
      return 9+perr("ftp: wrong login reply: %s", pline);
_
   if (sendLine(str("TYPE I"))) return 9;
   if (!readLine()) return 9; // 200 OK
_
   bClLoggedIn = 1;
   pszClHost   = strdup(phostorip);

   mtklog(("ftp-login done %s", phostorip));

   return 0;
}

int FTPClient::loginOnDemand(char *phostorip, int nport)
{__
   // TODO: check maybe by dummy command if line is still valid
   if (bClLoggedIn) {
      mtklog(("ftp-login-reuse: %s", phostorip));
      return 0;
      // logout();
   }
   return login(phostorip, nport);
}

void FTPClient::logout( )
{__
   if (bClLoggedIn) {
      mtklog(("ftp-logout: %s", pszClHost ? pszClHost:""));
      if (pClCtlCon) close(pClCtlCon);
      pClCtlCon = 0;
      bClLoggedIn = 0;
   }
}

int FTPClient::setPassive(TCPCon **ppout)
{__
   if (pClPassive) { delete [] pClPassive; pClPassive=0; }

   if (!pClPassive) {
      // first call to setPassive:
      if (sendLine(str("PASV"))) return 10;
      char *pTmp = 0;
      if (!(pTmp = readLine())) return 11;
      pClPassive = strdup(pTmp);
   }

   // (re)use reply string to PASV
   char *pBuf = pClPassive;

   // 227 Entering Passive Mode (127,0,0,1,117,246)
   char *psz = strchr(pBuf, '(');
   if (!psz) return 12+perr("set passive failed: \"%s\"",pBuf);
   psz++;
   uchar n[6];
   for (int i=0; i<6; i++) {
      n[i] = (uchar)atol(psz);
      psz = strchr(psz+1, ',');
      if (psz) psz++; else break;
   }
   char szIP[50];
   sprintf(szIP, "%d.%d.%d.%d",n[0],n[1],n[2],n[3]);
   uint nPort = (((uint)n[4])<<8)|((uint)n[5]);

   // if (connectSocket(szIP, nPort, SoAdr, hData, "pasv data")) return 9;
   SOCKET hSock = socket(AF_INET, SOCK_STREAM, 0);
   if (hSock == INVALID_SOCKET)
      return 9+perr("set passive failed: cannot create socket");

   struct sockaddr_in ClntAdr;
   ClntAdr.sin_family = AF_INET;
   ClntAdr.sin_port = htons((unsigned short)nPort);
   if (setaddr(&ClntAdr,szIP,1))
      return 9+perr("set passive failed: cannot get host %s", szIP);

   IOStatusPhase ophase("connect ftp");

   if ((::connect(hSock, (struct sockaddr *)&ClntAdr, sizeof(struct sockaddr_in))) == -1)
      return 9+perr("set passive failed: cannot establish connection to %s", szIP);

   if (verbose())
      printf("< connected to %s:%u\n", szIP, nPort);

   // turn this into a tcpcore managed connection
   TCPCon *pcon = new TCPCon(hSock, this, __LINE__);
   // TODO: pcon->setBlocking(0) required?
   addCon(pcon);
   *ppout = pcon;

   return 0;
}

// list remote files of a directory
int FTPClient::list(char *pdir, CoiTable **ppout, char *pRootURL)
{__
   if (!pdir) return 9;

   if (!*pdir)    pdir = str(".");
   if (!pRootURL) pRootURL = str(""); // safety

   #ifdef DEEP_FTP
   // printf("ftp list begin: dir=%s root=%s\n",pdir,pRootURL);
   #endif

   int nrc = 0;

   TCPCon *pdat = 0;

   if (bClSFT) {
      // if (nClSFTVer >= 105) may use SLSB
      if (pClCtlCon->putf("SLST %s\r\n", pdir)) return 9;
      pdat = pClCtlCon;
   } else {
      // create a "passive" data connection
      if ((nrc = setPassive(&pdat)))
         return 9+perr("set passive failed, %d", nrc);
      pdat->setBlocking(0);
   
      // still send commands on control connection
      if (pClCtlCon->putf("LIST %s\r\n", pdir)) return 9;
   }

   char *pres = readLine(); // expect "150 Listing"
   if (!pres)
      return 9+perr("ftp list failed: %s", pdir);
   if (!strBegins(pres, "150 "))
      return 9+perr("ftp error: %s", pres);
 
   CoiTable  *ptab = *ppout;
   if (!ptab) ptab = new CoiTable();

   bool bGotDone = 0;

   // not at all a refname, just a buffer:
   char szTmpBuf1[300]; mclear(szTmpBuf1);
   char szTmpBuf2[500]; mclear(szTmpBuf2);

   // receive list of filenames on data connection
   while (1)
   {
      char *pline = 0;

      if (bClSFT) {
         if (!(pline = readLine()))
            return 9+perr("ftp list error: %s", pdir);
         if (!strncmp(pline, "226 ", 4)) {
            bGotDone = 1;
            break; // ok all done
         }
      } else {
         // any further lines on the data connection?
         TCPCon *prec = 0;
         int nrc = selectInput(&prec, pdat);
   
         if (nrc > 0) {
            // no: check control connection
            nrc = selectInput(&prec, pClCtlCon);
            if (nrc >= 5)
               return 9+perr("ftp list failed: %d", nrc);
            if (nrc == 1) // no status available
               { doSleep(500); continue; }
            if (!(pline = readLine()))
               return 9+perr("ftp list error: %s", pdir);
            mtklog(("from ctl: %s",pline));
            if (!strncmp(pline, "226 ", 4)) {
               bGotDone = 1;
               break; // ok all done
               // TODO: can really stop here w/o further data read?
            }
            pinf("%s", pline);
            continue;
         }
   
         // no: fall through to data read
         mtklog(("read from dcon %p", pdat));
         if (!(pline = pdat->readLine())) {
            mtklog(("eod from dcon"));
            break;
         }
      }

      // === extract meta data from pline ===

      // -rw-rw-rw-t 1 ftp ftp        30353 Sep 08 13:47   readme.txt
      //    0        1  2   3          4    5   6   7      8
      // drw-rw-rw-d 1 ftp ftp            0 20061231235959 mydir
      // -rw-rw-rw-b 1 ftp ftp        30353 20061231235959 test.dat
      //    0        1  2   3          4    5              6

      // since SFT 105, t/b are no longer provided.

      char *apcol[20];
      memset(apcol, 0, sizeof(apcol));

      char *pszFileRaw = pline;

      // parse raw line, copy from ftpClient()
      int ncol = 0;
      strcopy(szTmpBuf1, pszFileRaw);
      char *psz1 = szTmpBuf1;
      while (ncol < 15) {
         // store column start
         apcol[ncol++] = psz1;
         // find end of column
         skipToWhite(&psz1);
         if (!*psz1) break;
         *psz1++ = '\0';
         // find start of next column
         skipWhite(&psz1);
         if (!*psz1) break;
      }

      bool bIsDir = 0;
      bool bHaveBinInfo = 0;
      bool bIsBinary    = 0;
      char *pattr = apcol[0];
      if (pattr) {
         // 12345678901
         // drw-rw-rw-d
         // -rw-rw-rw-b : binary
         // -rw-rw-rw-t : text
         int nlen = strlen(pattr);
         if (pattr[0] == 'd') bIsDir = 1;
         if (nlen >= 11 && pattr[10] == 'b')
            { bHaveBinInfo=1; bIsBinary=1; }
         if (nlen >= 11 && pattr[10] == 't')
            { bHaveBinInfo=1; bIsBinary=0; }
      }

      char *pszMonTS = apcol[5]; // month or timestamp
      bool bHaveFlatTime = 0;
      if (pszMonTS && isdigit(*pszMonTS))
           bHaveFlatTime = 1;

      int iName = 8;
      if (bHaveFlatTime) {
         if (ncol < 7)
            {  pwarn("wrong format: %s - skipping\n", pszFileRaw); continue; }
         iName = 6;
      }
      else
      if (ncol < 9)
         {  pwarn("wrong format: %s - skipping\n", pszFileRaw); continue; }

      // always take filename from original buffer,
      // blanks may have been replaced by zeros in RefNameBuf.
      char *pszFile = pszFileRaw + (apcol[iName]-szTmpBuf1);
      char *pszSize = apcol[4];

      num nFileTime = 0;

      // if (bGlblFTPSetAttribs)
      {
         if (bHaveFlatTime) {
            timeFromString(pszMonTS, nFileTime); // ftp.list
         } else {
            if (apcol[5] && apcol[6] && apcol[7]) {
               sprintf(szTmpBuf2, "%s %s %s",apcol[5],apcol[6],apcol[7]);
               timeFromString(szTmpBuf2, nFileTime); // ftp.list
            }
         }
      }

      num nFileSize = atonum(pszSize);
      if (!bIsDir && (nFileSize <= 0))
      {
         printf("] skip, size=%s: %s\n", pszSize, pszFile);
         continue;
      }

      // === end meta data extraction ===

      // prefix every entry by its source url
      cchar *pInsPath = "";
      cchar *pszTrail = "";

      int nlen = strlen(pRootURL);
      if (nlen > 0 && pRootURL[nlen-1] != '/')
            pInsPath = "/";
      int nRootUseLen = strlen(pRootURL);

      #ifdef DEEP_FTP
      // does the root contain pdir redundantly?
      int nSubDirLen = strlen(pdir);
      if (    nSubDirLen < nRootUseLen
          && !strcmp(pRootURL+nRootUseLen-nSubDirLen, pdir)
         )
      {
         // printf("root contains pdir\n");
         nRootUseLen -= nSubDirLen;
         if (nRootUseLen > 0 && pRootURL[nRootUseLen-1] != '/')
            pInsPath = "/";
         else
            pInsPath = "";
      } else {
         // printf("root does not contain dir \"%s\" \"%s\" \"%s\" %d %d\n",pRootURL+nRootUseLen-nSubDirLen,pdir,pRootURL,nRootUseLen,nSubDirLen);
      }
      if (bIsDir) pszTrail = "/"; // TODO: check if there's a slash already
      #endif

      snprintf(szTmpBuf2, sizeof(szTmpBuf2), "%.*s%s%s%s", nRootUseLen,pRootURL,pInsPath,pszFile,pszTrail);

      // force whole url to net slashes
      void setNetSlashes(char *pdst);
      setNetSlashes(szTmpBuf2);

      Coi ocoi(szTmpBuf2, pRootURL);

      SFKFindData myfdat;
      memset(&myfdat, 0, sizeof(myfdat));
      myfdat.size = nFileSize;
      myfdat.time_write = nFileTime;
      if (bIsDir) {
         // printf("copy dir : %s\n",ocoi.name());
         myfdat.attrib |= 0x10;
      } else {
         // printf("copy file: %s\n",ocoi.name());
      }

      ocoi.fillFrom(&myfdat);

      if (bHaveBinInfo) {
         ocoi.setBinaryFile(bIsBinary);
         mtklog(("ftp list: %s : %s",bIsBinary?"isbin":"istxt",ocoi.name()));
      }

      #ifdef DEEP_FTP
      // printf("ftp list: add entry: %s  (dir=%d)\n", ocoi.name(), bIsDir);
      #endif

      ptab->addEntry(ocoi);
   }

   if (pdat != pClCtlCon) {
      // ftp: close separate data connection
      close(pdat);
   }

   // expect 226 Closing
   if (!bGotDone)
      if (!readLine())
         return 9;

   // result is owned by caller
   *ppout = ptab;

   mtklog(("ftp list end: %s return %d entries",pdir,ptab->numberOfEntries()));

   return 0;
}

int FTPClient::readLine(TCPCon *pcon)
{__
   char *pszLineBuf = line();
   int  nMaxLineBuf = lineMax();

   if (!pcon->readLine(pszLineBuf, nMaxLineBuf))
      return 9;

   // sft101: optional skip records to enforce socket flushing
   if (strBegins(pszLineBuf, "SKIP "))
   {
      // read intermediate skip record
      uint nLen = (uint)atol(pszLineBuf+5);
      if ((int)nLen > nMaxLineBuf) return 9;
      if (nLen) {
         if (pcon->read((uchar*)pszLineBuf, nLen) < 0)
            return 9;
      }

      // now read the actual record
      if (!pcon->readLine(pszLineBuf, nMaxLineBuf))
         return 9;
   }

   mtklog(("ftp: < %s", pszLineBuf));

   return 0;
}

int FTPClient::readLong(TCPCon *pcon, uint &rOut, cchar *pszInfo)
{__
   uchar szBuf[100];
   if (pcon->read(szBuf, 4) != 4) return 9+perr("failed to read %s\n", pszInfo);
   uint nLen =   (((uint)szBuf[3])<<24)
                | (((uint)szBuf[2])<<16)
                | (((uint)szBuf[1])<< 8)
                | (((uint)szBuf[0])<< 0);
   rOut = nLen;
   return 0;
}

int FTPClient::sendLong(TCPCon *pcon, uint nOut, cchar *pszInfo)
{__
   uchar szBuf[100];
   szBuf[3] = ((uchar)(nOut >> 24));
   szBuf[2] = ((uchar)(nOut >> 16));
   szBuf[1] = ((uchar)(nOut >>  8));
   szBuf[0] = ((uchar)(nOut >>  0));
   int nSent = pcon->send(szBuf, 4);
   if (nSent != 4) return 9+perr("failed to send %s\n", pszInfo);
   return 0;
}

int FTPClient::readNum(TCPCon *pcon, num &rOut, cchar *pszInfo)
{__
   uchar szBuf[100];
   if (pcon->read(szBuf, 8) != 8) return 9;
   num nOut = 0;
   for (int i=0; i<8; i++) {
      nOut <<= 8;
      nOut |= (uint)szBuf[i];
   }
   rOut = nOut;
   return 0;
}

int FTPClient::readNum(uchar *pbuf, int &roff, num &rOut, cchar *pszInfo)
{__
   num nOut = 0;
   for (int i=0; i<8; i++) {
      nOut <<= 8;
      nOut |= (uint)pbuf[roff+i];
   }
   roff += 8;
   rOut = nOut;
   return 0;
}

int FTPClient::sendNum(TCPCon *pcon, num nOut, cchar *pszInfo)
{__
   uchar szBuf[100];
   // this may fail with num's >= 2 up 63.
   for (int i=7; i>=0; i--) {
      szBuf[i] = (uchar)(nOut & 0xFF);
      nOut >>= 8;
   }
   int nSent = pcon->send(szBuf, 8);
   if (nSent != 8) return 9+perr("failed to send %s\n", pszInfo);
   return 0;
}

extern int nGlblTCPMaxSizeMB;
extern char *localPath(char *pAbsFile);
extern int fastMode();

bool bGlblBulkFTPIO = 0;

void setBulkFTPIO(bool bYesNo) { bGlblBulkFTPIO = bYesNo; }

// open remote file for download
// RC:  9 == general error
//     10 == fatal communication error, connection invalid
int FTPClient::openFile(char *pfilename, cchar *pmode)
{__
   mtklog(("ftp: openFile: %s %s",pfilename,pmode));

   if (strcmp(pmode, "rb"))
      return 9+perr("cannot open ftp file, only read supported: %s", pfilename);

   TCPCon *pcon = pClCtlCon;

   #ifdef USE_SFT
   if (bClSFT)
   {
      // so far used only by dview:
      bool bbulk = bGlblBulkFTPIO;

      // request block mode transfer
      if (bbulk) {
         if (pcon->putf("SGET %s", pfilename)) return 10;
      } else {
         if (pcon->putf("SOPEN %s", pfilename)) return 10;
      }
      if (readLine(pcon)) return 10; // 200 OK
      if (!strBegins(line(), "200")) return 9;

      // read SFT file header meta infos
      uchar abHead[512+10];
   
      uint nMetaSize = 0;
      if (readLong(pcon, nMetaSize, "metalen")) return 9;
      if (nMetaSize > sizeof(abHead)-10)
         return 9+perr("unsupported SFT protocol version\n");
      if (pcon->read(abHead, nMetaSize) != (int)nMetaSize) return 9;
   
      // take from header what we need
      int ioff = 0;
   
      // meta 1: 8 bytes filesize
      num nLen = 0, nTime = 0, nFlags = 0;
      char szLocalTime[20]; mclear(szLocalTime);
      if (readNum(abHead, ioff, nLen, "size")) return 9;
   
      if (nGlblTCPMaxSizeMB)
         if (nLen > nGlblTCPMaxSizeMB * 1000000)
            return 9+perr("illegal length received, %s\n", numtoa(nLen));
   
      if (nClSFTVer >= 102) {
         if (readNum(abHead, ioff, nTime , "time" )) return 9;
         if (readNum(abHead, ioff, nFlags, "flags")) return 9;
      }

      if (nClSFTVer < 102) {
         // meta 2: md5 before content
         memcpy(file.abmd5, abHead+ioff, 16);
         ioff += 16;
      }

      if (file.name) delete [] file.name;
      file.name   = strdup(pfilename);

      if (file.md5)  delete file.md5;
      file.md5    = new SFKMD5();

      file.time   = nTime;
      file.size   = nLen;
      file.remain = nLen;

      file.blockmode = bbulk ? 0 : 1;
      file.block     = 0;

      // we do NOT really write a file here!
   }
   else
   #endif // USE_SFT
   {
      if (setPassive(&pClDatCon)) return 10;
      if (pClCtlCon->putf("RETR %s", pfilename)) return 10;
   
      // TODO: check actual RC if file exists
      if (!pClCtlCon->readLine()) return 10;
      // download started on data connection
   
      if (verbose()) {
         printf("< %s   \r", pfilename);
         fflush(stdout);
      }
   }

   return 0;
}

// read block of a file
int FTPClient::readFile(uchar *pbuf, int nmaxlen)
{__
   #ifdef USE_SFT
   if (bClSFT)
   {
      TCPCon *pcon = pClCtlCon;

      int nmaxin = nmaxlen; (void)nmaxin;

      if (nmaxlen > file.remain) nmaxlen = file.remain;

      if (nmaxlen <= 0) {
         mtklog(("ftp: readFile: max=%d return=%d", nmaxin, nmaxlen));
         return nmaxlen;
      }

      file.block++;

      if (nClSFTVer >= 102 && file.blockmode) 
      {
         num nreqlen = nmaxlen;

         // optim: on the first block, request only maxlen.
         // from the second block, transfer all in one.
         // NOTE: there can be no upper limit for this
         //       all-in-one size, as otherwise we have
         //       to remember subblock lengths which can
         //       become complicated.

         extern int fastMode();

         // with fastmode, get all in one from first block.
         int nbiglatch = fastMode() ? 1 : 2;

         if (file.block == nbiglatch) {
            // request bulk transfer, no further SREAD.
            nreqlen = file.remain;
         }

         if (file.block <= nbiglatch) {
            mtklog(("ftp: request %d remain=%s", nreqlen, numtoa(file.remain)));
            if (pcon->putf("SREAD %s\n", numtoa(nreqlen))) {
               perr("failed to send block request");
               return 0; // NOT -1, size_t problem
            }
         }
      }

      int nread = pClCtlCon->read(pbuf, nmaxlen);

      mtklog(("ftp: read %d", nread));

      if (nread > 0) 
      {
         if (file.md5) file.md5->update(pbuf, nread);
         file.remain -= nread;
         // reached end of content flank?
         if (file.remain == 0 && nClSFTVer >= 102) 
         {
            if (file.blockmode) {
               // request md5_post
               mtklog(("ftp: req sum"));
               if (pcon->putf("SSUM\n")) {
                  perr("failed to request checksum");
                  return 0; // NOT -1, size_t problem
               }
            }
            mtklog(("ftp: wait for sum"));
            if (pClCtlCon->read(file.abmd5, 16) != 16) {
               perr("failed to receive checksum");
               return 0; // NOT -1, size_t problem
            }
         }
      }
      mtklog(("ftp: readFile: max=%d return=%d", nmaxin, nread));
      // SKIP record will follow after content, we ignore that
      return nread;
   }
   else
   #endif // USE_SFT
   {
      if (!pClDatCon) {
         perr("ftp: cannot read, no download open");
         return 0;
      }
      return pClDatCon->read(pbuf, nmaxlen);
   }
}

void FTPClient::closeFile( )
{__
   char szBuf[300];

   #ifdef USE_SFT
   if (bClSFT)
   {
      if (!pClCtlCon)
         return;

      // sender will wait now until we confirm successful transfer.
      TCPCon *pcon = pClCtlCon;

      mtklog(("ftp: closeFile %s remain=%d", file.name ? file.name : "", (int)file.remain));
   
      if (nClSFTVer >= 102) {
         if (file.blockmode) {
            // send close
            mtklog(("ftp: req close"));
            if (pcon->putf("SCLOSE\n")) {
               perr("failed to send close");
               return;
            }
         } else {
            // bulk SFT cannot handle premature file close
            if (file.remain > 0) {
               pwarn("bulk transfer but %d remaining for: %s\n", (int)file.remain, file.name ? file.name : "");
            }
            while (file.remain > 0) {
               int nread = readFile((uchar*)line(), lineMax());
               if (nread <= 0) break;
            }
         }
         // expect and receive SKIP record of any length
         mclear(szBuf);
         recv(pcon->clSock, (char*)szBuf, sizeof(szBuf)-10, 0);
         mtklog(("ftp: got past close: %s",szBuf));
         // ack is sent below
      } else {
         // old SFT cannot handle premature file close
         while (file.remain > 0) {
            int nread = readFile((uchar*)line(), lineMax());
            if (nread <= 0) break;
         }
      }

      if (!file.remain && file.md5) 
      {
         // check and clear md5
         uchar abdig[20];
         memcpy(abdig, file.md5->digest(), 16);

         delete file.md5;
         file.md5 = 0;

         if (memcmp(abdig, file.abmd5, 16)) {
            pcon->send((uchar*)"EE\n\n", 4);
            perr("md5 mismatch - transfered file corrupted (size=%d)\n", (int)file.size);
            return ;
         }
      }

      // send short confirmation, so peer can safely close socket.
      int nSent = pcon->send((uchar*)"OK\n\n", 4);
      if (nSent != 4) {
         perr("failed to send reply, %d\n", nSent);
         return;
      }
   }
   else
   #endif // USE_SFT
   {
      if (!pClDatCon)
         return;

      close(pClDatCon);
      pClDatCon = 0;

      // expect reply on control connection
      char *pline = readLine();
      if (pline && !strBegins(pline, "226 "))
         perr("ftp: unexpected reply after download: %s", pline);
   }
}

// returns RC
int HTTPClient::sendReq
 (
   cchar *pcmd,
   char *pfile,
   char *phost,
   int  nport
 )
{
   if (!pClCurCon)
      { perr("int. #175296 missing connection"); return 9; }

   char szPort[20];
   szPort[0] = '\0';
   if (nport != 80)
      sprintf(szPort, ":%u", nport);

   char szAuth1[200];
   char szAuth2[200];
   szAuth1[0] = '\0';
   szAuth2[0] = '\0';
   if (cs.puser && cs.ppass) {
      snprintf(szAuth1,sizeof(szAuth1)-10, "%s:%s", cs.puser, cs.ppass);
      encode64((uchar*)szAuth1,strlen(szAuth1),(uchar*)szAuth2,sizeof(szAuth2)-10,10000);
      // encode64 adds CRLF already!
      snprintf(szAuth1,sizeof(szAuth1)-10, "Authorization: Basic %s", szAuth2);
   }

   if (szClProxyHost[0])
   snprintf(aClIOBuf, sizeof(aClIOBuf)-10,
      "%s http://%s%s/%s HTTP/1.1\r\n"
      "Host: %s%s\r\n"
      "%s"
      "User-Agent: %s\r\n"
      "Accept: text/html;q=0.9,*/*;q=0.8\r\n"
      "Accept-Language: en-us,en;q=0.8\r\n"
      "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7\r\n"
      "Proxy-Connection: close\r\n"
      "\r\n"
      , pcmd, phost, szPort, pfile
      , phost, szPort
      , szAuth1
      , getHTTPUserAgent()
      );
   else
   snprintf(aClIOBuf, sizeof(aClIOBuf)-10,
      "%s /%s HTTP/1.1\r\n"
      "Host: %s%s\r\n"
      "%s"
      "User-Agent: %s\r\n"
      "Accept: text/html;q=0.9,*/*;q=0.8\r\n"
      "Accept-Language: en-us,en;q=0.8\r\n"
      "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7\r\n"
      "Connection: close\r\n"
      "\r\n"
      , pcmd, pfile, phost, szPort
      , szAuth1
      , getHTTPUserAgent()
      );

   if (cs.showreq)
      printx("<file>http://%s%s/%s\n", phost, szPort, pfile);

   if (cs.headers & 2) {
      char *psz = (char*)aClIOBuf;
      char ccol = 'f';
      while (*psz!=0) {
         char *peol=psz;
         while (*peol && !iseol(*peol)) peol++;
         int ilen=peol-psz;
         // chain.print(ccol, 1, "< %.*s",ilen,psz);
         if (ccol=='f')
            printx("<file>< %.*s\n",ilen,psz);
         else
            printf("< %.*s\n",ilen,psz);
         while (*peol && iseol(*peol)) peol++;
         psz=peol;
         ccol = ' ';
      }
   }

   mtklog(("send.request: %s",(char*)aClIOBuf));

   size_t nlen = (int)strlen(aClIOBuf);

   if (nlen >= sizeof(aClIOBuf)-20)
   {
      perr("HttpClient: request too long, cannot send: \"%.100s\"\n", aClIOBuf);
      return 9;
   }

   if (fGlblWebDump) {
      fprintf(fGlblWebDump, "-----req.begin-----\n");
      fwrite(aClIOBuf,1,nlen,fGlblWebDump);
      fprintf(fGlblWebDump, "-----req.done-----\n");
      fflush(fGlblWebDump);
   }

   size_t nsent = 0;

   #ifdef WITH_SSL
   if (bClSSL)
   {
      nsent = SSL_write(pClSSLSocket, aClIOBuf, nlen);
   }
   else
   #endif
   {
      nsent = pClCurCon->send((uchar*)aClIOBuf, strlen(aClIOBuf));
   }

   return 0;
}

int CoiData::getFtp(char *purl)
{__
   TCPCore::sysInit();

   if (pClFtp) return 0; // reuse

   int nprelen = strlen("ftp://");
   if ((int)strlen(purl) <= nprelen) return 9;

   // isolate base url with the hostname
   char szBase[200];
   strcopy(szBase, purl);
   char *psz = szBase + nprelen;
   psz = strchr(psz, '/');
   if (!psz) return 9;
   *psz = '\0';

   // now try to alloc the relevant client
   if (!(pClFtp = glblConCache.allocFtpClient(szBase))) {
      perr("unable to ftp to: %s", szBase);
      return 9;
   }

   return 0; // ok, use pClFtp
}

int CoiData::getHttp(char *purl)
{__
   TCPCore::sysInit();

   if (pClHttp) return 0; // reuse

   int nprelen = 0;

   if (strBegins(purl, "http://")) nprelen = 7;
   else
   if (strBegins(purl, "https://")) nprelen = 8;
   else
      return 0;

   // isolate base url with the hostname
   char szBase[200];
   strcopy(szBase, purl);
   char *psz = szBase + nprelen;
   psz = strchr(psz, '/');

   if (psz)
      *psz = '\0';
   // else it is http://justhost

   // now try to alloc the relevant client
   #ifdef USE_WEBCONCACHE
   if (!(pClHttp = glblConCache.allocHttpClient(szBase))) {
      perr("unable to http to: %s", szBase);
      return 9;
   }
   #else
   if (!(pClHttp = new HTTPClient(szBase))) {
      perr("unable to http to: %s", szBase);
      return 9;
   }
   #endif

   mtklog(("coidata.http.alloc done %p", pClHttp));

   return 0; // ok, use pClHttp
}

int CoiData::releaseFtp( ) 
{__
   if (!pClFtp)
      return 9+perr("releaseFtp without ptr, %p", this);
   pClFtp->decref("rft");
   pClFtp = 0;
   return 0;
}

int CoiData::releaseHttp( ) 
{__
   if (!pClHttp)
      return 9+perr("releasehttp without ptr, %p", this);

   pClHttp->resetCache();

   #ifdef USE_WEBCONCACHE
   pClHttp->decref("rht");
   #else
   delete pClHttp;
   #endif

   pClHttp = 0;

   return 0;
}

CoiTable &CoiData::elements( )
{
   if (!pelements) pelements = new CoiTable();
   return *pelements;
}

StringMap &CoiData::headers( )
{
   if (!pClHeaders) pClHeaders = new StringMap();
   return *pClHeaders;
}

StringMap &Coi::headers( ) {
   return data().headers();
}

char *Coi::header(cchar *pname) {
   if (!hasData()) return 0;
   if (!data().pClHeaders) return 0;
   return data().headers().get((char*)pname);
}

// PROVEN CODE. OLD CRAWL REQUIRES THIS !!!
bool sameDomainOld(char *psz1in, char *psz2in, int &rdomlen)
{
   char *psz1 = psz1in;
   char *psz2 = psz2in;

   if (strBegins(psz1, "http://"))  psz1 += 7;
   else
   if (strBegins(psz1, "https://")) psz1 += 8;
   else
      return 0;

   if (strBegins(psz2, "http://"))  psz2 += 7;
   else
   if (strBegins(psz2, "https://")) psz2 += 8;
   else
      return 0;

   // ignore any www.
   if (striBegins(psz1, "www.")) psz1 += 4;
   if (striBegins(psz2, "www.")) psz2 += 4;

   // isolate main domains
   if (!(psz1 = strchr(psz1, '/'))) return 0;
   if (!(psz2 = strchr(psz2, '/'))) return 0;
   char *psla1 = psz1+1; // including slash
   char *psla2 = psz2+1; // including slash

   int nlen1 = psla1 - psz1in;
   int nlen2 = psla2 - psz2in;
   if (nlen1 != nlen2) return 0;

   bool brc = strncmp(psz1in, psz2in, nlen1) ? 0 : 1;

   if (brc) rdomlen = nlen1;

   return brc;
}

// TODO: exakte definition was sameDomain eigentlich macht!
// ACHTUNG was will der aufrufer bei skiplen!
bool sameDomainNew(char *psz1in, char *psz2in, int &rskiplen1)
{
   char *psz1  = psz1in;
   char *psz2  = psz2in;
   char *edom1 = 0;
   char *edom2 = 0;
   char *psla1 = 0;
   char *psla2 = 0;

   if (strBegins(psz1, "http://"))  psz1 += 7;
   else
   if (strBegins(psz1, "https://")) psz1 += 8;
   else
      return 0;

   if (strBegins(psz2, "http://"))  psz2 += 7;
   else
   if (strBegins(psz2, "https://")) psz2 += 8;
   else
      return 0;

   // ignore any www.
   if (striBegins(psz1, "www.")) psz1 += 4;
   if (striBegins(psz2, "www.")) psz2 += 4;

   // isolate main domains from foo.com/ or foo.com:80/
   for (; *psz1!=0; psz1++) {
      if (*psz1==':' || *psz1=='/') {
         if (!edom1) edom1 = psz1-1;
      }
      if (*psz1=='/') {
         if (!psla1) psla1 = psz1;
      }
   }
   for (; *psz2!=0; psz2++) {
      if (*psz2==':' || *psz2=='/') {
         if (!edom2) edom2 = psz2-1;
      }
      if (*psz2=='/') {
         if (!psla2) psla2 = psz2;
      }
   }

   if (!edom1 || !edom2 || !psla1 || !psla2) {
      // printf("fail\n");
      return 0;
   }

   // set this to last char of domain name
   psz1 = edom1;
   psz2 = edom2;

   // step 2 dots back, or until /
   int ndots = 2;
   for (; psz1 > psz1in; psz1--) {
      if (*psz1 == '.' && !(--ndots)) break;
      if (*psz1 == '/') break;
   }
   char *pdom1 = psz1+1;
   int  nlen1 = edom1 - pdom1;

   // same on psz2
   ndots = 2;
   for (; psz2 > psz2in; psz2--) {
      if (*psz2 == '.' && !(--ndots)) break;
      if (*psz2 == '/') break;
   }
   char *pdom2 = psz2+1;
   int  nlen2 = edom2 - pdom2;

   if (nlen1 != nlen2)
      return 0;

   bool brc = strncmp(pdom1, pdom2, nlen1) ? 0 : 1;

   if (brc) rskiplen1 = (int)((psla1 + 1) - psz1in);

   return brc;
}

// list of non-traversable binary extensions
cchar *apBinExtList[] = {
   "jpg","gif","png",
   0 // EOD
};

int Coi::rawLoadDir(int ilevel)
{__
   if (data().bloaddirdone) {
      mtklog(("coi::loaddir: done, %d entries", data().elements().numberOfEntries()));
      return 1; // already done
   }
   data().bloaddirdone = 1;

   #ifdef SFKDEEPZIP
   if (cs.probefiles)
      probeFile();
   #endif // SFKDEEPZIP

   #ifdef VFILEBASE
   if (isFtp())   return rawLoadFtpDir();
   #endif // VFILEBASE

   return 9; // n/a with fsdirs
}

int Coi::setTypeFromHeaders( )
{
   StringMap *pheads = &headers();
   if (!pheads)
      return 5;

   char *pctype = pheads->get(str("content-type"));

   if (!pctype)
      return 5;

   return setTypeFromContentType(pctype);
}

int Coi::setTypeFromContentType(char *pctype)
{
   bClWebText=0;
   bClWebBinary=0;
   bClWebPage=0;
   bClWebJpeg=0;
   bClWebPNG=0;
   bClWebImage=0;
   
   if (striBegins(pctype, "image/jpeg")) {
      bClWebImage=1; bClWebJpeg=1;
      bClWebBinary=1; bClWebText=0;
      setBinaryFile(1);
      return 0;
   }
   if (striBegins(pctype, "image/png")) {
      bClWebImage=1; bClWebPNG=1;
      bClWebBinary=1; bClWebText=0;
      setBinaryFile(1);
      return 0;
   }
   if (   striBegins(pctype, "image/")
       || striBegins(pctype, "audio/")
       || striBegins(pctype, "video/")
       || striBegins(pctype, "application/x-msdos-program")
       || striBegins(pctype, "application/pdf")
       || striBegins(pctype, "application/zip")
      )
   {
      bClWebBinary=1; bClWebText=0;
      setBinaryFile(1);
      return 0;
   }
   if (   striBegins(pctype, "text/html")
       || striBegins(pctype, "application/xhtml")
       || striBegins(pctype, "application/rss+xml")
      )
   {
      bClWebText=1; bClWebPage=1;
      setBinaryFile(0);
      return 0;
   }
   if (   striBegins(pctype, "text/")
       || striBegins(pctype, "application/javascript")
       || striBegins(pctype, "application/x-javascript")
       || striBegins(pctype, "application/json")
       || striBegins(pctype, "application/xml")
      )
   {
      bClWebText=1;
      setBinaryFile(0);
      return 0;
   }
   if (  (strBegins(pctype, "application/") && strstr(pctype, "zip"))
       || strBegins(pctype, "application/x-tar")
       || strBegins(pctype, "application/x-compressed")
      )
   {
      setBinaryFile(1); // is binary
      setArc(1);        // but also an archive
      return 0;
   }

   return 5;
}

// .
int Coi::preloadFromWeb( )
{
   num nMaxSize = cs.maxwebsize;

   if (nMaxSize < 1000000)
       nMaxSize = 1000000;

   uchar *pLoadBuf  = new uchar[nMaxSize+1000];
   if (!pLoadBuf)
      return 9+perr("out of memory");

   int irc = 0;

   int iopenrc=0,iopenrc2=0;
   if ((iopenrc = open("rb")))
   {
      #ifndef SFKWEB
      return 5;
      #endif
   }

   char szCType[100]; mclear(szCType);

   int  iTotalRead  = 0;

   if ((nClHave & COI_HAVE_BINARY) == 0)
   {
      mtklog(("read probe"));

      // we have ZERO information. read probe.
      memset(pLoadBuf, 0, 1024);

      iTotalRead = read(pLoadBuf, 1024);

      if (iTotalRead > 0) {
         if (fGlblWebDump) {
            fprintf(fGlblWebDump, "-----probe.beg-----\n");
            fwrite(pLoadBuf,1,mymin(128,iTotalRead),fGlblWebDump);
            fprintf(fGlblWebDump, "-----probe.done-----\n");
            fflush(fGlblWebDump);
         }
         pLoadBuf[iTotalRead]='\0';
         // detect binary by content
         uchar *p = pLoadBuf;
         if (memchr(pLoadBuf, 0, iTotalRead)) {
            // detect image by content
            if (p[1]=='P' && p[2]=='N' && p[3]=='G') {
               bClWebImage=1; bClWebPNG=1;
               bClWebBinary=1; bClWebText=0;
               setBinaryFile(1);
            } else if (p[0]==0xFF && p[1]==0xD8) {
               bClWebImage=1; bClWebJpeg=1;
               bClWebBinary=1; bClWebText=0;
               setBinaryFile(1);
            } else {
               bClBinary = 1;
            }
         } else {
            bClBinary = 0;
         }
      } else {
         bClBinary = 0;
      }
      nClHave |= COI_HAVE_BINARY;

      bClWebBinary = bClBinary;
      bClWebText   = bClWebBinary ? 0 : 1;
   }

   // complete loading of object contents
   int iMaxRead = nMaxSize;

   do
   {
      if (nClHave & COI_HAVE_SIZE)
      {
         if (getSize() > iMaxRead)
         {
            pwarn("file too large: %s (%dm)\n", name(), (int)getSize()/1000000);
            pinf("use option -weblimit=n to change limit.\n");
            irc = 5;
            break;
         }
         iMaxRead = getSize();
      }
   
      while (iTotalRead < iMaxRead)
      {
         // it may be important to read all in one call
         int iRemainSpace = iMaxRead - iTotalRead;
         int iBytes = read(pLoadBuf+iTotalRead, iRemainSpace);
         if (iBytes <= 0)
            break;
         iTotalRead += iBytes;
      }
   
      // store a copy in coi which becomes owner
      uchar *ptmp = new uchar[iTotalRead+10];

      if (!ptmp)
         return 9+perr("outofmem");

      memcpy(ptmp, pLoadBuf, iTotalRead);
      ptmp[iTotalRead] = '\0';

      setContent(ptmp, iTotalRead, nClMTime);

      mtklog(("preload sets CACHED DATA with %d bytes", iTotalRead));
   }
   while (0);

   close();
   
   delete [] pLoadBuf;

   return irc;
}

// caller MUST RELEASE COI after use!
Coi *Coi::rawNextFtpEntry( ) 
{
   if (!data().bdiropen) {
      perr("ftp nextEntry() called without openDir()");
      return 0;
   }

   Coi *psubsrc = 0;

   #ifndef DEEP_FTP
   do
   #endif
   {
      // something left to return?
      if (data().nNextElemEntry >= data().elements().numberOfEntries())
         return 0; // end of list

      // return a COPY from the internal list entries.
      psubsrc = data().elements().getEntry(data().nNextElemEntry, __LINE__);
      data().nNextElemEntry++;
   }
   #ifndef DEEP_FTP
   while (psubsrc->isTravelDir()); // for now, SKIP dir entries of ftp
   #endif

   // if there is a global cache entry machting this sub,
   Coi *pcached = glblVCache.get(psubsrc->name());

   // caller MUST RELEASE COI after use!

   if (pcached) 
   {
      bool bhasptr = pcached->data().src.data ? 1 : 0; (void)bhasptr;
      mtklog(("coi::nextftpentry cache hit %d %d %s", (int)bhasptr, (int)pcached->data().src.size, pcached->name()));
      return pcached;
   }
   else 
   {
      Coi *psubdst = psubsrc->copy();
      psubdst->incref("nft");
      mtklog(("coi::nextftpentry cache miss, returning copy of %s", psubdst->name()));
      return psubdst;
   }
}

void Coi::rawCloseFtpDir( ) {
   // see remarks in rawCloseZipDir
   data().bdiropen = 0;
}

int Coi::rawOpenFtpSubFile(cchar *pmode) 
{
   if (!isFtp()) return 9;
   if (strcmp(pmode, "rb")) return 9;

   // get client for that base url
   if (data().getFtp(name())) return 9;

   // use supplied client, release after dir download
   FTPClient *pftp = data().pClFtp;

   // isolate hostname from url
   if (pftp->splitURL(name())) {
      perr("ftp: wrong url format: %s", name());
      return 9;
   }
   // nRelIndex is now the relative path start index.
   char *phost    = pftp->curhost();
   char *prelfile = pftp->curpath();
   int  nport    = pftp->curport();

   mtklog((" ftp open host \"%s\" file \"%s\"", phost, prelfile));

   int nrc = 0;

   for (int itry=0; itry<2; itry++)
   {
      if (pftp->loginOnDemand(phost, nport))
         return 9;

      nrc = pftp->openFile(prelfile, pmode);
      // RC  9 == general error, e.g. file not available
      // RC 10 == communication failed, connection invalid

      if (nrc < 10)
         break;

      // loginOnDemand thought the line is still valid, but it isn't.
      pinf("ftp session expired, retrying\n");
   
      // devalidate session, relogin and retry
      pftp->logout();
   }
   
   if (nrc) {
      if (nrc > 9) {
         pinf("ftp communication failed (connection closed)\n");
         pftp->logout();
      }
      data().releaseFtp();  // failed
   }
   else
      data().bfileopen = 1;

   // general releaseFtp is done after file download.

   return nrc;
}

int Coi::rawOpenHttpSubFile(cchar *pmode)
{__
   if (!isHttp()) return 9;
   if (strcmp(pmode, "rb")) return 9;

   if (data().getHttp(name())) return 9;
   HTTPClient *phttp = data().pClHttp;

   mtklog(("http-open %s",name()));

   int nrc = phttp->open(name(), pmode, this);
   // may redirect and change current coi's name!

   if (nrc) {
      if (nrc==11 && !cs.verbose)
         { }
      else
      {
         if (root(1)) pinf("[nopre] from : %s\n", root());
         if (ref(1))  pinf("[nopre] ref  : %s\n", ref());
      }
   } else {
      data().bfileopen = 1;
   }

   return nrc;
}

extern char *getxlinfo();
extern num   getxllim();

size_t Coi::rawReadFtpSubFile(void *pbufin, size_t nBufSize) 
{
   if (!data().pClFtp || !data().bfileopen) {
      perr("ftp not open, cannot read: %s (%d)", name(), data().bfileopen);
      return 0;
   }

   int nread = data().pClFtp->readFile((uchar*)pbufin, (int)nBufSize);
   mtklog((" ftp read %s %u done %d", name(), (uint)nBufSize, nread));

   return (nread >= 0) ? nread : 0;
}

size_t Coi::rawReadHttpSubFile(void *pbufin, size_t nBufSize) 
{__
   if (!data().pClHttp || !data().bfileopen) {
      perr("http not open, cannot read: %s (%d)", name(), data().bfileopen);
      return 0;
   }

   int nread = data().pClHttp->read((uchar*)pbufin, (int)nBufSize);
   mtklog(("http-read done=%d buf=%p max=%d", nread, pbufin, (int)nBufSize));

   return (nread >= 0) ? nread : 0;
}

void Coi::rawCloseFtpSubFile( ) 
{
   mtklog(("ftp-close %s", name()));

   if (!data().pClFtp) {
      mtklog(("close.ftp already done: %s",name()));
      return;
   }

   data().pClFtp->closeFile();

   // release connection ptr, without closing it:
   data().releaseFtp();

   data().bfileopen = 0;
}

void Coi::rawCloseHttpSubFile( ) 
{__
   mtklog(("http-close %s", name()));

   if (!hasData()) {
      mtklog(("close.http already done: %s",name()));
      return;
   }

   if (!data().pClHttp) {
      mtklog(("close.http already done: %s",name()));
      return; 
   }

   // so far, coi http core can NOT reuse the same connection
   // for multiple commands, so we MUST close the socket.
   // (otherwise GET without full read must be avoided)
   data().pClHttp->close();

   // release connection ptr, without closing it:
   data().releaseHttp();

   data().bfileopen = 0;
}

int Coi::prefetch(bool bLoadNonArcBinaries, num nFogSizeLimit, num nHardSizeLimit)
{
   return preload("dvw", 0, bLoadNonArcBinaries ? 1 : 2); // dview
}

// .
int Coi::preload(cchar *pszFromInfo, uchar **ppout, num &rsize, int iStopMode)
{
   int isubrc = preload(pszFromInfo, 0, iStopMode, 1); // internal
   if (isubrc) return isubrc;

   *ppout = data().src.data;
   rsize  = data().src.size;

   return 0;
}

// stopmode 0: load everything
// stopmode 1: load no binaries except archives
// stopmode 2: load no binaries
int Coi::preload(cchar *pszFromInfo, bool bsilent, int iStopMode, bool bfile)
{
   if (data().src.data)
      return 0; // nothing to do

   if (cs.debug)
      printf("preload.1: %s %d mode=%d file=%d %s\n", pszFromInfo, bsilent, iStopMode, bfile, name());

   bool bIsZipTrav = isTravelZip(111,1);
   bool bIsZipSub  = isZipSubEntry();
   bool bIsZipAny  = (bIsZipTrav || bIsZipSub);

   if (isNet()) // && bIsZipTrav)
      {_ } // accept, need to cache whole file
   else
   if (bIsZipSub)
      {_ } // accept, need to cache sub entry via parent
   else 
   if (!bfile) {
      // physical file: no preload
      return 0;
   }

   num  nLoadLimit   = nGlblMemLimit;
   cchar *pszLimitOpt= "-memlimit";
   num  nAllocSize   = 2000000; // 2 mb
   bool bStreamLoad  = 1;

   if (isHttp()) {
      nLoadLimit  = cs.maxwebsize;
      pszLimitOpt = "-weblimit";
   }

   int iopenrc=0,iopenrc2=0;

   if ((iopenrc = open("rb")))
   do
   {
      if (isHttp())
      {
      }

      // if (!bsilent)
      //    pwarn("cannot read: %s\n", name());

      return 9;
   }
   while (0);

   if (hasSize()) {
      nAllocSize  = getSize();
      bStreamLoad = 0;
      if (cs.debug) printf("preload.2: have=%u size=%d\n",nClHave,(int)nAllocSize);
   } else {
      if (cs.debug) printf("preload.2: have=%u alloc=%d\n",nClHave,(int)nAllocSize);
   }

   if (nAllocSize < 0) {
      close();
      return 9;
   }

   if (nAllocSize > nLoadLimit) {
      close();
      if (!bsilent) {
         pwarn("file too large, skipping: %s\n", name());
         if (pszLimitOpt)
            pinf("use option %s to change load limit\n", pszLimitOpt);
      }
      return 1; // block loading
   }

   uchar *pdata  = new uchar[nAllocSize+100];
   num    nused  = 0;

   if (!pdata) { // safety
      close();
      return 9+perr("out of memory (%d)\n", (int)(nAllocSize/1000000));
   }

   if (   iStopMode > 0
       && (nClHave & COI_HAVE_BINARY) == 0
      )
   {
      mtklog(("read probe"));

      int nProbeSize = mymin(1024, nAllocSize);

      memset(pdata, 0, nProbeSize);

      nused = read(pdata, nProbeSize);

      if (nused < 0) {
         close();
         return 9+perr("cannot read: %s\n", name());
      }

      pdata[nused]='\0';
      uchar *p = pdata;

      if (nused>0 && memchr(pdata, 0, nused)) {
         if (p[1]=='P' && p[2]=='N' && p[3]=='G') {
            bClWebImage=1; bClWebPNG=1;
            bClWebBinary=1; bClWebText=0;
            setBinaryFile(1);
         } else if (p[0]==0xFF && p[1]==0xD8) {
            bClWebImage=1; bClWebJpeg=1;
            bClWebBinary=1; bClWebText=0;
            setBinaryFile(1);
         } else {
            bClBinary = 1;
         }
      } else {
         bClBinary = 0;
      }
      nClHave |= COI_HAVE_BINARY;

      bClWebBinary = bClBinary;
      bClWebText   = bClWebBinary ? 0 : 1;
   }

   bool bIsKnownBinary = ((nClHave & COI_HAVE_BINARY) && bClBinary) ? 1 : 0;
   bool bIsKnownArc    = ((nClHave & COI_HAVE_ARC   ) && bClArc   ) ? 1 : 0;

   switch (iStopMode)
   {
      case 0: // load everything
         break;

      case 1: // load no binaries except archives
         if (bIsKnownBinary && !bIsKnownArc)
         {
            if (cs.debug)
               printf("preload stop: binary and no archive\n");
            close();
            return 2; // skip download and caching as it's not text, and no archive
         }
         break;

      case 2: // load no binaries
         if (bIsKnownBinary)
         {
            if (cs.debug)
               printf("preload stop: binary\n");
            close();
            return 3; // skip download and caching as it's not text, and no archive
         }
         break;
   }

   if (cs.debug) printf("preload.4: probe=%d\n",(int)nused);
   
   while (1)
   {
      num nrem = nAllocSize - nused;

      if (bStreamLoad)
      {
         // expand buffer by next stream data
         if (nrem < nAllocSize / 4)
         {
            num nAllocSize2 = nAllocSize * 2;
            uchar *ptmp = new uchar[nAllocSize2+100];
            memcpy(ptmp, pdata, nused);
            delete [] pdata;
            pdata  = ptmp;

            nAllocSize = nAllocSize2;
            nrem       = nAllocSize - nused;
         }
      }
      else if (nused >= nAllocSize)
      {
         break;
      }

      num nread = read(pdata+nused, nrem);

      // if (cs.debug) printf("preload.5: read %d\n",(int)nread);

      if (nread <= 0)
         break;

      nused += nread;
   }

   if (bStreamLoad)
   {
      // how much is left empty in read cache?
      num nrem = nAllocSize - nused;
      if (nrem > 1000)
      {
         // adapt to the size really used
         num nAllocSize2 = nused + 100;
         uchar *ptmp = new uchar[nAllocSize2];
         memcpy(ptmp, pdata, nused);
         delete [] pdata;
         pdata  = ptmp;

         nAllocSize = nAllocSize2;
      }
   }

   close();

   pdata[nused] = '\0'; // is guaranteed

   if (cs.debug) printf("preload.6: data %p used=%d\n",pdata,(int)nused);
   
   setContent(pdata, nused, nClMTime);

   return 0;
}

int Coi::provideInput(cchar *pszFromInfo, bool bsilent)
{
   return preload(pszFromInfo, bsilent, 1); // provideInput
}

Coi *Coi::getElementByAbsName(char *pabsname)
{__
   if (!data().elements().numberOfEntries())
      if (rawLoadDir() >= 5)
         return 0;

   // check absname, if it matches ourselves at all
   if (!striBegins(pabsname, name())) {
      // should NOT happen
      pwarn("cannot get element, name mismatch: %s / %s", pabsname, name());
      return 0;
   }

   Coi *psub = 0;
   for (int i=0; i<data().elements().numberOfEntries(); i++)
   {
      psub = data().elements().getEntry(i, __LINE__);
      if (!strcmp(psub->name(), pabsname)) break;
   }

   return psub;
}

bool Coi::isFtp() {
   #ifdef VFILENET
   if (nGlblCoiConfig & COI_CAPABILITY_NET)
      return strBegins(name(), "ftp://");
   #endif // VFILENET
   return 0;
}

bool Coi::isHttp(char *pszOptURL) {
   #ifdef VFILENET
   char *psz = pszOptURL ? pszOptURL : name();
   if (nGlblCoiConfig & COI_CAPABILITY_NET) {
      if (strBegins(psz, "http://"))
         return 1;
      if (strBegins(psz, "https://"))
         return 1;
   }
   #endif // VFILENET
   return 0;
}

bool Coi::isNet() {
   return isHttp() || isFtp();
}

bool Coi::isVirtual(bool bWithRootZips)
{
   if (isNet() || isZipSubEntry())     return 1;
   if (bWithRootZips && isTravelZip(109)) return 1;
   return 0;
}

bool Coi::rawIsFtpDir() 
{
   if (!isFtp()) return 0;

   // try to detect by name
   char *pnam = name();
   int nlen  = strlen(pnam);
   if (nlen > 0 && pnam[nlen-1] == '/')
      return 1;

   // but also use the coi flag
   return bClDir;
}

int Coi::readWebHead( )
{
   if (!isHttp())
      return 9;

   if (data().getHttp(name()))
      return 9;

   HTTPClient *phttp = data().pClHttp;

   if (phttp->getFileHead(name(), this, "head"))
      return 9+perr("cannot get headers: %s", name());

   return 0;
}

// TODO: rework error rc handling?
bool Coi::rawIsHttpDir(int ilevel) 
{__
   #ifdef SFKINT
   pwarn("isdir: wrong http call sequence.\n");
   #endif

   return 0;
}

int Coi::rawLoadFtpDir( ) 
{
   if (!isFtp()) return 9;

   // get client for that base url
   if (data().getFtp(name())) return 9;

   // use supplied client, release after dir download
   FTPClient *pftp = data().pClFtp;
   if (pftp->splitURL(name())) {
      perr("ftp: wrong url format: %s", name());
      data().releaseFtp();
      return 9;
   }
   // nRelIndex is now the relative path start index.
   char *phost = pftp->curhost();
   char *ppath = pftp->curpath();
   int  nport = pftp->curport();

   mtklog((" ftp open host \"%s\" path \"%s\"", phost, ppath));

   if (pftp->loginOnDemand(phost, nport)) {
      data().releaseFtp();
      return 9+perr("ftp login failed: %s", phost);
   }

   // let the ftp client fill our elements list.
   // it must prefix any name by our name.
   CoiTable *plist = &data().elements();
   plist->resetEntries(); // if any
   if (pftp->list(ppath, &plist, name())) {
      data().releaseFtp();
      return 9+perr("ftp list failed: %s", phost);
   }

   // list downloaded: do NOT close connection
   //   pftp->logout();
   // as it may be used for subsequent downloads

   // start from zip entry 0
   data().nNextElemEntry = 0;

   // current I/O job done: release the client,
   // meaning the refcnt is dec'ed, but NO logout.
   data().releaseFtp();

   return 0;
}

num Coi::getUsedBytes()
{
   num nsize = sizeof(*this);

   if (pszClName)   nsize += strlen(pszClName)+1;
   if (pszClRoot)   nsize += strlen(pszClRoot)+1;
   if (pszClRef)    nsize += strlen(pszClRef)+1;
   if (pszClExtStr) nsize += strlen(pszClExtStr)+1;

   if (hasData()) {
      nsize += sizeof(CoiData);
      CoiData *p = pdata;
      nsize += p->src.size;
      if (p->prelsubname)  nsize += strlen(p->prelsubname)+1;
      if (p->pdirpat    )  nsize += strlen(p->pdirpat)+1;
   }

   // NOT considered, as they are volatile and may have
   // different values on cache put and remove:
   //    rbuf.data, pzip

   return nsize;
}

#endif // VFILEBASE

// ----------------------------------------------------------------

int netErrno()
{
   #ifdef _WIN32
   return WSAGetLastError();
   #else
   return errno;
   #endif
}

char *netErrStr()
{
   int ncode = netErrno();

   static char szErrBuf[200];
 
   const char *perr = "";

   #ifdef _WIN32
   switch (ncode)
   {
      case WSAEWOULDBLOCK      : perr="WSAEWOULDBLOCK"; break;
      case WSAEINPROGRESS      : perr="WSAEINPROGRESS"; break;
      case WSAEALREADY         : perr="WSAEALREADY"; break;
      case WSAENOTSOCK         : perr="WSAENOTSOCK"; break;
      case WSAEDESTADDRREQ     : perr="WSAEDESTADDRREQ"; break;
      case WSAEMSGSIZE         : perr="WSAEMSGSIZE"; break;
      case WSAEPROTOTYPE       : perr="WSAEPROTOTYPE"; break;
      case WSAENOPROTOOPT      : perr="WSAENOPROTOOPT"; break;
      case WSAEPROTONOSUPPORT  : perr="WSAEPROTONOSUPPORT"; break;
      case WSAESOCKTNOSUPPORT  : perr="WSAESOCKTNOSUPPORT"; break;
      case WSAEOPNOTSUPP       : perr="WSAEOPNOTSUPP"; break;
      case WSAEPFNOSUPPORT     : perr="WSAEPFNOSUPPORT"; break;
      case WSAEAFNOSUPPORT     : perr="WSAEAFNOSUPPORT"; break;
      case WSAEADDRINUSE       : perr="WSAEADDRINUSE"; break;
      case WSAEADDRNOTAVAIL    : perr="WSAEADDRNOTAVAIL"; break;
      case WSAENETDOWN         : perr="WSAENETDOWN"; break;
      case WSAENETUNREACH      : perr="WSAENETUNREACH"; break;
      case WSAENETRESET        : perr="WSAENETRESET"; break;
      case WSAECONNABORTED     : perr="WSAECONNABORTED"; break;
      case WSAECONNRESET       : perr="WSAECONNRESET"; break;
      case WSAENOBUFS          : perr="WSAENOBUFS"; break;
      case WSAEISCONN          : perr="WSAEISCONN"; break;
      case WSAENOTCONN         : perr="WSAENOTCONN"; break;
      case WSAESHUTDOWN        : perr="WSAESHUTDOWN"; break;
      case WSAETOOMANYREFS     : perr="WSAETOOMANYREFS"; break;
      case WSAETIMEDOUT        : perr="WSAETIMEDOUT"; break;
      case WSAECONNREFUSED     : perr="WSAECONNREFUSED"; break;
      case WSAELOOP            : perr="WSAELOOP"; break;
      case WSAENAMETOOLONG     : perr="WSAENAMETOOLONG"; break;
      case WSAEHOSTDOWN        : perr="WSAEHOSTDOWN"; break;
      case WSAEHOSTUNREACH     : perr="WSAEHOSTUNREACH"; break;
      case WSAENOTEMPTY        : perr="WSAENOTEMPTY"; break;
      case WSAEUSERS           : perr="WSAEUSERS"; break;
      case WSAEDQUOT           : perr="WSAEDQUOT"; break;
      case WSAESTALE           : perr="WSAESTALE"; break;
      case WSAEREMOTE          : perr="WSAEREMOTE"; break;
   }
   #else
   switch (ncode)
   {
      case EWOULDBLOCK         : perr="EWOULDBLOCK"; break;
      case EINPROGRESS         : perr="EINPROGRESS"; break;
      case EALREADY            : perr="EALREADY"; break;
      case ENOTSOCK            : perr="ENOTSOCK"; break;
      case EDESTADDRREQ        : perr="EDESTADDRREQ"; break;
      case EMSGSIZE            : perr="EMSGSIZE"; break;
      case EPROTOTYPE          : perr="EPROTOTYPE"; break;
      case ENOPROTOOPT         : perr="ENOPROTOOPT"; break;
      case EPROTONOSUPPORT     : perr="EPROTONOSUPPORT"; break;
      case ESOCKTNOSUPPORT     : perr="ESOCKTNOSUPPORT"; break;
      case EOPNOTSUPP          : perr="EOPNOTSUPP"; break;
      case EPFNOSUPPORT        : perr="EPFNOSUPPORT"; break;
      case EAFNOSUPPORT        : perr="EAFNOSUPPORT"; break;
      case EADDRINUSE          : perr="EADDRINUSE"; break;
      case EADDRNOTAVAIL       : perr="EADDRNOTAVAIL"; break;
      case ENETDOWN            : perr="ENETDOWN"; break;
      case ENETUNREACH         : perr="ENETUNREACH"; break;
      case ENETRESET           : perr="ENETRESET"; break;
      case ECONNABORTED        : perr="ECONNABORTED"; break;
      case ECONNRESET          : perr="ECONNRESET"; break;
      case ENOBUFS             : perr="ENOBUFS"; break;
      case EISCONN             : perr="EISCONN"; break;
      case ENOTCONN            : perr="ENOTCONN"; break;
      case ESHUTDOWN           : perr="ESHUTDOWN"; break;
      case ETOOMANYREFS        : perr="ETOOMANYREFS"; break;
      case ETIMEDOUT           : perr="ETIMEDOUT"; break;
      case ECONNREFUSED        : perr="ECONNREFUSED"; break;
      case ELOOP               : perr="ELOOP"; break;
      case ENAMETOOLONG        : perr="ENAMETOOLONG"; break;
      case EHOSTDOWN           : perr="EHOSTDOWN"; break;
      case EHOSTUNREACH        : perr="EHOSTUNREACH"; break;
      case ENOTEMPTY           : perr="ENOTEMPTY"; break;
      case EUSERS              : perr="EUSERS"; break;
      case EDQUOT              : perr="EDQUOT"; break;
      case ESTALE              : perr="ESTALE"; break;
      case EREMOTE             : perr="EREMOTE"; break;
   }
   #endif

   #ifdef _WIN32
   if (strBegins((char*)perr, "WSA")) perr += 3;
   #endif

   if (strlen(perr))
      snprintf(szErrBuf, sizeof(szErrBuf)-10, "status=%d (%s)", ncode, perr);
   else
      snprintf(szErrBuf, sizeof(szErrBuf)-10, "status=%d", ncode);

   return szErrBuf;
}

// ----------------------------------------------------------------

UDPIO::UDPIO( )
{
   rawInit();
}

void UDPIO::rawInit( )
{
   memset(this, 0, sizeof(*this));

   fdClSocket = INVALID_SOCKET;
   mclear(szClDescription);
   mclear(clTargetAddr);
   mclear(clRawInAddr);
   mclear(clInBufInAddr);
   iClOwnReceivePort = 0;
   iClTargetSendPort = 0;
   bClMulticast = 0;
   bClVerbose = false;
   iClPackageSize = 1000;
   bClRawText = 0;
   iClReqNum = 1;
   iClTimeout = 1000;
   cClCurrentInColor = ' ';
   cClTellColor = '\0';
   iClUsingAltPortInsteadOf = -1;
   iClNonDuplexSendDelay = 10;
}

UDPIO::~UDPIO( )
{
   if (fdClSocket != INVALID_SOCKET)
      closesocket(fdClSocket);
}

bool UDPIO::isOpen( )
{
   return (fdClSocket != INVALID_SOCKET) ? 1 : 0;
}

int UDPIO::closeAll( )
{
   if (fdClSocket != INVALID_SOCKET)
   {
      closesocket(fdClSocket);
   }

   rawInit();
 
   return 0;
}

bool UDPIO::isMulticast( )
{
   return bClMulticast;
}

// RC  9 : cannot create socket
//    10 : cannot bind socket
//    11 : cannot multicast
int UDPIO::initSendReceive
 (
   const char *pszDescription,
   int iOwnReceivePort,
   int iTargetSendPort,
   char *pszTargetAddress,
   uint uiFlags
 )
{
   strcopy(szClDescription, pszDescription);

   iClOwnReceivePort = iOwnReceivePort;
   iClTargetSendPort = iTargetSendPort;
   iClUsingAltPortInsteadOf = -1;

   // printf("UDP: initSendReceive ownport=%d targport=%d addr=%s\n",
   //   iOwnReceivePort, iTargetSendPort, pszTargetAddress);

   bClMulticast = (uiFlags & 1) ? 1 : 0;
   bool bReuse  = (uiFlags & 2) ? 1 : 0;
   bool bRetry  = (uiFlags & 4) ? 1 : 0;

   if (pszTargetAddress && strchr(pszTargetAddress, '.'))
   {
      // check for multicast addresses "224.x" to "239.x"
      int iFirstPart = atoi(pszTargetAddress);
      if (iFirstPart >= 224 && iFirstPart <= 239)
         bClMulticast = true;
   }

   int fdTmp = socket(AF_INET, SOCK_DGRAM, 0);

   if (fdTmp < 0)
   {
      perr("Error creating socket for %s. errno=%u %s\n",
         szClDescription, netErrno(), netErrStr());
      return 9;
   }

   if (bReuse)
   {
      int nOnVal = 1;
      setsockopt(fdTmp, SOL_SOCKET, SO_REUSEADDR, (const char *)&nOnVal, sizeof(nOnVal));
   }

   if (iOwnReceivePort >= 0)
   {
      int iMaxTry = bRetry ? 5 : 1;

      for (int itry=0; itry<iMaxTry; itry++)
      {
         // on port conflict, retry 10 ports higher
         iClOwnReceivePort = iOwnReceivePort + itry * 10;
   
         // own address for input
         struct sockaddr_in saOwnAddr;
         memset((char *)&saOwnAddr, 0,sizeof(saOwnAddr));

         saOwnAddr.sin_family      = AF_INET;
         saOwnAddr.sin_port        = htons(iClOwnReceivePort);
         saOwnAddr.sin_addr.s_addr = INADDR_ANY;
      
         if (bind(fdTmp, (struct sockaddr *)&saOwnAddr, sizeof(saOwnAddr)) >= 0) {
            if (itry > 0)
               iClUsingAltPortInsteadOf = iOwnReceivePort;
            break; // OK
         }

         if (itry < iMaxTry-1) {
            pwarn("Cannot listen on port %d, retrying on %d.", iClOwnReceivePort, iClOwnReceivePort+10);
            // and reloop
         } else {
            perr("Cannot listen on port %d, rc=%d.", iClOwnReceivePort, netErrno());
            perr("Missing access rights, or port used by other program.\n");
            return 10;
         }
      }
   }

   if (isMulticast())
   {
      struct ip_mreq mreq;
      memset(&mreq, 0, sizeof(mreq));
      mreq.imr_interface.s_addr = htonl(INADDR_ANY);

      #if defined(MAC_OS_X) || defined(SOLARIS)
        #define SOL_IP IPPROTO_IP
      #endif

      #ifdef _WIN32
 
      char name[512];
      PHOSTENT hostinfo;
      mclear(name);
      mclear(hostinfo);

      if (gethostname(name, sizeof(name)))
         return 11+perr("gethostname failed\n");

      if (!(hostinfo=gethostbyname(name)))
         return 11+perr("get ownhost failed (%s) (2)\n", name);

      struct in_addr *pin_addr = (struct in_addr *)*hostinfo->h_addr_list;
      mreq.imr_interface.s_addr = pin_addr->s_addr;
      mreq.imr_multiaddr.s_addr = inet_addr(pszTargetAddress);

      // force IP_ADD_MEMBERSHIP of ws2tcpip.h
      #define MY_IP_ADD_MEMBERSHIP 12

      if (setsockopt(fdTmp, IPPROTO_IP, MY_IP_ADD_MEMBERSHIP, (char *)&mreq, sizeof(mreq)) != 0 )
         return 11+perr("Join multicast failed. Errno=%u (%s)",  netErrno(), netErrStr());

      // in case of error 10042 see
      //    http://support.microsoft.com/kb/257460
      // wrong winsocket header, runtime linkage etc.
 
      #else

      if (inet_aton(pszTargetAddress, &mreq.imr_multiaddr) == 0)
      {
         perr("Join multicast failed: bad address %s\n", pszTargetAddress);
         return 11; // cannot multicast
      }

      if (setsockopt(fdTmp, SOL_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq)) != 0 )
      {
         perr("No default-route to support multicast.");
         perr("Try 'route add -net 224.000 netmask 240.000 eth0'");
         return 11;
      }

      #endif
 
      // printf("mcast: fd=%d outport=%d inport=%d group=%s active.\n",
      //   fdTmp, iClTargetSendPort, iClOwnReceivePort, pszTargetAddress);

      // do not call gethostbyname, but set addr manually
      memset((char *)&clTargetAddr, 0,sizeof(clTargetAddr));

      clTargetAddr.sin_family      = AF_INET;
      clTargetAddr.sin_addr.s_addr = inet_addr(pszTargetAddress);
      clTargetAddr.sin_port        = htons((int)iClTargetSendPort);
   }
   else if (pszTargetAddress)
   {
      // printf("udp: fd=%d outport=%d inport=%d active.\n",
      //   fdTmp, iClTargetSendPort, iClOwnReceivePort);

      if (setTarget(pszTargetAddress, iClTargetSendPort))
         return 12;
   }
 
   fdClSocket = fdTmp;

   return 0;
}

int UDPIO::setTarget(char *pszTargetAddress, int iTargetPort)
{
   memset((char *)&clTargetAddr, 0,sizeof(clTargetAddr));

   clTargetAddr.sin_family = AF_INET;
   clTargetAddr.sin_port   = htons((int)iTargetPort);
   if (setaddr(&clTargetAddr, pszTargetAddress))
      return 11;

   return 0;
}

// RC  0 : OK
//     9 : send failed, no socket
//    10 : send failed, transmission error
//    11 : send failed, wrong parameters
int UDPIO::sendData(uchar *pData, int iDataSize)
{
   if (fdClSocket == INVALID_SOCKET)
      return 9+perr("send: invalid UDP socket\n");

   if (sendto(fdClSocket, (char *)pData, iDataSize, 0,
          (struct sockaddr *)&clTargetAddr, sizeof(clTargetAddr)) != iDataSize)
   {
      perr("send: failed errno=%d %s\n", netErrno(), netErrStr());
      return 12;
   }

   return 0;
}

// RC >  0 : number of bytes received
// RC <= 0 : error
int UDPIO::receiveData(
   uchar *pBuffer, int iBufferSize,
   struct sockaddr_in *pAddrIncoming,
   int iSizeOfAddrIncoming
 )
{
   if (fdClSocket == INVALID_SOCKET)
      return -1;

   int iRead = 0;

   if (isDataAvailable(0, 0))
   {
      struct sockaddr addrIncoming;
      memset(&addrIncoming, 0, sizeof(addrIncoming));
   
      socklen_t clilen = sizeof(addrIncoming);
   
      // receive with 10 bytes buffer tolerance.
      // result is guaranteed to be zero terminated.
      iRead = recvfrom(fdClSocket, (char*)pBuffer, iBufferSize-10, 0, &addrIncoming, &clilen);
   
      if (pAddrIncoming != 0 && clilen == iSizeOfAddrIncoming)
         memcpy(pAddrIncoming, &addrIncoming, iSizeOfAddrIncoming);
   }

   // always guarantee zero termination.
   if (iRead >= 0)
      pBuffer[iRead] = '\0';

   return iRead;
}

bool UDPIO::isDataAvailable(int iSec, int iMSec)
{
   if (fdClSocket == INVALID_SOCKET)
      return false;

   struct timeval tv;
   fd_set fdvar;

   tv.tv_sec  = iSec;
   tv.tv_usec = iMSec ? iMSec * 1000 : 100;

   FD_ZERO(&fdvar);
   FD_SET(fdClSocket, &fdvar);

   if (select(fdClSocket+1, &fdvar, 0, 0, &tv) > 0)
      return 1;

   return 0;
}

// SYNC also: sendDuplexReply
int UDPIO::addHeader( )
{
   iClRecentReqNum = iClReqNum;

   char szStartColor[20];
   szStartColor[0] = '\0';
   if (cClTellColor) 
   {
      sprintf(szStartColor, ",sc%c", cClTellColor);
      cClTellColor = '\0';
   }

   sprintf(aClRawOutBuf, ":sfktxt:v100,req%d%s,rt0%s%s,fl\n", 
      iClReqNum++,
      bClDuplex ? ",copy" : "",
      bClColor ? ",cs1" : "",
      szStartColor
      );

   // remember index of retry number
   char *psz = strstr(aClRawOutBuf, ",rt0");
   if (psz)
      iClRetryOff = (psz - aClRawOutBuf) + 3;
   
   // remember index of split line indicator
   iClSLIOff = strlen(aClRawOutBuf) - 3;

   for (int i=0; i<iClCommand; i++) 
   {
      strcat(aClRawOutBuf, ":");
      strcat(aClRawOutBuf, aClCommand[i]);
      strcat(aClRawOutBuf, "\n");
   }
   strcat(aClRawOutBuf, "\n");
   
   iClCommand = 0;

   iClHeadSize = strlen(aClRawOutBuf);
   iClOutIndex = iClHeadSize;
   return 0;
}

bool UDPIO::hasCachedOutput( )
{
   return iClOutIndex > iClHeadSize ? 1 : 0;
}

int UDPIO::flushSend(bool bTellAboutSplitLine)
{
   // set optional split line indicator in header
   if (   !bClRawText && bTellAboutSplitLine 
       && iClSLIOff > 0 && iClSLIOff < iClHeadSize
      )
      aClRawOutBuf[iClSLIOff] = 's'; // ,fl -> ,sl

   int irc = 0;
   int itry = 0;
   
   // printf("-----------------------------\n");

   for (; itry<10; itry++)
   {
      if (itry >= 5) {
         perr("line broken, failed to send package %d times.\n", itry);
         irc = 9;
         break;
      }   
      
      if (iClRetryOff > 0 && iClRetryOff < iClHeadSize) {
         aClRawOutBuf[iClRetryOff] = itry + '0';
      }

      if ((irc = sendData((uchar*)aClRawOutBuf, iClOutIndex)))
         break;
         
      // printf("SENT: %s\n", aClRawOutBuf);

      if (bClDuplex)
      {
         if (!isDataAvailable(0, iClTimeout))
            continue; // retry send

         aClRawInBuf2[0] = '\0';

         int i = receiveData((uchar*)aClRawInBuf2, sizeof(aClRawInBuf2)-100);
         if (i <= 0)
            continue; // retry send

         // printf("RECV: \"%s\" (%d)\n", aClRawInBuf2, i);

         // :sfktxt:v100,rep123,ok\n\n
         char *psz = strstr(aClRawInBuf2, ",rep");
         if (!psz) {
            perr("wrong -duplex reply received: %.30s", aClRawInBuf2);
            irc = 9;
            break;
         }

         int iReqNum = iClRecentReqNum;
         int iRepNum = atoi(psz+4);
         if (iRepNum < iReqNum) 
         {
            // happens when sending retry requests which are answered 
            // AFTER we already sent the next original request.
            pwarn("duplex: old reply record (%d/%d), lines may be duplicated\n", iReqNum, iRepNum);
            irc = 5;
            break;
         }
         else
         if (iRepNum != iReqNum)
         {
            // should not happen.
            pwarn("duplex: wrong reply record (%d/%d), lines may be invalid\n", iReqNum, iRepNum);
            irc = 5;
            break;
         }

         // package was fully confirmed
         break;
      }
      else
      {
         if (iClNonDuplexSendDelay)
            doSleep(iClNonDuplexSendDelay);
         break;
      }
   }

   iClHeadSize = 0;
   iClOutIndex = 0;
   iClCommand  = 0;
   iClSLIOff   = 0;

   return irc;
}

int UDPIO::addCommand(char *pszCmd)
{
   int iMaxCommands = sizeof(aClCommand)/sizeof(aClCommand[0]);
   if (iClCommand < 0 || iClCommand >= iMaxCommands-2)
      return 5;
      
   int iMaxCopy = sizeof(aClCommand[0])-2;
   strncpy(aClCommand[iClCommand], pszCmd, iMaxCopy);
   aClCommand[iClCommand][iMaxCopy-2] = '\0';
   iClCommand++;
   
   return 0;
}

char UDPIO::sfkToNetColor(char c)
{
   switch (c)
   {
      // keep these as is
      case 'r': case 'g': case 'b': case 'y': case 'c': case 'm':
      case 'R': case 'G': case 'B': case 'Y': case 'C': case 'M':
         return c;

      // white is sfk-internally coded as v to separate from
      // logical 'w'arning color.
      case 'v': return 'w';
      case 'V': return 'W';

      // default color ' ' is marked as 'd'
      case ' ': return 'd';
   }
   
   // all other cases are sfk logical colors
   extern int sfkMapAttrToColor(char cAttr);
   int nSFKIntColor = sfkMapAttrToColor(c);
   
   // bit   0:bright 1:red 2:green 3:blue
   // value     1       2      4      8
   switch (nSFKIntColor)
   {
      case  0: case 1: return 'd';
      case  2: return 'r';
      case  3: return 'R';
      case  4: return 'g';
      case  5: return 'G';
      case  6: return 'y';
      case  7: return 'Y';
      case  8: return 'b';
      case  9: return 'B';
      case 10: return 'm';
      case 11: return 'M';
      case 12: return 'c';
      case 13: return 'C';
      case 14: return 'w';
      case 15: return 'W';
   }

   // all other cases
   return 'd';
}

int UDPIO::checkTellCurrentColor(char cSFKAttrib)
{
   if (iClOutIndex > 0)
      return 5; // something was cached already

   cClTellColor = sfkToNetColor(cSFKAttrib);
   
   return 0;
}

int UDPIO::addOrSendText(char *pszInText, char *pszInAttr)
{
   if (bClRawText)
   {
      bClColor = 0;
      return addOrSendText(pszInText, strlen(pszInText), 0);
   }

   int iPhrase = 0;
   int iSrcCur = 0;
   int iAttCur = 0;
   
   // next addHeader should tell about color coding
   bClColor = 1;

   // if nothing was cached or sent yet, tell current color
   char cFirstColor = pszInAttr[0] ? pszInAttr[0] : ' ';
   checkTellCurrentColor(cFirstColor);

   // force setting of current color on every line start
   char aOld = '\0';

   char szCmd[30];

   memset(szCmd, 0, sizeof(szCmd));
   szCmd[0] = (char)0x1F;

   int irc = 0;

   while (1)
   {
      char c = pszInText[iSrcCur];
      char a = pszInAttr[iAttCur];

      if (!c)
         break;

      // attribs may end sooner, e.g. on LF of text
      if (a)
         iAttCur++;
      else
         a = aOld;

      if (a != aOld) 
      {
         // color change: flush recent phrase, if any
         if (iSrcCur > iPhrase)
            if ((irc = addOrSendText(pszInText+iPhrase, iSrcCur-iPhrase, 0)))
               return irc;
         iPhrase = iSrcCur;

         // send \x1F and color code
         szCmd[1] = sfkToNetColor(a);
         if ((irc = addOrSendText(szCmd, 2, 1)))
            return irc;
         
         // switch current color
         aOld = a;
      }
      
      if (((uchar)c) == 0x1FU)
      {
         // input contains non control \x1F: flush phrase
         if (iSrcCur > iPhrase)
            if ((irc = addOrSendText(pszInText+iPhrase, iSrcCur-iPhrase, 0)))
               return irc;
         iPhrase = iSrcCur;

         // send escaped \x1F\x1F
         szCmd[1] = sfkToNetColor(a);
         if ((irc = addOrSendText(szCmd, 2, 1)))
            return irc;
      }
      
      iSrcCur++;
   }

   // flush remainder:
   if (iSrcCur > iPhrase)
      if ((irc = addOrSendText(pszInText+iPhrase, iSrcCur-iPhrase, 0)))
         return irc;

   return 0;
}

int UDPIO::addOrSendText(char *pszPhrase, int iPhraseLen, bool bNoWrap)
{
   int irc = 0;

   if (!iClOutIndex && !bClRawText)
      addHeader();

   // package size with tolerance for EOL etc.
   int iNettoPackSize = iClPackageSize - 4;

   int iSrcLenRaw = iPhraseLen;
   int iCopyLen   = iSrcLenRaw;

   char *pszSrcCur= pszPhrase;
   int iSrcRemain = iSrcLenRaw;

   // color control sequences should never be split
   if (bNoWrap != 0 && iClOutIndex + iCopyLen > iNettoPackSize)
   {
      // therefore don't try to wrap, but flush immediately
      if ((irc = flushSend(0)))
         return irc;

      if (!bClRawText)
         addHeader();

      // iClOutIndex was reset, is now after new header.
   }

   while (   iCopyLen > 0
          && iClOutIndex + iCopyLen > iNettoPackSize
         )
   {
      // phrase does not fit completely.
      // try a soft wrap based on CR or LF.
      // we do NOT consider control sequences here.
      int iWrap = 0;
      for (int i=0; iClOutIndex+i<iNettoPackSize;)
      {
         if (!strncmp(pszSrcCur+i, "\r\n", 2))
            { iWrap=i+2; i+=2; } // after EOL
         else
         if (pszSrcCur[i]=='\r' || pszSrcCur[i]=='\n')
            { iWrap=i+1; i++; }  // after EOL
         else
            i++;
      }

      bool bSplitLine = 0;

      if (iWrap > 0) {
         iCopyLen = iWrap; // until wrap point
         // printf("... soft wrap %d\n", iWrap);
      }
      else
      if (iClOutIndex - iClHeadSize > 0) {
         // found no soft wrap point, but there is cached text
         iCopyLen = 0;     // flush recent as is
         // printf("... flush recent %d\n", iClOutIndex - iClHeadSize);
      }
      else {               // hard wrap
         iCopyLen = iNettoPackSize - iClOutIndex;
         bSplitLine = 1;
         // printf("... hard wrap %d %d %d\n", iCopyLen, iNettoPackSize, iClOutIndex);
      }
      
      // printf("addOrSend: %.*s (%d)\n", (int)iCopyLen, pszSrcCur, iCopyLen);
         
      if (iCopyLen > 0)
         memcpy(aClRawOutBuf+iClOutIndex, pszSrcCur, iCopyLen);
      iClOutIndex += iCopyLen;

      if ((irc = flushSend(bSplitLine)))
         return irc;

      if (!bClRawText)
         addHeader();

      pszSrcCur  += iCopyLen;
      iSrcRemain -= iCopyLen;
      iCopyLen    = iSrcRemain;
   }
   
   if (iCopyLen > 0)
   {
      // add (last part of) phrase to cache
      memcpy(aClRawOutBuf+iClOutIndex, pszSrcCur, iCopyLen);
      iClOutIndex += iCopyLen;
   }
   
   return irc;
}

int UDPIO::storeHeader(char *pszRaw, int iHeadLen)
{
   /*
      :sfktxt:v100,req1,copy,scd\n
      :clear\n
      :setpos,10,10\n
      :status,step 1\n
   */

   if (iHeadLen > sizeof(aClHeaderBuf)-100)
       iHeadLen = sizeof(aClHeaderBuf)-100;
   memcpy(aClHeaderBuf, pszRaw, iHeadLen);
   aClHeaderBuf[iHeadLen] = '\0';

   char *pszLine = aClHeaderBuf;

   // parse headline
   while (*pszLine)
   {
      if (*pszLine=='\n')
         { pszLine++; break; }
      if (*pszLine==',') {
         pszLine++;
         if (!strncmp(pszLine, "req", 3))
            iClInReqNum = atoi(pszLine+3);
         if (!strncmp(pszLine, "rt", 2))
            iClInRetryNum = atoi(pszLine+2);
         if (!strncmp(pszLine, "copy", 4))
            bClCopyRequest = 1; // duplex
         if (!strncmp(pszLine, "cs1", 3))
            bClDecodeColor = 1;
         if (bClDecodeColor && !strncmp(pszLine, "sc", 2))
            cClCurrentInColor = pszLine[6]; // start color
         continue;
      }
      pszLine++;
   }
   
   // parse commands.
   while (*pszLine)
   {
      // valid command lines must end with LF
      char *pszNext = strchr(pszLine, '\n');
      if (!pszNext)
         break; // possibly truncated header
      *pszNext++ = '\0';

      if (!strcmp(pszLine, ":clear"))
         bClCmdClear = 1;

      // to next line
      pszLine = pszNext;
   }

   return 0;
}

// IN : aClRawInBuf1 with mixed text
// OUT: aClRawInBuf2 with plain text
//      aClRawInAttr2 with color attributes
int UDPIO::decodeColorText(int iFromOffset)
{
   aClRawInBuf2[0]  = '\0';
   aClRawInAttr2[0] = '\0';

   int iSrcCur = iFromOffset;

   int iDstCur = 0;
   int iDstMax = sizeof(aClRawInBuf2) - 100;
   
   int iAttCur = 0;
   int iAttMax = sizeof(aClRawInAttr2) - 100;

   char a = cClCurrentInColor;

   while (iDstCur < iDstMax)
   {
      char c = aClRawInBuf1[iSrcCur];

      if (!c)
         break;

      if (bClDecodeColor!=0 && ((uchar)c) == 0x1FU)
      {
         // control sequence. get next char.
         iSrcCur++;
         char c2 = aClRawInBuf1[iSrcCur];

         if (!c2)
         {
            // invalid sequence at end of text.
            // treat as single control char.
            aClRawInBuf2[iDstCur++] = c;
            if (iAttCur < iAttMax)
             aClRawInAttr2[iAttCur++] = a;
            pwarn("invalid control sequence in color text\n");
            break;
         }
         
         if (((uchar)c2) == 0x1FU)
         {
            // escaped \x1F. replace by single char.
            aClRawInBuf2[iDstCur++] = c;
            if (iAttCur < iAttMax)
             aClRawInAttr2[iAttCur++] = a;

            iSrcCur++;
            continue;
         }
         
         // change current color
         a = c2;
         
         // also remember for package spanning text
         cClCurrentInColor = a;
         
         iSrcCur++;
         continue;
      }
      
      // copy through plain text char
      aClRawInBuf2[iDstCur++] = c;
      if (iAttCur < iAttMax)
       aClRawInAttr2[iAttCur++] = a;

      iSrcCur++;
   }

   // MUST zero terminate.
   aClRawInBuf2[iDstCur] = '\0';
   aClRawInAttr2[iAttCur] = '\0';

   return 0;
}

int UDPIO::getClientIndex(struct sockaddr_in *pAddr, bool *pFound)
{
   int iEmpty  = -1;
   int nOldest =  0;
   int iOldest =  0;

   struct UCPClientState *pcln = 0;

   for (int i=0; i<UDPIO_MAX_CLIENTS; i++)
   {
      pcln = &aClClients[i];

      // empty slot?
      if (!pcln->ntime) {
         if (iEmpty < 0)
            iEmpty = i;
         continue;
      }
      // oldest slot?
      if (nOldest==0 || pcln->ntime<nOldest) {
         nOldest = pcln->ntime;
         iOldest = i;
      }
      // matching?
      if (   pAddr->sin_addr.s_addr == pcln->addr.sin_addr.s_addr
          && pAddr->sin_port == pcln->addr.sin_port
         )
      {
         *pFound = 1;
         return i;
      }
   }

   int iReuse = (iEmpty >= 0) ? iEmpty : iOldest;

   pcln = &aClClients[iReuse];

   memset(pcln, 0, sizeof(aClClients[iReuse]));
   pcln->ntime = getCurrentTime();
   pcln->reqnum = 0; // filled in later
   memcpy(&pcln->addr, pAddr, sizeof(struct sockaddr_in));
   pcln->color = 'd';

   return iReuse;
}

void dumpdata(const char *pszTitle, char *psz) 
{
   printf("%s : \"", pszTitle);
   while (*psz) {
      switch (*psz) {
         case 0x1F: printf("{COL}"); break;
         case '\r': printf("{CR}"); break;
         case '\n': printf("{LF}"); break;
         default  : putchar(*psz);
      }
      psz++;
   }
   printf("\"\n");
}

bool UDPIO::hasCachedInput( )
{
   return iClRawInputCached > 0 ? 1 : 0;
}

int UDPIO::receiveText( )
{
   // to detect mixed input from different clients
   int iRecentClient = iClClient;
   bool bChangedClient = 0;

   if (!iClRawInputCached)
   {
      // cache is empty, get next network packet
      mclear(clRawInAddr);
      int clilen = sizeof(clRawInAddr);
      bool bSkipDecode = 0;
      
      // reinit per packet
      aClRawInBuf1[0]   = '\0';
      aClRawInBuf2[0]   = '\0';
      aClRawInAttr2[0]  = '\0';
      bClForceNextInput = 0;

      // taken from header, if any
      iClInReqNum = 0;
      iClInRetryNum = 0;
      bClCopyRequest = 0;
      cClCurrentInColor = 'd';
      bClCmdClear = 0;
      bClContinuedStream = 0;
      bClDecodeColor = 0;

      int iRawRead = receiveData((uchar*)aClRawInBuf1, sizeof(aClRawInBuf1)-100,
                                 &clRawInAddr, clilen);
      if (iRawRead <= 0)
         return 0;

      // data is zero terminated.
      // dumpdata("RECV", aClRawInBuf1); fflush(stdout);

      // set current client index by input address
      bool bClientRefound = 0;
      iClClient = getClientIndex(&clRawInAddr, &bClientRefound);

      // detect mixed client input
      if (iRecentClient != iClClient)
         bChangedClient = 1;
      
      bClRawText = 1;

      // parse header, if any
      if (!strncmp(aClRawInBuf1, ":sfktxt:", 8))
      {
         char *pszPastHeader = strstr(aClRawInBuf1, "\n\n");
         if (pszPastHeader) 
         {
            // parse header
            pszPastHeader += 2; // keep the LFs
            int iHeadLen = pszPastHeader - aClRawInBuf1;
            storeHeader(aClRawInBuf1, iHeadLen);
            // sets reqnum, copyreq, currentcolor, cmdclear

            // is there a continued stream with a client?
            if (bClientRefound) {
               // normal transfer: reqnum increments by one
               if (iClInReqNum == aClClients[iClClient].reqnum + 1)
                  bClContinuedStream = 1;
               // retry transfer: trynum increments by one
               if (   iClInReqNum == aClClients[iClClient].reqnum
                   && iClInRetryNum == aClClients[iClClient].copytry + 1)
               {
                  // the client sent us same record TWICE because
                  // it received the first reply with a huge delay.
                  // repair this: the stream is still intact
                  bClContinuedStream = 1;
                  // we already replied for that reqnum, therefore
                  aClClients[iClClient].copytry++;
                  bClCopyRequest = 0;
                  // and the dup text must be dropped.
                  // because we skip colorDecode:
                  aClRawInBuf2[0] = '\0';
                  // leads to iToCopy == 0 below.
                  bSkipDecode = 1;
               }
            }
            aClClients[iClClient].reqnum = iClInReqNum;

            // then reuse recent color. redundant to storeHeader.
            if (bClContinuedStream && bClDecodeColor)
               cClCurrentInColor = aClClients[iClClient].color;

            // reply duplex request immediately
            if (bClCopyRequest) {
               bClCopyRequest = 0;
               sendDuplexReply(&clRawInAddr);
            }

            // apply color decoding. will just copy thru if bClDecodeColor==0
            if (!bSkipDecode) {
               int iText = pszPastHeader - aClRawInBuf1;
                decodeColorText(iText);
                // from InBuf1 to InBuf2
               aClClients[iClClient].color = cClCurrentInColor;
            }

            // cached in RawInBuf2, RawInAttr2
            bClRawText = 0;
            
            // printf("PART: \"%s\" clf=%d cstrm=%d\n", aClRawInBuf2, bClientRefound, bClContinuedStream);
         }
         // else fall thru as raw text
      }

      if (bClRawText)
      {
         // take plain UDP text as is
         memcpy(aClRawInBuf2, aClRawInBuf1, iRawRead);
         aClRawInBuf2[iRawRead] = '\0';
         memset(aClRawInAttr2, 'd', iRawRead);
         aClRawInAttr2[iRawRead] = '\0';
      }
   }

   // new or cached text input is now in RawInBuf2, RawInAttr2.
   int iToCopy = strlen(aClRawInBuf2);
   // can be NULL if input was just a color control sequence!
   // in this case, only state information like reqnum is cached.

   // when should we print collected chars to terminal?
   // - if the sfktxt client changed
   bool bShouldFlush = bChangedClient;
   // - OR if same client has no continued stream
   if (!bClContinuedStream)
        bShouldFlush = 1;
   // but never on raw text input, unless option LFOnRaw is set
   if (bClRawText && !bClAppendLFOnRaw) 
      bShouldFlush = 0;

   // if there a partial line stored in output, we MUST feed the line
   // -  if the client changed
   // -  if the same client provides a mismatched request number
   if (iClInBufUsed > 0 && bShouldFlush)
   {
      // then the output line MUST be flushed now.
      // we keep current input in aClRawInBuf2.
      // all state like iClClient stays as is.
      iClRawInputCached = iToCopy; // can be NULL!
      bClForceNextInput = 1;
      // printf("back: caller must flush %d (1)\n", iClInBufUsed);
      return 1;
   }

   // is enough space in rejoin buffer for further text?
   if (iClInBufUsed + iToCopy > MAX_LINE_LEN)
   {
      // not enough space in inbuf for additional text.
      // caller must flush input. this flag signals
      // that no end of line char should be searched.
      iClRawInputCached = iToCopy; // can be NULL!
      bClForceNextInput = 1;
      // printf("back: caller must flush %d (2)\n", iClRawInputCached);
      return 1;
   }
   
   // add next line part to line rejoin buffer
   memcpy(aClInBuf+iClInBufUsed, aClRawInBuf2, iToCopy);
   memcpy(aClInAtt+iClInBufUsed, aClRawInAttr2, iToCopy);
   
   // on add of first part also copy sender info
   if (!iClInBufUsed)
      memcpy(&clInBufInAddr, &clRawInAddr, sizeof(clRawInAddr));

   // no cache remains   
   iClRawInputCached = 0;

   iClInBufUsed += iToCopy;
   
   aClInBuf[iClInBufUsed] = '\0';
   aClInAtt[iClInBufUsed] = '\0';

   // caller must consume new input lines as soon as
   // getNextInput() returns a complete line.
   
   // printf("join: \"%s\"\n", aClInBuf);
   
   return 0;
}

int UDPIO::sendDuplexReply(struct sockaddr_in *pAddr)
{
   if (fdClSocket == INVALID_SOCKET)
      return 9;

   char szReply[200];
   
   snprintf(szReply, sizeof(szReply)-10,
      ":sfktxt:v100,rep%d,rt%d,ok\n\n",
      iClInReqNum, iClInRetryNum
      );

   int iSendSize = strlen(szReply);

   if (sendto(fdClSocket, szReply, iSendSize, 0,
          (struct sockaddr *)pAddr, sizeof(struct sockaddr_in)) != iSendSize
      )
      return 10;

   aClClients[iClClient].copyreq = iClInReqNum;
   aClClients[iClClient].copytry = iClInRetryNum;

   return 0;
}

char *UDPIO::getNextCommand( )
{
   if (bClCmdClear) {
      bClCmdClear = 0;
      return (char*)"clear";
   }
   return 0;
}

char *UDPIO::getNextInput(char **ppAttr, struct sockaddr_in *pSenderAddr, bool bDontCache)
{
   if (iClInBufUsed <= 0)
      return 0;

   bool bAllowJoin = 1;
   if (bClRawText && bClAppendLFOnRaw)
        bAllowJoin = 0;

   // when receiving raw text, take input as is.
   // if input buffer overflows, also take as is.
   if (!bDontCache && !bClForceNextInput && bAllowJoin)
   {
      // wait for next CR or LF
      char cLast = aClInBuf[iClInBufUsed-1];
      if (cLast!='\r' && cLast!='\n')
         return 0;
   }
   
   bClForceNextInput = 0;

   iClInBufUsed = 0;

   if (ppAttr)
      *ppAttr = aClInAtt;

   if (pSenderAddr)
      memcpy(pSenderAddr, &clInBufInAddr, sizeof(struct sockaddr_in));

   // dumpdata("nxin", aClInBuf);

   return aClInBuf;
}

int UDPIO::getTextSendDelay( )
{
   if (bClDuplex)
      return 0;

   return iClNonDuplexSendDelay;
}

#ifndef USE_SFK_BASE

// ------------- sfk patch - Text File Patching support -----------------

#define SFKPATCH_MAX_CMDLINES    10000 // max lines per :file ... :done block
#define SFKPATCH_MAX_CACHELINES  10000 // max lines per :from ... :to pattern
#define SFKPATCH_MAX_NUMCMD        500 // max number of :from commands per patchfile
#define SFKPATCH_MAX_OUTLINES   500000 // max lines per target file

class SFKPatch
{
public:
      SFKPatch ( );
     ~SFKPatch ( );
 
static SFKPatch
   *current    ( );

   int processCmdPatch(char *psz);
   int processCmdInfo (char *psz);
   void log(int nLevel, const char *pFormat, ... );
   int detabLine(char *pBuf, char *pTmp, int nBufSize, int nTabSize);
   int processCmdRoot (char *pszIn);
   int patchMainInt(int argc, char *argv[], int offs);
   char *skipspace(char *psz);
   int processPatchFile(char *pszPatchFileName);
   int processCmdFile(char *pszIn);
   int processCreateFile(char *pszIn);
   int processCreateDir(char *pszIn);
   void shrinkLine(char *psz, char *pszOut);
   int compareLines(char *psz1, char *psz2);
   int processFileUntilDone(char *pszTargFileName);

static SFKPatch
   *pClCurrent;

FILE *fpatch;
char *pszRoot;
char szCmdBuf[MAX_LINE_LEN];
int  bGlblRevoke;
int  bGlblBackup;
int  bGlblSimulate;
int  bGlblTouchOnRevoke;
int  nCmdFileLineEndings;
int  nGlblLine;
int  bGlblIgnoreWhiteSpace;
int  bGlblAlwaysSimulate;
int  bGlblVerbose;
int  bGlblQuickSum;
int  bGlblUnixOutput;
int  nGlblPatchedFiles;
int  nGlblRevokedFiles;
char *pszGlblRelWorkDir;
int  bGlblAnySelRep;
int  bGlblCheckSelRep;
int  bGlblStats;
int  nGlblDetabOutput;
int  bGlblVerify;
int  bGlblNoPID ;
int  bGlblIgnoreRoot;
char **apOut;

// select-replace table over all targets
#define MAX_GLOBAL_CHANGES 50
char *apGlobalChange[MAX_GLOBAL_CHANGES][3];
int anGlobalChange[MAX_GLOBAL_CHANGES];
int iGlobalChange;

// select-replace table local to current target
#define MAX_LOCAL_CHANGES 50
char *apLocalChange[MAX_LOCAL_CHANGES][3];
int anLocalChange[MAX_GLOBAL_CHANGES];
int iLocalChange;

char *aPatch[SFKPATCH_MAX_CMDLINES];
char *aBuf[SFKPATCH_MAX_CACHELINES];
int   aifrom[SFKPATCH_MAX_NUMCMD];
int   aifromlen[SFKPATCH_MAX_NUMCMD];
int   aito[SFKPATCH_MAX_NUMCMD];
int   aitolen[SFKPATCH_MAX_NUMCMD];

char szLine1[MAX_LINE_LEN];
char szLine2[MAX_LINE_LEN];
};

class PatchMemCover {
public:
   PatchMemCover  ( ) {
      bdead = 0;
      SFKPatch::current()->apOut = new char*[SFKPATCH_MAX_OUTLINES+10];
      if (!SFKPatch::current()->apOut)
         bdead = 1;
   }
   ~PatchMemCover ( ) {
      if (SFKPatch::current()->apOut) {
         delete [] SFKPatch::current()->apOut;
         SFKPatch::current()->apOut = 0;
      }
   }
   int bdead;
};

SFKPatch *SFKPatch :: pClCurrent = 0;

SFKPatch :: SFKPatch( )
{
   memset(this, 0, sizeof(*this));
   bGlblTouchOnRevoke = 1;
   nCmdFileLineEndings = -1;
   bGlblIgnoreWhiteSpace = 1;
}

SFKPatch *SFKPatch :: current( )
{
   if (!pClCurrent)
      pClCurrent = new SFKPatch();

   return pClCurrent;
}

int patchMain(int argc, char *argv[], int offs)
{
   return SFKPatch::current()->patchMainInt(argc, argv, offs);
}

int SFKPatch :: processCmdPatch(char *psz) { return 0; }
int SFKPatch :: processCmdInfo (char *psz) { return 0; }

// 0 == error, >0 == normal msg, >= 5 do not tell if in QuickSum mode
void SFKPatch :: log(int nLevel, const char *pFormat, ... )
{
   va_list argList;
   va_start(argList, pFormat);
   if (nLevel == 0) {
      vfprintf(stderr, pFormat, argList);
      fflush(stderr);
   } else {
      if (!(bGlblQuickSum && nLevel >= 5)) {
         vprintf(pFormat, argList);
         fflush(stdout);
      }
   }
   va_end(argList);
}

int SFKPatch :: detabLine(char *pBuf, char *pTmp, int nBufSize, int nTabSize)
{
   strcpy(pTmp, pBuf);
   int iout=0, nInsert=0;
   for (int icol=0; pTmp[icol] && iout < (nBufSize-nTabSize-2); icol++) {
      char c1 = pTmp[icol];
      if (c1 == '\t') {
         nInsert = nTabSize - (iout % nTabSize);
         for (int i2=0; i2<nInsert; i2++)
            pBuf[iout++] = ' ';
      } else {
         pBuf[iout++] = c1;
      }
   }
   pBuf[iout] = '\0';
   if (iout >= (nBufSize-nTabSize-2)) {
      log(0, "error  : detab: line buffer overflow. max line len supported is %d\n",(nBufSize-nTabSize-2));
      return 9;
   }
   return 0;
}

int SFKPatch :: processCmdRoot (char *pszIn) {
   strcpy(szCmdBuf, pszIn);
   char *psz = 0;
   if ((psz = strchr(szCmdBuf, '\r')) != 0) *psz = 0;
   if ((psz = strchr(szCmdBuf, '\n')) != 0) *psz = 0;
   pszRoot = strdup(szCmdBuf);
   if (!bGlblIgnoreRoot && strcmp(pszRoot, pszGlblRelWorkDir)) {
      log(0, "error  : you are not in the %s directory.\n",pszRoot);
      return 1+4;
   }
   return 0;
}

int SFKPatch :: patchMainInt(int argc, char *argv[], int offs)
{
   PatchMemCover mem;
   if (mem.bdead) {
      log(0, "error: out of memory in patchMain\n");
      return 9;
   }

   if (!strcmp(argv[1+offs], "-example"))
   {
      printx(
         "#patchfile example, containing all supported patchfile commands:\n\n"
         ":patch \"enable FooBar testing\"\n"
         ":info makes some stuff public, for direct access by test funcs\n"
         "\n"
         ":root foosrc\n"
         "\n"
         ":file include\\Foobar.hpp\n"
         ":from \n"
         "private:\n"
         "    bool                  isAvailable               (int nResource);\n"
         "    void                  openBar                   (int nMode);\n"
         ":to\n"
         "public: // [patch-id]\n"
         "    bool                  isAvailable               (int nResource);\n"
         "    void                  openBar                   (int nMode);\n"
         ":from \n"
         "    // returns the application type, 0x00 == not set.\n"
         "    UInt16                getAppType                ( );\n"
         ":to\n"
         "    // returns the application type, 0x00 == not set.\n"
         "    UInt16                getAppType                ( );\n"
         "    UInt32                getAppTypeInternal        ( );\n"
         ":done\n"
         "\n"
         ":## this is a remark, allowed only outside :file blocks.\n"
         ":## the above syntax is sufficient for most cases; but now follow some\n"
         ":## more commands for global replace, file and dir creation, etc.\n"
         ":## select-replace has 3 parms, and applies changes (parms 2+3) only\n"
         ":## in lines containing the search term (parm 1).\n"
         "\n"
         ":file include\\Another.cpp\n"
         ":select-replace /MY_TRACE(/\\n\"/\"/\n"
         ":select-replace _printf(\"spam: _printf(_while(0) printf(_\n"
         ":set only-lf-output\n"
         ":from \n"
         "    bool                  existsFile                (char *psz);\n"
         ":to\n"
         "    // [patch-id]\n"
         "    int                   existsFile                (char *psz);\n"
         ":done\n"
         "\n"
         ":mkdir sources\n"
         ":create sources\\MyOwnFix.hpp\n"
         "// this file is generated by sfk patch.\n"
         "##define OTHER_SYMBOL MY_OWN_SYMBOL\n"
         ":done\n"
         "\n"
         ":skip-begin\n"
         "this is outcommented stuff. the skip-end is optional.\n"
         ":skip-end\n"
         );
      return -1;
   }

   if (!strcmp(argv[1+offs], "-template") || !strcmp(argv[1+offs], "-tpl"))
   {
      printf(
         ":patch \"thepatch\"\n"
         "\n"
         ":root theproject\n"
         "\n"
         ":file include\\file1.hpp\n"
         ":from \n"
         ":to\n"
         "    // [patch-id]\n"
         ":from \n"
         ":to\n"
         ":done\n"
         "\n"
         ":file sources\\file1.cpp\n"
         ":from \n"
         ":to\n"
         "    // [patch-id]\n"
         ":done\n"
         "\n"
         );
      return -1;
   }

   szCmdBuf[0] = '\0';
   #ifdef _WIN32
   if (_getcwd(szCmdBuf,sizeof(szCmdBuf)-10)) { }
   #else
   if (getcwd(szCmdBuf,sizeof(szCmdBuf)-10)) { }
   #endif
   char *psz = strrchr(szCmdBuf, glblPathChar);
   if (!psz) {
      log(0, "error: cannot identify working dir. make sure you are in the correct directory.\n");
      return 9;
   }
   psz++;
   pszGlblRelWorkDir = strdup(psz);
 
   char *pszPatchFileName = 0;
   char *pszPatchFileBackup = 0;
   int bWantRevoke = 0;
   int bWantRedo   = 0;
   int bJustSim    = 0;

   for (int iarg=1; iarg<argc; iarg++) {
      if (!strcmp(argv[iarg+offs], "-revoke")) {
         bWantRevoke = true;
      }
      else
      if (!strcmp(argv[iarg+offs], "-redo")) {
         bWantRevoke = true;
         bWantRedo   = true;
      }
      else
      if (!strcmp(argv[iarg+offs], "-keep-dates")) {
         bGlblTouchOnRevoke = 0;
      }
      else
      if (!strcmp(argv[iarg+offs], "-exact-match")) {
         bGlblIgnoreWhiteSpace = 0;
      }
      else
      if (!strcmp(argv[iarg+offs], "-sim")) {
         bJustSim = 1;
      }
      else
      if (!strcmp(argv[iarg+offs], "-verify")) {
         bJustSim    = 1;
         bGlblVerify = 1;
      }
      else
      if (!strcmp(argv[iarg+offs], "-qs")) {
         bGlblQuickSum = 1;
      }
      else
      if (!strcmp(argv[iarg+offs], "-verbose")) {
         bGlblVerbose = 1;
      }
      else
      if (!strcmp(argv[iarg+offs], "-stat")) {
         bGlblStats = 1;
      }
      else
      if (!strcmp(argv[iarg+offs], "-nopid")) {
         bGlblNoPID = 1;
      }
      else
      if (!strcmp(argv[iarg+offs], "-anyroot")) {
         bGlblIgnoreRoot = 1;
      }
      else
      if (!strncmp(argv[iarg+offs], "-", 1)) {
         printf("unknown option: %s\nuse with no parameters to get help.\n",argv[iarg+offs]);
         return 9;
      }
      else {
         pszPatchFileName = argv[iarg+offs];
         char *psz = strrchr(pszPatchFileName, glblPathChar);
         if (!psz) psz = strrchr(pszPatchFileName,':');
         if (!psz) { psz = pszPatchFileName; } else psz++;
         sprintf(szCmdBuf,"save_patch%c%s", glblPathChar, psz);
         pszPatchFileBackup = strdup(szCmdBuf);
      }
   }

   // pass -1: check logic
   if (bJustSim && bWantRevoke) {
      log(0, "error  : cannot simulate and revoke together.\n");
      return 9;
   }

   // pass 0: init stats
   for (int i1=0; i1<MAX_GLOBAL_CHANGES; i1++)
      anGlobalChange[i1] = 0;
   for (int i2=0; i2<MAX_LOCAL_CHANGES; i2++)
      anLocalChange[i2]  = 0;

   // pass 1: revoke: always, unconditional.
   int iRC = 0;
   if (bWantRevoke) {
      bGlblRevoke = 1;
      if (fileExists(pszPatchFileBackup)) {
         log(5, "* revoking changes from: %s\n", pszPatchFileBackup);
         iRC = processPatchFile(pszPatchFileBackup);
      } else {
         log(5, "* revoking changes from: %s\n", pszPatchFileName);
         iRC = processPatchFile(pszPatchFileName);
      }
      bGlblRevoke = 0;
      if (!iRC && !bWantRedo) {
         if (bGlblQuickSum) {
            printf("* patch revoked: %s - %d target files\n",pszPatchFileName,nGlblRevokedFiles);
         } else {
            if (bGlblTouchOnRevoke)
               printf("* all changes revoked. the target files got the current time stamp,\n"
                      "* to ease recompile. you may use -keepdates to change this behaviour.\n");
            else
               printf("* all changes revoked, including original timestamps.\n");
         }
      }
      if (!iRC) {
         // remove patchfile backup
         if (fileExists(pszPatchFileBackup))
            if (remove(pszPatchFileBackup)) {
               log(0, "error  : cannot remove stale backup: %s\n",pszPatchFileBackup);
               return 1;
            }
      }
      if (!iRC && !bWantRedo)
         return 0;
   }

   // pass 2: pre-scan if all patches may be applied
   bGlblSimulate = 1;
   if (!iRC) {
      log(5, "* checking target file compliancies\n");
      iRC = processPatchFile(pszPatchFileName);
   }
   if (bJustSim) {
      if (!iRC) {
         if (bGlblQuickSum)
          printf("* patch %s: %s\n", bGlblVerify ? "intact" : "valid", pszPatchFileName);
         else
          printf("* all checked. the patch is %s.\n", bGlblVerify ? "still intact" : "valid and may be applied.");
         return 0;
      } else {
         if (bGlblQuickSum)
            log(0, "patch  : %s\n",pszPatchFileName);
         printf("* there were errors. the patch cannot be applied.\n");
         printf("* however, if an older patch is active, you may still -revoke it.\n");
         return 1;
      }
   }
   bGlblSimulate = 0;

   // pass 3: create backups
   if (!iRC && !bGlblNoPID) {
      log(5, "* creating backups\n");
      bGlblBackup = 1;
      iRC = processPatchFile(pszPatchFileName);
      bGlblBackup = 0;
   }

   // pass 3: apply patches
   if (!iRC) {
      log(5, "* applying patches%s\n", bGlblNoPID?" permanently":"");
      bGlblCheckSelRep = 1;
      iRC = processPatchFile(pszPatchFileName);
      if (!iRC) {
         if (bWantRedo) {
            if (bGlblQuickSum)
               printf("* all changes re-applied: %s - %d target files\n",pszPatchFileName,nGlblPatchedFiles);
            else
               printf("* all changes re-applied.\n");
         } else {
            if (bGlblQuickSum) {
               printf("* patch applied: %s - %d target files\n",pszPatchFileName,nGlblPatchedFiles);
            } else {
               printf("* all done.\n");
            }
         }
         // patch applied: save the patchfile for future revoke
         if (!bGlblNoPID)
         {
         #ifdef _WIN32
         _mkdir("save_patch");
         #else
         mkdir("save_patch", S_IREAD | S_IWRITE | S_IEXEC);
         #endif
         FILE *fout = fopen(pszPatchFileBackup,"w");
         if (fout) { fprintf(fout,"dummy"); fclose(fout); }
         #ifdef _WIN32
         sprintf(szCmdBuf, "xcopy /Q /K /Y %s %s >nul",pszPatchFileName,pszPatchFileBackup);
         #else
         sprintf(szCmdBuf, "cp -p %s %s",pszPatchFileName,pszPatchFileBackup);
         #endif
         iRC = system(szCmdBuf);
         if (iRC)
            log(0, "error  : cannot backup patchfile to: %s\n",pszPatchFileBackup);
         }
      } else {
         if (iRC & 4)
            log(0, "info   : make sure you are above the \"%s\" directory.\n",pszRoot);
      }
   } else {
      if (bGlblQuickSum)
         log(0, "patch  : %s\n",pszPatchFileName);
      if (iRC & 4) {
         log(0, "info   : make sure you are in the \"%s\" directory.\n",pszRoot);
         return iRC;
      }
      printf("* NOTHING CHANGED: i will either apply ALL changes, or NONE.\n"
             "* you may also try sfk patch -revoke or -redo.\n"
            );
      fflush(stdout);
   }

   return iRC;
}

char *SFKPatch :: skipspace(char *psz) {
   while (*psz && *psz == ' ')
      psz++;
   return psz;
}

int SFKPatch :: processPatchFile(char *pszPatchFileName)
{
   int iRC = 0;

   fpatch = fopen(pszPatchFileName, "r");
   if (!fpatch) { log(0, "error  : cannot open patchfile: %s\n",pszPatchFileName); return 2+4; }
   nGlblLine = 0;

   // parse patch file, exec commands
   int bWithinSkip = 0;
   char szBuf[MAX_LINE_LEN];
   while (fgets(szBuf,sizeof(szBuf)-10,fpatch) != NULL)
   {
      nGlblLine++;

      // determine line endings of the command file
      if (nCmdFileLineEndings == -1)
      {
         if (strstr(szBuf,"\r\n") != 0)
            nCmdFileLineEndings = 2;   // CR/LF
         else
            nCmdFileLineEndings = 1;   // LF only
      }

      if (strBegins(szBuf,":#"))
         continue;

      if (strBegins(szBuf,":skip-end")) {
         if (!bWithinSkip) {
            log(0, "error  : skip-end without skip-begin in line %d\n",nGlblLine);
            return 2;
         }
         bWithinSkip = 0;
         continue;
      }

      if (strBegins(szBuf,":skip-begin")) {
         if (bWithinSkip) {
            log(0, "error  : skip-begin twice in line %d\n",nGlblLine);
            return 2;
         }
         bWithinSkip = 1;
         continue;
      }

      if (bWithinSkip)
         continue;

      if (strBegins(szBuf,":patch ")) {
         iRC |= processCmdPatch(skipspace(szBuf+7));
         continue;
      }
      if (   strBegins(szBuf,":info ")
          || strBegins(szBuf,":info\r")
          || strBegins(szBuf,":info\n")
         )
      {
         iRC |= processCmdInfo(skipspace(szBuf+6));
         continue;
      }
      if (strBegins(szBuf,":root ")) {
         if (processCmdRoot(skipspace(szBuf+6)))
            return 1+4;
         continue;
      }
      if (strBegins(szBuf,":select-replace "))
      {
         bGlblAnySelRep = 1;
         if (iGlobalChange < MAX_GLOBAL_CHANGES-2) {
            char *psz = skipspace(szBuf+strlen(":select-replace "));
            char  nCC = *psz++;
            char *pszMaskBegin = psz;
            while (*psz && (*psz != nCC)) psz++;
            char *pszMaskEnd   = psz;
            if (*psz) psz++;
            char *pszFromBegin = psz;
            while (*psz && (*psz != nCC)) psz++;
            char *pszFromEnd   = psz;
            if (*psz) psz++;
            char *pszToBegin   = psz;
            while (*psz && (*psz != nCC)) psz++;
            char *pszToEnd     = psz;
            *pszMaskEnd = 0;
            *pszFromEnd = 0;
            *pszToEnd   = 0;
            if (strlen(pszFromBegin) > 0) {
               char *pszMaskDup = strdup(pszMaskBegin);
               char *pszFromDup = strdup(pszFromBegin);
               char *pszToDup   = strdup(pszToBegin);
               apGlobalChange[iGlobalChange][0] = pszMaskDup;
               apGlobalChange[iGlobalChange][1] = pszFromDup;
               apGlobalChange[iGlobalChange][2] = pszToDup;
               iGlobalChange++;
            }
         } else {
            log(0, "error  : too many global select-replace, only up to %d supported.\n",MAX_GLOBAL_CHANGES);
            return 2;
         }
         continue;
      }
      if (strBegins(szBuf,":create ")) {
         iRC |= processCreateFile(skipspace(szBuf+8));
         continue;
      }
      if (strBegins(szBuf,":mkdir ")) {
         iRC |= processCreateDir(skipspace(szBuf+7));
         continue;
      }
      if (strBegins(szBuf,":file ")) {
         iRC |= processCmdFile(skipspace(szBuf+6));
         continue;
      }
      if (strBegins(szBuf,":set only-lf-output")) {
         bGlblUnixOutput = 1;
         continue;
      }
      if (strBegins(szBuf,":set detab=")) {
         nGlblDetabOutput = atol(szBuf+strlen(":set detab="));
         log(5, "setting detab to %d\n",nGlblDetabOutput);
         continue;
      }
      if (strBegins(szBuf,":")) {
         log(0, "error  : unknown command in line %d: %s\n",nGlblLine,szBuf);
         return 1;
      }

      // everything else handled by processCmdFile
   }

   fclose(fpatch);

   // now that all was processed, cleanup table of global changes
   for (int i=0;i<iGlobalChange;i++) {
      if (bGlblCheckSelRep) {
         if (!anGlobalChange[i])
            log(5, "info   : global select-replace never applied: %s, %s, %s\n",apGlobalChange[i][0],apGlobalChange[i][1],apGlobalChange[i][2]);
         else
         if (bGlblStats || bGlblVerbose)
            log(5, "global select-replace applied %d times: %s, %s, %s\n",anGlobalChange[i],apGlobalChange[i][0],apGlobalChange[i][1],apGlobalChange[i][2]);
      }
      free(apGlobalChange[i][0]);
      free(apGlobalChange[i][1]);
      free(apGlobalChange[i][2]);
   }
   iGlobalChange = 0;

   return iRC;
}

int SFKPatch :: processCmdFile(char *pszIn)
{
   if (strlen(pszIn) < 1) { log(0, "error  : missing filename after :file\n"); return 2; }

   strcpy(szCmdBuf, pszIn);
   char *psz = 0;
   if ((psz = strchr(szCmdBuf, '\r')) != 0) *psz = 0;
   if ((psz = strchr(szCmdBuf, '\n')) != 0) *psz = 0;
   char *pszFile = strdup(szCmdBuf);
 
   strcpy(szCmdBuf, pszFile);

   // check if file exists
   if (!bGlblRevoke)
      if (!fileExists(szCmdBuf)) {
         log(0, "error  : unable to open file: %s\n",szCmdBuf);
         return 2+4;
      }

   iLocalChange = 0;
   int iRC = processFileUntilDone(szCmdBuf);

   // always cleanup this table, which is feeded by processFileUntilDone
   for (int i=0;i<iLocalChange;i++) {
      if (bGlblCheckSelRep) {
         if (!anLocalChange[i])
            log(5, "info   : local select-replace never applied: %s, %s, %s\n",apLocalChange[i][0],apLocalChange[i][1],apLocalChange[i][2]);
         else
         if (bGlblStats || bGlblVerbose)
            log(5, "local select-replace applied %d times: %s, %s, %s\n",anLocalChange[i],apLocalChange[i][0],apLocalChange[i][1],apLocalChange[i][2]);
      }
      free(apLocalChange[i][0]);
      free(apLocalChange[i][1]);
      free(apLocalChange[i][2]);
   }
   iLocalChange = 0;

   return iRC;
}

int SFKPatch :: processCreateFile(char *pszIn)
{
   if (strlen(pszIn) < 1) { log(0, "error  : missing filename after :create\n"); return 2; }

   strcpy(szCmdBuf, pszIn);
   char *psz = 0;
   if ((psz = strchr(szCmdBuf, '\r')) != 0) *psz = 0;
   if ((psz = strchr(szCmdBuf, '\n')) != 0) *psz = 0;
   char *pszFile = strdup(szCmdBuf);
 
   strcpy(szCmdBuf, pszFile);

   // any existing file?
   if (!bGlblRevoke && !bGlblBackup) {
      if (fileExists(szCmdBuf)) {
         if (!bGlblVerify)
            log(0, "warning: file already exists: %s\n", szCmdBuf);
      } else {
         if (bGlblVerify) {
            log(0, "error  : file no longer exists: %s\n", szCmdBuf);
            return 1;
         }
      }
   }

   FILE *fout = 0;

   if (!bGlblSimulate && bGlblRevoke) {
      // do exact opposite: delete old file
      if (remove(szCmdBuf))
         log(0, "warning: cannot remove: %s\n", szCmdBuf);
      else {
         nGlblRevokedFiles++;
         log(5, "removed: %s\n", szCmdBuf);
      }
   }
   else
   {
      // create new output file
      if (!bGlblSimulate && !bGlblRevoke && !bGlblBackup) {
         fout = fopen(szCmdBuf, "w");
         if (!fout) {
            log(0, "error  : cannot create file: %s\n", szCmdBuf); // return 2+4;
            // fall-through, continue to allow creation of other files.
         }
      }
   }

   // copy-through contents from patchfile until :done
   char szBuf[MAX_LINE_LEN];
   int iout = 0;
   int bGotDone = 0;
   int nStartLine = nGlblLine;
   while (fgets(szBuf,sizeof(szBuf)-10,fpatch) != NULL)
   {
      nGlblLine++;
      if (!strncmp(szBuf, ":done", 5)) {
         bGotDone = 1;
         break;
      }
      if (!bGlblSimulate && !bGlblRevoke && !bGlblBackup && fout) {
         fputs(szBuf, fout);
         iout++;
      }
   }

   // close output file
   if (!bGlblSimulate && !bGlblRevoke && !bGlblBackup && fout) {
      fflush(fout);
      fclose(fout);
      nGlblPatchedFiles++;
      log(5, "written: %s, %d lines.\n",szCmdBuf,iout);
   }

   if (!bGotDone) {
      if (!fout) { log(0, "error  : missing :done after :create of line %d\n", nStartLine); return 2; }
   }

   return 0;
}

int SFKPatch :: processCreateDir(char *pszIn)
{
   if (strlen(pszIn) < 1) { log(0, "error  : missing filename after :mkdir\n"); return 2; }

   strcpy(szCmdBuf, pszIn);
   char *psz = 0;
   if ((psz = strchr(szCmdBuf, '\r')) != 0) *psz = 0;
   if ((psz = strchr(szCmdBuf, '\n')) != 0) *psz = 0;
   char *pszFile = strdup(szCmdBuf);
 
   strcpy(szCmdBuf, pszFile);

   if (!bGlblSimulate && bGlblRevoke) {
      // not yet supported: remove dir on revoke (sequence problem)
      // _rmdir(szCmdBuf);
      return 0;
   }

   // create dir. have to use Win-specific API.
   if (!bGlblSimulate && !bGlblRevoke && !bGlblBackup) {
      #ifdef _WIN32
      int iRC = _mkdir(szCmdBuf);
      #else
      int iRC = mkdir(szCmdBuf, S_IREAD | S_IWRITE | S_IEXEC);
      #endif
      if (!iRC) log(5, "created: %s\n",szCmdBuf);
   }

   return 0;
}

void SFKPatch :: shrinkLine(char *psz, char *pszOut)
{
   int bWithinString = 0;
   int nWhiteCnt = 0;
   for (;*psz; psz++)
   {
      if (*psz == '\r' || *psz == '\n')
         break;   // strip also CR, LF from shrinked strings

      if (*psz == '\"' || *psz == '\'')
         bWithinString = 1-bWithinString;

      if (bWithinString)
         *pszOut++ = *psz;
      else
      if (*psz != ' ' && *psz != '\t') {
         *pszOut++ = *psz;
         nWhiteCnt = 0;
      }
      else {
         // always apply first whitespace
         nWhiteCnt++;
         if (nWhiteCnt == 1)
            *pszOut++ = ' ';
      }
   }
   *pszOut = 0;
}

int SFKPatch :: compareLines(char *psz1, char *psz2)
{
   if (bGlblIgnoreWhiteSpace)
   {
      shrinkLine(psz1, szLine1);
      shrinkLine(psz2, szLine2);
      int iRC = strcmp(szLine1,szLine2);
      if (bGlblVerbose)
      {
         if (iRC)
            printf("src-> %s\npat-> %s\n",szLine1,szLine2);
         else
            printf("src*> %s\npat*> %s\n",szLine1,szLine2);
      }
      return iRC;
   }
   return strcmp(psz1, psz2);
}

int SFKPatch :: processFileUntilDone(char *pszTargFileName)
{
   // INPUT implicite: fpatch stream

   // 1. read next block from patchfile until ":done"
   char szBuf[MAX_LINE_LEN];
   char szBuf2[MAX_LINE_LEN];
   int ipatch = 0;
   while (fgets(szBuf,sizeof(szBuf)-10,fpatch) != NULL)
   {
      nGlblLine++;
      aPatch[ipatch++] = strdup(szBuf);
      aPatch[ipatch] = 0;
      if (ipatch > SFKPATCH_MAX_CMDLINES) { log(0, "command block too large, max %d lines supported.\n",(int)SFKPATCH_MAX_CMDLINES); return 2; }
      if (!strncmp(szBuf, ":done", 5))
         break;
   }

   // 2. find commands
   int icmd=0; int iline=0; int bNextCmd=0; int bDone=0;
   int bWithinToBlock=0, bHavePatchIDForThisFile=0;
   int bFromPassed=0, nLocalDetabOutput=0;
   while (!bDone)
   {
      aifrom   [icmd]=-1;
      aifromlen[icmd]=-1;
      aito     [icmd]=-1;
      aitolen  [icmd]=-1;
      for (;iline<ipatch;iline++)
      {
         if (!strncmp(aPatch[iline],":select-replace ",strlen(":select-replace ")))
         {
            bGlblAnySelRep = 1;
            if (iLocalChange < MAX_LOCAL_CHANGES-2) {
               char *psz = aPatch[iline]+strlen(":select-replace ");
               char  nCC = *psz++;
               char *pszMaskBegin = psz;
               while (*psz && (*psz != nCC)) psz++;
               char *pszMaskEnd   = psz;
               if (*psz) psz++;
               char *pszFromBegin = psz;
               while (*psz && (*psz != nCC)) psz++;
               char *pszFromEnd   = psz;
               if (*psz) psz++;
               char *pszToBegin   = psz;
               while (*psz && (*psz != nCC)) psz++;
               char *pszToEnd     = psz;
               *pszMaskEnd = 0;
               *pszFromEnd = 0;
               *pszToEnd   = 0;
               if (strlen(pszFromBegin) > 0) {
                  char *pszMaskDup = strdup(pszMaskBegin);
                  char *pszFromDup = strdup(pszFromBegin);
                  char *pszToDup   = strdup(pszToBegin);
                  apLocalChange[iLocalChange][0] = pszMaskDup;
                  apLocalChange[iLocalChange][1] = pszFromDup;
                  apLocalChange[iLocalChange][2] = pszToDup;
                  iLocalChange++;
               }
            } else {
               log(0, "error  : too many select-replace in one :file, only up to %d supported.\n",MAX_LOCAL_CHANGES);
               return 2;
            }
            continue;
         }

         if (!strncmp(aPatch[iline],":set detab=",strlen(":set detab="))) {
            nLocalDetabOutput = atol(aPatch[iline]+strlen(":set detab="));
            // log(5, "setting local detab to %d\n",nLocalDetabOutput);
            continue;
         }

         if (!strncmp(aPatch[iline],":from",strlen(":from")))
         {
            bFromPassed = 1;
            bWithinToBlock = 0;
            if (aifrom[icmd] == -1) {
               // starts new command (only at file start)
               aifrom[icmd]    = iline+1;
            } else {
               // ends current command
               aitolen[icmd]   = iline-aito[icmd];
               bNextCmd = 1;
            }
         }

         if (!bFromPassed && !strncmp(aPatch[iline], ":", 1)) {
            log(0, "unexpected command: %s\n", aPatch[iline]);
            return 9;
         }

         if (!strncmp(aPatch[iline],":to",strlen(":to"))) {
            aito[icmd]      = iline+1;
            aifromlen[icmd] = aito[icmd]-aifrom[icmd]-1;
            bWithinToBlock  = 1;
         }

         if (!strncmp(aPatch[iline],":done",strlen(":done"))) {
            // only at EOF
            bWithinToBlock = 0;
            aitolen[icmd]   = iline-aito[icmd];
            bNextCmd = 1;
            bDone = 1;
         }

         if (strstr(aPatch[iline], "[patch-id]") != 0) {
            if (bWithinToBlock)
               bHavePatchIDForThisFile = 1;
            else {
               log(0, "error  : line %d: [patch-id] not allowed within :from block. expected in :to block.\n",nGlblLine);
               return 2;
            }
         }

         if (bNextCmd)
         {
            bNextCmd=0;
            if (aifrom[icmd]   ==-1) { log(0, "error  : line %d: :from block missing\n",nGlblLine); return 2; }
            if (aito[icmd]     ==-1) { log(0, "error  : line %d: :to block missing\n",nGlblLine); return 2; }
            if (aifromlen[icmd]<= 0) { log(0, "error  : line %d: :from block empty\n",nGlblLine); return 2; }
            if (aitolen[icmd]  <= 0) { log(0, "error  : line %d: :to block empty\n",nGlblLine);   return 2; }
            icmd++;
            if (icmd >= SFKPATCH_MAX_NUMCMD-2)   { log(0, "error  : too many commands, only %d supported\n",SFKPATCH_MAX_NUMCMD); return 2; }
            aifrom[icmd]    = iline+1;
            break;
         }

      }  // endfor inner loop

   }  // endfor outer loop (bDone)

   if (!bHavePatchIDForThisFile && !bGlblNoPID) {
      log(0, "error  : line %d: [patch-id] missing!\n",nGlblLine);
      log(0, "info   : you must supply at least one [patch-id] within a :to block per :file,\n"
             "info   : otherwise i cannot identify already-patched files.\n");
      return 2;
   }

   // =========== pre-scan the target file, find out if it's patched =====================

   int bTargetIsPatched = 0;

   FILE *ftarg2 = fopen(pszTargFileName, "r");

   if (!ftarg2) { log(0, "error  : cannot read target file: %s\n", pszTargFileName); return 2+4; }

   while (fgets(szBuf,sizeof(szBuf)-10,ftarg2) != NULL)
      if (strstr(szBuf,"[patch-id]") != 0)
         bTargetIsPatched = 1;

   fclose(ftarg2);

   // ====================================================================================

   char szProbeCmd[MAX_LINE_LEN];

 if (!bGlblSimulate)
 { // begin backup block

   // make a backup of the target file
   char szRelFileName[1024];
   char szBackupDir[MAX_LINE_LEN];
   strcpy(szBackupDir, pszTargFileName);
   char *pszLastDir = strrchr(szBackupDir, glblPathChar);
   // if (!pszLastDir) { log(0, "error  : no '%c' path character in %s, cannot create backup dir.\n", glblPathChar, szBackupDir); return 2; }
   if (pszLastDir) {
      pszLastDir++;
      strcpy(szRelFileName,pszLastDir);
      *pszLastDir = 0;
      strcat(szBackupDir, "save_patch");
   } else {
      // file name without any path:
      strcpy(szRelFileName, pszTargFileName);
      strcpy(szBackupDir, "save_patch");
   }

   // IS a backup file already existing?
   sprintf(szProbeCmd,"%s%c%s",szBackupDir,glblPathChar,szRelFileName);

   // are we by any chance in REVOKE mode?
   if (bGlblRevoke && bTargetIsPatched)
   {
      // YES: copy backup file back.
      char szCopyCmd[MAX_LINE_LEN];
      // 0. ensure backup exists
      if (!fileExists(szProbeCmd)) { log(0, "error  : cannot revoke, no backup file: %s\n",szProbeCmd); return 1+4; }
      // is there an old target?
      if (fileExists(pszTargFileName))
      {
         // 1. ensure target is writeable
         #ifdef _WIN32
         sprintf(szCopyCmd, "attrib -R %s",pszTargFileName);
         #else
         sprintf(szCopyCmd, "chmod +w %s", pszTargFileName);
         #endif
         if (system(szCopyCmd)) { }
         #ifdef _WIN32
         // 2. delete target to ensure copy will work
         sprintf(szCopyCmd, "del %s",pszTargFileName);
         if (system(szCopyCmd)) { }
         #endif
      }
      // 3. copy backup over target
      if (bGlblTouchOnRevoke) {
         // make sure target has current timestamp
         FILE *fsrc = fopen(szProbeCmd, "rb");
         if (!fsrc) { log(0, "error  : cannot open %s\n",szProbeCmd); return 2+4; }
         FILE *fdst = fopen(pszTargFileName,"wb");
         if (!fdst) { log(0, "error  : cannot open %s\n",pszTargFileName); return 2+4; }
         // quick binary block copy
         // size_t fread( void *buffer, size_t size, size_t count, FILE *stream );
         // size_t fwrite( const void *buffer, size_t size, size_t count, FILE *stream );
         size_t ntotal = 0;
         while (1) {
            size_t nread = fread(szCopyCmd, 1, sizeof(szCopyCmd), fsrc);
            if (nread <= 0)
               break;
            fwrite(szCopyCmd, 1, nread, fdst);
            ntotal += nread;
         }
         fclose(fdst);
         fclose(fsrc);
         // write-protect target
         #ifdef _WIN32
         sprintf(szCopyCmd, "attrib +R %s",pszTargFileName);
         #else
         sprintf(szCopyCmd, "chmod -w %s", pszTargFileName);
         #endif
         if (system(szCopyCmd)) { }
         log(5, "revoked: %s, %u bytes\n",pszTargFileName,(unsigned int)ntotal);
         nGlblRevokedFiles++;
      } else {
         // xcopy requires us to create a dummy, otherwise we get a prompting
         FILE *fdst = fopen(pszTargFileName,"w");
         if (!fdst) { log(0, "error  : cannot open %s\n",pszTargFileName); return 2+4; }
         fprintf(fdst, "tmp\n\n"); fflush(fdst);
         fclose(fdst);
         // no overwrite this with /K, keeping potential +R attributes
         #ifdef _WIN32
         sprintf(szCopyCmd, "xcopy /Q /K /Y %s %s >nul",szProbeCmd,pszTargFileName);
         #else
         sprintf(szCopyCmd, "cp -p %s %s",szProbeCmd,pszTargFileName);
         #endif
         int iRC = system(szCopyCmd);
         if (!iRC) {
            log(5, "revoked: %s\n",pszTargFileName);
            nGlblRevokedFiles++;
         } else {
            log(0, "revoke failed: %s\n",pszTargFileName);
            return 1;
         }
      }
      // 4. make backup writeable, and remove
      #ifdef _WIN32
      sprintf(szCopyCmd, "attrib -R %s",szProbeCmd);
      #else
      sprintf(szCopyCmd, "chmod +w %s", szProbeCmd);
      #endif
      if (system(szCopyCmd)) { }
      if (remove(szProbeCmd)) {
         log(0, "error  : cannot delete stale backup: %s\n",szProbeCmd);
         return 1;
      }
      return 0;
   }

   if (bGlblRevoke && !bTargetIsPatched)
   {
      if (!bTargetIsPatched) {
         log(0, "warning: isn't patched, will not revoke: %s\n",pszTargFileName);
      }
   }

   // otherwise continue creating a backup
   if (bGlblBackup)
   {
      // prepare: if stale backup, delete first
      if (fileExists(szProbeCmd))
      {
         // remove old backup, most probably stale
         char szCopyCmd[MAX_LINE_LEN];
         log(5, "del.bup: %s\n",szProbeCmd);
         #ifdef _WIN32
         sprintf(szCopyCmd, "attrib -R %s",szProbeCmd);
         #else
         sprintf(szCopyCmd, "chmod +w %s", szProbeCmd);
         #endif
         if (system(szCopyCmd)) { }
         if (remove(szProbeCmd)) {
            log(0, "error  : cannot delete stale backup: %s\n",szProbeCmd);
            return 1;
         }
      }

      // create backup dir and file
      char szCopyCmd[MAX_LINE_LEN];
      int iRC = 0;
      // sprintf(szCopyCmd,"mkdir %s",szBackupDir);
      // int iRC = system(szCopyCmd); // create backup dir, if not done yet
      #ifdef _WIN32
      if (_mkdir(szBackupDir))
      #else
      if (mkdir(szBackupDir, S_IREAD | S_IWRITE | S_IEXEC))
      #endif
      {
         // log(0, "warning: cannot create backup dir: %s\n",szBackupDir);
         // return 1;
      }
      #ifdef _WIN32
      sprintf(szCopyCmd,"xcopy /Q /K %s %s >nul",pszTargFileName,szBackupDir);
      #else
      sprintf(szCopyCmd,"cp -p %s %s",pszTargFileName,szBackupDir);
      #endif
      iRC = system(szCopyCmd); // create backup file
      if (iRC) {log(0, "error  : creation of backup file failed: RC %d\n",iRC); return 2+4; }
      if (fileExists(szProbeCmd)) {
         log(5, "backupd: %s\n",szProbeCmd);
      } else {
         log(0, "error  : verify of backup file failed: %s\n",szProbeCmd); return 2+4;
      }
      return 0;
   }

 } // end backup block

   if (bGlblRevoke)
      return 0;

   // 3. read and patch the target file
   FILE *ftarg = fopen(pszTargFileName, "r");
   if (!ftarg) { log(0, "error  : cannot read target file: %s\n", pszTargFileName); return 2+4; }

   // we cache the output in memory
   int iout = 0;

   int isrcbuf=0, ipatmatch=0;
   aBuf[0] = 0;
   int icmd2 = 0, nLine = 0, nTargLineEndings = -1;
   while (fgets(szBuf,sizeof(szBuf)-10,ftarg) != NULL)
   {
      nLine++;

      // make sure target file has SAME line endings as cmd file.
      if (nTargLineEndings == -1)
      {
         if (strstr(szBuf,"\r\n") != 0)
            nTargLineEndings = 2;   // CR/LF
         else
            nTargLineEndings = 1;   // LF only
         if (nCmdFileLineEndings != nTargLineEndings)
         {
            log(0, "error  : different line endings!\n");
            log(0, "error  :   the patch file uses %s line endings.\n",(nCmdFileLineEndings==2)?"CR/LF":"LF");
            log(0, "error  :   this target file uses %s line endings: %s\n",(nTargLineEndings==2)?"CR/LF":"LF",pszTargFileName);
            return 2;
         }
      }

      if (strstr(szBuf,"[patch-id]") != 0) {
         if (bGlblVerify) {
            if (!bGlblQuickSum)
               log(5, "checked: %s is still patched\n",pszTargFileName);
            return 0;
         }
         if (!bGlblNoPID) {
            log(0, "error  : %s already patched\n",pszTargFileName);
            return 1;
         }
      }

      // does current in-line match the CURRENT pattern's current line?
      if ((icmd2<icmd) && !compareLines(szBuf,aPatch[aifrom[icmd2]+ipatmatch]))
      {
         ipatmatch++;
         aBuf[isrcbuf++] = strdup(szBuf);
         if (isrcbuf > SFKPATCH_MAX_CACHELINES-10) { log(0, "pattern cache overflow, %d lines exceeded\n",(int)SFKPATCH_MAX_CACHELINES); return 2; }
         if (ipatmatch == aifromlen[icmd2]) {
            // full pattern match:
            // write replacement pattern
            for (int i3=0;i3<aitolen[icmd2];i3++) {
               apOut[iout++] = strdup(aPatch[aito[icmd2]+i3]);
               if (iout > SFKPATCH_MAX_OUTLINES-10) { log(0, "output cache overflow, %d lines exceeded\n",(int)SFKPATCH_MAX_OUTLINES); return 2; }
            }
            // drop the cache
            for (int i4=0;i4<isrcbuf;i4++)
               free(aBuf[i4]);
            // reset stats
            isrcbuf=0;
            ipatmatch=0;
            // switch to next command
            icmd2++;
         }
      } else {
         // flush and clear the cache, if any
         for (int i2=0;i2<isrcbuf;i2++) {
            apOut[iout++] = strdup(aBuf[i2]);
            if (iout > SFKPATCH_MAX_OUTLINES-10) { log(0, "output cache overflow, %d lines exceeded\n",(int)SFKPATCH_MAX_OUTLINES); return 2; }
            free(aBuf[i2]);
         }
         // flush also current line, which wasn't cached
         apOut[iout++] = strdup(szBuf);
         if (iout > SFKPATCH_MAX_OUTLINES-10) { log(0, "output cache overflow, %d lines exceeded\n",(int)SFKPATCH_MAX_OUTLINES); return 2; }
         // reset stats
         isrcbuf=0;
         ipatmatch=0;
      }
   }

   if (icmd2 != icmd) {
      log(0, "error  : from-pattern %d of %d mismatch, in file %s\n",icmd2+1,icmd,pszTargFileName);
      log(0, "info   : check pattern content and SEQUENCE (must match target sequence).\n");
      return 2;
   }

   fclose(ftarg);

 if (!bGlblSimulate)
 {
   // now, we hold the patched target file in apOut.
   // overwrite the target.
   int bSwitchedAttrib = 0;
   cchar *pszFileMode = "w";
   if (bGlblUnixOutput)
         pszFileMode = "wb";
   ftarg = fopen(pszTargFileName, pszFileMode);
   if (!ftarg) {
      // open for write failed? try switching attributes
      #ifdef _WIN32
      sprintf(szProbeCmd, "attrib -R %s",pszTargFileName);
      #else
      sprintf(szProbeCmd, "chmod +w %s", pszTargFileName);
      #endif
      if (system(szProbeCmd)) { }
      bSwitchedAttrib = 1;
      ftarg = fopen(pszTargFileName, pszFileMode);
   }
   if (!ftarg) {
      log(0, "error  : cannot overwrite target file: %s\n", pszTargFileName); return 2+4;
   }

   // write and free all memory lines
   for (int n=0; n<iout; n++)
   {
      strcpy(szBuf, apOut[n]);

      // apply local changes, which have priority over globals
      int ipat=0;
      for (ipat=0; ipat<iLocalChange; ipat++) {
         if (   (strstr(szBuf, apLocalChange[ipat][0]) != 0)
             && (strstr(szBuf, apLocalChange[ipat][1]) != 0)
            )
         {
            // replace pattern within line
            if (bGlblVerbose) { printf("lc1>%s",szBuf);fflush(stdout); }

            char *psz = strstr(szBuf, apLocalChange[ipat][1]);
            *psz = 0;
            strcpy(szBuf2,szBuf);
            strcat(szBuf2,apLocalChange[ipat][2]);
            psz += strlen(apLocalChange[ipat][1]);
            strcat(szBuf2,psz);
            strcpy(szBuf,szBuf2);

            if (bGlblVerbose) { printf("lc2>%s",szBuf);fflush(stdout); }

            anLocalChange[ipat]++;
         }
      }

      // apply global changes, if anything left to change
      for (ipat=0; ipat<iGlobalChange; ipat++) {
         if (   (strstr(szBuf, apGlobalChange[ipat][0]) != 0)
             && (strstr(szBuf, apGlobalChange[ipat][1]) != 0)
            )
         {
            // replace pattern within line
            if (bGlblVerbose) { printf("gc1>%s",szBuf);fflush(stdout); }

            char *psz = strstr(szBuf, apGlobalChange[ipat][1]);
            *psz = 0;
            strcpy(szBuf2,szBuf);
            strcat(szBuf2,apGlobalChange[ipat][2]);
            psz += strlen(apGlobalChange[ipat][1]);
            strcat(szBuf2,psz);
            strcpy(szBuf,szBuf2);

            if (bGlblVerbose) { printf("gc2>%s",szBuf);fflush(stdout); }

            anGlobalChange[ipat]++;
         }
      }

      // apply detabbing, if selected
      if (nLocalDetabOutput) {
         if (detabLine(szBuf, szBuf2, MAX_LINE_LEN, nLocalDetabOutput))
            return 9;
      }
      if (nGlblDetabOutput) {
         if (detabLine(szBuf, szBuf2, MAX_LINE_LEN, nGlblDetabOutput))
            return 9;
      }

      // apply unix conversion or not, and finally write
      if (bGlblUnixOutput) {
         char *psz = strrchr(szBuf,'\n'); if (psz) *psz = 0;
               psz = strrchr(szBuf,'\r'); if (psz) *psz = 0;
         fprintf(ftarg, "%s\n", szBuf);
      } else {
         fputs(szBuf,ftarg);
      }

      free(apOut[n]);
   }

   fclose(ftarg);

   // have to re-enable write protection?
   if (bSwitchedAttrib) {
      #ifdef _WIN32
      sprintf(szProbeCmd, "attrib +R %s",pszTargFileName);
      #else
      sprintf(szProbeCmd, "chmod -w %s", pszTargFileName);
      #endif
      if (system(szProbeCmd)) { }
   }

   if (bSwitchedAttrib) {
      log(5, "Patched: %s, %d lines.\n",pszTargFileName,iout);
   } else {
      log(5, "patched: %s, %d lines.\n",pszTargFileName,iout);
   }
   nGlblPatchedFiles++;
 }
 else {
   log(5, "checked: %s, %d lines.\n",pszTargFileName,iout);
 }

   if (bGlblVerify) {
      log(0, "error  : %s no longer patched - probably overwritten\n",pszTargFileName);
      return 1;
   }

   return 0;
}

// ----------- sfk inst - c++ source code instrumentation support --------------

#define SFKINST_TRBSIZE    200 // token ring buffer
#define SFKINST_BLINESIZE 1024
#define SFKINST_BLINEMAX    50

class SrcParse
{
public:
   SrcParse ( );
   uint processFile (char *pText, bool bSimulate, FILE *foutOptional);
   void  processLine (char *pBuf, bool bSimulate);

protected:
   void addtok    (char c);
   void addWord   ( );
   void addColon  ( );
   void addScope  ( );
   void addBra    ( );
   void addKet    ( );
   void addCBra   ( );
   void addCKet   ( );
   void addSemi   ( );
   void addRemark ( );
   bool hasFunctionStart (uint &rn1stline);
   char pretok    (uint &itok2, uint &nstepdowncnt, uint &rnline);
   void addDetectKeyword   (char **rpsz);
   void reduceSignature    (char *pszIn, char *pszOut);

   enum eSFKInstScanStates {
      ess_idle  = 1,
      ess_word  = 2,
      ess_num   = 3,
      ess_colon = 4,
      ess_slash = 5
      };

private:
   uchar atok[SFKINST_TRBSIZE+10];
   uint itok;
   uchar altok[SFKINST_TRBSIZE+10]; // just for the current line
   uint iltok;
   uint atokline[SFKINST_TRBSIZE+10]; // line number of token
   uint nline;
   char  abline[SFKINST_BLINEMAX][SFKINST_BLINESIZE+2];
   uint ibline;
   uint ibackscope;
   bool  bbackscope;
   FILE *clOut;
   uint nClHits;

   char szLineBuf[MAX_LINE_LEN+10];
   char szLineBuf2[MAX_LINE_LEN+10];
   char szLineBuf3[MAX_LINE_LEN+10];
   char szBupDir[MAX_LINE_LEN+10];
   char szBupFile[MAX_LINE_LEN+10];
   char szCopyCmd[MAX_LINE_LEN+10];

public:
static bool
   bdebug,
   binsteol;

static cchar
   *pszGlblInclude,
   *pszGlblMacro;
};

bool   SrcParse::bdebug = 0;
bool   SrcParse::binsteol = 0;
cchar *SrcParse::pszGlblInclude = "";
cchar *SrcParse::pszGlblMacro   = "";

SrcParse::SrcParse()
{
   memset(this, 0, sizeof(*this));
}

uint SrcParse::processFile(char *pText, bool bSimulate, FILE *fout)
{
   if (!bSimulate) {
      clOut = fout;
      fprintf(fout, "#include \"%s\" // [instrumented]\n", pszGlblInclude);
   }

   // char *pCopy = strdup(pText);
   uint nTextLen = strlen(pText);
   char *pCopy = new char[nTextLen+10];
   if (!pCopy) { fprintf(stderr, "error  : out of memory at %d\n", __LINE__); return 0; }
   memcpy(pCopy, pText, nTextLen+1);

   nClHits = 0;

   // NO RETURNS FROM HERE

   uint nMaxLineLen = sizeof(szLineBuf)-10;
   char *psz1 = pCopy;
   char *pszContinue = 0;
   while (psz1)
   {
      char *psz2 = strchr(psz1, '\n');
      if (psz2)
      {
         pszContinue = psz2+1;
         int nLineLen = psz2 - psz1;
         if (nLineLen > (int)nMaxLineLen) nLineLen = nMaxLineLen;
         strncpy(szLineBuf, psz1, nLineLen);
         szLineBuf[nLineLen] = '\0';
         char *pszCR = strchr(szLineBuf, '\r');
         if (pszCR) *pszCR = '\0';
      }
      else
      {
         memset(szLineBuf, 0, sizeof(szLineBuf));
         strncpy(szLineBuf, psz1, nMaxLineLen);
         pszContinue = 0;
      }

      processLine(szLineBuf, bSimulate);
      psz1 = pszContinue;
   }

   // NO RETURNS UNTIL HERE

   delete [] pCopy;

   return nClHits;
}

bool isatoz(char c) { char c2=tolower(c); return (c2>='a' && c2<='z'); }
bool isnum_(char c) { return (c>='0' && c<='9') || (c=='_'); }

void SrcParse::reduceSignature(char *psz1, char *psz2)
{
   // reduce [type] class::method([parms])
   //     to class::method

   // goto last scope (in case there are many)
   //     cls1::type1 & cls2::type2::method3(
   char *pszs = strstr(psz1, "::");
   if (!pszs) { strcpy(psz2, psz1); return; }
   char *prbra = strrchr(psz1, '(');
   char *pszn;
   while ((pszn = strstr(pszs+1, "::")) && (pszn < prbra))
      pszs = pszn;
   // find head
   char *pszh = pszs-1;
   while (pszh >= psz1) {
      char c = *pszh;
      // if (!isnum_(c) && !isatoz(c))
      //    break;
      if (c == ' ' || c == '\t')
         break;
      pszh--;
   }
   while ((pszh<pszs) && !isatoz(*pszh))
      pszh++;
   // find tail
   char *pszt = pszs+2;
   while (*pszt) {
      char c = *pszt;
      // if ((c != '~') && !isnum_(c) && !isatoz(c))
      //   break;
      if (c == '(')
         break;
      pszt++;
   }
   while ((pszt > pszh) && (*pszt == ' ' || *pszt == '('))
      pszt--;
   pszt++;
   // check and copy
   if (pszh < pszt) {
      strncpy(psz2, pszh, pszt-pszh);
      psz2[pszt-pszh] = '\0';
   } else {
      strcpy(psz2, "?::?");
   }
}

void SrcParse::processLine(char *pszLine, bool bSimulate)
{
   nline++;

   char *pszx;
   if ((pszx = strchr(pszLine, '\n'))) *pszx = '\0';
   if ((pszx = strchr(pszLine, '\r'))) *pszx = '\0';

   // store in backline buffer
   strncpy(abline[ibline], pszLine, SFKINST_BLINESIZE-10);
   abline[ibline][SFKINST_BLINESIZE-10] = '\0';
   if (ibackscope == ibline) {
      bbackscope = 0; // got overwritten
   }

   // reset current line token buffer.
   // this is handled like a string, with zero terminator.
   iltok = 0;
   memset(altok, 0, sizeof(altok));

   // printf("] %s\n", pszLine);
   // printf("] %s\n", abline[ibline]);

   char *psz1 = pszLine;
   char c1;
   uchar nstate = ess_idle;
   do
   {
      c1 = *psz1; // incl. null at eol

      mtklog(("inst: %c %d",c1,nstate));

      if (isatoz(c1)) {
         switch (nstate) {
            case ess_idle:
               nstate=ess_word;
               addDetectKeyword(&psz1);
               break;
         }
      }
      else
      if (isnum_(c1)) {
         switch (nstate) {
            case ess_idle: nstate=ess_num ; break;
         }
      }
      else
      {
         // NOT alphanumeric
         switch (nstate) {
            case ess_word : nstate=ess_idle; addWord(); break;
         }

         if (c1 == '/') {
            switch (nstate) {
               case ess_idle : nstate=ess_slash; break;
               case ess_slash:
                  nstate=ess_idle ; addRemark(); c1=0; break;
            }
         }
         else
         if (c1 == '*') {
            switch (nstate) {
               case ess_slash:
                  nstate=ess_idle; addRemark(); break;
            }
         }
         else
         if (nstate == ess_slash)
             nstate = ess_idle;

         if (c1 == ':') {
            switch (nstate) {
               case ess_idle : nstate=ess_colon; break;
               case ess_colon: nstate=ess_idle ; addScope(); break;
            }
         }
         else
         if (nstate == ess_colon) {
             nstate = ess_idle;
             addColon();
         }
 
         if (c1 == '(') { nstate=ess_idle; addBra(); }
         else
         if (c1 == ')') { nstate=ess_idle; addKet(); }
         else
         if (c1 == '{') { nstate=ess_idle; addCBra(); }
         else
         if (c1 == '}') { nstate=ess_idle; addCKet(); }
         else
         if (c1 == ';') { nstate=ess_idle; addSemi(); }
      }

      psz1++;
   }
   while (c1);
   // printf("\n");

   // assumed function start in current line?
   if (   strstr((char*)altok, "wsw(")
       || strstr((char*)altok, "wsww(")
      )
   {
      ibackscope = ibline;
      bbackscope = 1;
   }

   strcpy(szLineBuf2, szLineBuf);

   // REDUCTION: so far, this accepts only "{" lines
   //            without anything else in it.
   if (hasFunctionStart(ibackscope))
   {
      char *pszMethodStartLine = abline[ibackscope];

      mtklog(("inst:   msline \"%.20s\"", pszMethodStartLine));

     if (bdebug)
     {
      printf("FN BODY at %d: %s\n", nline, (char*)atok);
      char *psz1;
      uint i2 = ibackscope;
      while ((psz1 = abline[i2])) {
         if (strlen(psz1))
            printf("] %s\n", psz1);
         if (i2 == ibline)
            break;
         if (++i2 >=  SFKINST_BLINEMAX)
            i2 = 0;
      }
     }

      // the current line contains the relevant "{" somewhere.
      // for now, we instrument only simple lines:
      mtklog(("inst:   lbuf2  \"%s\"", szLineBuf2));
      // accept "{" but also "[anywhitespace]{"
      char *pszs = szLineBuf2;
      while (*pszs && (*pszs==' ' || *pszs=='\t')) pszs++;
      if (!strcmp(pszs, "{")) {
         reduceSignature(pszMethodStartLine, szLineBuf3);
         sprintf(pszs, "{%s(\"%s\");", pszGlblMacro, szLineBuf3);
         // printf("=> %s \"%s\"\n", szLineBuf2, pszMethodStartLine);
         nClHits++;
      }
      else
      if (binsteol)
      do
      {
         // also instrument "{" at end of line
         char *pcur = strrchr(szLineBuf2, '{');
         if (!pcur) break;
         if (!strcmp(pcur, "{")) {
            reduceSignature(pszMethodStartLine, szLineBuf3);
            sprintf(pcur, "{%s(\"%s\");", pszGlblMacro, szLineBuf3);
            // printf("=> %s \"%s\"\n", szLineBuf2, pszMethodStartLine);
            nClHits++;
         }
      }
      while (0);
   }
   // else keep szLineBuf2 unchanged

   if (!bSimulate) {
      fputs(szLineBuf2, clOut);
      fputc('\n', clOut);
   }

   if (++ibline >= SFKINST_BLINEMAX)
      ibline = 0;
}

void SrcParse::addDetectKeyword(char **rpsz)
{
   char *psz1 = *rpsz;
   if (!strncmp(psz1, "class ", strlen("class ")))
      {  addtok('k'); psz1+=strlen("class "); }
   else
   if (!strncmp(psz1, "struct ", strlen("struct ")))
      {  addtok('k'); psz1+=strlen("struct "); }
   *rpsz = psz1;
}

void SrcParse::addWord()   { addtok('w'); }
void SrcParse::addColon()  { addtok(':'); }
void SrcParse::addScope()  { addtok('s'); }
void SrcParse::addBra()    { addtok('('); }
void SrcParse::addKet()    { addtok(')'); }
void SrcParse::addCBra()   { addtok('{'); }
void SrcParse::addCKet()   { addtok('}'); }
void SrcParse::addSemi()   { addtok(';'); }
void SrcParse::addRemark() { addtok('r'); }

void SrcParse::addtok(char c)
{
   mtklog(("inst:  addtok %c", c));

   atok[itok] = c;
   atokline[itok] = ibline;
   if (++itok >= SFKINST_TRBSIZE)
      itok = 0;
   atok[itok] = '*';

   altok[iltok] = c;
   if (++iltok >= SFKINST_TRBSIZE)
      iltok = 0;
   altok[iltok] = '*';
   // printf("%c", c);
}

char SrcParse::pretok(uint &itok2, uint &nstepcnt, uint &rnline)
{
   if (nstepcnt == 0)
      return 0;
   else
      nstepcnt--;

   if (itok2 == 0)
      itok2 = SFKINST_TRBSIZE-1;
   else
      itok2--;

   rnline = atokline[itok2];
   return atok[itok2];
}

bool SrcParse::hasFunctionStart(uint &rnline)
{
   uint itok2 = itok;
   uint ncnt  = SFKINST_TRBSIZE;

   // W* S W B W* K ** {

   uint ntline = 0;
   char c1 = pretok(itok2, ncnt, ntline);
   if (!c1) return false;
   if (c1 != '{') {
      mtklog(("inst:   hasfs %c, false", c1));
      return false;
   }

   // have a curly braket:

   uint nBra = 0;
   uint nKet = 0;
   uint nrc  = 0;
   uint nScope = 0;
   uint nBraDist = 0; // word distance from last bra
 
   while (!nrc && (c1 = pretok(itok2, ncnt, ntline))) {
      switch (c1) {
         case 's':
            if (bdebug) printf("s-hit %d %d\n",nBra,nKet);
            if (nBra > 0 && (nBra == nKet) && (nBraDist==1))
            {
               rnline = ntline;
               // nrc = 1;
               nScope++;
            }
            break;
         case '{': nrc=2; break;
         case '}': nrc=3; break;
         case ';': nrc=4; break;
         case '(': nBra++; nBraDist=0; break;
         case ')': nKet++; break;
         case ':': nBra=nKet=0; break;
         case 'k': nrc=5; break; // class or struct
         case 'w':
            nBraDist++;
            if (nScope == 1) {
               // probably standing on wsw(
               nrc = 1;
            }
            break;
      }
   }

   if (nrc == 1) {
      mtklog(("inst:   hasfs true"));
      return true;
   }

   if (bdebug) {
      printf("MISS.%d: %s %d %d\n", nrc, (char*)atok,nBra,nKet);
      char *psz1;
      uint i2=ibackscope;
      while ((psz1 = abline[i2])) {
         if (strlen(psz1))
            printf("] %s\n", psz1);
         if (i2 == ibline)
            break;
         if (++i2 >=  SFKINST_BLINEMAX)
            i2 = 0;
      }
   }

   return false;
}

static int fileSize(char *pszFile)
{
   struct stat sinfo;
   if (stat(pszFile, &sinfo))
      return -1;
   return sinfo.st_size;
}

// NOTE: DO NOT FORGET TO DELETE RESULT
static char *loadFile(char *pszFile, int nLine)
{
   int lFileSize = fileSize(pszFile);
   if (lFileSize < 0)
      return 0;
   char *pOut = new char[lFileSize+10];
   if (!pOut)
      return 0;
   memset(pOut, 0, lFileSize+10);
   FILE *fin = fopen(pszFile, "rb");
   if (!fin) { fprintf(stderr, "error  : cannot read: %s\n", pszFile); return 0; }
   int nRead = fread(pOut, 1, lFileSize, fin);
   fclose(fin);
   if (nRead != lFileSize) {
      fprintf(stderr, "error  : cannot read: %s (%d %d)\n", pszFile, nRead, lFileSize);
      delete [] pOut;
      return 0;
   }
   pOut[lFileSize] = '\0';
   return pOut;
}

int sfkInstrument(char *pszFile, cchar *pszInc, cchar *pszMac, bool bRevoke, bool bRedo, bool bTouchOnRevoke, int nmode)
{
   char szLineBuf[MAX_LINE_LEN+10];
   char szLineBuf2[MAX_LINE_LEN+10];
   char szLineBuf3[MAX_LINE_LEN+10];
   char szBupDir[SFK_MAX_PATH+100];
   char szBupFile[SFK_MAX_PATH+100];
   char szCopyCmd[MAX_LINE_LEN+10];

   // printf("INST %s %u %s %s\n",pszFile,bRevoke,pszInc,pszMac);

   SrcParse::binsteol = (nmode & 1) ? 1 : 0;

   SrcParse::pszGlblInclude = pszInc;
   SrcParse::pszGlblMacro   = pszMac;

   #ifdef _WIN32
   if (strstr(pszFile, "save_inst\\"))
   #else
   if (strstr(pszFile, "save_inst/"))
   #endif
   {
      fprintf(stderr, "warning: exclude, cannot instrument: %s\n", pszFile);
      return 5;
   }

   // create backup infos
   strcpy(szBupDir, pszFile);
   char *pszPath = strrchr(szBupDir, glblPathChar);
   if (pszPath) *pszPath = '\0';
   else strcpy(szBupDir, ".");
   char *pszRelFile = strrchr(pszFile, glblPathChar);
   if (pszRelFile) pszRelFile++;
   else pszRelFile = pszFile;
   strcat(szBupDir, glblPathStr);
   strcat(szBupDir, "save_inst");
   sprintf(szBupFile, "%s%c%s", szBupDir, glblPathChar, pszRelFile);
   // printf("BUPDIR: %s\n", szBupDir);
   // printf("BUPFIL: %s\n", szBupFile);

   if (bRevoke)
   {
      // first check if the file is really instrumented
      char *pFile = loadFile(pszFile, __LINE__);
      bool bisins = 1;
      if (pFile) {
         if (!strstr(pFile, "// [instrumented]"))
            bisins = 0;
         delete [] pFile;
      }

      if (!bisins)
      {
         if (!bRedo) {
            fprintf(stderr, "skipped: %s - not instrumented\n", pszFile);
            return 1;
         }  // else fall through
      }
      else
      {
         if (!fileExists(szBupFile)) { fprintf(stderr, "warning: cannot revoke, no backup: %s\n", pszFile); return 5; }
 
         if (fileExists(pszFile)) {
            // 1. ensure target is writeable
            #ifdef _WIN32
            sprintf(szCopyCmd, "attrib -R %s",pszFile);
            #else
            sprintf(szCopyCmd, "chmod +w %s", pszFile);
            #endif
            if (system(szCopyCmd)) { }
            #ifdef _WIN32
            // 2. delete target to ensure copy will work
            sprintf(szCopyCmd, "del %s",pszFile);
            if (system(szCopyCmd)) { }
            #endif
         }

         char *pszTargFileName = pszFile;

         if (bTouchOnRevoke)
         {
            // make sure target has current timestamp
            FILE *fsrc = fopen(szBupFile, "rb");
            if (!fsrc) { fprintf(stderr, "error  : cannot open %s\n",szBupFile); return 2+4; }
            FILE *fdst = fopen(pszTargFileName,"wb");
            if (!fdst) { fprintf(stderr, "error  : cannot open %s\n",pszTargFileName); return 2+4; }
            // quick binary block copy
            // size_t fread( void *buffer, size_t size, size_t count, FILE *stream );
            // size_t fwrite( const void *buffer, size_t size, size_t count, FILE *stream );
            size_t ntotal = 0;
            while (1) {
               size_t nread = fread(szCopyCmd, 1, sizeof(szCopyCmd), fsrc);
               if (nread <= 0)
                  break;
               fwrite(szCopyCmd, 1, nread, fdst);
               ntotal += nread;
            }
            fclose(fdst);
            fclose(fsrc);
            // write-protect target
            #ifdef _WIN32
            sprintf(szCopyCmd, "attrib +R %s",pszTargFileName);
            #else
            sprintf(szCopyCmd, "chmod -w %s", pszTargFileName);
            #endif
            if (system(szCopyCmd)) { }
            if (!bRedo) {
               printf("revoked: %s, %u bytes\n",pszTargFileName,(unsigned int)ntotal);
               return 0;
            }  // else fall through
         }
         else
         {
            // xcopy requires us to create a dummy, otherwise we get a prompting
            FILE *fdst = fopen(pszTargFileName,"w");
            if (!fdst) { fprintf(stderr, "error  : cannot open %s\n",pszTargFileName); return 9; }
            fprintf(fdst, "tmp\n\n"); fflush(fdst);
            fclose(fdst);
            // now overwrite this with /K, keeping potential +R attributes
            #ifdef _WIN32
            sprintf(szCopyCmd, "xcopy /Q /K /Y /R %s %s >nul",szBupFile,pszTargFileName);
            #else
            sprintf(szCopyCmd, "cp -p %s %s",szBupFile,pszTargFileName);
            #endif
            int iRC = system(szCopyCmd);
            if (!iRC) {
               if (!bRedo) {
                  printf("revoked: %s\n",pszTargFileName);
                  return 0;
               }  // else fall through
            } else {
               fprintf(stderr, "error  : revoke failed: %s\n",pszTargFileName);
               return 1;
            }
         }   // endelse touch-on-revoke
      }  // endelse is-instrumented
   }

   // instrument the target file

   int nsize = fileSize(pszFile);
   if (nsize <= 0) { fprintf(stderr, "skipped: %s - empty file\n", pszFile); return 5; }
   if (nsize > 50 * 1048576) { fprintf(stderr, "warning: too large, skipping: %s\n", pszFile); return 5; }

   char *pFile = loadFile(pszFile, __LINE__);
   if (!pFile)
      return 9;

   // COVER ALL RETURNS WITH pFILE CLEANUP FROM HERE:

   if (strstr(pFile, "// [instrumented]")) {
      fprintf(stderr, "warning: already instrumented, skipping: %s\n", pszFile);
      delete [] pFile;
      return 5;
   }

   SrcParse *pparse1 = new SrcParse();
   if (pparse1->processFile(pFile, 1, 0) == 0) {
      fprintf(stderr, "skipped: %s - nothing to change\n", pszFile);
      delete [] pFile;
      delete pparse1;
      return 5;
   }
   delete pparse1;

   // create backup file
   #ifdef _WIN32
   _mkdir(szBupDir);
   #else
   mkdir(szBupDir, S_IREAD | S_IWRITE | S_IEXEC);
   #endif
   FILE *ftmp = fopen(szBupFile,"w");
   if (ftmp) { fprintf(ftmp,"dummy"); fclose(ftmp); }
   #ifdef _WIN32
   sprintf(szLineBuf, "xcopy /Q /K /Y /R %s %s >nul",pszFile,szBupFile);
   #else
   sprintf(szLineBuf, "cp -p %s %s",pszFile,szBupFile);
   #endif
   int iRC = system(szLineBuf);
   if (iRC) {
      fprintf(stderr, "error  : cannot backup file to: %s\n",szBupFile);
      delete [] pFile;
      return 9;
   }

   // reopen target file for write
   FILE *fout = fopen(pszFile, "w");
   if (!fout) {
      // probably write protected
      #ifdef _WIN32
      sprintf(szLineBuf, "attrib -R %s", pszFile);
      #else
      sprintf(szLineBuf, "chmod +w %s",  pszFile);
      #endif
      if (system(szLineBuf)) { }
      // retry
      if (!(fout = fopen(pszFile, "w"))) {
         fprintf(stderr, "error  : unable to write: %s\n", pszFile);
         delete [] pFile;
         return 9;
      }
   }

   SrcParse *pparse2 = new SrcParse();
   uint nHits = pparse2->processFile(pFile, 0, fout);

   // cleanup
   delete pparse2;
   delete [] pFile;
   fclose(fout);

   if (bRedo)
      printf("redone : %s, %d hits\n", pszFile, nHits);
   else
      printf("inst'ed: %s, %d hits\n", pszFile, nHits);

   return 0;
}

static char abLineEditPartInfo[1024];
char abLineEditPartInfo2[1024];

static ushort aswchar(char c)
{
   ushort nres = ((ushort)c) & 0xFFU;
   // if (nres != c) printf("%c -> 0x%02x\n",c,nres);
   return nres;
}

int pointedit(char *pszMaskIn, char *pszSrc, int *pOutMatchLen, char *pszDst, int iMaxDst, bool verb)
{
   ushort aFrom[1024];
   ushort aInfoIdx[1024];
   ushort aTo[1024];
   char   aLitPart[22][610];
   char   aPart[22][610];
   int    iPartIdx= 0, iPartIdxMax = 12-2;
   int    iPartChr= 0, iPartChrMax = 610-10;

   char *pszMask = pszMaskIn;

   int iMaskLen = strlen(pszMask);
   if (iMaskLen < 3)
      return 10+(verb?perr("/from/to/ too short"):0);

   int iFromCur = 0;
   int iFromMax = (sizeof(aFrom)/sizeof(ushort))-10;
   int iToCur   = 0;
   int iToMax   = (sizeof(aTo)/sizeof(ushort))-10;

   // --- split from/to and tokenize ---

   char csep = *pszMask++;
   char ccur = 0, csub = 0; // BEWARE of char/ushort conversion! use aswchar()
   char *pszCur = 0;

   while (*pszMask!=0 && *pszMask!=csep)
   {
      if (iFromCur >= iFromMax)
         return 11+(verb?perr("from text too long"):0);

      pszCur = pszMask;

      ccur = *pszMask++;

      if (cs.spat!=0 && ccur=='\\') {
         int iskip=1;
         ccur=0;
         switch (*pszMask) {
            case 't': ccur='\t'; break;
            case 'q': ccur='"'; break;
            case '\\': case '*': case '?':
            case '[': case ']': case '#':
               ccur=*pszMask; break;
            case 'x':
               if (pszMask[1] && pszMask[2])
                  ccur = (char)getTwoDigitHex(pszMask+1);
               iskip=3;
               break;
         }
         if (!ccur)
            return 12+(verb?perr("invalid slash pattern: %s",pszMask-1):0);
         pszMask+=iskip;
         aInfoIdx[iFromCur] = (ushort)(pszMask-1-pszMaskIn);
         aFrom[iFromCur++] = aswchar(ccur);
         continue;
      }

      if (ccur == '*') {
         aFrom[iFromCur] = 0x2000U;
         // determine stop literal and store as part
         if (iPartIdx >= 20)
            return 13+(verb?perr("too many parts"):0);
         int iLitChrIdx = pszMask-pszMaskIn;
         int iLitChrLen = 0;
         for (; pszMask[iLitChrLen]; iLitChrLen++) {
            csub = pszMask[iLitChrLen];
            if (csub==csep || csub=='*' || csub=='?')
               break;
            aLitPart[iPartIdx][iLitChrLen] = aswchar(csub);
         }
         aLitPart[iPartIdx][iLitChrLen] = '\0';
         aFrom[iFromCur] += iPartIdx;
         aInfoIdx[iFromCur] = (ushort)(pszMask-1-pszMaskIn);
         iFromCur++;
         iPartIdx++;
         continue;
      }

      if (ccur == '?') {
         int ilen = 1;
         while (*pszMask!=0 && *pszMask=='?') {
            ilen++;
            pszMask++;
         }
         aInfoIdx[iFromCur] = (ushort)(pszMask-1-pszMaskIn);
         aFrom[iFromCur++] = 0x1000U + ilen;
         continue;
      }

      if (ccur == '[') {
         // [2 chars]
         int ilen = atoi(pszMask);
         while (isdigit(*pszMask))
            pszMask++;
         if (*pszMask!=' ')
            return 14+(verb?perr("wrong [] syntax: %s",pszCur):0);
         pszMask++;
         if (strBegins(pszMask, "chars]")) {
            pszMask += strlen("chars]");
            aInfoIdx[iFromCur] = (ushort)(pszMask-1-pszMaskIn);
            aFrom[iFromCur++] = 0x1000U + ilen;
            continue;
         }
         return 15+(verb?perr("wrong [] syntax: %s",pszCur):0);
      }

      aInfoIdx[iFromCur] = (ushort)(pszMask-1-pszMaskIn);
      aFrom[iFromCur++] = aswchar(tolower(ccur));
   }
   aFrom[iFromCur] = 0;
   iFromMax = iFromCur;
   if (*pszMask!=csep)
      return 16+(verb?perr("missing end separator '%c'",csep):0);
   pszMask++;

   int iToPart = 0;

   while (*pszMask!=0 && *pszMask!=csep)
   {
      if (iToCur >= iToMax)
         return 17+(verb?perr("to text too long"):0);

      if (cs.spat!=0 && *pszMask=='\\') {
         pszMask++;
         int iskip=1;
         ccur=0;
         switch (*pszMask) {
            case 't': ccur='\t'; break;
            case 'q': ccur='"'; break;
            case '\\': case '*': case '?':
            case '[': case ']': case '#': 
               ccur=*pszMask; break;
            case 'x':
               if (pszMask[1] && pszMask[2])
                  ccur = (char)getTwoDigitHex(pszMask+1);
               iskip=3;
               break;
         }
         if (!ccur)
            return 18+(verb?perr("invalid slash pattern: %s",pszMask-1):0);
         pszMask+=iskip;
         aTo[iToCur++] = aswchar(ccur);
         continue;
      }

      if (*pszMask=='#') {
         pszMask++;
         if (isdigit(*pszMask)) {
            iToPart = atoi(pszMask);
            while (isdigit(*pszMask))
               pszMask++;
         } else {
            iToPart++;
         }
         int ipart = iToPart;
         if (ipart > 0)
             ipart--;
         aTo[iToCur++] = 0x1000U + ipart;
         continue;
      }

      if (!strncmp(pszMask, "[parts ", 7))
      {
         pszMask += 7;
         bool bfill = 0;
         while (1)
         {
            // expect partno or ]
            if (isdigit(*pszMask)) {
               int ipart = atoi(pszMask);
               if (ipart < 1)
                  return 19+(verb?perr("wrong part number: %d",ipart):0);
               while (isdigit(*pszMask))
                  pszMask++;
               if (bfill) {
                  bfill=0;
                  iToPart++;
                  for (; iToPart<ipart; iToPart++)
                     aTo[iToCur++] = 0x1000U + (iToPart-1);
                  aTo[iToCur++] = 0x1000U + (ipart-1);
                  iToPart=ipart;
               } else {
                  iToPart=ipart;
                  aTo[iToCur++] = 0x1000U + (ipart-1);
               }
               continue;
            }
            if (*pszMask==',') {
               pszMask++;
               bfill=0;
               continue;
            }
            if (*pszMask=='-') {
               pszMask++;
               bfill=1;
               continue;
            }
            if (*pszMask==']') {
               pszMask++;
               break;
            }
            return 20+(verb?perr("wrong parts syntax"):0);
         }
         continue;
      }

      if (!strncmp(pszMask, "[part", 5)) {
         pszMask += 5;
         if (*pszMask==' ')
            pszMask++;
         int ipart = atoi(pszMask);
         if (ipart > 0)
             ipart--;
         iToPart=ipart+1;
         while (*pszMask!=0 && isdigit(*pszMask))
            pszMask++;
         if (*pszMask != ']')
            return 21+(verb?perr("missing ]"):0);
         pszMask++;
         aTo[iToCur++] = 0x1000U + ipart;
         continue;
      }

      aTo[iToCur++] = *pszMask++;
   }
   aTo[iToCur] = 0;
   iToMax = iToCur;
   if (*pszMask!=csep)
      return 22+(verb?perr("missing end separator '%c'",csep):0);

   pszMask++;
   if (*pszMask)
      return 23+(verb?perr("unexpected text after end separator '%c': %s",csep,pszMask):0);

   // --- match source and collect dynamic parts ---

   char *pSrcCur = pszSrc;
   int   iFrom   = 0;
   int   istate  = 0;
   int   imaxcol = 0;
   int   iLitPart= 0;

   iPartIdx = 0;
   iPartChr = 0;

   if (aFrom[iFrom] >= 0x2000U) {
      istate   = 2;
      iLitPart = aFrom[iFrom] & 0x0FFU;
      if (aLitPart[iLitPart][0])
         istate = 3;
   }
   else
   if (aFrom[iFrom] >= 0x1000U) {
      istate  = 1;
      imaxcol = aFrom[iFrom] & 0x0FFFU;
   }

   bool btrace = 0;

   if (iMaskLen+10 < sizeof(abLineEditPartInfo))
     memset(abLineEditPartInfo, ' ', iMaskLen);

   while (*pSrcCur && aFrom[iFrom])
   {
      // int ipinf = pSrcCur - pszSrc;
      // if (ipinf+10 < sizeof(abLineEditPartInfo))
      //    abLineEditPartInfo[ipinf] = '1'+(iPartIdx%10);

      ushort ninfidx = aInfoIdx[iFrom];
      if (ninfidx+10 < sizeof(abLineEditPartInfo))
         abLineEditPartInfo[ninfidx] = '1'+(iPartIdx%10);

      char csrc = *pSrcCur++;

      if (iPartIdx >= iPartIdxMax)
         return 24+(verb?perr("too many match parts"):0);
      if (iPartChr >= iPartChrMax)
         return 25+(verb?perr("match part overflow"):0);

      switch (istate)
      {
         case 0: // any or single char
            if (aFrom[iFrom] >= 0x1000U) {
               pSrcCur--;
               break;
            }
            if (aswchar(tolower(csrc)) != aFrom[iFrom]) {
               if (btrace) {
                  printf("miss %c %c\n",csrc,aFrom[iFrom]);
                  for (int i=0; i<iPartIdx; i++)
                     printf("p%d %s\n",i+1,aPart[i]);
               }
               return 1; // no match
            }
            // single char matched
            aPart[iPartIdx][iPartChr++] = csrc;
            iFrom++;
            continue;

         case 1: // group of ?
            aPart[iPartIdx][iPartChr++] = csrc;
            imaxcol--;
            if (imaxcol > 0)
               continue;
            iFrom++;
            break;

         case 2: // open *
            aPart[iPartIdx][iPartChr++] = csrc;
            continue;

         case 3: // * then literal
            // look for stop literal part
            char *psz  = pSrcCur-1;
            int   ichr = 0;
            char  c1=0, c2=0;
            for (;;ichr++) {
               c1 = tolower(psz[ichr]);
               c2 = tolower(aLitPart[iLitPart][ichr]);
               // if (btrace) printf("cmp %c %c\n",c1,c2);
               if (!c1 || !c2) break;
               if (c1 != c2) break;
            }
            if (c2) {
               aPart[iPartIdx][iPartChr++] = csrc;
               continue;
            }
            // stop literal match
            istate = 4;
            pSrcCur--;
            if (btrace) printf("stoplit match: %s\n",pSrcCur);
            iFrom++;
            break;
      }

      if (istate > 0 || iPartChr > 0) {
         aPart[iPartIdx][iPartChr] = '\0';
         iPartIdx++;
         iPartChr = 0;
      }

      if (aFrom[iFrom] >= 0x2000U) {
         istate   = 2;
         iLitPart = aFrom[iFrom] & 0x0FFU;
         if (aLitPart[iLitPart][0])
            istate = 3;
         if (btrace) printf("to state %d seeking \"%s\"\n",istate,aLitPart[iLitPart]);
      }
      else
      if (aFrom[iFrom] >= 0x1000U) {
         istate  = 1;
         imaxcol = aFrom[iFrom] & 0x0FFFU;
         if (btrace) printf("to state %d over %d chars on %s\n",istate,imaxcol,pSrcCur);
      }
      else if (aFrom[iFrom])
      {
         istate  = 0;
         if (btrace) printf("to state %d on %s mask %c\n",istate,pSrcCur,aFrom[iFrom]);
      }
   }
   if (iMaskLen+10 < sizeof(abLineEditPartInfo))
      abLineEditPartInfo[iMaskLen] = '\0';

   if (istate > 0) {
      aPart[iPartIdx][iPartChr] = '\0';
      iPartIdx++;
   }

   // is it a match?
   if (aFrom[iFrom]!=0 && istate!=2) {
      if (btrace) printf("mask not done at end of src\n");
      return 1;
   }
   // if (aFrom[iFrom]==0 && *pSrcCur!=0) {
   //    if (btrace) printf("src not done at end of mask\n");
   //    return 1;
   // }
   *pOutMatchLen = (int)(pSrcCur - pszSrc);
   if (btrace) printf("point match len=%d\n", *pOutMatchLen);

   if (btrace) {
      for (int i=0; i<iPartIdx; i++)
         printf("p%d %s\n",i+1,aPart[i]);
   }

   // --- build output from to mask and parts ---
 
   ushort *pToSrc = aTo;
   char *pDstCur = pszDst;
   char *pDstMax = pszDst+iMaxDst-10;
   while (*pToSrc)
   {
      if (pDstCur >= pDstMax)
         return 26+(verb?perr("output buffer overflow"):0);

      ushort csrc = *pToSrc++;

      if (csrc < 0x1000) {
         *pDstCur++ = (char)csrc;
         continue;
      }

      int ipart = csrc & 0xFFFU;
      if (ipart < 0 || ipart >= iPartIdxMax)
         return 27+(verb?perr("invalid part number: %d",ipart+1):0);

      char *ppart = aPart[ipart];
      while (*ppart) {
         if (pDstCur >= pDstMax)
            return 28+(verb?perr("output buffer overflow"):0);
         *pDstCur++ = *ppart++;
      }
   }
   *pDstCur = '\0';

   return 0;
}

void lineeditinit()
{
   memset(abLineEditPartInfo2, 0, sizeof(abLineEditPartInfo2));
}

char *lineeditinfo()
{
   return abLineEditPartInfo2;
}

int lineedit(char *pszMaskIn, char *pszSrc, char *pszDst, int iMaxDst, char *pAtt1, char *pAtt2, 
   uint flags, int *poff, int *plen)
{
   bool bexact = (flags & 1) ? 1 : 0;
   bool bverb  = (flags & 2) ? 1 : 0;

   char aPointBuf[1024];
   mclear(aPointBuf);

   char *pSrcOld = pszSrc;
   char *pSrcCur = pszSrc;
   char *pDstCur = pszDst;
   char *pDstMax = pszDst+iMaxDst-10;

   bool  bAnyDone = 0;

   if (cs.debug)
      printf("match name: %s\n", dataAsTrace(pszSrc,strlen(pszSrc)));

   while (*pSrcCur)
   {
      int imatch = 0;
      int isubrc = pointedit(pszMaskIn, pSrcCur, &imatch, aPointBuf, sizeof(aPointBuf), bverb);
      if (isubrc >= 10)
         return isubrc;
      if (isubrc > 0) {
         if (bexact)
            return 1;
         if (pDstCur > pDstMax)
            return 30+perr("ledit: output overflow");
         *pDstCur++ = *pSrcCur++;
         continue;
      }
      if (imatch < 1)
         return 31+perr("ledit: invalid match");
      int iedit = strlen(aPointBuf);
      // mark match src
      if (pAtt1) memset(pAtt1+(pSrcCur-pszSrc),'i',imatch);
      // mark match dst
      if (pAtt2) memset(pAtt2+(pDstCur-pszDst),'a',iedit);
      // copy edited part
      if (pDstCur+iedit > pDstMax)
         return 32+perr("ledit: output overflow");
      memcpy(pDstCur, aPointBuf, iedit);
      pDstCur += iedit;
      if (!bAnyDone)
      {
         bAnyDone = 1;
         if (!abLineEditPartInfo2[0]) {
            memcpy(abLineEditPartInfo2, abLineEditPartInfo, sizeof(abLineEditPartInfo));
            myrtrim(abLineEditPartInfo2);
         }
         if (poff) *poff = (int)(pSrcCur-pszSrc);
         if (plen) *plen = imatch;
      }
      // skip matched source
      pSrcCur += imatch;
      if (bexact && *pSrcCur)
         return 1;
   }
   *pDstCur = '\0';

   return bAnyDone ? 0 : 1;
}

int execRename(Coi *pcoi)
{
   char abSrcBuf[1024];
   char abDstRel[1024];
   char abSrcRelAtt[1024];
   char abDstRelAtt[1024];
   char abDstAbs[1024];
   char abSrcAbsAtt[1024];
   char abDstAbsAtt[1024];
   char abSrcPrint[1024];
   char abDstPrint[1024];

   mclear(abDstRel);
   mclear(abDstAbs);

   strcopy(abSrcBuf, pcoi->name());

   char *pszSrcPath = 0;
   char *pszRelFile = 0;

   char *prel = strrchr(abSrcBuf, glblPathChar);
   if (prel) {
      *prel++ = '\0';
      pszRelFile = prel;
      pszSrcPath = abSrcBuf;
   } else {
      pszRelFile = abSrcBuf;
      pszSrcPath = str("");
   }

   memset(abSrcRelAtt, 0, sizeof(abSrcRelAtt));
   memset(abSrcRelAtt, ' ', sizeof(abSrcRelAtt)-10);
   memset(abDstRelAtt, 0, sizeof(abDstRelAtt));
   memset(abDstRelAtt, ' ', sizeof(abDstRelAtt)-10);

   memset(abSrcAbsAtt, 0, sizeof(abSrcAbsAtt));
   memset(abSrcAbsAtt, ' ', sizeof(abSrcAbsAtt)-10);
   memset(abDstAbsAtt, 0, sizeof(abDstAbsAtt));
   memset(abDstAbsAtt, ' ', sizeof(abDstAbsAtt)-10);

   memset(abLineEditPartInfo, 0, sizeof(abLineEditPartInfo));

   if (cs.listfiles)
   {
      // just print selected files
      strcopy(abSrcPrint, pcoi->name());
      int iFullLen = strlen(abSrcPrint);
      int iPathLen = strlen(pszSrcPath)+1;
      int iRelOff  = iPathLen;
      int iRelLen  = iFullLen-iPathLen;
      if (iRelOff>=0 && iRelLen>0)
         memset(abSrcAbsAtt+iRelOff, 'i', iRelLen);
      printColorText(abSrcPrint, abSrcAbsAtt);
      return 0;
   }

   int iMatchOff=0,iMatchLen=0;
   int isubrc = lineedit(cs.renexp, pszRelFile,
                  abDstRel, sizeof(abDstRel),
                  abSrcRelAtt, abDstRelAtt,
                  cs.exact|2, &iMatchOff, &iMatchLen);

   if (isubrc) {
      // printf("miss: %s\n", pszFile);
      return 0; // no match
   }
   // printf("match: %s\n", pszFile);

   // fromtext matches
   int iDstRelSkip=0;
   if (cs.rentodir)
      joinPath(abDstAbs, sizeof(abDstAbs), cs.rentodir, abDstRel, &iDstRelSkip);
   else
      joinPath(abDstAbs, sizeof(abDstAbs), pszSrcPath, abDstRel, &iDstRelSkip);

   // ignore if no name change
   if (!strcmp(pcoi->name(), abDstAbs))
      return 0;

   // isolate output folder
   char szOutPath[1024];
   strcopy(szOutPath, abDstAbs);
   prel = strrchr(szOutPath, glblPathChar);
   #ifdef _WIN32
   if (!prel) {
      prel = strrchr(szOutPath, ':');
      if (prel)
         prel++;
   }
   #endif
   if (prel)
      *prel = '\0';
   else
      szOutPath[0] = '\0';
   // is output folder same as input?
   bool bMayCheckOutPath=1;
   if (!strcmp(szOutPath, pszSrcPath))
      bMayCheckOutPath=0;

   // highlight source match
   {
      int iCopyLen = strlen(pszRelFile);
      int iCopyPos = strlen(pcoi->name()) - iCopyLen;
      if (iCopyPos >= 0)
         memcpy(abSrcAbsAtt+iCopyPos+6, abSrcRelAtt, iCopyLen);
   }

   // highlight dst match
   {
      int iCopyLen = (int)strlen(abDstRel) - iDstRelSkip;
      int iCopyPos = (int)strlen(abDstAbs) - iCopyLen;
      if (iCopyPos >= 0 && iCopyLen > 0)
         memcpy(abDstAbsAtt+iCopyPos+6, abDstRelAtt+iDstRelSkip, iCopyLen);
   }

   snprintf(abSrcPrint, sizeof(abSrcPrint)-10, "FROM: %s", pcoi->name());
   abSrcPrint[sizeof(abSrcPrint)-10] = '\0';
   memset(abSrcAbsAtt, 'f', 6);
   printColorText(abSrcPrint, abSrcAbsAtt);

   if (cs.sim < 2)
   {
      bool bredundant=0;
      bool bexists=0;
      bool bnooutdir=0;
      bool bbadoutdir=0;

      if (cs.sim)
      {
         if (glblOutFileMap.isset(abDstAbs)) {
            bredundant=1;
            cs.filesRedundant++;
         } else {
            glblOutFileMap.put(abDstAbs);
         }

         Coi ocoi(abDstAbs, 0);
         if (ocoi.existsFile(1)) {
            bexists=1;
            cs.filesExisting++;
         }

         if (bMayCheckOutPath)
         {
            Coi opath(szOutPath, 0);
            if (opath.existsFile(0)) {
               if (cs.verbose>1)
                  printf("ERR : file exist with name: %s\n", szOutPath);
               bbadoutdir=1;
               cs.badOutDir++;
            }
            else if (!opath.existsFile(1)) {
               if (cs.verbose>1)
                  printf("ERR : dir does not exist: %s\n", szOutPath);
               bnooutdir=1;
               cs.noOutDir++;
            }
         }
      }

      if (bredundant || bexists || bnooutdir || bbadoutdir)
      {
         char szinfo[200];
         szinfo[0]='\0';
         cchar *szcont="";

         if (bredundant)
            { strcat(szinfo, "redundant"); szcont=","; }
         if (bexists)
            { strcat(szinfo, szcont); strcat(szinfo, "exists"); szcont=","; }
         if (bnooutdir)
            { strcat(szinfo, szcont); strcat(szinfo, "no outdir"); szcont=","; }
         if (bbadoutdir)
            { strcat(szinfo, szcont); strcat(szinfo, "bad outdir"); szcont=","; }

         snprintf(abDstPrint, sizeof(abDstPrint)-10, "ERR : %s - %s", abDstAbs, szinfo);
         abDstPrint[sizeof(abDstPrint)-10] = '\0';
         memset(abDstAbsAtt, 'e', 6);
         printColorText(abDstPrint, abDstAbsAtt);
      }
      else
      {
         snprintf(abDstPrint, sizeof(abDstPrint)-10, "TO  : %s", abDstAbs);
         abDstPrint[sizeof(abDstPrint)-10] = '\0';
         memset(abDstAbsAtt, 'f', 6);
         printColorText(abDstPrint, abDstAbsAtt);
      }
   }

   if (!cs.sim && cs.yes)
   {
      isubrc = pcoi->renameto(abDstAbs);
      if (isubrc)
         return 1+perr("... rename failed, rc=%d\n", isubrc);
   }

   return 0;
}

bool getistr(char *psz, int idigits, int ifrom, int ito, int &rout)
{
   int r=0;
   for (int i=0; i<idigits; i++)
   {
      char c = *psz++;
      if (!isdigit(c))
         return 0;
      r = r * 10 + (c - '0');
   }
   if (r < ifrom) return 0;
   if (r > ito) return 0;
   rout = r;
   return 1;
}

bool matchdate(char *pszsrcio, cchar *pszmask, int *adate, bool breorder=0)
{
   char *pszsrc = pszsrcio;

   int Y=0,M=0,D=0,h=0,m=0,s=0;
   int i=0,istate=0;

   int ireqdigits = 0;
   for (char *psz=(char*)pszmask; *psz; psz++)
      switch (*psz) {
         case 'Y': ireqdigits += 4; break;
         case 'M': ireqdigits += 2; break;
         case 'D': ireqdigits += 2; break;
         case 'h': ireqdigits += 2; break;
         case 'm': ireqdigits += 2; break;
         case 's': ireqdigits += 2; break;
      }

   int ihavedigits = 0;
   for (char *psz=pszsrc; *psz; psz++)
      if (isdigit(*psz))
         ihavedigits++;
      else
         break;

   if (ihavedigits < ireqdigits)
      return 0;

   while (*pszmask && *pszsrc)
   {
      switch (*pszmask)
      {
         case 'Y':
            if (!getistr(pszsrc,4,1970,3000,Y)) {
               if (istate) return 0;
               pszsrc++;
               continue;
            }
            adate[0] = Y;
            pszmask++;
            pszsrc += 4;
            istate=1;
            continue;
         case 'M':
            if (!getistr(pszsrc,2,01,12,M)) {
               if (istate) return 0;
               pszsrc++;
               continue;
            }
            adate[1] = M;
            pszmask++;
            pszsrc += 2;
            istate=1;
            continue;
         case 'D':
            if (!getistr(pszsrc,2,01,31,D)) {
               if (istate) return 0;
               pszsrc++;
               continue;
            }
            adate[2] = D;
            pszmask++;
            pszsrc += 2;
            istate=1;
            continue;
         case 'h':
            if (!getistr(pszsrc,2,00,23,h)) {
               if (istate) return 0;
               pszsrc++;
               continue;
            }
            adate[3] = h;
            pszmask++;
            pszsrc += 2;
            istate=1;
            continue;
         case 'm':
            if (!getistr(pszsrc,2,00,59,m)) {
               if (istate) return 0;
               pszsrc++;
               continue;
            }
            adate[4] = m;
            pszmask++;
            pszsrc += 2;
            istate=1;
            continue;
         case 's':
            if (!getistr(pszsrc,2,00,59,s)) {
               if (istate) return 0;
               pszsrc++;
               continue;
            }
            adate[5] = s;
            pszmask++;
            pszsrc += 2;
            istate=1;
            continue;
      }
   }

   if (!*pszmask)
   {
      if (breorder==1 && (pszsrc-pszsrcio)==8)
      {
         // rebuild date in order: YMD
         pszsrcio[0] = ((adate[0] / 1000) % 10) + '0';
         pszsrcio[1] = ((adate[0] /  100) % 10) + '0';
         pszsrcio[2] = ((adate[0] /   10) % 10) + '0';
         pszsrcio[3] = ((adate[0] /    1) % 10) + '0';
         pszsrcio[4] = ((adate[1] /   10) % 10) + '0';
         pszsrcio[5] = ((adate[1] /    1) % 10) + '0';
         pszsrcio[6] = ((adate[2] /   10) % 10) + '0';
         pszsrcio[7] = ((adate[2] /    1) % 10) + '0';
      }
      return 1;
   }

   return 0;
}

#ifdef SFK_W64
char *dataAsTraceQ(ushort *pAnyData)
{
   static char szBuf[300];

   char *pszBuf = szBuf;
   int  iMaxBuf = sizeof(szBuf);
 
   ushort *pSrcCur = (ushort *)pAnyData;
 
   char *pszDstCur = pszBuf;
   char *pszDstMax = pszBuf + iMaxBuf - 20;
 
   int i=0;
   for (; pSrcCur[i] != 0 && pszDstCur < pszDstMax; i++)
   {
      ushort uc = pSrcCur[i];
 
      if (uc < 0x100U && isprint((char)uc))
      {
         *pszDstCur++ = (char)uc;
         continue;
      }

      *pszDstCur++ = '?';
   }
 
   *pszDstCur = '\0';
 
   return pszBuf;
}

int execFixFile(ushort *ain, __wfinddata64_t *pdata)
{
   cs.files++;

   // derive all possibly needed data

   ushort apure[1024];  // for dewide, rewide
   char   szpure[1024]; // same in ascii
   int    adate[20];    // for setftime
   uchar  szcp[50];

   int isrc=0,idst=0,iuni=0;
   int msrc=1000,mdst=1000;
   mclear(adate);

   while (ain[isrc]!=0 && isrc<msrc && idst<mdst)
   {
      ushort uc = ain[isrc++];
      if (uc >= 0x100U)
      {
         iuni++;

         if (cs.dewide)
            continue;

         if (cs.rewide)
         {
            sprintf((char*)szcp, "{%04x}", uc);
            for (int i=0; szcp[i]!=0 && idst<mdst; i++)
            {
               apure[idst] = szcp[i];
               szpure[idst] = szcp[i];
               idst++;
            }
            continue;
         }

         apure[idst] = uc;
         szpure[idst] = '?';
         idst++;
         continue;
      }
      apure[idst] = uc;
      szpure[idst] = (char)uc;
      idst++;
   }
   apure[idst] = 0;
   szpure[idst] = '\0';

   /*
      scan for date, time
      -------------------
      01312015    MDY   201501   hms
      20150131    YMD   2015     hm

      01172015-0737  MDYhm
      20150131201501 YMDhms
   */
   bool bdate=0,btime=0,btsdiff=0;
   char *psz = strrchr(szpure, glblPathChar);
   if (!psz)
         psz = szpure;
   while (*psz)
   {
      if (!bdate) {
         if (matchdate(psz, "MDY", adate, cs.setndate)) {
            if (cs.setndate) {
               // write back possible reordered date
               int ioff = psz-szpure;
               for (int i=0; i<8; i++) {
                  if (apure[ioff+i] != ((ushort)psz[i]&0xFFU))
                     btsdiff = 1;
                  apure[ioff+i] = psz[i];
               }
            }
            bdate=1; 
            psz += 8;
            continue; 
         }
         if (matchdate(psz, "YMD", adate))
            { bdate=1; psz += 8; continue; }
         psz++;
         continue;
      }
      if (!btime) {
         if (matchdate(psz, "hms", adate))
            { btime=1; psz += 6; continue; }
         if (matchdate(psz, "hm", adate))
            { btime=1; psz += 4; continue; }
         psz++;
         continue;
      }
      break;
   }

   bool bNameDiffers = memcmp(ain, apure, (isrc+1)*2) ? 1 : 0;

   mytime_t now = mytime(NULL);
   struct tm *tm = 0;
   tm = mylocaltime(&now);
   tm->tm_isdst = -1;

   tm->tm_year = adate[0] - 1900;
   tm->tm_mon  = adate[1] - 1;
   tm->tm_mday = adate[2];
   tm->tm_hour = adate[3];
   tm->tm_min  = adate[4];
   tm->tm_sec  = adate[5];

   mytime_t nTime = mymktime(tm);
   num nTime2 = (num)nTime;

   bool bTimeDiffers = 0;

   if (nTime2 > 0 && nTime2 != pdata->time_write)
      bTimeDiffers = 1;

   // ignore, list, change?
   bool bChgName=0, bChgTime=0;
   
   if ((cs.dewide || cs.rewide) && bNameDiffers)
      bChgName = 1;

   if (cs.setftime && bTimeDiffers)
      bChgTime = 1;

   if (btsdiff)
      bChgName = 1;

   if (!bChgName && !bChgTime)
      return 0;

   printx("$FROM:<def> <time>%s<def> %s\n", 
      pdata->time_write > 0 ? timeAsString(pdata->time_write,1) : "[invalid time]",
      dataAsTraceQ(ain));

   // printx("$DIFF:<def> name=%d time=%d %llu %llu\n",bChgName,bChgTime,pdata->time_write,nTime2);

   cchar *ptimecol = (bChgTime != 0 && nTime2 > 0) ? "<rep>":"<time>";
   cchar *pnamecol = bChgName ? "<rep>":"";
   
   printx("$  TO:<def> %s%s<def> %s%s<def>\n", ptimecol, timeAsString(nTime2,1),
      pnamecol, dataAsTraceW(apure));

   if (idst < 1) {
      pwarn("... cannot change, name would be empty: %s\n", dataAsTraceW(ain));
      return 0;
   }

   if (cs.yes)
   {
      do
      {
         if (bChgName && _wrename(ain, apure))
         {
            perr("... rename failed: %s\n", dataAsTraceW(ain));
            break;
         }

         bool berr = 0;

         if (bChgTime != 0 && nTime2 > 0)
         {
            HANDLE hDst = CreateFileW(
               apure,
               FILE_WRITE_ATTRIBUTES,
               0,    // share
               0,    // security
               OPEN_EXISTING,
               FILE_ATTRIBUTE_NORMAL,
               0     // template file
               );
            if (hDst == INVALID_HANDLE_VALUE)
               { perr("... set filetime failed (1)\n"); break; }

            FILETIME nDstMTime, nDstCTime;
            FILETIME *pMTime=0, *pCTime=0;
 
            if (!makeWinFileTime(nTime2, nDstMTime))
               pMTime = &nDstMTime;
 
            // if (nClCTime > 0)
            // {
            //    if (!makeWinFileTime(nClCTime, nDstCTime))
            //       pCTime = &nDstCTime;
            // }

            if (pMTime || pCTime)
               if (!SetFileTime(hDst, pCTime, 0, pMTime))
                  { perr("... set filetime failed (2)\n"); berr=1; }

            CloseHandle(hDst);
         }

         if (!berr)
            cs.filesChg++;
      }
      while (0);
   }
   else
   {
      cs.filesChg++;
   }

   return 0;
}
#endif

int iGlblMovTotalTime = 0;
num nGlblMovFileSize  = 0;

int movtimetoms(int i)
{
   int ifrac = i % 100;
       i /= 100;
 
   int isec = i % 60;
       i /= 60;

   int imin = i % 60;
       i /= 60;

   int ihou = i;

   return (ihou * 100 + imin) * 100 + isec;
}

char *movtimetoa(int i, char *szBuf=0)
{
   static char szBuf2[100];
 
   if (!szBuf)
      szBuf = szBuf2;

   int ifrac = i % 100;
       i /= 100;
 
   int isec = i % 60;
       i /= 60;

   int imin = i % 60;
       i /= 60;

   int ihou = i;

   sprintf(szBuf, "%02u:%02u:%02u", ihou, imin, isec);

   return szBuf;
}

// RC 0: error
int atomovtime(char *psz, int ioptlen, bool bUseBytes)
{
   char szBuf[100];

   int ilen = ioptlen ? ioptlen : strlen(psz);

   if (ilen > sizeof(szBuf)-10)
      return 0+perr("buffer overflow");

   if (bUseBytes)
   {
      if (!nGlblMovFileSize)
         return 0+perr("missing filesize. specify as first parameter.");

      if (!iGlblMovTotalTime)
         return 0+perr("missing total time. specify as second parameter.");

      memcpy(szBuf, psz, ilen);
      szBuf[ilen] = '\0';

      num nBytePos = atonum(szBuf);

      int ires = nBytePos * iGlblMovTotalTime / nGlblMovFileSize;
 
      // printf("# time %08u = \"%s\" * %u / %s (inlen=%d)\n",
      //   ires, szBuf, iGlblMovTotalTime, numtoa(nGlblMovFileSize), ilen);

      if (cs.verbose > 1)
         printf("itime : %s = %s bytes\n", movtimetoa(ires, szBuf), numtoa(nBytePos));
 
      return ires;
   }

   // 3053     -> ((30 * 60) + 53) * 100
   // 305395   -> ((30 * 60) + 53) * 100 + 95

   char szHou[10]; mclear(szHou);
   char szMin[10]; mclear(szMin);
   char szSec[10]; mclear(szSec);
   char szFrc[10]; mclear(szFrc);

   if (strchr(psz, ':'))
   {
      // 30:53 and 01:30:53
      switch (ilen)
      {
         case 5:
            memcpy(szMin, psz, 2);
            memcpy(szSec, psz+3, 2);
            break;
 
         case 8:
            memcpy(szHou, psz, 2);
            memcpy(szMin, psz+3, 2);
            memcpy(szSec, psz+6, 2);
            break;
      }
   }
   else
   {
      // 3053 and 013053
      switch (ilen)
      {
         case 4:
            memcpy(szMin, psz, 2);
            memcpy(szSec, psz+2, 2);
            break;
 
         case 6:
            memcpy(szHou, psz, 2);
            memcpy(szMin, psz+2, 2);
            memcpy(szSec, psz+4, 2);
            break;
      }
   }

   int iTime =
         (atoi(szHou) * 3600) * 100
      +  (atoi(szMin) *   60) * 100
      +  (atoi(szSec)       ) * 100
      ;

   return iTime;
}

// RC 0: OK
int atomovrange(char *psz, num *pstart, num *pend)
{
   char *pszStart = psz;
   char *pszEnd   = strchr(psz, '-');
   if (!pszEnd)
      return 9+perr("wrong time range format: %s", psz);

   *pstart = atonum(pszStart);

   pszEnd++;

   if (!(*pend = atonum(pszEnd)))
      return 10+perr("wrong time range end: %s", psz);

   return 0;
}

// RC 0: OK
int atomovrange(char *psz, int *pstart, int *pend, bool bUseBytes)
{
   char *pszStart = psz;
   char *pszEnd   = strchr(psz, '-');
   if (!pszEnd)
      return 9+perr("wrong time range format: %s", psz);

   *pstart = atomovtime(pszStart, pszEnd-pszStart, bUseBytes);

   pszEnd++;

   if (!(*pend = atomovtime(pszEnd, 0, bUseBytes)))
      return 10+perr("wrong time range end: %s", psz);

   return 0;
}

int Media::findSeconds(num n)
{
   for (int i=0; i<iCmd; i++) {
      if (aBeg[i]==n && aBegSec[i]!=-1)
         return aBegSec[i];
      if (aEnd[i]==n && aEndSec[i]!=-1)
         return aEndSec[i];
   }
   return -1;
}

Media *Media::pClCurrent = 0;

Media::Media( )
{
   memset(this, 0, sizeof(*this));
}

void Media::reset( )
{
   iClInvalidFiles = 0;
   iClDoneFiles = 0;
   nClGlobalBytes = 0;
   bClHaveKeep = 0;
   bClKeepAll = 0;
   bClJoinOutput = 0;
   bClFixOutput = 0;
   iClDoneTS = 0;
   if (fClOut)
      perr("media: output file open on init\n");
   fClOut = 0;
   mclear(szClTmpOutFile);
   mclear(szClRecentOutFile);
   mclear(szClFinalFile);
   mclear(szClFixParms);
   clearCommands();
}

void Media::setFixParms(char *psz)
{
   if (!strcmp(psz, "pal-dvd") || !strcmp(psz, "dvd-pal"))
      strcopy(szClFixParms, "-target pal-dvd");
   else
   if (!strcmp(psz, "ntsc-dvd") || !strcmp(psz, "dvd-ntsc"))
      strcopy(szClFixParms, "-target ntsc-dvd");
   else
      strcopy(szClFixParms, psz);
}

void Media::closeOutput( )
{
   char szCmd[SFK_MAX_PATH+100];

   if (bClFixOutput)
   {
      snprintf(szCmd, sizeof(szCmd)-10,
         "ffmpeg -y -i \"%s\" %s -codec copy \"%s\"",
         szClTmpOutFile, szClFixParms, szClFinalFile);

      if (cs.sim && (cs.quiet<2))
         printx("$%s\n", szCmd);
      else
      if (!cs.sim && fClOut)
         printx("$%s\n", szCmd);
   }

   if (!fClOut)
      return;

   fclose(fClOut);
   fClOut = 0;
 
   if (bClFixOutput)
   {
      int iSubRC = system(szCmd);

      if (iSubRC > 0) {
         pwarn("ffmpeg possible error, RC=%d\n", iSubRC);
         pinf("use -keeptmp to keep temporary output file.\n");
      }
 
      if (!bClKeepTmp) {
         if (cs.verbose)
            printf("cleaning up temporary: %s\n", szClTmpOutFile);
         remove(szClTmpOutFile);
      }
   }

   if (cs.keeptime)
   {
      // this checks if it was really set
      clOutStat.writeStat(__LINE__);
   }
}

void Media::clearCommands( )
{
   bClHaveM3UCommands=0;
   mclear(aCmd);
   mclear(aBeg);
   mclear(aEnd);
   mclear(aBegSec);
   mclear(aEndSec);
   iFirstCmd=0;
   iCmd=0;
   for (int i=0; i<MAX_MOV_CMD; i++) {
      aBegSec[i]=-1;
      aEndSec[i]=-1;
   }
}

void Media::shutdown( )
{
   if (pszClM3UText) {
      delete [] pszClM3UText;
      pszClM3UText = 0;
   }
   if (!pClCurrent)
      return; // safety
   Media *pThis = pClCurrent;
   pClCurrent = 0;
   delete pThis;
   // no further processing
}

Media &Media::current( )
{
   if (!pClCurrent)
      pClCurrent = new Media();
   return *pClCurrent;
}

int Media::parseM3UFile(char *pszm3u)
{
   bClHaveM3UCommands=1;

   iFirstCmd=0;
   iCmd=0;

   if (pszClM3UText)
      delete [] pszClM3UText;
   if (!(pszClM3UText = loadFile(pszm3u, 0)))
      return 9;
   if (cs.verbose)
      printf("--- Using bookmarks: ---\n");
   /*
      #EXTVLCOPT:bookmarks={name=the.mpg0,bytes=56119296,time=93}
      #EXTVLCOPT:bookmarks={name=the.mpg0,bytes=56119296,time=93},{name=the.mpg1,bytes=1334441410,time=2354},...
      C:\video\the.mpg
   */
   bool  bNextIsFile = 0;
   char *pszMeta = 0;
   char *pszCur  = pszClM3UText;
   char *pszNext = 0;
   char *pszTime = 0;
   int iCurLine=0,iMetaLine=0,iFileLine=0;

   char  szTimeBuf1[100],szTimeBuf2[100],szTimeBuf3[100];

   // find last EXTVLCOPT entry
   while (pszCur && *pszCur) {
      pszNext = strchr(pszCur, '\n');
      if (pszNext)
         *pszNext++ = '\0';
      removeCRLF(pszCur);
      iCurLine++;
      if (strBegins(pszCur, "#EXTVLCOPT:bookmarks=")) {
         pszMeta = pszCur;
         bNextIsFile = 1;
         iMetaLine = iCurLine;
      }
      else
      if (bNextIsFile) {
         bNextIsFile = 0;
         pszClM3UFileEntry = pszCur;
         iFileLine = iCurLine;
      }
      pszCur = pszNext;
   }
   if (!pszMeta)
      return 9+perr("no #EXTVLCOPT:bookmarks= found within %s\n", pszm3u);
   if (!pszClM3UFileEntry || !strlen(pszClM3UFileEntry))
      return 9+perr("no input file filename found within %s\n", pszm3u);
   if (!fileExists(pszClM3UFileEntry)) {
      perr("input file not found: %s\n", pszClM3UFileEntry);
      pinf("from line %03u of M3U: %s\n", iFileLine, pszm3u);
      return 9;
   }
   if (cs.verbose) {
      printf("using: line %u, %.60s ...\n", iMetaLine, pszMeta);
      printf("using: line %u, %s\n", iFileLine, pszClM3UFileEntry);
   }
 
   // parse that entry
   pszCur = pszMeta;
   int istate2 = 0;
   int nTimeSec = 0;
   while (pszCur && *pszCur) {
      // convert bookmarks into keep commands
      if (!(pszNext = strstr(pszCur, "bytes=")))
         break;
      pszNext += 6;
      num nPos = atonum(pszNext);
      if (pszTime = strstr(pszNext, "time="))
         nTimeSec = atoi(pszTime+5);
      if (!(istate2++ & 1)){
         aCmd[iCmd] = SFKMOV_KEEP;
         aBeg[iCmd] = nPos;
         aBegSec[iCmd] = nTimeSec;
      } else {
         aEnd[iCmd] = nPos;
         aEndSec[iCmd] = nTimeSec;
         if (cs.verbose)
            printf("%s : %s-%s (%s-%s)\n",
               aCmd[iCmd] == SFKMOV_KEEP ? "keep":"skip",
               numtoa(aBeg[iCmd],10,szTimeBuf1), numtoa(aEnd[iCmd],10,szTimeBuf2),
               movtimetoa(aBegSec[iCmd]*100,szTimeBuf3),movtimetoa(aEndSec[iCmd]*100));
         iCmd++;
      }
      pszCur = pszNext;
   }
 
   // plausi check
   if (istate2 & 1)
      return 9+perr("uneven number of boomarks found in %s\n", pszm3u);
   if (cs.verbose) {
      printf("------------------------\n");
   }

   return 0;
}

int Media::analyze(uchar *pbuf, int isize)
{
   return 0;
}

int Media::renderTempName(char *pszFinal)
{
   // from: pszFinal == output.mpg
   // to  : pszFinal == output-tmp.mpg
   //       szClFinalFile  == output.mpg
   strcopy(szClFinalFile, pszFinal);

   char szNameBuf[SFK_MAX_PATH+10];
   strcopy(szNameBuf, pszFinal);

   char *pszBase = szNameBuf;
   char *pszExt  = strrchr(szNameBuf, '.');

   if (!pszExt)
      return 9+perr("missing file extension on output name: %s\n", pszFinal);

   if (SFTmpFile::tmpDirWasSet()) {
      // NO *pszExt del here, using full ".ext"
      SFTmpFile otmp(pszExt, 1);
      char *psz = otmp.name();
      strcopy(szClTmpOutFile, psz);
   } else {
      *pszExt++ = '\0';
      snprintf(szClTmpOutFile, sizeof(szClTmpOutFile)-10,
         "%s-tmp.%s", pszBase, pszExt);
   }

   if (bClShowTmp)
      printf("using temporary: %s\n", szClTmpOutFile);

   return 0;
}

int Media::processMediaFile(char *pszSrc, char *pszOutFile)
{
   if (!bClKeepAll && !iCmd) {
      pwarn("no commands given, skipping: %s\n", pszSrc);
      return 5;
   }

   const char *pszind = bClHaveM3UCommands ? "  ":"";
   if (cs.quiet >= 2) pszind = "";

   printf("input: %s%s\n", pszind, pszSrc);

   if (bClFixOutput)
   do
   {
      if (bClJoinOutput && szClTmpOutFile[0]) {
         pszOutFile = szClTmpOutFile;
         break; // names already rendered
      }

      if (!pszOutFile)
         return 9+perr("missing output filename");

      if (renderTempName(pszOutFile))
         return 9;
      // szClOut   is now TEMPORARY name
      // szClFinal is the final filename

      pszOutFile = szClTmpOutFile;
   }
   while (0);

   if (pszOutFile)
      strcopy(szClRecentOutFile, pszOutFile);

   if ((cs.quiet<2) && pszOutFile)
      printf("out  : %s%s%s\n", pszind, pszOutFile, bClJoinOutput ? " (joined)":"");

   FileStat ofsSrc;
   if (ofsSrc.readFrom(pszSrc, 0, 1))
      return 9+perr("no such input file: %s", pszSrc);

   num nFileSize = ofsSrc.getSize();

   if (nFileSize <= 0)
      return 9+perr("empty input file: %s", pszSrc);

   if (!cs.sim && !pszOutFile)
      return 9+perr("missing output filename");

   int iRC = 0;

   num nTotalTime = nFileSize;

   FILE *fin = fopen(pszSrc, "rb");
   if (!fin) return 9+perr("unable to open input file: %s\n", pszSrc);

   if (!cs.sim) {
      if (!fClOut) {
         fClOut = fopen(pszOutFile, "wb");
         if (!fClOut) { fclose(fin); return 9+perr("unable to write: %s\n", pszOutFile); }
         clOutStat.copyFrom(ofsSrc);
         clOutStat.setFilename(pszOutFile);
      }
   }

   num nTotalBytes=0;

   // set start state
   int iCopyState = 1; // keep
   if (   aCmd[iFirstCmd] == SFKMOV_KEEP
       && aBeg[iFirstCmd] > 0
      )
       iCopyState = 0; // keep, but not from start
   else
   if (   aCmd[iFirstCmd] == SFKMOV_CUT
       && aBeg[iFirstCmd] == 0
      )
       iCopyState = 0; // cut from start

   // define current switch point
   num nCurBeg = 0;
   num nCurEnd = nTotalTime;
 
   char szBuf1[100],szBuf2[100],szBuf3[100];
   char szInfoBuf[100];
 
   num tLastInfo = 0;

   while (iRC==0 && nCurBeg<nTotalTime)
   {
      // BEGIN state of current cmd was set already.
      // find next switch point.
      int iNextCmd   = -1;
      int bNextIsBeg =  0;
      num iNextTime  = nTotalTime;
      for (int iTmp=iFirstCmd; aCmd[iTmp]; iTmp++)
      {
         num ibeg = aBeg[iTmp];
         num iend = aEnd[iTmp];

         if (ibeg > nCurBeg && ibeg < iNextTime) {
            iNextTime=ibeg; iNextCmd=iTmp; bNextIsBeg=1;
            // printf("curmin: #%d with beg %s\n", iTmp, numtoa(ibeg, 10));
            continue;
         }

         if (iend > nCurBeg && iend < iNextTime) {
            iNextTime=iend; iNextCmd=iTmp; bNextIsBeg=0;
            // printf("curmin: #%d with end %s\n", iTmp, numtoa(iend, 10));
            continue;
         }
      }

      // calc current range to keep or cut
      if (iNextCmd >= 0)
         nCurEnd = iNextTime;
      else
         nCurEnd = nTotalTime;

      if (!cs.quiet)
      {
         info.clear();

         int iBegSec = findSeconds(nCurBeg);
         int iEndSec = findSeconds(nCurEnd);

         if (iBegSec >= 0 && iEndSec >= 0)
            sprintf(szInfoBuf, "%s-%s (%s-%s)",
               numtoa(nCurBeg, 10, szBuf1), numtoa(nCurEnd, 10, szBuf2),
               movtimetoa(iBegSec*100,szBuf3),movtimetoa(iEndSec*100));
         else
            sprintf(szInfoBuf, "%s-%s",
               numtoa(nCurBeg, 10, szBuf1), numtoa(nCurEnd, 10, szBuf2));

         if (iCopyState)
            printx("$copy : %s\n", szInfoBuf);
         else
            printx("#skip : %s\n", szInfoBuf);
      }

      // apply current range
      while (1)
      {
         info.setProgress(nTotalTime, nCurBeg, "bytes");
         info.setStatus(iCopyState ? "copy":"skip", pszOutFile ? pszOutFile : pszSrc);

         if (iCopyState)
         {
            // copy part
            int iMaxRead = sizeof(abBuf)-100;
 
            if (nCurEnd < nCurBeg + iMaxRead)
               iMaxRead = (int)(nCurEnd - nCurBeg);
 
            if (iMaxRead <= 0) {
               perr("invalid section length: %d at %s\n", iMaxRead, numtoa(nCurBeg, 10));
               iRC = 9;
               break;
            }
 
            int nread = (cs.sim && !bClScan) ? iMaxRead : fread(abBuf, 1, iMaxRead, fin);
 
            if (nread <= 0)
            {
               info.print("file end reached.\n");
               iRC = 9;
               break; // EOF on input
            }

            if (bClScan)
               analyze(abBuf, nread);
 
            if (!cs.sim && fClOut) {
               int nwrite = myfwrite(abBuf, nread, fClOut);
               if (nwrite != nread) {
                  esys("fwrite", "error while writing: %s   \n", pszOutFile);
                  iRC = 9;
                  break;
               }
            }

            nTotalBytes += nread;
            nClGlobalBytes += nread;
            nCurBeg += nread;
         }
         else
         {
            // skip part
            if (myfseek(fin, nCurEnd, SEEK_SET)) {
               iRC = 9;
               break;
            }
            nCurBeg = nCurEnd;
         }

         if (nCurBeg >= nCurEnd)
            break;

      }  // endwhile part read loop

      if (iRC > 0)
         break;

      // switch copy state
      if (iNextCmd >= 0)
      {
         if (aCmd[iNextCmd]==SFKMOV_KEEP && bNextIsBeg) {
            iCopyState = 1; // start of keep
            if (cs.verbose > 2)
               info.print("part : kb.KEEP from %s\n", numtoa(nCurBeg, 10));
         }
         else
         if (aCmd[iNextCmd]==SFKMOV_KEEP && !bNextIsBeg) {
            iCopyState = 0; // end of keep
            if (cs.verbose > 2)
               info.print("part : ke.SKIP from %s\n", numtoa(nCurBeg, 10));
         }
         else
         if (aCmd[iNextCmd]==SFKMOV_CUT && bNextIsBeg) {
            iCopyState = 0; // start of cut
            if (cs.verbose > 2)
               info.print("part : cb.SKIP from %s\n", numtoa(nCurBeg, 10));
         }
         else
         if (aCmd[iNextCmd]==SFKMOV_CUT && !bNextIsBeg) {
            iCopyState = 1; // end of cut
            if (cs.verbose > 2)
               info.print("part : ce.KEEP from %s\n", numtoa(nCurBeg, 10));
         }
      }

   }  // endwhile overall I/O loop

   info.clear();

   if (!bClJoinOutput)
      closeOutput();
   // else called later

   fclose(fin);

   if (!iRC && cs.verbose) {
      if (cs.sim) {
         printf("would copy %d mb (%s bytes).\n",
            (int)(nTotalBytes/1000000), numtoa(nTotalBytes));
      } else {
         printf("copied %s bytes.\n", numtoa(nTotalBytes));
      }
   }

   if (!iRC && szClMoveSrcOutDir[0]) {
      char *pszSrcRelName = strrchr(pszSrc, glblPathChar);
      if (pszSrcRelName)
         pszSrcRelName++;
      else
         pszSrcRelName = pszSrc;
      joinPath(szClMoveSrcOutFile, sizeof(szClMoveSrcOutDir),
               szClMoveSrcOutDir, pszSrcRelName);
      const char *pszInfo = "";
      if (fileExists(szClMoveSrcOutFile)) {
         if (cs.sim) {
            pszInfo = " (output file exists)";
         } else {
            if (cs.force) {
               remove(szClMoveSrcOutFile);
               pszInfo = " (overwritten)";
            } else {
               pszInfo = " "; // dummy for following error
            }
         }
      }
      if (!cs.quiet)
         printx("$move : %s -> %s%s\n", pszSrc, szClMoveSrcOutFile, pszInfo);
      if (!cs.sim) {
         if (rename(pszSrc, szClMoveSrcOutFile)) {
            perr("cannot move %s -> %s\n", pszSrc, szClMoveSrcOutFile);
            static bool btold=0;
            if (!btold) {
               btold=1;
               if (pszInfo[0])
                  pinf("add option -force to overwrite existing output file.\n");
               else
                  pinf("output dir must be on same file system as input file.\n");
            }
         }
      }
   }

   iClDoneFiles++;

   return iRC;
}

int execMedia(char *pszSrc, char *pszOutFile)
{
   Media &m = Media::current();
 
   int iRC = 0;

   if (m.bClHaveM3UCommands) {
      // these are valid per single file only
      m.clearCommands();
   }
 
   if (endsWithExt(pszSrc, str(".m3u"))) {
      if (!m.bClHaveKeep) {
         pwarn("missing \"-keepbook\" command, skipping: %s\n", pszSrc);
         return 5;
      }
      if (cs.quiet<2)
         printf("using: %s\n", pszSrc);
      if (iRC = m.parseM3UFile(pszSrc)) {
         // a single M3U batch is invalid,
         // but overall processing may keep running
         m.iClInvalidFiles++;
         return iRC;
      }
      if (!(pszSrc = m.pszClM3UFileEntry)) {
         m.iClInvalidFiles++;
         return 9; // safety
      }
   }

   if (iRC = m.processMediaFile(pszSrc, pszOutFile))
      m.iClInvalidFiles++;

   return iRC;
}

int ispuretext(char *psz, char ccurdelim, char coutdelim, char cquote)
{
   while (*psz)
   {
      char c = *psz++;
      if (c == ccurdelim)
         return 1;
      if (c == coutdelim)
         return 0;
      if (c == cquote)
         return 0;
   }

   return 1;
}

int ispurenum(char *psz, char ccurdelim, char coutdelim)
{
   /*
      +123.456e+10
      -234.387e3
      -234,387e-3
   */

   if (*psz=='+' || *psz=='-')
      psz++;

   int istate = 1;

   while (*psz != 0 && *psz != ccurdelim)
   {
      char c = *psz++;

      if (c == coutdelim)
         return 0;

      switch (istate)
      {
         case 1: // expect just digit
            if (isdigit(c)) {
               istate = 2;
               continue;
            }
            return 0;

         case 2: // expect digit . , e
            if (isdigit(c))
               continue;
            if (c == '.' || c == ',')
               continue;
            if (tolower(c) == 'e') {
               istate = 3;
               continue;
            }
            return 0;

         case 3: // after e: expect + - digit
            if (c == '+' || c == '-') {
               istate = 4;
               continue;
            }
         case 4:
            if (isdigit(c))
               continue;
            return 0;
      }
   }

   return 1;
}

int csvToTab(char *psrc, char *pdst, int imaxdst)
{
   char cdelim     = cs.cinsep;
   char ctab       = cs.coutsep;
   char cquote     = cs.cquote;
   char ctabescape = cs.coutsepesc;

   /*
      5324,John Smith,Los Angeles
      7936,"James Foo, Dr.",Atlanta
      3297,"Jack ""Goo"" Bar",San Diego
      5239,,Nowhere
      5240,Empty{TAB}City,
   */

   char *pSrcCur = psrc;
   char *pSrcMax = psrc + strlen(psrc);
   char *pDstCur = pdst;
   char *pDstMax = pdst + (imaxdst - 20);

   int istate   = 0;
   int binquote = 0;

   while (pSrcCur < pSrcMax && pDstCur < pDstMax)
   {
      char c  = *pSrcCur++;
      char c2 = *pSrcCur;  // NULL if at end

      switch (istate)
      {
         case 0:  // expect quote, start of data, delimiter
            if (c == cquote) {
               binquote = 1;
               istate = 1;
               continue;
            }
            if (c == cdelim) {
               *pDstCur++ = ctab;
               continue;
            }
            istate = 1;
            // fall through

         case 1:  // expect data byte, escaped quote, delimiter, EOR
            if (c == cquote && c2 == cquote) {
               *pDstCur++ = cquote;
               pSrcCur++;
               continue;
            }
            if (binquote == 0 && c == cdelim) {
               *pDstCur++ = ctab;
               istate = 0;
               continue;
            }
            if (binquote == 1 && c == cquote) {
               // delimiter or EOR must be next
               binquote = 0;
               continue;
            }
            if (c == ctab) {
               // remove tabs from input
               c = ctabescape;
            }
            *pDstCur++ = c;
            continue;
      }
   }

   if (pSrcCur >= pSrcMax)
   {
      // end of record checks
      if (pDstCur >= pDstMax)
         return 10;

      switch (istate)
      {
         case 0:  // expect quote, data, delimiter
            *pDstCur++ = '\0';
            return 0;

         case 1:  // expect data byte, escaped quote, delimiter, EOR
            if (binquote)
               return 11;
            *pDstCur++ = '\0';
            return 0;
      }
   }

   return 12;
}

int tabToCsv(char *psrc, char *pdst, int imaxdst)
{
   char ctab       = cs.cinsep;
   char cdelim     = cs.coutsep;
   char cquote     = cs.cquote;
   bool bquotetext = cs.quotetext;
   bool bfullquote = cs.quoteall;

   char *pSrcCur = psrc;
   char *pSrcMax = psrc + strlen(psrc);
   char *pDstCur = pdst;
   char *pDstMax = pdst + (imaxdst - 20);

   int istate   = 0;
   int binquote = 0;
   int boutquoteopen = 0;

   while (pSrcCur < pSrcMax && pDstCur < pDstMax)
   {
      char c  = *pSrcCur++;
      char c2 = *pSrcCur;  // NULL if at end

      switch (istate)
      {
         case 0:  // expect start of data, tab, quote-to-escape
            if (c == ctab) {
               if (bfullquote) {
                  *pDstCur++ = cquote;
                  *pDstCur++ = cquote;
               }
               *pDstCur++ = cdelim;
               continue;
            }
            // start of data, quote-to-escape
            if (   bfullquote == 1
                || (bquotetext && !ispurenum(pSrcCur-1, ctab, cdelim))
                || (!ispuretext(pSrcCur-1, ctab, cdelim, cquote))
               )
            {
               *pDstCur++ = cquote;
               boutquoteopen = 1;
            }
            istate = 1;
            // fall through

         case 1:  // expect tab, data byte, quote-to-escape
            if (c == ctab) {
               if (boutquoteopen)
                  *pDstCur++ = cquote;
               *pDstCur++ = cdelim;
               boutquoteopen = 0;
               istate = 0;
               // tab at end of record?
               if (pSrcCur >= pSrcMax) {
                  // then it means a trailing empty field
                  if (bfullquote) {
                     *pDstCur++ = cquote;
                     *pDstCur++ = cquote;
                  }
                  // but without extra separator
               }
               continue;
            }
            if (c == cquote) {
               // escape quote
               *pDstCur++ = cquote;
               *pDstCur++ = cquote;
               continue;
            }
            // continue data
            *pDstCur++ = c;
            continue;
      }
   }

   if (pSrcCur >= pSrcMax)
   {
      // end of record checks
      if (pDstCur >= pDstMax)
         return 10;

      switch (istate)
      {
         case 0:  // expect start of data, tab
            *pDstCur++ = '\0';
            return 0;

         case 1:  // expect tab, data byte
            if (boutquoteopen)
               *pDstCur++ = cquote;
            *pDstCur++ = '\0';
            return 0;
      }
   }

   return 12;
}

int execCsvConv(bool bToCsv, Coi *pcoi, FILE *fin, StringPipe *pInData, int nMaxLines, char *pszOutFile)
{
   FILE *fout = 0;

   // INPUT FILE CLOSES AUTOMATICALLY.
   FileCloser fcin(pcoi); // does nothing if pcoi == NULL

   if (pcoi)
   {
      if (pcoi->open("rb"))
         return 9+perr("cannot read: %s %s\n", pcoi->name(),pcoi->lasterr());
   }

   if (pszOutFile)
      if (!(fout = fopen(pszOutFile, "w")))
         return 10+perr("cannot write: %s\n", pszOutFile);

   int nMaxLineLen = sizeof(szLineBuf)-10;
   int ncheckcnt   = 0;
   int lRC         = 0;
   int nLine       = 0;

   myfgets_init();
   while (1)
   {
      // --- get next line to linebuf ---

      memset(szAttrBuf, ' ', MAX_LINE_LEN-10);
      szAttrBuf[MAX_LINE_LEN-10] = '\0';

      int nRead = 0;

      if (pInData) {
         if (pInData->eod())
            break;
         char *pattr = 0;
         char *psz = pInData->read(&pattr);
         mystrcopy(szLineBuf, psz, MAX_LINE_LEN);
         strcat(szLineBuf, "\n"); // force LF
         int nlen = strlen(szLineBuf);
         if (pattr) {
            mystrcopy(szAttrBuf, pattr, MAX_LINE_LEN);
            if ((int)strlen(szAttrBuf) < nlen-1) {
               memset(szAttrBuf, ' ', nlen);
               szAttrBuf[nlen] = '\0';
            }
         }
         nRead = nlen;
      } else if (pcoi) { // native or virtual file
         nRead = pcoi->readLine(szLineBuf, nMaxLineLen);
      } else if (fin)  { // probably stdin
         nRead = myfgets(szLineBuf, nMaxLineLen, fin, 0, szAttrBuf);
      }
      if (!nRead)
         break; // EOD

      if ((++ncheckcnt > 100000) && ((ncheckcnt & 65535)==0))
         if (userInterrupt())   // costs a bit of time
            {  lRC=9; break;  } // stop by escape

      szLineBuf[nRead] = '\0';
      szAttrBuf[nRead] = '\0';
      nLine++;
      removeCRLF(szLineBuf);

      // --- process line ---
      int isubrc = 0;
      if (bToCsv == 0)
         isubrc = csvToTab(szLineBuf, szLineBuf2, MAX_LINE_LEN);
      else
         isubrc = tabToCsv(szLineBuf, szLineBuf2, MAX_LINE_LEN);
      if (isubrc) {
         if (!cs.nowarn)
            pwarn("input line %d wrong format (%d): %s", nLine, isubrc, szLineBuf);
         snprintf(szLineBuf2, MAX_LINE_LEN, "[warning:%d]\t%s", isubrc, szLineBuf);
      }

      // -- write to output ---
      if (fout)
         fprintf(fout, "%s\n", szLineBuf2);
      else
      if (chain.coldata)
         chain.addLine(szLineBuf2, str(""));
      else
         printf("%s\n", szLineBuf2);
   }

   if (fout)
      fclose(fout);

   return lRC;
}

extern uint nGlblConvTarget;
extern uint aGlblConvStat[10];

int execFormConv(char *pszFile, char *pszOutFile)
{__
   bool bHaveOut = (pszOutFile != 0);
   if (!bHaveOut) pszOutFile = pszFile;

   num nFileSize = 0;
   char *pInFile = (char*)loadBinaryFile(pszFile, nFileSize);
   if (!pInFile) return 9;

   CharAutoDel odel(pInFile);

   // SFK 1.7.2: make sure no binary is truncated
   if (cs.textfiles) {
      if (memchr(pInFile, '\0', nFileSize)) {
         if (cs.verbose)
            printx("$skip <def> %s - binary\n", pszFile);
         return 0;
      }
   }

   bool bAny    = 0;
   bool berr    = 0;
   bool bshowle = (nGlblConvTarget & eConvFormat_ShowLE) ? 1 : 0;
   int ipasses  = bshowle ? 1 : 2;

   FILE *fOut = 0;

   uchar abCRLF[] = { 0xD, 0xA };

   int  icr=0, ilf=0, icrlf=0, iut=0;

   for (int ipass=0; ipass<ipasses && berr==0; ipass++)
   {
      char *pszSrcCur = pInFile;
      char *pszSrcMax = pszSrcCur + nFileSize;
      char *pszLine   = pszSrcCur;
      char *pszEOL    = 0;
      int   iLineLen  = 0;
      int   iEOLLen   = 0;
      uchar abEOL[10];
      char  c = 0;

      if (ipass)
      {
         if (!cs.writeall && !bAny) {
            if (cs.verbose)
               printx("$skip <def> %s - nothing to change\n", pszFile);
            return 0; // nothing to do
         }

         cs.files++;

         // write output file:
         //   if different output is specified, also create directory structure.
         if (bHaveOut) {
            if (createOutDirTree(pszOutFile))
               return 9;
            if (!cs.quiet) info.setStatus(cs.curcmd, pszOutFile);
         } else {
            if (!cs.quiet) info.setStatus(cs.curcmd, pszFile);
         }

         if (!cs.sim) {
            fOut = fopen(pszOutFile, "wb");
            if (!fOut) {
               delete [] pInFile;
               return 9+perr("cannot %swrite %s\n", bHaveOut?"":"over", pszOutFile);
            }
         }
      }

      while (pszSrcCur <= pszSrcMax)
      {
         if (pszSrcCur < pszSrcMax) {
            c = *pszSrcCur++;
         } else {
            // end of data
            if (pszLine == pszSrcCur)
               break;
            // line without (CR)LF exists
            c = '\0';
            iut++;
         }

         if (c == '\r' || c == '\n' || c == '\0')
         {
            // line end reached
            iEOLLen = 0;
            if (c) {
               pszEOL  = pszSrcCur-1;
               iEOLLen = 1;
            } else {
               pszEOL  = pszSrcCur;
               iEOLLen = 0;
            }

            if (c == '\r') {
               // eol by CR or CRLF
               if (*pszSrcCur == '\n') {
                  pszSrcCur++;
                  iEOLLen = 2;
                  icrlf++;
               } else {
                  icr++;
               }
            }
            else if (c == '\n') {
               ilf++;
            }

            iLineLen = pszEOL - pszLine;

            if (fOut)
            {
               // write line content
               if ((int)myfwrite((uchar*)pszLine, iLineLen, fOut) != iLineLen)
                  {  berr=1; break; }

               // write new line ending
               if (iEOLLen == 0 && cs.forcele == 0) {
                  // last line has no LF and should be kept as is
               }
               else
               if (nGlblConvTarget & eConvFormat_LF) {
                  if (fOut)
                     if (myfwrite(&abCRLF[1], 1, fOut) != 1)
                        {  berr=1; break; }
               }
               else
               if (nGlblConvTarget & eConvFormat_CRLF) {
                  if (fOut)
                     if (myfwrite(&abCRLF[0], 2, fOut) != 2)
                        {  berr=1; break; }
               }
            }
            else if (ipass == 0)
            {
               // check for differences
               abEOL[0] = '\0';
               abEOL[1] = '\0';

               if (iEOLLen == 0 && cs.forcele == 0) {
                  // last line has no LF and should be kept as is
               }
               else
               {
                  if (iEOLLen)
                     memcpy(abEOL, pszEOL, iEOLLen);
 
                  if (nGlblConvTarget & eConvFormat_LF) {
                     if (abEOL[0] != '\n')
                        bAny = 1;
                  }
                  else
                  if (nGlblConvTarget & eConvFormat_CRLF) {
                     if (memcmp(abEOL, "\r\n", 2))
                        bAny = 1;
                  }
               }
            }

            pszLine = pszSrcCur;
         }
 
         // else step over line content

      }  // endfor text

   }  // endfor pass

   if (fOut)
      fclose(fOut);

   if (bshowle) {
      printx("$%s %s %s %s<def> %s\n",
         icrlf ? "crlf" : "----",
         ilf   ? "lf"   : "--",
         iut   ? "ut"   : "--",
         icr   ? "cr"   : "--",
         pszFile
         );
      if (icrlf) aGlblConvStat[0]++;
      if (ilf  ) aGlblConvStat[1]++;
      if (iut  ) aGlblConvStat[2]++;
      if (icr  ) aGlblConvStat[3]++;
   }
   else if (!cs.quiet) {
      info.printLine(1<<2);
   }

   if (berr)
      return 9+esys("fwrite", "failed to write %s   \n", pszOutFile);

   return 0;
}

UDPCore::UDPCore(int iMaxWait)
{
   memset(this, 0, sizeof(*this));

   for (int i=0; i<nClCon; i++)
      aClCon[i].sock = INVALID_SOCKET;

   nClMaxSock = 0;

   bpure = 1;
   
   tstart = getCurrentTime();

   imaxwait = iMaxWait;
}

UDPCore::~UDPCore( )
{
   if (nClCon > 0)
      perr("missing shutdown() on udpcore %p",this);

   shutdown();
}

int UDPCore::lastError( )
{
   #ifdef _WIN32
   return WSAGetLastError();
   #else
   return errno;
   #endif
}

void UDPCore::shutdown( )
{
   for (int i=0; i<nClCon; i++) 
      if (aClCon[i].sock != INVALID_SOCKET)
         closesocket(aClCon[i].sock);

   memset(this, 0, sizeof(*this));

   for (int i=0; i<nClCon; i++)
      aClCon[i].sock = INVALID_SOCKET;

   nClMaxSock = 0;
}

int UDPCore::makeSocket(int iMode, char *pszHost, int nportin)
{__
   if (nClCon >= MAX_UDP_CON-2)
      return 9+perr("too many sockets, cannot connect more");

   mclear(aClCon[nClCon]);
   aClCon[nClCon].sock = INVALID_SOCKET;

   uint nPort = nportin;

   SOCKET hSock = 0;

   switch (iMode)
   {
      case 1: hSock = socket(AF_INET, SOCK_DGRAM, 0); break;
      case 2: hSock = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP); break;
   }

   if (hSock == INVALID_SOCKET)
      return 9+perr("cannot create socket, probably missing admin rights");

   UDPCon *pcon = &aClCon[nClCon];

   pcon->addr.sin_family = AF_INET;
   pcon->addr.sin_port = htons((unsigned short)nPort);
   if (setaddr(&pcon->addr,pszHost))
   {
      closesocket(hSock);
      return 9+perr("cannot get host\n");
   }

   char szBuf[100];

   strcopy(pcon->host, pszHost);
   pcon->port = nportin;
   pcon->sock = hSock;

   char *pstr = ipAsString((struct sockaddr_in *)&pcon->addr,szBuf,sizeof(szBuf),bpure?0:2);
   strcopy(pcon->ipstr, pstr);

   FD_SET(pcon->sock, &clReadSet);

   nClMaxSock = mymax(nClMaxSock, pcon->sock);

   nClCon++;

   return 0;
}

int UDPCore::selectInput(int *pIndex, int iMaxWaitMSec)
{
   struct timeval tv;
   tv.tv_sec  = iMaxWaitMSec/1000;
   tv.tv_usec = (iMaxWaitMSec < 1000) ? iMaxWaitMSec * 1000 : 0;

   memcpy(&clSetCopy, &clReadSet, sizeof(fd_set));

   int nrc = select(nClMaxSock+1,
      &clSetCopy,
      NULL,
      NULL,
      &tv
      );

   if (nrc == 0)
      return 1; // nothing received

   if (nrc < 0)
      return 9+perr("select() failed, %d",lastError());

   for (int i=0; i<nClCon; i++)
   {
      if (FD_ISSET(aClCon[i].sock, &clSetCopy)) 
      {
         *pIndex = i;
         return 0;
      }
   }

   return 1; // nothing to do
}

static unsigned char webdemo_abRawBlock[1358] = {
80,75,3,4,10,0,0,0,0,0,170,162,60,73,0,0,0,0,0,0,0,0,0,0,0,0,8,0,17,0,119,101,
98,100,101,109,111,47,85,84,13,0,7,32,10,236,87,224,235,234,87,250,181,236,87,80,75,3,4,20,0,0,0,8,
0,170,162,60,73,168,198,156,182,122,0,0,0,144,0,0,0,18,0,17,0,119,101,98,100,101,109,111,47,105,110,100,
101,120,46,104,116,109,108,85,84,13,0,7,32,10,236,87,224,235,234,87,19,182,236,87,53,142,193,10,194,48,16,68,
239,133,254,195,208,15,104,193,115,92,16,61,42,8,30,244,154,198,173,27,76,154,146,236,65,255,222,84,232,101,46,243,
120,51,70,52,6,50,99,122,126,169,109,140,236,232,230,227,18,24,119,30,113,112,142,75,193,137,99,194,213,190,216,12,
181,175,212,178,134,133,100,158,246,157,75,179,242,172,165,255,196,208,209,49,120,247,134,112,174,176,37,76,41,67,133,241,
184,156,177,129,8,190,104,191,105,134,255,116,53,175,63,218,230,7,80,75,3,4,20,0,0,0,8,0,170,162,60,73,
158,225,250,98,89,0,0,0,222,0,0,0,20,0,17,0,119,101,98,100,101,109,111,47,99,111,110,116,101,110,116,115,
46,120,109,108,85,84,13,0,7,32,10,236,87,224,235,234,87,27,182,236,87,179,41,202,47,47,182,227,229,82,176,73,
78,44,73,77,207,47,170,4,113,20,108,50,83,236,12,13,12,109,244,129,52,152,159,151,152,155,106,231,86,84,154,89,
82,108,163,15,230,128,244,232,35,107,194,102,130,17,154,9,97,169,233,169,37,137,73,57,169,36,153,98,140,102,138,83,
106,89,106,81,98,58,78,67,108,244,161,190,2,0,80,75,3,4,20,0,0,0,8,0,170,162,60,73,169,45,180,0,
91,0,0,0,13,1,0,0,28,0,17,0,119,101,98,100,101,109,111,47,112,114,111,100,117,99,116,95,108,105,115,116,
95,49,48,49,46,120,109,108,85,84,13,0,7,32,10,236,87,224,235,234,87,37,182,236,87,179,41,202,47,47,182,227,
229,82,80,80,176,1,50,237,108,242,18,115,83,237,28,11,10,114,82,139,109,244,193,28,176,36,24,216,20,20,101,38,
167,218,25,233,25,216,232,67,152,54,250,32,77,232,218,157,18,243,128,16,167,126,67,61,83,252,250,189,51,203,51,241,
232,54,199,175,219,189,40,177,0,159,227,141,209,181,131,105,80,32,0,0,80,75,3,4,20,0,0,0,8,0,170,162,
60,73,107,16,183,103,79,0,0,0,205,0,0,0,28,0,17,0,119,101,98,100,101,109,111,47,112,114,111,100,117,99,
116,95,108,105,115,116,95,49,48,50,46,120,109,108,85,84,13,0,7,32,10,236,87,224,235,234,87,39,182,236,87,179,
41,202,47,47,182,227,229,82,80,80,176,1,50,237,108,242,18,115,83,237,2,242,75,18,75,242,83,139,109,244,193,92,
176,52,24,216,20,20,101,38,167,218,25,234,25,217,232,67,152,54,250,32,109,232,6,56,165,38,230,225,209,109,129,95,
119,64,106,34,30,205,134,232,154,193,52,200,19,0,80,75,3,4,20,0,0,0,8,0,170,162,60,73,53,38,55,212,
83,0,0,0,208,0,0,0,28,0,17,0,119,101,98,100,101,109,111,47,112,114,111,100,117,99,116,95,108,105,115,116,
95,49,48,51,46,120,109,108,85,84,13,0,7,32,10,236,87,224,235,234,87,41,182,236,87,179,41,202,47,47,182,227,
229,82,80,80,176,1,50,237,108,242,18,115,83,237,194,19,75,82,139,108,244,193,108,176,28,24,216,20,20,101,38,167,
218,25,232,153,218,232,67,152,54,250,32,61,232,186,157,243,115,18,113,107,182,196,175,217,177,160,32,39,85,193,171,20,
168,2,183,25,230,232,102,128,105,144,63,0,80,75,1,2,23,11,10,0,0,0,0,0,170,162,60,73,0,0,0,0,
0,0,0,0,0,0,0,0,8,0,9,0,0,0,0,0,0,0,16,0,255,65,0,0,0,0,119,101,98,100,101,109,
111,47,85,84,5,0,7,32,10,236,87,80,75,1,2,23,11,20,0,0,0,8,0,170,162,60,73,168,198,156,182,122,
0,0,0,144,0,0,0,18,0,9,0,0,0,0,0,1,0,32,0,182,129,55,0,0,0,119,101,98,100,101,109,111,
47,105,110,100,101,120,46,104,116,109,108,85,84,5,0,7,32,10,236,87,80,75,1,2,23,11,20,0,0,0,8,0,
170,162,60,73,158,225,250,98,89,0,0,0,222,0,0,0,20,0,9,0,0,0,0,0,1,0,32,0,182,129,242,0,
0,0,119,101,98,100,101,109,111,47,99,111,110,116,101,110,116,115,46,120,109,108,85,84,5,0,7,32,10,236,87,80,
75,1,2,23,11,20,0,0,0,8,0,170,162,60,73,169,45,180,0,91,0,0,0,13,1,0,0,28,0,9,0,0,
0,0,0,1,0,32,0,182,129,142,1,0,0,119,101,98,100,101,109,111,47,112,114,111,100,117,99,116,95,108,105,115,
116,95,49,48,49,46,120,109,108,85,84,5,0,7,32,10,236,87,80,75,1,2,23,11,20,0,0,0,8,0,170,162,
60,73,107,16,183,103,79,0,0,0,205,0,0,0,28,0,9,0,0,0,0,0,1,0,32,0,182,129,52,2,0,0,
119,101,98,100,101,109,111,47,112,114,111,100,117,99,116,95,108,105,115,116,95,49,48,50,46,120,109,108,85,84,5,0,
7,32,10,236,87,80,75,1,2,23,11,20,0,0,0,8,0,170,162,60,73,53,38,55,212,83,0,0,0,208,0,0,
0,28,0,9,0,0,0,0,0,1,0,32,0,182,129,206,2,0,0,119,101,98,100,101,109,111,47,112,114,111,100,117,
99,116,95,108,105,115,116,95,49,48,51,46,120,109,108,85,84,5,0,7,32,10,236,87,80,75,5,6,0,0,0,0,
6,0,6,0,204,1,0,0,108,3,0,0,0,0,
};

uchar *getWebDemoData(int &isize) { isize = sizeof(webdemo_abRawBlock); return webdemo_abRawBlock; }

void printSamp(int nlang, char *pszOutFile, char *pszClassName, int bWriteFile, int iSystem)
{
      /*
         sfk fromclip +filt -srep "_\\_\\\\_" -srep "_\q_\\\q_" -sform "          \q$col1\\n\q"
         sfk filt src -rep "_%_%%_" -srep "_\\_\\\\_" -srep "_\q_\\\q_" -sform "         \q$col1\\n\q" +toclip
      */

      switch (nlang) {
      case 1:
      chain.print(
          "import java.io.*;\n"
          "\n"
          "public class %s\n"
          "{\n"
          "    static void log(String s) { System.out.println(\"main: \"+s); }\n"
          "\n"
          "    public static void main(String args[]) throws Throwable\n"
          "    {\n"
          "        if (args.length < 2)\n"
          "            { log(\"supply in- and output filename.\"); return; }\n"
          "\n"
          "        // copy or convert text file\n"
          "        BufferedReader rin = new BufferedReader(\n"
          "            new InputStreamReader(\n"
          "                new FileInputStream(args[0]), \"ISO-8859-1\"\n"
          "                // or US-ASCII,UTF-8,UTF-16BE,UTF-16LE,UTF-16\n"
          "                ));\n"
          "\n"
          "        PrintWriter pout = new PrintWriter(\n"
          "            new OutputStreamWriter(\n"
          "                new FileOutputStream(args[1]), \"ISO-8859-1\"\n"
          "                ));\n"
          "\n"
          "        while (true) {\n"
          "            String sline = rin.readLine();\n"
          "            if (sline == null) break; // EOD\n"
          "            log(\"copying line: \"+sline);\n"
          "            pout.println(sline);\n"
          "        }\n"
          "\n"
          "        pout.close();\n"
          "        rin.close();\n"
          "    }\n"
          "};\n",
          pszClassName
        );
         break;

      case 2:
      chain.print(
         "#include <stdio.h>\n"
         "#include <string.h>\n"
         "#include <stdarg.h>\n"
         "#include <stdlib.h>\n"
         "#include <ctype.h>\n"
         "\n"
         "// print error message with variable parameters.\n"
         "int perr(const char *pszFormat, ...) {\n"
         "   va_list argList;\n"
         "   va_start(argList, pszFormat);\n"
         "   char szBuf[1024];\n"
         "   ::vsprintf(szBuf, pszFormat, argList);\n"
         "   fprintf(stderr, \"error: %%s\", szBuf);\n"
         "   return 0;\n"
         "}\n"
         "\n"
         "// copy text lines from one file into another.\n"
         "int main(int argc, char *argv[]) \n"
         "{\n"
         "   if (argc < 2) return 9+perr(\"specify input and output filename.\\n\");\n"
         "\n"
         "   char *pszInFile  = argv[1];\n"
         "   char *pszOutFile = argv[2];\n"
         "\n"
         "   FILE *fin  = fopen(pszInFile , \"rb\"); if (!fin ) return 9+perr(\"cannot read %%s\\n\" , pszInFile);\n"
         "   FILE *fout = fopen(pszOutFile, \"wb\"); if (!fout) return 9+perr(\"cannot write %%s\\n\", pszOutFile);\n"
         "\n"
         "   char szBuf[1024];\n"
         "   memset(szBuf, 0, sizeof(szBuf));\n"
         "   while (fgets(szBuf, sizeof(szBuf)-10, fin)) \n"
         "   {\n"
         "      char *psz = strchr(szBuf, '\\r'); if (psz) *psz = '\\0'; // strip cr\n"
         "            psz = strchr(szBuf, '\\n'); if (psz) *psz = '\\0'; // strip lf\n"
         "      printf(\"line: \\\"%%s\\\"\\n\", szBuf);\n"
         "      strcat(szBuf, \"\\n\");\n"
         "      int nlen = strlen(szBuf);\n"
         "      if (fwrite(szBuf, 1, nlen, fout) != nlen)\n"
         "         return 9+perr(\"failed to fully write %%s\\n\", pszOutFile);\n"
         "   }\n"
         "\n"
         "   fclose(fout);\n"
         "   fclose(fin);\n"
         "\n"
         "   return 0;\n"
         "}\n"
        );
         break;

      case 3:
      chain.print(
         "@rem windows command shell batch example\n"
         "@echo off\n"
         "IF \"%%1\"==\"\" GOTO xerr01\n"
         "echo \"parameter is %%1\"\n"
         "GOTO xdone\n"
         "\n"
         ":xerr01\n"
         "echo \"please supply a parameter.\"\n"
         "echo \"example: mybat parm123\"\n"
         "GOTO xdone\n"
         "\n"
         ":xdone\n"
         );
         break;

      case 4:
      chain.print(
         "#!/bin/bash\n"
         "\n"
         "function pmsg {\n"
         "   # uses a local variable mystr\n"
         "   local mystr=\"info: $1\"\n"
         "   echo $mystr\n"
         "}\n"
         "\n"
         "myparm1=\"$1 and $2\"       # no blanks around \"=\"\n"
         "\n"
         "if [ \"$2\" = \"\" ]; then    # requires all blanks\n"
         "   pmsg \"please supply two parameters.\"\n"
         "else\n"
         "   pmsg \"you supplied \\\"$myparm1\\\".\"\n"
         "\n"
         "   #  < -lt   > -gt   <= -le   >= -ge   == -eq   != -ne\n"
         "   i=1\n"
         "   while [ $i -le 5 ]; do # not \"$i < 5\"\n"
         "      echo counting: $i   # quotes are optional\n"
         "      let i+=1            # not \"i += 1\" or \"$i+=1\"\n"
         "   done\n"
         "fi\n"
         );
         break;

      case 5:
      chain.print(
         "sfk select testfiles .txt .hpp .cpp\n"
         "\n"
         "   // find words supplied by user.\n"
         "   // note that %%1 is the same as $1.\n"
         "   +find\n"
         "      %%1 %%2 %%3 $4 $5 $6\n"
         "\n"
         "   // process files containing hits\n"
         "   +run -quiet \"sfk echo \\\"Found hit in: [green]$file[def]\\\"\" -yes\n"
         "\n"
         "   // run the script by:\n"
         "   // \"sfk script %s pattern1 [pattern2 ...]\"\n",
         pszOutFile ? pszOutFile : "thisfile"
         );
         break;

      case 6:
      chain.print(
         "@echo off\n"
         "sfk script %%~f0 -from begin %%*\n"
         "rem %%~f0 is the absolute batch file name\n"
         "GOTO xend\n"
         "\n"
         "sfk label begin -var\n"
         "   +if \"%%1 = \" call help\n"
         "   +echo \"main got parameters: %%1 %%2 %%3\"\n"
         "   +then setvar \"a=the quick brown fox\"\n"
         "   +call myfunc foo bar %%1\n"
         "   +end\n"
         "\n"
         "sfk label myfunc\n"
         "   +echo \"func got parameters: %%1 %%2 %%3\"\n"
         "   +echo -var \"variable a contains: #(a)\"\n"
         "   +echo -var \"#(a)\"\n"
         "      +tcall substr 4 5\n"
         "      +setvar b\n"
         "   +echo -var \"variable b contains: #(b)\"\n"
         "   +end\n"
         "\n"
         "sfk label substr\n"
         "   +xex \"/[start][%%1 chars][%%2 chars]/[part3]/\"\n"
         "   +tend\n"
         "\n"
         "sfk label help\n"
         "   +echo \"supply one or more parameters.\"\n"
         "   +stop -all\n"
         "   +end\n"
         "\n"
         ":xend\n"
         );
         break;

      case 7:
      chain.print(
         "#!/bin/bash\n"
         "sfk script $0 -from begin $@\n"
         "function skip_block\n"
         "{\n"
         "sfk label begin\n"
         "#  +echo \"main got parameters: %%1 %%2 %%3\"\n"
         "#  +then setvar \"a=the quick brown fox\"\n"
         "#  +call myfunc foo bar %%1\n"
         "#  +end\n"
         "#  // note that # lines are skipped by bash,\n"
         "#  // but not by sfk.\n"
         "\n"
         "sfk label myfunc\n"
         "   +echo \"func got parameters: %%1 %%2 %%3\"\n"
         "   +echo -var \"variable a contains: #(a)\"\n"
         "   +echo -var \"#(a)\"\n"
         "      +tcall substr 4 5\n"
         "      +setvar b\n"
         "   +echo -var \"variable b contains: #(b)\"\n"
         "   +end\n"
         "\n"
         "sfk label substr\n"
         "   +xex \"/[start][%%1 chars][%%2 chars]/[part3]/\"\n"
         "   +tend\n"
         "\n"
         "#  // if bash produces errors with \\r you must:\n"
         "#  //   sfk remcr %s\n"
         "}\n",
         pszOutFile ? pszOutFile : "thisfile.sh"
         );
         break;

      case 8:
      chain.print(
         "\n"
         "// Example source code for image file conversion\n"
         "// and simple image processing with Java.\n"
         "// Requires SUN's Java Advanced Imaging I/O Tools.\n"
         "// Usage: java imtool input.png outbase\n"
         "// Creates: outbase-jpg.jpg and further.\n"
         "\n"
         "import java.io.*;\n"
         "import java.awt.image.*;\n"
         "import javax.imageio.*;\n"
         "import com.sun.image.codec.jpeg.*;\n"
         "\n"
         "public class %s\n"
         "{\n"
         "    static void log(String s) { System.out.println(s); }\n"
         "\n"
         "    public static void main(String args[]) throws Throwable\n"
         "    {\n"
         "        if (args.length < 2)\n"
         "            throw new Exception(\"specify input filename and output basename.\");\n"
         "\n"
         "        String src  = args[0];\n"
         "        String dst1 = args[1]+\"-jpg.jpg\";\n"
         "        String dst2 = args[1]+\"-png.png\";\n"
         "        String dst3 = args[1]+\"-green.jpg\";\n"
         "        String dst4 = args[1]+\"-green.png\";\n"
         "\n"
         "        // load a PNG image, with or without transparency (alpha channel).\n"
         "        BufferedImage buf = ImageIO.read(new File(src));\n"
         "        int nwidth  = buf.getWidth();\n"
         "        int nheight = buf.getHeight();\n"
         "        log(\"width = \"+nwidth+\" pixels, height = \"+nheight);\n"
         "\n"
         "        // trivial file conversion: save as a JPEG or PNG image.\n"
         "        // JPEG will work only if input contained no transparency.\n"
         "        ImageIO.write(buf, \"jpg\", new File(dst1)); log(dst1);\n"
         "        ImageIO.write(buf, \"png\", new File(dst2)); log(dst2);\n"
         "\n"
         "        // image processing: turn all transparent pixels into green.\n"
         "\n"
         "        // 1. get access to main pixels, and transparency.\n"
         "        WritableRaster rmain = buf.getRaster();\n"
         "        WritableRaster rtran = buf.getAlphaRaster();\n"
         "\n"
         "        // 2. create a memory image to write to, WITHOUT transparency.\n"
         "        BufferedImage bout  = new BufferedImage(nwidth,nheight,BufferedImage.TYPE_INT_RGB);\n"
         "        WritableRaster rout = bout.getRaster();\n"
         "\n"
         "        int apixm[] = new int[4]; // main  pixel\n"
         "        int apixt[] = new int[4]; // trans pixel\n"
         "        int apixr[] = new int[4]; // repl. color\n"
         "\n"
         "        apixt[0] = 0xFF; // default is non-transparent\n"
         "        apixr[1] = 0xFF; // set replacement color to green\n"
         "\n"
         "        for (int y=0; y<nheight; y++)\n"
         "         for (int x=0; x<nwidth; x++) \n"
         "         {\n"
         "            rmain.getPixel(x,y,apixm);\n"
         "            if (rtran != null)\n"
         "                rtran.getPixel(x,y,apixt);\n"
         "            if (apixt[0] == 0x00)\n"
         "                // pixel is fully transparent: set to green\n"
         "                rout.setPixel(x,y,apixr);\n"
         "            else\n"
         "                // else copy through, do not change.\n"
         "                rout.setPixel(x,y,apixm);\n"
         "         }\n"
         "\n"
         "        // save memory image as JPEG, with control of quality.\n"
         "        File file = new File(dst3);\n"
         "        FileOutputStream out = new FileOutputStream(file);\n"
         "        JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);\n"
         "        JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(bout);\n"
         "        param.setQuality((float)90.0, false); // 90 percent quality\n"
         "        encoder.setJPEGEncodeParam(param);\n"
         "        encoder.encode(bout);\n"
         "        out.close();\n"
         "        log(dst3);\n"
         "\n"
         "        // save memory image as PNG.\n"
         "        ImageIO.write(bout, \"png\", new File(dst4)); log(dst4);\n"
         "    }\n"
         "};\n"
         ,pszClassName
         );
         break;

      case 9:
      chain.print(
         "<?php\n"
         "   // simple text file read and write in php.\n"
         "   // requires the php command line interface:\n"
         "   // 1. get the php 5.x zip package\n"
         "   // 2. unzip into a dir like c:\\app\\php\n"
         "   // 3. set PATH=%PATH%;c:\\app\\php;c:\\app\\php\\ext\n"
         "   // then run this script by \"php %s\"\n"
         "\n"
         "   if ($argc < 3) {\n"
         "      print(\"usage: php %s infile outfile\\n\");\n"
         "      return;\n"
         "   }\n"
         "\n"
         "   $ssrc = $argv[1];\n"
         "   $sdst = $argv[2];\n"
         "\n"
         "   if (($fsrc = fopen($ssrc, \"r\")) === false) die(\"cannot read $ssrc\\n\");\n"
         "   if (($fdst = fopen($sdst, \"w\")) === false) die(\"cannot write $sdst\\n\");\n"
         "\n"
         "   $nlines = 0;\n"
         "   while (!feof($fsrc)) {\n"
         "      $sline = fgets($fsrc, 4096);\n"
         "      if (fputs($fdst, $sline) === false)\n"
         "         { print(\"failed to write (disk full?)\\n\"); break; }\n"
         "      $nlines++;\n"
         "   }\n"
         "\n"
         "   fclose($fdst);\n"
         "   fclose($fsrc);\n"
         "\n"
         "   print(\"$nlines lines copied from $ssrc to $sdst.\\n\");\n"
         "?>\n"
         ,pszOutFile ? pszOutFile : "thisfile.php"
         ,pszOutFile ? pszOutFile : "thisfile.php"
         );
         break;

      case 10:
      chain.print(
         "<?php\n"
         "   // create a thumbnail image from a large image.\n"
         "   // requires the php command line interface:\n"
         "   // 1. get the php 5.x zip package\n"
         "   // 2. unzip into a dir like c:\\app\\php\n"
         "   // 3. set PATH=PATH;c:\\app\\php;c:\\app\\php\\ext\n"
         "   // then run this script by \"php %s in.jpg out.jpg\"\n"
         "\n"
         "   if ($argc < 3) {\n"
         "      print(\"usage: php %s input.jpg output.jpg [targetwidth quality]\\n\");\n"
         "      return;\n"
         "   }\n"
         "\n"
         "   $ssrc = $argv[1];\n"
         "   $sdst = $argv[2];\n"
         "   $wdst = isset($argv[3]) ? $argv[3] : 100;\n"
         "   $nqty = isset($argv[4]) ? $argv[4] :  80;\n"
         "\n"
         "   if (strstr($ssrc, \".jpg\"))\n"
         "      $isrc = ImageCreateFromJPEG($ssrc);\n"
         "   else\n"
         "      $isrc = ImageCreateFromPNG($ssrc);\n"
         "   if ($isrc === false) die(\"cannot load: $ssrc\");\n"
         "\n"
         "   $nsrcw = ImageSX($isrc);\n"
         "   $nsrch = ImageSY($isrc);\n"
         "   print(\"input: $ssrc with $nsrcw\".\"x$nsrch pixels\\n\");\n"
         "\n"
         "   $hdst  = intval($wdst * $nsrch / $nsrcw);\n"
         "   $idst  = ImageCreateTrueColor($wdst, $hdst);\n"
         "   if ($idst === false) die(\"cannot create thumb\");\n"
         "\n"
         "   imagecopyresampled($idst, $isrc, 0,0,0,0, $wdst,$hdst, $nsrcw, $nsrch);\n"
         "   imagejpeg($idst, $sdst, $nqty);\n"
         "   print(\"thumb: $sdst with $wdst\".\"x$hdst pixels, quality=$nqty\\n\");\n"
         "\n"
         "   imagedestroy($idst);\n"
         "   imagedestroy($isrc);\n"
         "?>\n"
         ,pszOutFile ? pszOutFile : "thisfile.php"
         ,pszOutFile ? pszOutFile : "thisfile.php"
         );
         break;

      case 11:
      chain.print(
         "<html>\n"
         " <head>\n"
         "  <title>Welcome to FooBar</title>\n"
         "   <style type=\"text/css\">\n"
         "      body     { font: 12px verdana,arial; }\n"
         "      table    { font: 12px verdana,arial; }\n"
         "      h1       { font: 16px verdana,arial; font-weight: bold; }\n"
         "      b.red    { color: #ee6622; }\n"
         "   </style>\n"
         "   <script type=\"text/javascript\">\n"
         "      function hello() {\n"
         "         document.write(\"hello from JavaScript.\");\n"
         "      }\n"
         "   </script>\n"
         " </head>\n"
         "<body leftmargin=\"0\" topmargin=\"0\" marginwidth=\"0\" marginheight=\"0\">\n"
         "\n"
         "<table width=\"980\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\" border=\"0\">\n"
         "\n"
         " <tr>\n"
         "  <td width=\"120\" align=\"center\" valign=\"middle\">\n"
         "  &nbsp;<br>\n"
         "  home\n"
         "  </td>\n"
         "  <td width=\"740\" align=\"center\" valign=\"top\">\n"
         "  &nbsp;<br>\n"
         "  <h1>Welcome to FooBar.</h1>\n"
         "  </td>\n"
         "  <td width=\"120\" align=\"center\" valign=\"middle\">\n"
         "  &nbsp;<br>\n"
         "  other\n"
         "  </td>\n"
         " </tr>\n"
         "\n"
         " <tr>\n"
         "  <td align=\"center\" valign=\"top\">&nbsp;</td>\n"
         "  <td>\n"
         "      <b class=\"red\">bold</b> and normal text.\n"
         "      <p>\n"
         "      <script type=\"text/javascript\">\n"
         "         hello();\n"
         "      </script>\n"
         "  </td>\n"
         "  <td align=\"center\" valign=\"top\">&nbsp;</td>\n"
         " </tr>\n"
         "\n"
         "</table>\n"
         "\n"
         "</body>\n"
         "</html>\n"
         );
         break;

      case 12:
      chain.print(
         "@rem <?php print(\"\\r\"); /*\n"
         "@echo off\n"
         "\n"
         "IF \"%%1\"==\"\" GOTO xerr01\n"
         "\n"
         "sfk script %s -from begin %%*\n"
         "GOTO xend\n"
         "\n"
         ":xerr01\n"
         "sfk echo \"[green]jpeg image size lister.[def]\"\n"
         "sfk echo \"lists width, height of all .jpg in a dir.\"\n"
         "sfk echo \"usage: %s dirname\"\n"
         "GOTO xend\n"
         "\n"
         "   // this script requires the php command line interface:\n"
         "   // 1. get the php 5.x zip package\n"
         "   // 2. unzip into a dir like c:\\app\\php\n"
         "   // 3. set PATH=PATH;c:\\app\\php;c:\\app\\php\\ext\n"
         "\n"
         "   // ----- begin of sfk script code -----\n"
         "\n"
         "sfk label begin\n"
         "\n"
         "   +sel %%1 .jpg\n"
         "\n"
         "   +run -quiet -yes \"php %s $file\"\n"
         "\n"
         "   +end\n"
         "\n"
         "*/ // ----- end of sfk, begin of php script -----\n"
         "\n"
         "   // print the width and height in pixel\n"
         "   // of the supplied image file name:\n"
         "\n"
         "   $asize = getimagesize($argv[1]);\n"
         "   printf(\"w=%%04d h=%%04d %%s\\n\", $asize[0], $asize[1], $argv[1]);\n"
         "\n"
         "/* // ----- end of php script, end of batch -----\n"
         ":xend\n"
         "@rem */ ?>\n"
         ,pszOutFile ? pszOutFile : "thisfile.bat"
         ,pszOutFile ? pszOutFile : "thisfile.bat"
         ,pszOutFile ? pszOutFile : "thisfile.bat"
         );
         break;

      case 13:
      chain.print(
         "import java.io.*;\n"
         "\n"
         "public class %s\n"
         "{\n"
         "    static void log(String s) { System.out.println(s); }\n"
         "\n"
         "    // convert a single byte record into a hexdump record.\n"
         "    // by default, set nrec to 16, and ndoff to 0.\n"
         "    public static String hexRecord(byte ab[], int noffset, int nlen, int nrec, int ndoff)\n"
         "    {\n"
         "        // create hex and text representation\n"
         "        StringBuffer sline = new StringBuffer();\n"
         "        StringBuffer stext = new StringBuffer();\n"
         "        for (int i=0; i<nlen; i++) {\n"
         "            int nval = ab[noffset+i] & 0xFF;\n"
         "            if (nval < 0x10) sline.append(\"0\");\n"
         "            sline.append(Integer.toString(nval, 0x10));\n"
         "            sline.append(\" \");\n"
         "            if (Character.isLetter(nval))\n"
         "                stext.append((char)nval);\n"
         "            else\n"
         "                stext.append('.');\n"
         "        }\n"
         "        // fill rest of line, if any\n"
         "        int npadlen = nrec;\n"
         "        while (stext.length() < npadlen) stext.append(' ');\n"
         "        npadlen *= 3;\n"
         "        while (sline.length() < npadlen) sline.append(' ');\n"
         "        sline.setLength(sline.length()-1);\n"
         "        // create offset as hex value\n"
         "        String soffset = \"\";\n"
         "        soffset = Integer.toString(ndoff, 0x10).toUpperCase();\n"
         "        while (soffset.length() < 10) soffset = \"0\"+soffset;\n"
         "        // combine hex, text and offset\n"
         "        return \">\"+sline.toString().toUpperCase()+\"< \"+stext+\" \"+soffset;\n"
         "    }\n"
         "    \n"
         "    // hexdump a whole byte array, from a given offset.\n"
         "    // nrec is the number of bytes per output record, use 16 by default.\n"
         "    // ndosv is the display offset start value, use 0 by default.\n"
         "    public static void hexDump(byte ab[], int noffset, int nlen, int nrec, int ndoff)\n"
         "    {\n"
         "        while (nlen > 0) {\n"
         "            int nblock  = (nlen < nrec) ? nlen : nrec;\n"
         "            String srec = hexRecord(ab, noffset, nblock, nrec, ndoff);\n"
         "            System.out.println(srec);\n"
         "            noffset += nblock;\n"
         "            ndoff   += nblock;\n"
         "            nlen    -= nblock;\n"
         "        }\n"
         "    }\n"
         "\n"
         "    // hex dump a whole binary file's content\n"
         "    public static void main(String args[]) throws Throwable\n"
         "    {\n"
         "        if (args.length < 1)\n"
         "            { log(\"usage: java %s inputfilename\"); return; }\n"
         "\n"
         "        byte abBuf[] = new byte[1600];\n"
         "\n"
         "        FileInputStream oin = new FileInputStream(args[0]);\n"
         "\n"
         "        int nread  = 0;\n"
         "        int ntotal = 0;\n"
         "        do {\n"
         "            nread = oin.read(abBuf, 0, abBuf.length);\n"
         "            if (nread > 0) hexDump(abBuf, 0, nread, 16, ntotal);\n"
         "            ntotal += nread;\n"
         "        }   while (nread > 0);\n"
         "\n"
         "        oin.close();\n"
         "    }\n"
         "}\n"
          ,pszClassName,pszClassName
        );
         break;

      case 14:
      chain.print(
         "\n"
         "import java.awt.*;\n"
         "import java.awt.event.*;\n"
         "import java.io.*;\n"
         "import javax.swing.*;\n"
         "import java.util.*;\n"
         "\n"
         "// can be run both as an applet and a command line application\n"
         "public class %s extends JApplet implements ActionListener\n"
         "{\n"
         "    // a panel to collect all objects for display\n"
         "    Container clPane = null;\n"
         "\n"
         "    // a hashmap to collect the same objects for retrieval by an id\n"
         "    HashMap<String,Component> clComp = new HashMap<String,Component>();\n"
         "    // HashMap clComp = new HashMap(); // for JDK 1.4.2\n"
         "\n"
         "    // the current add position\n"
         "    int xadd = 0, yadd = 0;\n"
         "\n"
         "    // set component placement cursor to a position\n"
         "    void setPos(int x,int y) { xadd=x; yadd=y; }\n"
         "    \n"
         "    // add and remember a generic component for display.\n"
         "    // steps the placement cursor w pixels to the right.\n"
         "    void add(int x,int y,int w,int h,String id,Component o) {\n"
         "        o.setBounds(x,y,w,h);   // set absolute position of object\n"
         "        clPane.add(o);          // add to panel to display object\n"
         "        clComp.put(id, o);      // and remember object in a hashmap\n"
         "        xadd += w;              // step add position horizontally\n"
         "    }\n"
         "    \n"
         "    // add a non-editable text label\n"
         "    void addLabel(int w, int h, String id, String text)\n"
         "        { add(xadd,yadd,w,h, id, new JLabel(text)); }\n"
         "\n"
         "    // add a single line editable text field    \n"
         "    void addTextField(int w, int h, String id, String text)\n"
         "        { add(xadd,yadd,w,h, id, new JTextField(text)); }\n"
         "\n"
         "    // add a multi linex editable text area\n"
         "    void addTextArea(int w, int h, String id, String text) {\n"
         "        JTextArea   oarea   = new JTextArea(text);\n"
         "        JScrollPane oscroll = new JScrollPane(oarea);\n"
         "        oscroll.setBounds(xadd,yadd,w,h);\n"
         "        clPane.add(oscroll);\n"
         "        clComp.put(id,oarea);\n"
         "    }\n"
         "\n"
         "    // add a push button\n"
         "    void addButton(int w, int h, String id, String text) {\n"
         "        JButton o = new JButton(text);\n"
         "        o.addActionListener(this);\n"
         "        add(xadd,yadd,w,h, id, o);\n"
         "    }\n"
         "\n"
         "    // easy access to any object by its id\n"
         "    JTextField getTextField(String id) { return (JTextField)clComp.get(id); }\n"
         "    JTextArea  getTextArea (String id) { return (JTextArea )clComp.get(id); }\n"
         "    JLabel     getLabel    (String id) { return (JLabel    )clComp.get(id); }\n"
         "\n"
         "    // setup visible objects at absolute positions\n"
         "    private void fillPane() \n"
         "    {        \n"
         "        clPane.setLayout(null); // absolute positioning layout\n"
         "        \n"
         "        setPos      ( 20, 20);\n"
         "        addLabel    ( 70, 20, \"lname\", \"filename\");\n"
         "        addTextField(620, 20, \"tname\", \"c:\\\\test.txt\");\n"
         "\n"
         "        setPos      ( 90, yadd + 30);\n"
         "        addButton   (620, 20, \"bload\", \"load\");\n"
         "\n"
         "        setPos      ( 20, yadd + 30);\n"
         "        addLabel    ( 70, 20, \"lcont\", \"content\");\n"
         "        addTextArea (620,400, \"acont\", \"\");\n"
         "    }\n"
         "\n"
         ,pszClassName);
    chain.print(
         "    // process push button command    \n"
         "    public void actionPerformed(ActionEvent e) \n"
         "    {\n"
         "        String sout = \"\";\n"
         "        try {\n"
         "            String scmd = e.getActionCommand();\n"
         "            if (scmd.equals(\"load\")) \n"
         "            {\n"
         "                String sFilename = getTextField(\"tname\").getText();\n"
         "                BufferedReader rin = new BufferedReader(\n"
         "                    new InputStreamReader(new FileInputStream(sFilename), \"ISO-8859-1\"));\n"
         "                while (true) {\n"
         "                    String sline = rin.readLine();\n"
         "                    if (sline == null) break; // EOD\n"
         "                    sout += sline + \"\\n\";\n"
         "                }\n"
         "                rin.close();\n"
         "            }\n"
         "        } catch (Throwable t) {\n"
         "            sout = \"\"+t;\n"
         "        }\n"
         "        getTextArea(\"acont\").setText(sout);\n"
         "    }\n"
         "\n"
         "    // to run it from the command line:\n"
         "    public static void main(String[] args)\n"
         "        { new %s().main2(args); }\n"
         "\n"
         "    public void main2(String[] args) {\n"
         "        JFrame frame = new JFrame(\"Simple File Viewer\");\n"
         "        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);\n"
         "        clPane = frame.getContentPane();\n"
         "        fillPane();\n"
         "        frame.setSize(760, 560);\n"
         "        frame.setVisible(true);\n"
         "    }\n"
         "\n"
         "    // to run it as an applet:\n"
         "  public void init() {\n"
         "     clPane = new JPanel();\n"
         "     this.setContentPane(clPane);\n"
         "     fillPane();\n"
         "  }\n"
         "    /*\n"
         "       create a page \"show.html\" containing\n"
         "\n"
         "       <html><body>\n"
         "          <Applet Code=\"%s.class\" width=800 height=600></Applet>\n"
         "       </body></html>\n"
         "      \n"
         "       and then type \"appletviewer show.html\"\n"
         "    */\n"
         "}\n"
          ,pszClassName,pszClassName
        );
        break;

      case 16:
      chain.print(
          "/*\n"
          "   Example for sending UDP color text in C++.\n"
          "   For more details read \"sfk netlog\".\n"
          "\n"
          "   Compile like:\n"
          "      Windows gcc : g++ %s -lws2_32\n"
          "      Windows VC  : cl  %s ws2_32.lib\n"
          "      Linux/Mac   : g++ %s\n"
          "*/\n"
          "\n"
          "#include <stdio.h>\n"
          "#include <stdlib.h>\n"
          "#include <string.h>\n"
          "#include <stdarg.h>\n"
          "#include <errno.h>\n"
          "\n"
          "#ifdef _WIN32\n"
          "  #include <windows.h>\n"
          "  #ifdef _MSC_VER\n"
          "    #define snprintf  _snprintf \n"
          "    #define vsnprintf _vsnprintf \n"
          "    #define sockerrno WSAGetLastError()\n"
          "  #else\n"
          "    #include <ws2tcpip.h>\n"
          "    #define sockerrno errno\n"
          "  #endif\n"
          "  #define socklen_t int\n"
          "#else\n"
          "  #include <sys/socket.h>\n"
          "  #include <netdb.h>\n"
          "  #ifdef __APPLE__\n"
          "    #define SOL_IP IPPROTO_IP\n"
          "  #endif\n"
          "  #ifndef INVALID_SOCKET\n"
          "    #define INVALID_SOCKET -1\n"
          "  #endif\n"
          "  #define sockerrno errno\n"
          "#endif\n"
          "\n"
          "char szLineBuf[500];\n"
          "\n"
          "int iNetSock = INVALID_SOCKET;\n"
          "int iRequest = 1;\n"
          "struct sockaddr_in oAddr;\n"
          "socklen_t iAddrLen = sizeof(oAddr);\n"
          "\n"
          "int perr(const char *pszFormat, ...)\n"
          "{\n"
          "   va_list argList;\n"
          "   va_start(argList, pszFormat);\n"
          "   vsnprintf(szLineBuf, sizeof(szLineBuf)-10, pszFormat, argList);\n"
          "   szLineBuf[sizeof(szLineBuf)-10] = '\\0';\n"
          "   printf(\"Error: %s\\n\", szLineBuf);\n"
          "   return 0;\n"
          "}\n"
          "\n"
          "int netlog(const char *pszFormat, ...)\n"
          "{\n"
          "   char szHeadBuf[100];\n"
          "   int  iHeadLen = 0;\n"
          "\n"
          "   va_list argList;\n"
          "   va_start(argList, pszFormat);\n"
          "   vsnprintf(szLineBuf+100, sizeof(szLineBuf)-110, pszFormat, argList);\n"
          "   szLineBuf[sizeof(szLineBuf)-10] = '\\0';\n"
          "   \n"
          "   // change all [red] to compact color codes \\x1Fr\n"
          "   for (char *psz=szLineBuf+100; *psz; psz++)\n"
          "      if (psz[0]=='[')\n"
          "         for (int i=1; psz[i]; i++)\n"
          "            if (i>=2 && psz[i]==']')\n"
          "               { psz[0]=0x1F; memmove(psz+2, psz+i+1, strlen(psz+i+1)+1); break; }\n"
          "\n"
          "   // add sfktxt header before text\n"
          "   snprintf(szHeadBuf, sizeof(szHeadBuf)-10, \":sfktxt:v100,req%s,cs1\\n\\n\", iRequest++);\n"
          "   iHeadLen = strlen(szHeadBuf);\n"
          "   char *pData = szLineBuf+100-iHeadLen;\n"
          "   memcpy(pData, szHeadBuf, iHeadLen);\n"
          "\n"
          "   sendto(iNetSock, pData, strlen(pData), 0, (struct sockaddr *)&oAddr, iAddrLen);\n"
          "\n"
          "   return 0;\n"
          "}\n"
          "\n"
          "int main(int argc, char *argv[])\n"
          "{\n"
          "   const char *pszHost = \"localhost\";\n"
          "   unsigned short iPort = 21323;\n"
          "   \n"
          "   #ifdef _MSC_VER\n"
          "   WORD wVersionRequested = MAKEWORD(1,1);\n"
          "   WSADATA wsaData;\n"
          "   if (WSAStartup(wVersionRequested, &wsaData)!=0)\n"
          "      return 9+perr(\"WSAStartup failed\");\n"
          "   #endif\n"
          "\n"
          "   memset((char *)&oAddr, 0,sizeof(oAddr));\n"
          "   oAddr.sin_family      = AF_INET;\n"
          "   oAddr.sin_port        = htons(iPort);\n"
          "\n"
          "   struct hostent *pHost = gethostbyname(pszHost);\n"
          "   memcpy(&oAddr.sin_addr.s_addr, pHost->h_addr, pHost->h_length);\n"
          "\n"
          "   if ((iNetSock = socket(AF_INET, SOCK_DGRAM, 0)) < 0)\n"
          "      return 9+perr(\"cannot create socket\");\n"
          "\n"
          "   netlog(\"[Red]Foo[def] and [Blue]bar[def] went to the [Green]zoo[def].\\n\");\n"
          "   \n"
          "   return 0;\n"
          "}\n"
          "\n"
          , pszOutFile ? pszOutFile : "netlog.cpp"
          , pszOutFile ? pszOutFile : "netlog.cpp"
          , pszOutFile ? pszOutFile : "netlog.cpp"
          , "%s" // literally
          , "%d" // literally
         );
         if (!pszOutFile)
            printf("// to write .cpp file use:\n"
                   "// sfk samp cppnetlog netlog.cpp\n");
         break;
 
      case 17:
      if (!pszOutFile) pszClassName = str("netlog");
      chain.print(
          "/*\n"
          "   Example for sending UDP color text in Java.\n"
          "   For more details read \"sfk netlog\".\n"
          "*/\n"
          "\n"
          "import java.io.*;\n"
          "import java.net.*;\n"
          "\n"
          "public class %s\n"
          "{\n"
          "   public static DatagramSocket clSocket = null;\n"
          "   public static InetAddress clAddress = null;\n"
          "   public static int iClPort = -1;\n"
          "   static int iClRequest = 1;\n"
          "\n"
          "   public static void init(String sHost, int iPort) throws Throwable\n"
          "   {\n"
          "      clAddress = InetAddress.getByName(sHost);\n"
          "      iClPort = iPort;\n"
          "      clSocket = new DatagramSocket();\n"
          "   }\n"
          "\n"
          "   public static void log(String sTextIn) throws Throwable\n"
          "   {\n"
          "      String sText   = sTextIn+\"\\n\";\n"
          "\n"
          "      // change all [red] to compact color codes \\x1Fr\n"
          "      byte[] abData1 = sText.getBytes();\n"
          "      int    iSize1  = abData1.length;\n"
          "      byte[] abData2 = new byte[iSize1+100];\n"
          "\n"
          "      // keep 100 bytes space for header\n"
          "      int i2=100;\n"
          "      for (int i1=0; i1<iSize1;)\n"
          "      {\n"
          "         if (abData1[i1]=='[') {\n"
          "            i1++;\n"
          "            if (i1>=iSize1)\n"
          "               break;\n"
          "            abData2[i2++] = (byte)0x1F;\n"
          "            abData2[i2++] = abData1[i1++];\n"
          "            while (i1<iSize1 && abData1[i1]!=']')\n"
          "               i1++;\n"
          "            if (i1<iSize1)\n"
          "               i1++;\n"
          "         } else {\n"
          "            abData2[i2++] = abData1[i1++];\n"
          "         }\n"
          "      }\n"
          "      int iTextSize = i2-100;\n"
          "\n"
          "      // add sfktxt header before text\n"
          "      String sHead = \":sfktxt:v100,req\"+iClRequest+\",cs1\\n\\n\";\n"
          "      iClRequest++;\n"
          "      byte abHead[] = sHead.getBytes();\n"
          "      int iHeadLen  = abHead.length;\n"
          "      for (int i=0; i<iHeadLen; i++)\n"
          "         abData2[100-iHeadLen+i] = abHead[i];\n"
          "      int iStartOff = 100-iHeadLen;\n"
          "      int iFullSize = iHeadLen+iTextSize;\n"
          "\n"
          "      DatagramPacket packet = new DatagramPacket(abData2, iStartOff, iFullSize, clAddress, iClPort);\n"
          "      clSocket.send(packet);\n"
          "   }\n"
          "\n"
          "   public static void main(String args[]) throws Throwable\n"
          "   {\n"
          "      %s.init(\"localhost\", 21323);\n"
          "      %s.log(\"[Red]Foo[def] and [Blue]bar[def] went to the [Green]zoo[def].\");\n"
          "   }\n"
          "}\n"
          "\n"
          , pszClassName
          , pszClassName
          , pszClassName
          );
         if (!pszOutFile)
            printf("// to write .java file use:\n"
                   "// sfk samp javanetlog netlog.java\n");
         break;

         case 18:
         if (iSystem==1)
         chain.print(
            "@echo off\n"
            "sfk -var script %%~f0 -from begin %%*\n"
            "rem \"-var\" enables variables everywhere.\n"
            "rem \"%%~f0\" is the absolute batch file name.\n"
            "GOTO xend\n"
            "\n");
         else
         chain.print(
            "#!/bin/bash\n"
            "sfk -var script $0 -from begin $@\n"
            "# \"-var\" enables variables everywhere.\n"
            "function skip_block\n"
            "{\n");

         chain.print(
            "sfk label begin\n"
            "   +setvar \"baseurl=http://stahlworks.com/webdemo\"\n"
            "   +web \"#(baseurl)/contents.xml\"\n"
            "   +xex \"_<category>**<id>*</id>**<name>*<\n"
            "         _[part4] [part8]\\n_\"\n"
            "   +perline \"call listCategory #text\" -yes\n"
            "   +end\n"
            "\n"
            "sfk label listCategory\n"
            "   +echo \"[green]=== List of %%2: ===[def]\"\n"
            "   +echo -spat \"[yellow]Name         Price[def]\"\n"
            "   +then web \"#(baseurl)/product_list_%%1.xml\"\n"
            "   // +xmlform +stop -all\n"
            "   +xex \"=<row>**<name>*<**<price>*<\n"
            "         =[part4]\\t[part8] \\x24\\n=\"\n"
            "   +filter -upat -stabform \"#(-12col1) #col2\"\n"
            "   +end\n"
            "\n");

         if (iSystem==1)
         chain.print(
            "rem a longer example with input, output and detail\n"
            "rem explanations is available in the SFK Book.\n"
            "\n"
            ":xend\n");
         else
         chain.print(
            "# a longer example with input, output and detail\n"
            "# explanations is available in the SFK Book.\n"
            "\n"
            "}\n");
         break;

         case 19:
         {
            if (!pszOutFile)
               { perr("missing output filename\n"); return; }
            if (!strEnds(pszOutFile, ".zip"))
               { perr("output filename must end with .zip\n"); return; }
            if (!cs.force && fileExists(pszOutFile)) {
               perr("file already exists: %s\n", pszOutFile);
               pinf("add -force to overwrite.\n");
               return;
            }
            printf("writing: %s\n", pszOutFile);
            int    isize = 0;
            uchar *pdata = getWebDemoData(isize);
            saveFile(pszOutFile, pdata, isize);
            printf("you may now:\n"
                   "- unzip %s\n"
                   "- sfk httpserv -deep\n"
                   "- open a different shell, then adapt the batch\n"
                   "  from \"sfk samp http\" to use localhost.\n",
                   pszOutFile
                   );
            break;
         }
      }
}

// internal check: structure alignments must be same as in sfk.cpp
void getAlignSizes2(int &n1, int &n2, int &n3)
{
   n1 = (int)sizeof(AlignTest1);
   n2 = (int)sizeof(AlignTest2);
   n3 = (int)sizeof(AlignTest3);
}

/*
   =====================================================================================
   SFK ping support code. Must be LAST in sfkext.cpp as it changes structure alignments!
   =====================================================================================
*/

#ifdef _WIN32

#define ICMP_ECHO_REPLY    0
#define ICMP_DEST_UNREACH  3
#define ICMP_ECHO_REQUEST  8
#define ICMP_TTL_EXPIRE    11

#ifndef ICMP_MINLEN
 #define ICMP_MINLEN 8
#endif
#ifndef ICMP_ECHOREPLY
 #define ICMP_ECHOREPLY 0
#endif
#ifndef ICMP_ECHO
 #define ICMP_ECHO 8
#endif

#ifdef _MSC_VER
 #pragma pack(1)  // CHANGES STRUCTURE ALIGNMENTS FROM HERE!
#endif

struct icmp {
    BYTE icmp_type;          // ICMP packet type
    BYTE icmp_code;          // Type sub code
    USHORT icmp_cksum;
    USHORT icmp_id;
    USHORT icmp_seq;
    ULONG timestamp;    // not part of ICMP, but we need it
};

struct ip { // IPHeader {
    BYTE h_len:4;           // Length of the header in dwords
    BYTE version:4;         // Version of IP
    BYTE tos;               // Type of service
    USHORT total_len;       // Length of the packet in dwords
    USHORT ident;           // unique identifier
    USHORT flags;           // Flags
    BYTE ttl;               // Time to live
    BYTE proto;             // Protocol number (TCP, UDP etc)
    USHORT checksum;        // IP checksum
    ULONG source_ip;
    ULONG dest_ip;
};

#else

 #include <sys/param.h>
 #include <sys/file.h>
 #include <netinet/in_systm.h>
 #include <netinet/ip.h>
 #include <netinet/ip_icmp.h>

// some linux/mac sys\param.h define that:
#ifdef isset
 #undef isset
#endif

#endif

#define  DEFDATALEN  (64-ICMP_MINLEN)  /* default data length */
#define  MAXIPLEN 60
#define  MAXICMPLEN  76
#define  MAXPACKET   (65536 - 60 - ICMP_MINLEN)/* max packet size */

static ushort in_cksum(ushort *addr, unsigned len)
{
   ushort answer = 0;
   uint sum = 0;
   while (len > 1)  {
      sum += *addr++;
      len -= 2;
   }
   if (len == 1) {
      *(unsigned char *)&answer = *(unsigned char *)addr ;
      sum += answer;
   }
   sum = (sum >> 16) + (sum & 0xffff);
   sum += (sum >> 16);
   answer = ~sum;
   return answer;
}

void UDPCore::stepPing(int i)
{
   int iResendTime = imaxwait/2;
   if (iResendTime < 400)
       iResendTime = 400;

   switch (aClCon[i].istate)
   {
      case 0:
         sendPing(i);
         aClCon[i].istate = 1;
         break;

      case 1:
         if (getCurrentTime() - tstart < iResendTime)
            break;
         // sendPing(i);
         aClCon[i].istate = 2;
         break;
   }
}

int UDPCore::sendPing(int i)
{
   int datalen = DEFDATALEN;
   u_char outpack[MAXPACKET];
   char szSenderInfo[200];

   mclear(outpack);
   mclear(szSenderInfo);

   aClCon[i].idelay = -1;

   struct icmp *icp = (struct icmp *)outpack;

   icp->icmp_type   = ICMP_ECHO;
   icp->icmp_code   = 0;
   icp->icmp_cksum  = 0;
   icp->icmp_seq    = 123+i;  /* seq and id must be reflected */
   icp->icmp_id     = getpid()+i;

   int cc = datalen + ICMP_MINLEN;
   icp->icmp_cksum = in_cksum((unsigned short *)icp,cc);

   num tstart = getCurrentTime();

   int isent = sendto(aClCon[i].sock, (char *)outpack, cc, 0,
      (struct sockaddr*)&aClCon[i].addr, (socklen_t)sizeof(struct sockaddr_in));

   aClCon[i].tsent = getCurrentTime();

   if (isent != cc)
   {
      perr("ping: send error (%d/%d) to %s\n", isent, cc, aClCon[i].ipstr);
      return -5;
   }

   if (bverbose)
     printf("ping: sent to #%u at %s\n", i, ipAsString(&aClCon[i].addr, szSenderInfo, sizeof(szSenderInfo)-10, 1));

   return 0;
}

int UDPCore::recvPing(int i, int *pDelay)
{
   int packlen = DEFDATALEN + MAXIPLEN + MAXICMPLEN;
   u_char packet[DEFDATALEN + MAXIPLEN + MAXICMPLEN + 10];
   char szSenderInfo[200];

   struct sockaddr_in from;
   int hlen = 0, end_t = 0;
   num tend = 0;

   mclear(packet);
   mclear(szSenderInfo);

   int fromlen = sizeof(sockaddr_in);
   int ret = 0;
   if ((ret = recvfrom(aClCon[i].sock, (char *)packet, packlen, 0,(struct sockaddr *)&from, (socklen_t*)&fromlen)) < 0)
      return -7+perr("ping: receive error\n");
   
   if (bverbose)
     printf("%d = recv\n", ret);

   struct ip *ip = (struct ip *)((char*)packet);
   
   hlen = sizeof(struct ip);
   
   if (ret < (hlen + ICMP_MINLEN))
      return -8+perr("ping: reply too short\n");
   
   struct icmp *icp = (struct icmp *)(packet + hlen);

   char *pszfrom = ipAsString(&from, szSenderInfo, sizeof(szSenderInfo)-10, 1);
   
   if (icp->icmp_type != ICMP_ECHOREPLY)
   {
      if (bverbose)
         printf("ping: got an invalid reply type %u from %s\n", icp->icmp_type, pszfrom);
         return 7;
   }

   if (bverbose)
      printf("ping: got an echo reply from %s\n", pszfrom);

   if (icp->icmp_seq != 123+i)
   {
      if (bverbose)
         printf("ping: received invalid sequence (%u/%u) from %s\n", icp->icmp_seq, 123+i, pszfrom);
      return 5;
   }

   if (icp->icmp_id != getpid()+i)
   {
      if (bverbose)
         printf("ping: received id %u from %s\n", icp->icmp_id, pszfrom);
      return 6;
   }

   aClCon[i].idelay = (int)(getCurrentTime() - aClCon[i].tsent);

   *pDelay = aClCon[i].idelay;

   int icopy = ret;
   if (icopy > sizeof(aClCon[i].reply))
       icopy = sizeof(aClCon[i].reply);
   memcpy(aClCon[i].reply, packet, icopy);
   aClCon[i].replylen = icopy;

   aClCon[i].istate = 3;

   iClResponses++;

   return 0;
}

#endif // USE_SFK_BASE

ExtProgram::ExtProgram( )
{
   memset(this, 0, sizeof(*this));
}

#ifdef _WIN32
int ExtProgram::winFork(char *pszCmd,
   HANDLE hChildStdOut,
   HANDLE hChildStdIn,
   HANDLE hChildStdErr
 )
{
   PROCESS_INFORMATION pi;
   STARTUPINFO si;

   ZeroMemory(&si,sizeof(STARTUPINFO));
   si.cb = sizeof(STARTUPINFO);
   si.dwFlags = STARTF_USESTDHANDLES;
   si.hStdOutput = hChildStdOut;
   si.hStdInput  = hChildStdIn;
   si.hStdError  = hChildStdErr;
   // si.wShowWindow = SW_HIDE;
   // dwFlags |= STARTF_USESHOWWINDOW;

   if (!CreateProcess(NULL,pszCmd,NULL,NULL,TRUE,
                      0, // CREATE_NEW_CONSOLE,
                      NULL,NULL,&si,&pi))
      return 9+perr("cannot run: CreateProcess failed%s",winSysError());

   clXPid = pi.hProcess;

   if (!CloseHandle(pi.hThread))
      return 9+perr("cannot run: CloseHandle failed%s",winSysError());

   return 0;
}
#else
pid_t ExtProgram::mypopen2(char *commandin[], int *infp, int *outfp)
{
    int iREAD=0,iWRITE=1;
    int p_stdin[2], p_stdout[2];
    pid_t pid;

    const char *pbinary = (const char *)commandin[0];
    char * const *pargs = (char * const *)commandin;

    if (pipe(p_stdin) != 0 || pipe(p_stdout) != 0)
        return -1;

    pid = fork();

    if (pid < 0)
    {
        return pid;
    }
    else if (pid == 0)
    {
        close(p_stdin[iWRITE]);
        dup2(p_stdin[iREAD], iREAD);

        close(p_stdout[iREAD]);
        dup2(p_stdout[iWRITE], iWRITE);

        execvp(pbinary, pargs);

        exit(1);
    }

    close(p_stdin[iREAD]);
    close(p_stdout[iWRITE]);

    if (infp == NULL)
        close(p_stdin[iWRITE]);
    else
        *infp = p_stdin[iWRITE];

    if (outfp == NULL)
        close(p_stdout[iREAD]);
    else
        *outfp = p_stdout[iREAD];

    return pid;
}
#endif

int ExtProgram::start(int iTimeout, const char *pszMask, ...)
{
   va_list argList;
   va_start(argList, pszMask);
   ::vsnprintf(szClXCmdBuf, sizeof(szClXCmdBuf)-10, pszMask, argList);
   szClXCmdBuf[sizeof(szClXCmdBuf)-10] = '\0';

   mtklog(("%s",szClXCmdBuf));

   clXTimeout = iTimeout;
   clXRunStart = getCurrentTime();

#ifdef _WIN32
   SECURITY_ATTRIBUTES sa;
   sa.nLength= sizeof(SECURITY_ATTRIBUTES);
   sa.lpSecurityDescriptor = NULL;
   sa.bInheritHandle = TRUE;

   if (!CreatePipe(&hOutputReadTmp,&hOutputWrite,&sa,0))
      return 9+perr("cannot run: CreatePipe failed%s",winSysError());

   if (!DuplicateHandle(GetCurrentProcess(),hOutputWrite,
                        GetCurrentProcess(),&hErrorWrite,0,
                        TRUE,DUPLICATE_SAME_ACCESS))
      return 9+perr("cannot run: DuplicateHandle failed%s",winSysError());

   if (!CreatePipe(&hInputRead,&hInputWriteTmp,&sa,0))
      return 9+perr("cannot run: CreatePipe failed%s",winSysError());

   if (!DuplicateHandle(GetCurrentProcess(),hOutputReadTmp,
                        GetCurrentProcess(),
                        &hOutputRead, // Address of new handle.
                        0,FALSE, // Make it uninheritable.
                        DUPLICATE_SAME_ACCESS))
      return 9+perr("cannot run: DuplicateHandle failed%s",winSysError());

   if (!DuplicateHandle(GetCurrentProcess(),hInputWriteTmp,
                        GetCurrentProcess(),
                        &hInputWrite, // Address of new handle.
                        0,FALSE, // Make it uninheritable.
                        DUPLICATE_SAME_ACCESS))
      return 9+perr("cannot run: DuplicateHandle failed%s",winSysError());

   if (!CloseHandle(hOutputReadTmp))
      return 9+perr("cannot run: CloseHandle failed%s",winSysError());
   if (!CloseHandle(hInputWriteTmp))
      return 9+perr("cannot run: CloseHandle failed%s",winSysError());

   int lRC = winFork(szClXCmdBuf, hOutputWrite, hInputRead, hErrorWrite);

   if (!CloseHandle(hOutputWrite))
      return 9+perr("cannot run: CloseHandle failed%s",winSysError());
   if (!CloseHandle(hInputRead))
      return 9+perr("cannot run: CloseHandle failed%s",winSysError());
   if (!CloseHandle(hErrorWrite))
      return 9+perr("cannot run: CloseHandle failed%s",winSysError());
#else
   mclear(szClXCmdBuf);

   int lRC = 0;
   int iparms = 0;

   char *psz = szClXCmdBuf;
   while (*psz)
   {
      aClXCmdParms[iparms++] = psz;

      while (*psz!=0 && *psz!=' ')
         psz++;

      if (!*psz)
         break;

      while (*psz==' ')
         *psz++ = '\0';
   }
   aClXCmdParms[iparms] = 0;

   clXFin = 0;
   clXPid = mypopen2(aClXCmdParms, 0, &clXFin);
#endif

   return 0;
}

int ExtProgram::readFull(uchar *pBuf, int iToRead)
{
   int isubrc=0;

   int iTotal=0;
   int iRemain=iToRead;

   while (iRemain>0)
   {
      isubrc = read(pBuf+iTotal,iRemain);

      if (isubrc >= 0) {
         iTotal += isubrc;
         iRemain -= isubrc;
         continue;
      }

      mtklog(("%d = ext.read",isubrc));

      // case -1 and other
      return 0;
   }

   return iTotal;
}

int ExtProgram::readFull(uchar **ppBuf, int *pBufSize)
{
   *ppBuf = 0;

   int iBufSize = *pBufSize;

   if (iBufSize < 100)
      return 9+perr("extprog: wrong input buffer size");

   uchar *pBuf = new uchar[iBufSize+100];
   if (!pBuf)
      return 9+perr("outofmem %d",iBufSize);

   int isubrc=0;

   int iTotal=0;
   int iRemain=0;
   while (1)
   {
      iRemain = iBufSize-iTotal;

      if (iRemain<=0) {
         // buffer overflow
         isubrc=-9;
         break;
      }

      isubrc = read(pBuf+iTotal,iRemain);

      if (isubrc >= 0) {
         iTotal += isubrc;
         continue;
      }

      // case -1 and other
      break;
   }

   // require "command completed"
   if (isubrc == -1)
   {
      // todo: adjust buffer
      *pBufSize = iTotal;
      *ppBuf    = pBuf;
      return 0;
   }

   // otherwise drop buffer
   delete [] pBuf;

   if (isubrc == -5)
      return 5;

   return 9;
}

// .
char *ExtProgram::readLine( )
{
   char *pBuf   = szClXLineBuf;
   int  nBufMax = sizeof(szClXLineBuf)-10;

   int nCursor = 0;
   int nRemain = nBufMax;
   pBuf[0] = '\0';

   while (nRemain > 10)
   {
      if (bGlblEscape)
      {
         printf("!Curl: Canceling connect due to stop request (2)\n");
         return 0;
      }

      int nRead = read((uchar*)pBuf+nCursor, 1);

      if (nRead == 0) // no input yet available
         { doSleep(20); continue; }

      if (nRead < 0) { // end of stream, or error
         mtklog(("curl.readline error: %d",nRead));
         return 0;
      }

      nCursor += nRead;
      nRemain -= nRead;
      pBuf[nCursor] = '\0';
      if (nCursor >= 2 && !strncmp(pBuf+nCursor-2, "\r\n", 2))
         break;
      if (nCursor >= 1 && !strncmp(pBuf+nCursor-1, "\n", 1))
         break;
   }

   {
      char *pcr = strchr(pBuf, '\r'); if (pcr) *pcr = '\0';
            pcr = strchr(pBuf, '\n'); if (pcr) *pcr = '\0';
   }

   // printf("< %s\n", pBuf);

   return pBuf;
}

// 0 : no data yet
// >0: no. of bytes received
// -1: command completed
// -5: timeout
// -9: other error
int ExtProgram::read(uchar *pBuf, int iMaxBuf)
{
#ifdef _WIN32
   char szTmpBuf[100];

   DWORD n1=0,nAvail=0,n3=0;
   BOOL brc = PeekNamedPipe(hOutputRead, szTmpBuf, 10, &n1, &nAvail, &n3);

   if (nAvail < 1)
   {
      mtklog(("ext.read.1 %d %d",nAvail,brc));

      if (brc == FALSE && GetLastError() == ERROR_BROKEN_PIPE) {
         clXPid = 0;
         return -1;
      }

      return 0;
   }

   DWORD nBytesRead = 0;

   if (   !ReadFile(hOutputRead,pBuf,iMaxBuf,&nBytesRead,NULL)
       || !nBytesRead
      )
   {
      mtklog(("ext.read.2"));

      if (GetLastError() == ERROR_BROKEN_PIPE) {
         clXPid = 0;
         return -1;
      }

      perr("error during run%s",winSysError());
      return -9;
   }

   // got further data from child stdout
   int iread = (int)nBytesRead;

   if (iread > 0)
   {
      return iread;
   }

   perr("no data from pipe: %d",iread);

   stop();

   return -9;
#else
   if (getCurrentTime()-clXRunStart >= clXTimeout)
   {
      printf("< command timeout, stopping.\n");
      stop();
      return -5;
   }

   fd_set fdr;
   FD_ZERO(&fdr);
   FD_SET(clXFin,&fdr);
   struct timeval tv;
   tv.tv_sec  = 0;
   tv.tv_usec = 200*1000;

   int irc = select(clXFin+1,&fdr,NULL,NULL,&tv);

   if (irc == 0)
   {
      int nstat=0;
      pid_t isubrc = waitpid(clXPid,&nstat,WNOHANG);
      if (isubrc != 0) {
         if (cs.verbose)
            printf("< command completed by pid.\n");
         return -1;
      }
   }
   else
   if (irc < 0) {
      printf("error %d\n",irc);
      stop();
      return -9;
   }
   else
   {
      if (FD_ISSET(clXFin,&fdr))
      {
         int iread = ::read(clXFin,pBuf,iMaxBuf);
         // printf("%d = ::read(%d,%d)\n",iread,clXFin,iMaxBuf);
         if (iread > 0)
         {
            return iread;
         }
         else
         {
            // if (cs.verbose)
               printf("< command completed by eod.\n");
            stop();
            return -1;
         }
      }
   }
#endif

   return 0;
}

int ExtProgram::stop()
{
#ifdef _WIN32
   if (hOutputRead && !CloseHandle(hOutputRead))
      return 9+perr("rerun: CloseHandle failed%s",winSysError());
   hOutputRead = 0;

   if (hInputWrite && !CloseHandle(hInputWrite))
      return 9+perr("rerun: CloseHandle failed%s",winSysError());
   hInputWrite = 0;

   if (clXPid != 0) {
      if (cs.verbose)
         printf("[stopping child process.]\n");
      TerminateProcess(clXPid, 0);
      clXPid = 0;
   }
#else
   if (clXRunStart == 0)
      return 0;

   clXRunStart = 0;

   // stop 1. forked proc 2. child of fork
   kill(clXPid, SIGINT);
   close(clXFin);

   // must do this otherwise forked process
   // runs endless as "defunct".
   int iwaitstat=0;
   waitpid(clXPid, &iwaitstat, 0);
#endif

   return 0;
}

static cchar *pszPicReaderTpl1 =
"<html><head><title>image reader</title>\n"
"<script type=\"text/javascript\">\n"
"var apic = new Array();\n"
"apic = [\n";

static cchar *pszPicReaderTpl2 =
"   ];\n"
"var ipic = 0;\n"
"function gopic() {\n"
"   var opic = document.getElementById(\"pic\");\n"
"   opic.src = apic[ipic];\n"
"   document.title = apic[ipic];\n"
"   scroll(0,0);\n"
"}\n"
"function doprev() { if (ipic > 0) ipic--; else ipic = apic.length-1; gopic(); }\n"
"function donext() { if (ipic < apic.length-1) ipic++; else ipic = 0; gopic(); }\n"
"function doinit() {\n"
"   gopic();\n"
"   var w     = document.body.clientWidth;\n"
"   var h     = document.body.clientHeight;\n"
"   var oarea = document.getElementById(\"aprev\");\n"
"   oarea.coords = \"0,0,\"+(w/2)+\",\"+(h*2);\n"
"   var oarea = document.getElementById(\"anext\");\n"
"   oarea.coords = \"\"+(w/2)+\",0,\"+w+\",\"+(h*2);\n"
"}\n"
"</script></head>\n"
"<body id=\"doc\" leftmargin=\"0\" topmargin=\"0\" marginwidth=\"0\" marginheight=\"0\" onload=\"javascript:doinit()\">\n"
" <center>\n"
" <img id=\"pic\" src=\"tmp.png\" ";

static cchar *pszPicReaderTpl3 =
" usemap=\"#mymap\">\n"
" <map name=\"mymap\">\n"
"  <area id=\"aprev\" shape=\"rect\" coords=\"0,0,400,400\"   title=\"previous\" onclick=\"javascript:doprev()\">\n"
"  <area id=\"anext\" shape=\"rect\" coords=\"0,400,400,800\" title=\"next\"     onclick=\"javascript:donext()\">\n"
" </map>\n"
"</body>\n"
"</html>\n"
;

static cchar *pszPicListTpl1 =
"<html><body>\n"
;

static cchar *pszPicListTpl2 =
"</body></html>\n"
;

bool ispathchr(char c) {
   if (c=='\\') return 1;
   if (c=='/') return 1;
   return 0;
}

int execToHtml(int imode, int iaspect, char *plist, char *pszOutFile)
{
   FILE *fout = fopen(pszOutFile, "w");
   if (!fout)
      return 9+perr("cannot write: %s", pszOutFile);

   if (imode==1)
      fwrite(pszPicReaderTpl1, 1, strlen(pszPicReaderTpl1), fout);
   else
      fwrite(pszPicListTpl1, 1, strlen(pszPicListTpl1), fout);

   char *pcur=plist;
   char *pmax=pcur+strlen(pcur);
   while (pcur<pmax)
   {
      char *pnext = pcur;

      while (*pnext!=0 && *pnext!='\r' && *pnext!='\n') {
         if (*pnext=='\\')
            *pnext='/';
         pnext++;
      }

      if (*pnext)
         *pnext++ = '\0';

      while (*pnext=='\r' || *pnext=='\n')
         pnext++;

      /*
         outfile: mydir\index.html
         pcur   : mydir/pic1.jpg
      */
      int ioff=0;
      for (int i=0; pcur[i] && pszOutFile[i]; i++) {
         if (ispathchr(pcur[i]) && ispathchr(pszOutFile[i]))
            ioff=i+1;
         else
         if (pcur[i] != pszOutFile[i])
            break;
      }
      pcur+=ioff; // -> pic1.jpg

      if (imode==1) {
         fprintf(fout, "   \"%s\",\n", pcur);
      } else {
         if (iaspect==1) // fitw
            fprintf(fout, "<img src=\"%s\" width=\"100%%\"><p/>\n", pcur);
         else
            fprintf(fout, "<img src=\"%s\"><p/>\n", pcur);
      }

      pcur=pnext;
   }

   if (imode==1) {
      fwrite(pszPicReaderTpl2, 1, strlen(pszPicReaderTpl2), fout);
      if (iaspect==1)
         fprintf(fout, "width=\"94%%\"");
      else
         fprintf(fout, "height=\"94%%\"");
      fwrite(pszPicReaderTpl3, 1, strlen(pszPicReaderTpl3), fout);
   } else {
      fwrite(pszPicListTpl2, 1, strlen(pszPicListTpl2), fout);
   }

   fclose(fout);

   return 0;
}

size_t myfread(uchar *pBuf, size_t nBytes, FILE *fin , num nMaxInfo=0, num nCur=0, SFKMD5 *pmd5=0);
char getYNAchar();

int getPartExtDigits(char *pszPartExt)
{
   if (strncmp(pszPartExt, ".part", 5))
      return 0;
 
   char *psz = pszPartExt + 5;
   int iDigits = 0;
   char c=0;
   while (c = *psz++)
   {
      if (!isdigit(c))
         return 0+perr("non-digit character '%c' is not allowed\n", c);
      iDigits++;
   }
 
   return iDigits;
}

int execJoin(char *pszFirstInput, char *pszDst, bool bTest, char *pszMD5Write)
{__
   char szAddInfo[200];

   int nWorkMB = 100;
   num nWorkBufSize = nWorkMB * 1000000;
   uchar *pWorkBuf = new uchar[nWorkBufSize+1000];
   if (!pWorkBuf) return 9+perr("out of memory, cannot allocate working buffer.\n");

   // NO RETURN W/O DELETE FROM HERE

   // x.part1
   strcopy(szLineBuf, pszFirstInput);
   char *pszBaseName = szLineBuf;
   char *pszPartExt  = strrchr(szLineBuf, '.');
 
   int iDigits = getPartExtDigits(pszPartExt);
   if (!pszPartExt || !iDigits) {
      delete [] pWorkBuf;
      return 9+perr("expecting input filename ending like .part1, .part001 etc.\n");
   }

   // check if first input exists
   if (!fileExists(szLineBuf))
      return 9+perr("first input file not found: %s\n", szLineBuf);

   // cut ".part1" in szLineBuf
   *pszPartExt = '\0';

   // and use this as output filename
   if (!pszDst)
      pszDst = szLineBuf;

   FILE *fout = 0;

   if (!bTest)
   {
      if (fileExists(pszDst) && !cs.force && !cs.yes)
         while (1) {
            printf("%s output file exists, overwrite? (y/n) ",pszDst);
            fflush(stdout);
            char nReply = getYNAchar();
            if (nReply == 'y') break;
            if (nReply == 'n') { delete [] pWorkBuf; return 5; }
            // printf("\n");
         }
 
      fout = fopen(pszDst, "wb");
      if (!fout) {
         delete [] pWorkBuf;
         return 9+perr("cannot write output file: %s\n",pszDst);
      }
   }

   num ntotal = 0;
   SFKMD5 md5;

   int nin = 1;
   bool bbail = 0;
   while (!bbail)
   {
      sprintf(szLineBuf2, "%s.part%0*d", pszBaseName, iDigits, nin);
      char *pszSrc = szLineBuf2;
 
      // internal check: first part's name must be the same as input
      if ((nin == 1) && strcmp(pszSrc, pszFirstInput))
         perr("int. error while building name: %s\n", pszSrc);

      FILE *fpart = fopen(pszSrc, "rb");
      if (!fpart)
         break;   // (probably) all done

      if (cs.debug)
         info.print("open.read: %s\n", pszSrc);

      nin++;

      while (!bbail)
      {
         num nTotalMB = ntotal / 1000000;

         if (pszMD5Write)
         {
            // printf("verifying part %d, %s mb done [Esc to skip] \r", nin-1, numtoa(nTotalMB));
            // fflush(stdout);
            sprintf(szAddInfo, "%s mb [Esc to skip]", numtoa(nTotalMB));
            info.setStatus("verfy", pszSrc, szAddInfo);
            if (userInterrupt(1)) {
               info.print("verify skipped.\n");
               fclose(fpart);
               bbail = 1;
               break;
            }
         }
         else
         {
            // printf("reading part %d, %s mb done \r", nin-1, numtoa(nTotalMB));
            // fflush(stdout);
            sprintf(szAddInfo, "%s mb", numtoa(nTotalMB));
            info.setStatus("read ", pszSrc, szAddInfo);
         }

         int nread = myfread(pWorkBuf, nWorkBufSize, fpart);

         if (cs.debug)
            info.print("read.blck: %d maxbuf=%d\n", nread, (int)nWorkBufSize);

         if (nread <= 0)
            break; // EOD

         if (!bTest)
         {
            int nwrite = myfwrite(pWorkBuf, nread, fout);

            if (cs.debug)
               info.print("writ.blck: %d\n", nwrite);

            if (nwrite != nread) {
               delete [] pWorkBuf;
               fclose(fout); fclose(fpart);
               remove(pszDst); // cleanup incomplete output
               return 9+esys("fwrite", "failed to write %s   \n", pszDst);
            }
         }

         md5.update(pWorkBuf, nread);

         ntotal += nread;
      }

      if (cs.debug)
         info.print("clos.read: %s totalDone=%d\n", pszSrc, (int)ntotal);

      fclose(fpart);
   }
 
   if (!bTest)
      fclose(fout);

   delete [] pWorkBuf;

   // NO RETURN W/O DELETE UNTIL HERE

   info.clear();

   if (bbail)
      return 0;

   if (bTest) {
      if (!pszMD5Write)
         printf("tested join of %d files, %s total bytes.\n", nin-1, numtoa(ntotal));
   } else {
      printf("%s created from %d files, %s total bytes.\n", pszDst, nin-1, numtoa(ntotal));
   }

   char szMD5Read[100];

   uchar *pmd5 = md5.digest();
   for (int i=0; i<16; i++)
      sprintf(&szMD5Read[i*2], "%02x", pmd5[i]);
   printf("md5 = %s   %s ", szMD5Read, pszMD5Write ? "[verify]" : "");

   if (pszMD5Write) {
      if (strcmp(pszMD5Write, szMD5Read)) {
         printf("\n");
         return 9+perr("checksum mismatch - re-read of output files failed.\n");
      }
      else
         printf("- OK\n");
   }
   else
      printf("\n");

   return 0;
}

#ifndef USE_SFK_BASE

void ab8ToNum(uchar *pin, num &rn1) {
    num n1 =  (num)(*(pin+0)) & 0xFFUL;
    n1 = (n1 << 8) | ((num)(*(pin+1)) & 0xFFUL);
    n1 = (n1 << 8) | ((num)(*(pin+2)) & 0xFFUL);
    n1 = (n1 << 8) | ((num)(*(pin+3)) & 0xFFUL);
    n1 = (n1 << 8) | ((num)(*(pin+4)) & 0xFFUL);
    n1 = (n1 << 8) | ((num)(*(pin+5)) & 0xFFUL);
    n1 = (n1 << 8) | ((num)(*(pin+6)) & 0xFFUL);
    n1 = (n1 << 8) | ((num)(*(pin+7)) & 0xFFUL);
    rn1 = n1;
}

uint ab4toulong(uchar *pin) {
    uint n1 = (uint)(*(pin+0)) & 0xFFUL;
    n1 = (n1 << 8) | ((uint)(*(pin+1)) & 0xFFUL);
    n1 = (n1 << 8) | ((uint)(*(pin+2)) & 0xFFUL);
    n1 = (n1 << 8) | ((uint)(*(pin+3)) & 0xFFUL);
    return n1;
}

void ab16ToNum(uchar *pin, num &rn1, num &rn2) {
    ab8ToNum(pin+0, rn1);
    ab8ToNum(pin+8, rn2);
}

void numToAb8(num n1, uchar *pout) {
   pout[7]  = (uchar)n1;
   n1 = (n1 >> 8); pout[6] = (uchar)n1;
   n1 = (n1 >> 8); pout[5] = (uchar)n1;
   n1 = (n1 >> 8); pout[4] = (uchar)n1;
   n1 = (n1 >> 8); pout[3] = (uchar)n1;
   n1 = (n1 >> 8); pout[2] = (uchar)n1;
   n1 = (n1 >> 8); pout[1] = (uchar)n1;
   n1 = (n1 >> 8); pout[0] = (uchar)n1;
}

void ulongtoab4(uint n1, uchar *pout) {
   pout[3]  = (uchar)n1;
   n1 = (n1 >> 8); pout[2] = (uchar)n1;
   n1 = (n1 >> 8); pout[1] = (uchar)n1;
   n1 = (n1 >> 8); pout[0] = (uchar)n1;
}

void numToAb16(num n1, num n2, uchar *pout) {
   numToAb8(n1, pout+0);
   numToAb8(n2, pout+8);
}

char *FileMetaDB::pszClFileDBHead = (char*)"SFKSIG10";

FileMetaDB filedb;

FileMetaDB::FileMetaDB()
{
   pszClDBPath    = 0;
   pszClDBFile    = 0;
   pszClLineBuf   = 0;
   pszClMetaDir   = 0;
   nClMode        = 0;
   nClVerified    = 0;
   nClVerMissing  = 0;
   nClVerFailed   = 0;
}

int FileMetaDB::setMetaDir(char *psz)
{
   if (pszClMetaDir) delete [] pszClMetaDir;
   pszClMetaDir = strdup(psz);
   return 0;
}

bool FileMetaDB::isSignatureFile(char *pszBase)
{
   if (!pszClLineBuf)
      if (!(pszClLineBuf = new char[MAX_LINE_LEN+100]))
         { perr("outofmem.1\n"); return 0; }

   bool bChecked = 0;

   int i=0;
   for (i=1; i<=3 && !bChecked; i++)
   {
      SFKMD5 md5; // re-init per loop

      sprintf(pszClLineBuf, "%s-%02d.dat", pszBase, i);

      FILE *fin = fopen(pszClLineBuf, "rb");
      if (!fin) return 0;
 
      uchar abin[20];
      char *pszHead = pszClFileDBHead;
      int nread = fread(abin, 1, 8, fin);
      if (nread < 8) { fclose(fin); return 1; } // EOD
      abin[8] = '\0';
      if (!strcmp((char*)abin, pszHead))
         bChecked = 1;
 
      fclose(fin);
   }

   return bChecked;
}

int FileMetaDB::indexOf(char *pszInFile)
{
   int nEntries = aUnixTime.numberOfEntries();
   for (int i=0; i<nEntries; i++)
   {
      char *pszRefFile = aPath.getEntry(i, __LINE__);
      if (!strcmp(pszInFile, pszRefFile))
      {
         return i;
      }
   }
   return -1;
}

int FileMetaDB::loadDB(char *pszBase, bool bVerbose)
{
   if (pszClDBPath) { delete [] pszClDBPath; pszClDBPath=0; }
   pszClDBPath = strdup(pszBase);

   if (pszClDBFile) { delete [] pszClDBFile; pszClDBFile=0; }
   pszClDBFile = new char[strlen(pszClDBPath)+100];

   bool bChecked = 0;
   int nSigRes  = 0;

   // pass 1: check several sign files until a functional one is found
   int i=0;
   for (i=1; i<=3 && !bChecked; i++)
   {
      SFKMD5 md5; // re-init per loop

      sprintf(pszClDBFile, "%s-%02d.dat", pszClDBPath, i);

      // if (i > 1)
      //   pwarn("retrying on signature db: %s\n", pszClDBFile);

      if (fileExists(pszClDBFile))
      {
         // printf("load %s\n", pszClDBFile);

         FILE *fin = fopen(pszClDBFile, "rb");
         if (!fin)
            nSigRes = 3;
         else
         if (!loadHeader(fin, &md5))
         for (int nrec=1; ;nrec++)
         {
            int nrc = loadRecord(fin, &md5, 1); // uses szLineBuf
            // printf("   rec %d loaded, rc %d\n", nrec, nrc);
            if (nrc == 1)
               break; // EOD
            if (bChecked) {
               perr("unexpected record data at end of %s\n", pszClDBFile);
               break;
            }
            if (nrc == 2) {
               if (!(nSigRes = loadCheckEpilogue(fin, &md5)))
                  bChecked = 1;
            }
            if (nrc > 2) {
               perr("error while reading %s: wrong content format (%d)\n", pszClDBFile, nrc);
               break;
            }
         }

         fclose(fin);
      } else {
         nSigRes = 3;
      }

      if (!bChecked) {
         if (nSigRes == 3) {
            if (bVerbose)
               printf("signature db not found: %s\n", pszClDBFile);
         }
         else
         if (i < 3) {
            if (nSigRes == 2)
               pwarn("signature db modified: %s - retrying on copy\n", pszClDBFile);
            else
               pwarn("invalid signature db: %s - retrying on copy\n", pszClDBFile);
         } else {
            perr("all signature databases unreadable or modified.\n", pszClDBFile);
         }
      }
   }

   // pass 2: load the first functional file
   if (!bChecked) {
      return 9; // +perr("cannot find a valid signature database.");
   }
   else
   {
      // pszClDBFile is still the valid name
      FILE *fin = fopen(pszClDBFile, "rb");
      if (!fin) return 9+perr("cannot read: %s\n", pszClDBFile);

      SFKMD5 md5;

      if (!loadHeader(fin, &md5))
      while (1) {
         int nrc = loadRecord(fin, &md5, 0); // uses szLineBuf
         if (nrc == 1)
            break; // EOD
         if (nrc == 2) {
            if (loadCheckEpilogue(fin, &md5))
               { fclose(fin); return 9+perr("internal #11571940"); }
         }
         if (nrc > 2) {
            perr("error while reading %s: wrong content format\n", pszClDBFile);
            break;
         }
      }

      fclose(fin);
   }

   return 0;
}

int FileMetaDB::openUpdate(char *pszBase)
{__
   loadDB(pszBase, 0);
   // ignore rc

   nClMode = 2;

   return 0;
}

int FileMetaDB::openRead(char *pszBase, bool bVerbose)
{__
   if (loadDB(pszBase, bVerbose))
      return 9;

   nClMode = 1;

   return 0;
}

int FileMetaDB::verifyFile(char *pszName, char *pszShadow, bool bSilentAttribs)
{
   char *relName(char *pszRoot, char *pszAbs);
   char *pszRelName = pszName;

   if (pszGlblCopySrc)
      pszRelName = relName(pszGlblCopySrc, pszName);

   int nind = indexOf(pszRelName);
   if (nind < 0) {
      nClVerMissing++;
      return 8;   // not found
   }

   // get archived metadata
   num nUnixTime2  = aUnixTime.getEntry(nind, __LINE__);
   // num nWinTime2   = aWinTime.getEntry(nind, __LINE__);
   num nContSumLo2 = aContSumLo.getEntry(nind, __LINE__);
   num nContSumHi2 = aContSumHi.getEntry(nind, __LINE__);

   // build current metadata
   FileStat ofs;
   ofs.readFrom(pszName, 0, bSilentAttribs);
   num nUnixTime = ofs.getUnixTime();
   // num nWinTime  = ofs.getWinTime();
   num ncontlo, nconthi;
   uchar abContSum[20];
   if (getFileMD5(pszName, abContSum)) {
      perr("no such file: %s - cannot read checksum\n", pszName);
      return 9;
   }
   ab16ToNum(abContSum, ncontlo, nconthi);

   // let's expect that time is the same, all that matters is
   // if the content was tampered during transport:
   if (ncontlo != nContSumLo2 || nconthi != nContSumHi2)
   {
      nClVerFailed++;

      if (pszShadow && fileExists(pszShadow))
      {
         // try fallback to shadow file
         if (getFileMD5(pszShadow, abContSum)) {
            perr("no such file: %s - cannot read shadow file\n", pszShadow);
            return 9;
         }
         ab16ToNum(abContSum, ncontlo, nconthi);
         if (ncontlo == nContSumLo2 && nconthi == nContSumHi2)
            return 5;   // fallback to shadow is possible
      }

      return 9;
   }

   nClVerified++;

   if (nUnixTime != nUnixTime2)  return 1; // informal

   return 0;
}

int FileMetaDB::verifyFile(int nind, bool bCleanup)
{
   uint currentKBPerSec();

   // if anything fails with this record, skip it on cleanup
   aFlags.updateEntry(0, nind); // no save by default

   // get archived metadata
   char *pszRelName = aPath.getEntry(nind, __LINE__);
   if (!pszRelName) return 9+perr("unexpected filedb entry at record %d\n", nind);

   num nUnixTime2  = aUnixTime.getEntry(nind, __LINE__);
   // num nWinTime2   = aWinTime.getEntry(nind, __LINE__);
   num nContSumLo2 = aContSumLo.getEntry(nind, __LINE__);
   num nContSumHi2 = aContSumHi.getEntry(nind, __LINE__);

   // create absolute filename
   if (!pszGlblCopySrc) return 9+perr("internal #0605071204");
   joinPath(szRefNameBuf, sizeof(szRefNameBuf)-10, pszGlblCopySrc, pszRelName);
   char *pszName = szRefNameBuf;

   joinShadowPath(szRefNameBuf2, sizeof(szRefNameBuf2)-10, pszGlblCopySrc, pszRelName);
   char *pszShadow = szRefNameBuf2;

   // show detailed info
   char szAddInfo[200];
   int nVerOK     = filedb.numberOfVerifies();
   int nVerFailed = filedb.numberOfVerFailed();
   if (nVerFailed > 0)
      sprintf(szAddInfo, "%u files ok, %d failed, %u mb %u kbs", nVerOK, nVerFailed, (uint)(nGlblBytes/1000000UL), currentKBPerSec());
   else
      sprintf(szAddInfo, "%u files %u mb %u kbs", nVerOK, (uint)(nGlblBytes/1000000UL), currentKBPerSec());
   info.setProgress(numberOfFiles(), nind, "files");
   info.setStatus("verfy", pszName, szAddInfo, eKeepProg);

   // build current metadata
   FileStat ofs;
   if (ofs.readFrom(pszName)) {
      nClVerMissing++;
      return 9+perr("file not found: %s\n", pszName);
   }
   num nUnixTime = ofs.getUnixTime();
   num nWinTime  = ofs.getWinTime();
   num ncontlo, nconthi;
   uchar abContSum[20];
   if (getFileMD5(pszName, abContSum)) {
      perr("no such file: %s - cannot read checksum\n", pszName);
      nClVerMissing++;
      return 9;
   }
   ab16ToNum(abContSum, ncontlo, nconthi);

   // check if the content was tampered during transport:
   if (ncontlo != nContSumLo2 || nconthi != nContSumHi2)
   {
      // primary file content corrupted
      nClVerFailed++;

      if (bCleanup) {
         setTextColor(nGlblErrColor);
         oprintf("DEL: %s - was modified, please resync\n", pszName);
         if (remove(pszName)) {
            if (setWriteEnabled(pszName))
               perr("cannot delete: %s\n", pszName);
            else
            if (remove(pszName))
               perr("cannot delete: %s\n", pszName);
         }
         setTextColor(-1);
         return 9;
      }

      if (pszShadow && fileExists(pszShadow))
      {
         // try fallback to shadow file
         if (getFileMD5(pszShadow, abContSum)) {
            perr("content modified  : %s\n", pszName);
            perr("cannot read shadow: %s\n", pszShadow);
            return 9;
         }

         ab16ToNum(abContSum, ncontlo, nconthi);

         if (ncontlo == nContSumLo2 && nconthi == nContSumHi2)
         {
            cs.shadowFallbacks++;
            pwarn("content modified: %s\n", pszName);
            pwarn("shadow file ok  : %s\n", pszShadow);
            return 5;   // fallback to shadow is possible
         }

         perr("content modified: %s\n", pszName);
         perr("shadow modified : %s\n", pszShadow);

         return 9;
      }

      perr("content modified: %s\n", pszName);

      return 9;
   }

   // produce only notic if time mismatches:
   if (nUnixTime != nUnixTime2)
   {
      num nTimeDiff = nUnixTime - nUnixTime2;
      if (nTimeDiff < -5 || nTimeDiff > 5)
      {
         pinf("time difference (%s sec), content ok: %s\n", numtoa(nTimeDiff), pszName);
         // in case cleanup is done: update with current times
         aUnixTime.updateEntry(nUnixTime, nind);
         if (nWinTime != 0)
            aWinTime.updateEntry(nWinTime, nind);
      }
      // else ignore: up to 5 sec time diff happens between file systems
   }

   nClVerified++;

   // record confirmed, keep it in case of cleanup.
   aFlags.updateEntry(1, nind);

   return 0;
}

int FileMetaDB::updateFile(char *pszName, uchar *pmd5cont, bool bJustKeep)
{
   // printf("updateFile %s, %02X%02X%02X%02X\n", pszName, *(pmd5cont+0),*(pmd5cont+1),*(pmd5cont+2),*(pmd5cont+3));

   char *relName(char *pszRoot, char *pszAbs);

   // printf("updatefile: %s\n", pszName);

   FileStat ofs;
   ofs.readFrom(pszName);

   num nUnixTime = ofs.getUnixTime();
   num nWinTime  = ofs.getWinTime();

   // strip x:\the\foo\bar.txt to the\foo\bar.txt
   char *pszRelName = relName(pszGlblCopySrc, pszName);

   int nind = indexOf(pszRelName);
   if (nind >= 0)
   {
      // we have this filename in the db.
      if (bJustKeep) {
         // unconditionally keep the entry of a non-synced file
         // e.g. on copy: target is newer than source (no copy)
         // if (aUnixTime.getEntry(nind, __LINE__) == nUnixTime) {
         aFlags.updateEntry(1, nind); // store file entry again
         return 0;
         // }
      }

      // update metadata:
      aUnixTime.updateEntry(nUnixTime, nind);
      aWinTime.updateEntry(nWinTime, nind);

      // update content checksum
      num ncontlo, nconthi;
      uchar abContSum[20];
      // take supplied content md5, or build now
      if (pmd5cont != 0)
         memcpy(abContSum, pmd5cont, 16);
      else
         if (getFileMD5(pszName, abContSum)) return 9;
      ab16ToNum(abContSum, ncontlo, nconthi);
      aContSumLo.updateEntry(ncontlo, nind);
      aContSumHi.updateEntry(nconthi, nind);

      // mark this record as updated, for save:
      aFlags.updateEntry(2, nind);
   }
   else
   {
      // not yet in the db
      if (aUnixTime.addEntry(nUnixTime))  return 9;
      if (aWinTime.addEntry(nWinTime))    return 9;

      // add content checksum
      num ncontlo, nconthi;
      uchar abContSum[20];
      // take supplied content md5, or build now
      if (pmd5cont != 0)
         memcpy(abContSum, pmd5cont, 16);
      else
         if (getFileMD5(pszName, abContSum)) return 9;
      ab16ToNum(abContSum, ncontlo, nconthi);
      if (aContSumLo.addEntry(ncontlo))   return 9;
      if (aContSumHi.addEntry(nconthi))   return 9;

      if (aFlags.addEntry(2)) return 9;

      // add also path for easier verify syntax
      if (aPath.addEntry(pszRelName)) return 9;
   }

   return 0;
}

int FileMetaDB::removeFile(char *pszName, bool bPrefixLF)
{
   char *relName(char *pszRoot, char *pszAbs);

   // strip x:\the\foo\bar.txt to the\foo\bar.txt
   char *pszRelName = relName(pszGlblCopySrc, pszName);

   int nind = indexOf(pszRelName);
   if (nind >= 0)
   {
      // mark this record as deleted, for save:
      aFlags.updateEntry(0, nind);
   }
   else
   {
      if (bPrefixLF) printf("\n");
      pwarn("cannot remove filename from metadb: %s\n", pszName);
   }

   return 0;
}

int FileMetaDB::checkFile(char *pszName)
{
   FileStat ofs;
   if (ofs.readFrom(pszName)) {
      perr("cannot read file infos: %s\n", pszName);
      return 5;
   }

   cs.files++;

   num nUnixTime = ofs.getUnixTime();
   // num nWinTime  = ofs.getWinTime();

   int nind = indexOf(pszName);
   if (nind >= 0)
   {
      // we have this filename in the db
      num nUnixTime2  = aUnixTime.getEntry(nind, __LINE__);
      // num nWinTime2   = aUnixTime.getEntry(nind, __LINE__);
      num nContSumLo2 = aContSumLo.getEntry(nind, __LINE__);
      num nContSumHi2 = aContSumHi.getEntry(nind, __LINE__);

      if (nUnixTime2 != nUnixTime) {
         printf("time: %s\n", pszName);
         return 0;
      }

      num ncontlo, nconthi;
      uchar abContSum[20];
      if (getFileMD5(pszName, abContSum)) return 9;
      ab16ToNum(abContSum, ncontlo, nconthi);

      if (ncontlo != nContSumLo2 || nconthi != nContSumHi2) {
         printf("cont: %s\n", pszName);
         return 0;
      }
   }

   return 0;
}

int FileMetaDB::updateDir(char *pszName)
{
    return 0;
}

int FileMetaDB::writeRecord(FILE *fout, int nIndex, SFKMD5 *pmd5, bool bIsLastRec)
{
   uchar about1[20];

   // since SFKSIG10, first field is uint nmetalen.
   uint nmetalen = 16+16+2;
   ulongtoab4(nmetalen, about1);
   if (myfwrite(about1, 4, fout, 0,0,pmd5) != 4) return 9;

   // - - - meta data block: - - -

   // file times
   numToAb16(aUnixTime.getEntry(nIndex, __LINE__),
             aWinTime.getEntry(nIndex, __LINE__) ,
             about1);
   if (myfwrite(about1, 16, fout, 0,0,pmd5) != 16) return 9;

   // content checksum
   numToAb16(aContSumLo.getEntry(nIndex, __LINE__),
             aContSumHi.getEntry(nIndex, __LINE__),
             about1);
   if (myfwrite(about1, 16, fout, 0,0,pmd5) != 16) return 9;

   // update flags
   uchar abFlags[2];
   uint nflags = aFlags.getEntry(nIndex, __LINE__);
   if (bIsLastRec)
      nflags |= 4;
   abFlags[0] = (uchar)(nflags >> 8);
   abFlags[1] = (uchar)(nflags     );
   if (myfwrite(abFlags, 2, fout, 0,0,pmd5) != 2) return 9;

   // - - - end meta data block - - -

   uchar abPathLen[2];
   memset(abPathLen, 0, sizeof(abPathLen));
   if (aPath.isSet(nIndex)) {
      char *psz  = aPath.getEntry(nIndex, __LINE__);
      // printf("WRITE %d %s\n", nIndex, psz);
      uint nlen = strlen(psz);
      abPathLen[0] = (uchar)(nlen >> 8);
      abPathLen[1] = (uchar)(nlen     );
      if (myfwrite(abPathLen,    2, fout, 0,0,pmd5) !=    2) return 9;
      if (myfwrite((uchar*)psz    , nlen, fout, 0,0,pmd5) != nlen) return 9;
   } else {
      // printf("WRITE %d [noname]\n", nIndex);
      if (myfwrite(abPathLen,    2, fout, 0,0,pmd5) != 2) return 9;
   }

   // printf(" saved record, %d %d\n", nflags, bIsLastRec);

   return 0;
}

int FileMetaDB::loadHeader(FILE *fin, SFKMD5 *pmd5)
{
   uchar abin[20];
   char *pszHead = pszClFileDBHead;
   int nread = myfread(abin, 8, fin, 0,0,pmd5);
   if (nread < 8) { fclose(fin); return 1; } // EOD
   abin[8] = '\0';
   if (strcmp((char*)abin, pszHead))
      return 9+perr("wrong signature db version: \"%s\"\n", abin);

   return 0;
}

int FileMetaDB::loadCheckEpilogue(FILE *fin, SFKMD5 *pmd5)
{
   uchar abin[20];

   int nread = myfread(abin, 16, fin, 0,0,0);
   if (nread < 16) {
      return 1; // EOD
   }

   uchar *pdig = pmd5->digest();
   if (memcmp(abin, pdig, 16)) {
      return 2; // mismatch
   }

   return 0;
}

// uses szLineBuf
int FileMetaDB::loadRecord(FILE *fin, SFKMD5 *pmd5, bool bSim)
{
   memset(abClRecBuf, 0, sizeof(abClRecBuf));
   uchar *abin = abClRecBuf;

   int nread = myfread(abin, 4, fin, 0,0,pmd5);
   if (nread < 4) return 1; // EOD, read after epilogue
   uint nmetalen = ab4toulong(abin);

   if (nmetalen > sizeof(abClRecBuf)-10)
      return 9+perr("metadb: header block too large (%u), cannot load.\n",nmetalen);

   if (nmetalen < 16+16+2)
      return 9+perr("metadb: header block too small (%u), cannot load.\n",nmetalen);

   // - - - meta data block - - -

   nread = myfread(abin, nmetalen, fin, 0,0,pmd5);
   if (nread < (int)nmetalen) return 10; // unexpected

   num n1, n2;
   ab16ToNum(abin+0, n1, n2);
   if (!bSim) {
      if (aUnixTime.addEntry(n1)) return 9;
      if (aWinTime.addEntry(n2))  return 9;
   }

   ab16ToNum(abin+16, n1, n2);
   if (!bSim) {
      if (aContSumLo.addEntry(n1)) return 9;
      if (aContSumHi.addEntry(n2)) return 9;
   }

   // read flag value
   uchar abFlags[2];
   memcpy(abFlags, abin+32, 2);
   uint nflags = (((uint)abFlags[0]) << 8) | ((uint)abFlags[1]);
   if (!bSim) {
      // filter out flag "4" (last record marker):
      if (aFlags.addEntry(nflags & (255UL ^ 4))) return 9;
   }

   // - - - end of meta data block - - -

   // read filename
   uchar abPathLen[2];
   nread = myfread(abPathLen, 2, fin, 0,0,pmd5);
   if (nread < 2) return 12; // unexpected
   uint nlen = (((uint)abPathLen[0]) << 8) | ((uint)abPathLen[1]);
   if (nlen > 0) {
      if (nlen > MAX_LINE_LEN-1) return 13;
      nread = myfread((uchar*)szLineBuf, nlen, fin, 0,0,pmd5);
      if (nread < (int)nlen) return 14;
      szLineBuf[nlen] = '\0';
      if (!bSim) {
         aPath.addEntry(szLineBuf);
      }
      // printf("LOADED NAME %s\n", szLineBuf);
   } else {
      // printf("LOADED NO NAME\n");
   }

   if (nflags & 4) {
      // printf("metadb load: lastrec found\n");
      return 2; // last data record read, md5 follows
   }

   return 0;
}

int FileMetaDB::writeEpilogue(FILE *fout, SFKMD5 *pmd5)
{
   uchar *pdig = pmd5->digest();
   if (myfwrite(pdig, 16, fout, 0,0,0) != 16) return 9;
   return 0;
}

int FileMetaDB::save(int &rnSignsWritten)
{__
   if (!pszClDBPath) return 9+perr("internal #11571945");

   if (pszClDBFile) { delete [] pszClDBFile; pszClDBFile=0; }
   pszClDBFile = new char[strlen(pszClDBPath)+100];

   int nCopies = 3;
   int nCopied = 0;

   // write signature db 3 times
   for (int i=1; i<=nCopies; i++)
   {
      sprintf(pszClDBFile, "%s-%02d.dat", pszClDBPath, i);
 
      SFKMD5 md5;
 
      // printf("saveto %s\n", pszClDBFile);
      FILE *fout = fopen(pszClDBFile, "wb");
      if (!fout) {
         perr("cannot write file meta db: %s\n", pszClDBFile);
         continue; // but retry with next
      }
 
      char *pszHead = pszClFileDBHead;
      if (myfwrite((uchar*)pszHead, 8, fout, 0,0,&md5) != 8)
         {  fclose(fout); continue; }
 
      bool bFailed = 0;
      bool bDoneLastRec = 0;

      int nEntries = aUnixTime.numberOfEntries();

      // identify last valid record to be saved
      int ilastval = 0;
      for (int k=0; k<nEntries; k++) {
         if (aFlags.getEntry(k, __LINE__) >= 1)
            ilastval = k;
      }

      int nWritten = 0;
      for (int i=0; i<nEntries; i++)
      {
         // write only added or updated records
         if (aFlags.getEntry(i, __LINE__) >= 1) {
            bool bIsLastRec = (i == ilastval);
            // printf("   write rec %d last=%d\n",i,bIsLastRec);
            if (writeRecord(fout, i, &md5, bIsLastRec)) {
               perr("error while writing file meta db: %s\n", pszClDBFile);
               bFailed = 1;
               break;
            } else {
               nWritten++;
               if (bIsLastRec)
                  bDoneLastRec = 1;
            }
         }
      }

      if (!bDoneLastRec)
         perr("internal: no lastrec saved %d %d\n",ilastval,nEntries);
 
      if (!bFailed)
         writeEpilogue(fout, &md5);
 
      fclose(fout);

      if (!bFailed) {
         rnSignsWritten = nWritten;
         nCopied++;
      }
   }

   if (nCopied <= 0)
      return 9+perr("failed to write any metadb copy.\n");

   if (nCopied < nCopies)
      return 5+perr("%d metadb copies written, %d failed.\n", nCopied, (nCopies-nCopied));

   return 0;
}

void FileMetaDB::reset( )
{
   if (pszClDBPath) {
      delete [] pszClDBPath;
      pszClDBPath = 0;
   }
   if (pszClDBFile) {
      delete [] pszClDBFile;
      pszClDBFile = 0;
   }
   if (pszClLineBuf) {
      delete [] pszClLineBuf;
      pszClLineBuf = 0;
   }
   if (pszClMetaDir) {
      delete [] pszClMetaDir;
      pszClMetaDir = 0;
   }
   aUnixTime.resetEntries();
   aWinTime.resetEntries();
   aContSumLo.resetEntries();
   aContSumHi.resetEntries();
   aFlags.resetEntries();
   aPath.resetEntries();
}

FileVerifier glblVerifier;

FileVerifier::FileVerifier()
{
   nClMatched = 0;
   nClFailed  = 0;
}

void FileVerifier::reset()
{
   aClSumHi.resetEntries();
   aClSumLo.resetEntries();
   aClDst.resetEntries();
}

int FileVerifier::remember(char *pszDst, num nsumhi, num nsumlo)
{
   if (aClSumHi.addEntry(nsumhi)) return 9;
   if (aClSumLo.addEntry(nsumlo)) return 9;
   if (aClDst.addEntry(pszDst))   return 9;
   return 0;
}

int FileVerifier::verify()
{
   char szAddInfo[200];

   int lRC = 0;

   int nFiles = totalFiles();
   for (int i=0; i<nFiles; i++)
   {
      if (userInterrupt(1, 1)) // silent, wait for release
      {
         info.print("verify stopped by user.\n");
         bGlblEscape = 0;
         return 1;
      }

      // get source file sum
      num nsrchi = aClSumHi.getEntry(i, __LINE__);
      num nsrclo = aClSumLo.getEntry(i, __LINE__);

      // build destination sum
      char *pszDst = aClDst.getEntry(i, __LINE__);
      info.setProgress(nFiles, i, "files");
      sprintf(szAddInfo, "file %d/%d", i+1, nFiles);
      info.setStatus("verfy", pszDst, szAddInfo);
      uchar abMD5Dst[20];
      if (getFileMD5NoCache(pszDst, abMD5Dst, 1)) // silent
      {
         if (userInterrupt(1, 1)) {
            pinf("[nopre] verify skipped.\n");
            lRC = 1;
            break;
         }
         perr("unable to read for verify: %s   \n", pszDst);
         lRC = 5;
         nClFailed++;
         continue;
      }
      uchar *pmd5dst = abMD5Dst;
      num ndstlo=0, ndsthi=0;
      for (int i=0,b=64-8; i<8; i++) {
         ndsthi = ndsthi | (((num)pmd5dst[0+i]&0xFF) << b);
         ndstlo = ndstlo | (((num)pmd5dst[8+i]&0xFF) << b);
         b -= 8;
      }

      // compare both
      if (nsrchi!=ndsthi || nsrclo!=ndstlo) {
         perr("verify failed, file differs: %s   \n", pszDst);
         nClFailed++;
         lRC = 6;
      } else {
         // info.setStatus("vryfd", pszDst); // , 0, eNoCycle);
         // info.printLine(1<<2); // w/o progress
         nClMatched++;
      }
   }

   return lRC;
}

void printCopyCompleted(char *pszName, uint nflags)
{
   info.clear();
   if (cs.quiet >= 2)
      return;
   cchar *pszpre = "";
   if (nflags & 8) {
      printx("<warn>##<def>"); pszpre=" ";
   }
   switch (nflags & 3) {
      case 1 : printx("<prefix>]<def>"); pszpre=" "; break;
      case 3 : printx("<warn>]<def>");   pszpre=" "; break;
   }
   if (nflags & 4) {
      printx("<prefix>><def>"); pszpre=" ";
   }
   oprintf("%s%s", pszpre, pszName);
   if (nflags & 8)
      printx(" <warn>[sync'ing older file]<def>");
   printf("\n");
}

CopyCache glblCopyCache;

CopyCache::CopyCache()
{
}

void CopyCache::setBuf(uchar *pBuf, num nBufSize)
{
   pClBuf      = pBuf;
   nClBufSize  = nBufSize;
   nClUsed     = 0;
}

int CopyCache::process(char *pszSrcFile, char *pszDstFile, char *pszShDst, uint nflags)
{
   if (!pszShDst) pszShDst = str("");

   // may another source file fit into the cache?
   FileStat ofsrc;
   if (ofsrc.readFrom(pszSrcFile))
      return 9+perr("unable to read: %s\n", pszSrcFile);
   num nSrcSize = ofsrc.getSize();
   num nRemain  = nClBufSize - nClUsed;
   if (nRemain < 0) return 9+perr("internal 612112001\n");

   // if not, write all cache contents
   if (nSrcSize + 1500 > nRemain) {
      int lRes = flush();
      if (lRes >= 9)
         return lRes;
      setEmpty(); // in case flush was interrupted
   }
 
   if (nSrcSize + 1500 > nClBufSize)
      return 1;   // file too large to fit into cache, copy directly
 
   // cache is ready to accept file
   num nUsedSave = nClUsed;

   // 1. filenames
   if (putBlock((uchar*)pszSrcFile, strlen(pszSrcFile)+1)) return 9+perr("internal 612112002\n");
   if (putBlock((uchar*)pszDstFile, strlen(pszDstFile)+1)) return 9+perr("internal 612112009\n");
   if (putBlock((uchar*)pszShDst  , strlen(pszShDst  )+1)) return 9+perr("internal 612112029\n");
 
   // 2. meta data: filestat and flags
   int nMetaSize = 0;
   uchar *pMeta = ofsrc.marshal(nMetaSize);
   if (putBlock(pMeta, nMetaSize)) return 9+perr("internal 612112006\n");

   uchar abflags[10];
   ulongtoab4(nflags, abflags);
   if (putBlock(abflags, 4)) return 9+perr("internal 612112006.2\n");

   // 3. if it's a directory,
   if (ofsrc.src.bIsDir)
   {
      // set zero-sized content, meta data is sufficient
      uchar *pCur = pClBuf+nClUsed;
      int nLongSize = 0;
      memcpy(pCur, &nLongSize, sizeof(int));
      pCur += sizeof(int);
      nClUsed += sizeof(int);
   }
   else
   {
      // else add the file content
      uchar *pCur = pClBuf+nClUsed;
      int nLongSize = (int)nSrcSize;
      memcpy(pCur, &nLongSize, sizeof(int));
      pCur += sizeof(int);
      nClUsed += sizeof(int);
 
      info.setStatProg("cache", pszSrcFile, nClBufSize, nUsedSave, "bytes");

      FILE *fin = fopen(pszSrcFile, "rb");
      if (!fin) {
         nClUsed = nUsedSave;
         return 5+perr("cannot open input file %s   \n", pszSrcFile);
         // non-fatal, proceed copy, but list error count at end.
      }
 
      size_t nRead = 0;
      if (cs.sim)
         nRead = nSrcSize;
      else
         nRead = myfread(pCur, (size_t)nSrcSize, fin, nClBufSize, nUsedSave);

      fclose(fin);
 
      if (nRead != nSrcSize) {
         perr("while reading %s: incomplete data\n", pszSrcFile);
         // fall back, remove metadata from cache
         nClUsed = nUsedSave;
      } else {
         SFKMD5 md5in;
         md5in.update(pCur, nSrcSize);
 
         nClUsed += nSrcSize;
         pCur += nSrcSize;
 
         // 4. md5
         uchar *pmd5in = md5in.digest();

         // remember source sum in case of late verify:
         if (cs.verifyLate) {
            num nsumlo=0, nsumhi=0;
            for (int i=0,b=64-8; i<8; i++) {
               nsumhi = nsumhi | (((num)pmd5in[0+i]&0xFF) << b);
               nsumlo = nsumlo | (((num)pmd5in[8+i]&0xFF) << b);
               b -= 8;
            }
            glblVerifier.remember(pszDstFile, nsumhi, nsumlo);
         }

         memcpy(pCur, pmd5in, 16);

         // printf("1] %02X%02X%02X%02X %s %p %s\n",pmd5in[0],pmd5in[1],pmd5in[2],pmd5in[3], numtoa(nSrcSize), pCur, pszSrcFile);

         pCur += 16;
         nClUsed += 16;

         // and also to filedb, if active
         if (filedb.canUpdate())
            if (filedb.updateFile(pszSrcFile, pmd5in))
               return 9;
      }
   }
 
   return 0;
}

int CopyCache::putBlock(uchar *pData, int nDataSize)
{
   uchar *pCur = pClBuf+nClUsed;
   num nRemain = nClBufSize-nClUsed;
   if (nDataSize > nRemain + 100) return 9;
   memcpy(pCur, &nDataSize, sizeof(int));
   memcpy(pCur+sizeof(int), pData, nDataSize);
   nClUsed += sizeof(int)+nDataSize;
   return 0;
}

void CopyCache::setEmpty()
{
   nClUsed = 0;
}

int CopyCache::flush()
{
   uchar *pCur = pClBuf;
   uchar *pMax = pClBuf+nClUsed;
   while (pCur < pMax)
   {
      bool bDoneFile = 0;

      // 1. filenames
      int nBlockSize = 0;
      if (pCur >= (pMax - sizeof(int))) return 9+perr("internal #113701\n");
      memcpy(&nBlockSize, pCur, sizeof(int));
      pCur += sizeof(int);
      char *pszSrc = (char*)pCur;
      pCur += nBlockSize;
      if (nBlockSize < 0 || pCur >= pMax) return 9+perr("internal #113702\n");

      memcpy(&nBlockSize, pCur, sizeof(int));
      pCur += sizeof(int);
      char *pszDst = (char*)pCur;
      pCur += nBlockSize;
      if (nBlockSize < 0 || pCur >= pMax) return 9+perr("internal #113703\n");

      memcpy(&nBlockSize, pCur, sizeof(int));
      pCur += sizeof(int);
      char *pszShDst = (char*)pCur;
      pCur += nBlockSize;
      if (nBlockSize < 0 || pCur >= pMax) return 9+perr("internal #113733\n");

      char *pszTell = chain.usefiles ? pszDst : pszSrc;
      if (cs.listTargets) pszTell = pszDst;

      // 2. meta data
      // filestat
      memcpy(&nBlockSize, pCur, sizeof(int));
      pCur += sizeof(int);
      uchar *pMeta = pCur;
      int nMetaSize = nBlockSize;
      pCur += nBlockSize;
      if (nBlockSize < 0 || pCur >= pMax) return 9+perr("internal #113704\n");

      // flags, also prefixed by blocksize (4)
      memcpy(&nBlockSize, pCur, sizeof(int));
      pCur += sizeof(int);
      if (nBlockSize != 4) return 9+perr("internal #113704.2\n");
      uchar abflags[10];
      memcpy(abflags, pCur, 4);
      pCur += 4;
      uint nflags = ab4toulong(abflags);
      // bit0: verified by checksum.
      // bit1: is shadow fallback.
      // bit2:
      // bit3: source is older than target (sync)

      // 3. file content
      memcpy(&nBlockSize, pCur, sizeof(int));
      pCur += sizeof(int);
      uchar *pContent = pCur;
      pCur += nBlockSize;
      if (nBlockSize < 0 || pCur > pMax) return 9+perr("internal #113705\n");

      FileStat ofsdst;
      if (ofsdst.setFrom(pMeta, nMetaSize))
         return 9;
 
      if (ofsdst.src.bIsDir)
      {
         // set target dir meta data
         if (cs.verbose > 2)
            info.print("[%s : about to copy time]\n", pszDst);
         if (!cs.sim)
            if (!ofsdst.writeTo(pszDst, __LINE__)) {
               cs.dirsCloned++;
               if (cs.verbose)
                  info.print("[%s : time copied]\n", pszDst);
            }
         // IGNORE rc. error messages are counted.
         // cs.dirs++;
      }
      else
      if (cs.sim)
      {
         // 4. skip md5
         pCur += 16;

         info.setStatus("", pszTell, "-----", eNoCycle);
         info.printLine(nGlblCopyStyle);
         cs.files++;
      }
      else
      {
         // 4. md5
         uchar *pmd5in = pCur;
         pCur += 16;

         for (int ntry=1; ntry<=3; ntry++)
         {
            // write target file
            info.setStatus("write", pszDst, "00");
 
            FILE *fout = myfopen(pszDst, "wb");
            if (!fout) {
               perr("cannot open output file %s (rc %d)\n", pszDst, (int)errno);
               break; // PROCEED with next file. errors are counted.
            }
 
            num nSize = ofsdst.src.nSize;
 
            size_t nWrite = myfwrite(pContent, nSize, fout, nSize, 0);
 
            myfclose(fout);
 
            if (bGlblEscape) {
               remove(pszDst);
               return 9+perr("failed to fully write %s, user interrupt\n", pszDst);
            }
            else
            if (nWrite != nSize)
               return 9+esys("fwrite", "failed to fully write %s   \n", pszDst);
               // do NOT proceed, this seems fatal.
 
            // set target meta data
            if (!ofsdst.writeTo(pszDst, __LINE__))
               cs.filesCloned++;
            // IGNORE rc. errors are counted.
 
            if (!cs.sim && cs.verifyEarly)
            {
               // run target verify
               info.setStatus("verfy", pszDst, "00");
               uchar abmd5[20];

               int nrcsub = getFileMD5NoCache(pszDst, abmd5, 1);

               if (userInterrupt(1))
               {
                  info.setAction("stop", pszDst, 0, 4);
                  info.printLine();
                  break;
               }
               else
               if (nrcsub == 0)
               {
                  if (memcmp(pmd5in, abmd5, 16)) {
                     if (ntry < 3) {
                        pwarn("verify failed, file differs: %s - retrying write\n", pszDst);
                        // fall through, next retry
                        remove(pszDst);
                     } else {
                        perr("verify failed, file differs: %s - giving up\n", pszDst);
                        remove(pszDst);
                     }
                  } else {
                     // verify succeeded
                     bDoneFile = 1;
                     cs.files++;
                     break;
                  }
               }
            }
            else
            {
               // no verify selected
               bDoneFile = 1;
               cs.files++;
               break;
            }
         }  // endfor tries

         // pszShDst must be set, but may be empty
         if (   filedb.canUpdate() && nGlblCopyShadows && strlen(pszShDst)
             && (!nGlblShadowSizeLimit || (ofsdst.src.nSize < nGlblShadowSizeLimit))
            )
         {
            // write shadow
            pszDst = pszShDst;

            info.setStatus("write", pszDst, "00");
            FILE *fout = myfopen(pszDst, "wb");
            if (!fout) {
               perr("cannot open output file %s (rc %d)\n", pszDst, (int)errno);
            } else {
               num nSize = ofsdst.src.nSize;
               size_t nWrite = myfwrite(pContent, nSize, fout, nSize, 0);
               myfclose(fout);
               if (bGlblEscape) {
                  remove(pszDst);
                  return 9+perr("failed to fully write %s, user interrupt\n", pszDst);
               }
               else
               if (nWrite != nSize)
                  return 9+esys("fwrite", "failed to fully write %s   \n", pszDst);
                  // do NOT proceed, this seems fatal.

               // set target meta data
               ofsdst.writeTo(pszDst, __LINE__);
               // IGNORE rc. errors are counted.
               nflags |= 4; // shadow written
               cs.shadowsWritten++;
            }
         }

         // print filename, tell how it was copied
         if (bDoneFile)
            printCopyCompleted(pszTell, nflags);
      }
   }
   setEmpty();
   return 0;
}

#ifdef _WIN32
DWORD CALLBACK cbCopyFileProgress(
   LARGE_INTEGER TotalFileSize,
   LARGE_INTEGER TotalBytesTransferred,
   LARGE_INTEGER StreamSize,
   LARGE_INTEGER StreamBytesTransferred,
   DWORD dwStreamNumber,
   DWORD dwCallbackReason,
   HANDLE hSourceFile,
   HANDLE hDestinationFile,
   LPVOID lpData  // optional
 )
{
   if (userInterrupt(1))
      return 1; // PROGRESS_CANCEL;

   num nTotal =  (((num)TotalFileSize.HighPart) << 32)
               | (((num)TotalFileSize.LowPart ) <<  0);

   num nDone  =  (((num)TotalBytesTransferred.HighPart) << 32)
               | (((num)TotalBytesTransferred.LowPart ) <<  0);

   info.setAddInfo("%u / %u mb", (uint)(nDone/1000000UL), (uint)(nTotal/1000000UL));
   info.setProgress(nTotal, nDone, "bytes");

   return 0; // PROGRESS_CONTINUE;
}

int copyFileWin(char *pszSrc, char *pszDst, char *pszShDst, uchar *pWorkBuf, num nBufSize, uint nflagsin)
{__
   char *pszTell = chain.usefiles ? pszDst : pszSrc;
   if (cs.listTargets) pszTell = pszDst;

   if (cs.sim) {
      info.setStatus("", pszTell, "-----", eNoCycle);
      if (!cs.dostat)
         info.printLine(nGlblCopyStyle);
      cs.files++;
      return 0;
   }

   info.setAction("copy ", pszSrc, "00");

   DWORD nSysFlags = 0;

   // these are yet internal and completely untested
   if (cs.copyLinks)   nSysFlags |= 0x00000800UL; // COPY_FILE_COPY_SYMLINK;
   if (cs.copyNoBuf)   nSysFlags |= 0x00001000UL; // COPY_FILE_NO_BUFFERING;
   if (cs.copyDecrypt) nSysFlags |= 0x00000008UL; // COPY_FILE_ALLOW_DECRYPTED_DESTINATION;

   BOOL bcancel = 0;
   bool brc = CopyFileExA(pszSrc, pszDst, cbCopyFileProgress, 0, &bcancel, nSysFlags);

   if (!brc) {
      uint nerr = GetLastError();
      switch (nerr) {
         case ERROR_ACCESS_DENIED:
            perr("copy failed, access denied (rc=%u): %s\n", nerr, pszDst);
            pinf("make sure you have full access rights. maybe you have to be administrator.\n");
            break;
         case ERROR_REQUEST_ABORTED:
            // the OS cleaned up the target file.
            pwarn("copy stopped, cleanup done.\n");
            return 19; // stop all further processing
         default:
            perr("copy failed, rc=%u: %s\n", nerr, pszDst);
            break;
      }
   } else {
      cs.files++;
      printCopyCompleted(pszTell, nflagsin);
   }

   return brc ? 0 : 9;
}
#endif // _WIN32

int copyFile(char *pszSrc, char *pszDst, char *pszShDst, uchar *pWorkBuf, num nBufSize, uint nflags)
{__
   char *pszTell = chain.usefiles ? pszDst : pszSrc;
   if (cs.listTargets) pszTell = pszDst;

   if (cs.sim) {
      info.setStatus("", pszTell, "-----", eNoCycle);
      if (!cs.dostat)
         info.printLine(nGlblCopyStyle);
      cs.files++;
      return 0;
   }

   int lRC = 0;
   uchar abMD5Src[20];
   bool  bmdsrcset = 0;
   memset(abMD5Src, 0, sizeof(abMD5Src));

   bool bDoneFile = 0;

   // try to copy the file, upto 3 times
   for (int ntry=1; ntry<=3; ntry++)
   {
      info.setAction("read ", pszSrc, "00");
 
      num nFileSize = getFileSize(pszSrc);
 
      FILE *fin = fopen(pszSrc, "rb");
      if (!fin) return 9+perr("cannot open input file %s   \n", pszSrc);
 
      FILE *fout = myfopen(pszDst, "wb");
      if (!fout) {
         fclose(fin);
         return 9+perr("cannot open output file %s   \n", pszDst);
      }

      FILE *fsh = 0;
      if (   filedb.canUpdate() && nGlblCopyShadows && pszShDst
          && (!nGlblShadowSizeLimit || (nFileSize < nGlblShadowSizeLimit))
         )
      {
         fsh = fopen(pszShDst, "wb");
         if (!fsh)
            perr("cannot write shadow file %s   \n", pszShDst);
            // but continue, w/o shadow
      }
 
      num nTime1=0, nTime2=0, nReadTime=0, nWriteTime=0;
      num nReadBytes=0, nWriteBytes=0;
      uint nkbsread=0, nkbswrite=0;
      SFKMD5 md5in;
      int nBlock = 0;
      while (!userInterrupt())
      {
         nTime1 = getCurrentTime();
         info.setStatus("read ", pszSrc, "00");
         size_t nRead = 0;
         if (cs.sim)
            nRead = nBufSize;
         else
            nRead = myfread(pWorkBuf, (size_t)nBufSize, fin, nFileSize, nReadBytes);
         nTime2 = getCurrentTime();
         if (nRead <= 0)
            break; // EOD
         nReadTime  += (nTime2-nTime1);
         nReadBytes += nRead;
 
         md5in.update(pWorkBuf, nRead);
 
         nTime1 = getCurrentTime();
         info.setStatus("write", pszDst, "00");
         size_t nWrite = myfwrite(pWorkBuf, nRead, fout, nFileSize, nWriteBytes);
         nTime2 = getCurrentTime();
         if (nWrite != nRead) {
            lRC = 9;
            if (!bGlblEscape)
               esys("fwrite", "failed to write %s   \n", pszDst);
            break;
         }
         nWriteTime  += (nTime2-nTime1);
         nWriteBytes += nWrite;

         // extra shadow write
         if (fsh) {
            nWrite = myfwrite(pWorkBuf, nRead, fsh, nFileSize, nWriteBytes);
            if (nWrite != nRead) {
               // shadow writing fails silently
               fclose(fsh);
               remove(pszShDst);
               fsh = 0;
               pszShDst = 0;
            }
         }
 
         nkbsread  = (nReadBytes  / (nReadTime  ? nReadTime : 1));
         nkbswrite = (nWriteBytes / (nWriteTime ? nWriteTime : 1));
 
         nBlock++;
      }

      if (fsh) {
         fclose(fsh);
         nflags |= 4; // shadow written
         cs.shadowsWritten++;
      }
      pszShDst = 0; // block 2nd writing of shadow
 
      myfclose(fout);
      fclose(fin);
 
      if (bGlblEscape) {
         remove(pszDst);
         if (cs.verbose)
            pwarn("copy stopped, cleaning up: %s\n", pszDst);
         else
            pwarn("copy stopped, cleanup done.\n");
         return 19;
      }
 
      FileStat ofs;
      if (ofs.readFrom(pszSrc))
         return 9+perr("failed to read attributes: %s\n", pszSrc);
      if (ofs.writeTo(pszDst, __LINE__))
         return 9+perr("failed to write attributes: %s\n", pszDst);
      else
         cs.filesCloned++;

      uchar *pmd5in = md5in.digest();

      // remember source sum in case of late verify:
      if (cs.verifyLate) {
         num nsumlo=0, nsumhi=0;
         for (int i=0,b=64-8; i<8; i++) {
            nsumhi = nsumhi | (((num)pmd5in[0+i]&0xFF) << b);
            nsumlo = nsumlo | (((num)pmd5in[8+i]&0xFF) << b);
            b -= 8;
         }
         glblVerifier.remember(pszDst, nsumhi, nsumlo);
      }

      // remember src file md5 beyond this scope
      memcpy(abMD5Src, pmd5in, 16);
      bmdsrcset = 1;

      if (!cs.sim && cs.verifyEarly)
      {
         info.setAction("verfy", pszTell, "00");
 
         // run target verify
         uchar abmd5[20];
         int nrcsub = getFileMD5NoCache(pszDst, abmd5, 1);
 
         if (userInterrupt(1))
         {
            info.setAction("stop ", pszDst, 0, 4);
            info.printLine();
            break;
         }
         else
         if (nrcsub == 0)
         {
            if (memcmp(pmd5in, abmd5, 16)) {
               if (ntry < 3) {
                  pwarn("verify failed, file differs: %s - retrying write\n", pszDst);
                  // fall through, next retry
                  remove(pszDst);
               } else {
                  perr("verify failed, file differs: %s - giving up\n", pszDst);
                  remove(pszDst);
               }
            } else {
               // verify succeeded
               bDoneFile = 1;
               cs.files++;
               break;
            }
         }
      }
      else
      {
         // no verify selected
         bDoneFile = 1;
         cs.files++;
         break;
      }
   }  // endfor tries

   if (bDoneFile)
      printCopyCompleted(pszTell, nflags);

   if (lRC == 0) {
      if (!bmdsrcset) return 9+perr("internal #0505071820");
      filedb.updateFile(pszSrc, abMD5Src);
   }

   return lRC;
}

int execDirCopy(char *pszSrc, FileList &oDirFiles)
{__
   // copy metadata of directory
   char *pszDstRaw = pszGlblCopyDst;

   // expect Src to contain a RELATIVE path, e.g.
   //    data\tmp1.txt  data\sub\tmp2.txt
   // strip the original base path, if any
   char *pszRelSrc = relName(pszGlblCopySrc, pszSrc);

   cs.dirsScanned++;
   sprintf(szLineBuf, "%u files %u dirs", cs.filesScanned, cs.dirsScanned);
   if (strlen(szLineBuf) > 20)
      info.setAddInfoWidth(strlen(szLineBuf));
   info.setStatus("scan ", pszRelSrc, szLineBuf);

   // build full target name: d:/tmp/subdir
   joinPath(szRefNameBuf, sizeof(szRefNameBuf), pszDstRaw, pszRelSrc);
   // strip trailing / if any
   int nRefLen = strlen(szRefNameBuf);
   if ((nRefLen > 0) && (szRefNameBuf[nRefLen-1] == glblPathChar))
      szRefNameBuf[nRefLen-1] = '\0';

   // in case we have to copy EMPTY target directories:
   // if (createSubDirTree(szRefNameBuf, ""))
   //   return 9;

   // execFileCopy has created dir tree on demand,
   // so all dirs must exist, IF files have been copied.
   if (!isDir(szRefNameBuf)) {
      if (cs.verbose)
         info.print("%s : skip, no files copied.\n",szRefNameBuf);
      return 0; // no files have been copied in that dir.
   }

   char szReason[50];
   szReason[0] = '\0';

   // check if we really need to copy attributes

   // win: don't try to clone x: to y: etc.
   #ifdef _WIN32
   if (endsWithColon(pszSrc)) return 0;
   if (endsWithColon(szRefNameBuf)) return 0;
   #endif

   // BEWARE OF MIXUP:
   //    sfk list -sincedir foo bar
   //       means for the user: FOO (szRefNameBuf) is the SOURCE.
   // NO problem here, as in
   //    sfk copy foo bar
   //       the provided pszSrc in here IS actually the SOURCE.

   FileStat ofsSrc;
   FileStat ofsDst;
   if (ofsSrc.readFrom(pszSrc)) {
      perr("cannot read dir time: %s\n", pszSrc);
      return 9;
   }

   char *pszTell = pszSrc;
   if (cs.listTargets) pszTell = szRefNameBuf;

   // checked isDir(szRefNameBuf) above
   if (!ofsDst.readFrom(szRefNameBuf))
   {
      // copy the directory timestamp or not? during filecopy,
      // we may have created the dir on demand. in this case,
      // copy the dir timestamp unconditionally. ELSE copy it only
      // if the src is newer than the target.
      bool bOnlyOnNewSrc = 1;
      // this check is not at all beautiful, but it works
      // without restructuring the whole tree processing.
      #ifdef SFK_CCDIRTIME
      int ipos = glblCreatedDirs.find(szRefNameBuf);
      if (ipos >= 0) {
         // the dir was recently created: ignore its new timestamp
         glblCreatedDirs.removeEntry(ipos);
         bOnlyOnNewSrc = 0;
      }
      #endif
      int ndif = ofsSrc.differs(ofsDst, bOnlyOnNewSrc);
      if (!ndif) {
         if (cs.verbose > 1)
            info.print("%s : no time / attrib change\n", szRefNameBuf);
         return 0;   // skip
      }
      if (ndif >= 7 && ndif <= 10 && cs.nodirtime != 0) {
         if (cs.verbose > 1)
            info.print("%s : ignore time difference (%d)\n", szRefNameBuf, ndif);
         return 0;   // skip
      }
      if (cs.verbose > 0)
         info.print("%s : copying attribs, ndif %d\n", szRefNameBuf, ndif);
      // sprintf(szReason, "%d", ndif);
   }

   bool bDone = 0;
   if (bGlblUseCopyCache) {
      int lRes = glblCopyCache.process(pszSrc, szRefNameBuf, 0, 0);
      if (lRes == 0)
         bDone = 1;
   }

   if (!bDone)
   {
      if (cs.sim) {
         cs.dirsCloned++;
      } else {
         if (cloneAttributes(pszSrc, szRefNameBuf, __LINE__))
            return 1; // error, but skip and continue
         cs.dirsCloned++;
      }

      setTextColor(nGlblTimeColor);
      info.setStatus("", pszTell, "copy time", eNoCycle);
      info.printLine(nGlblCopyStyle);
      setTextColor(-1);
   }

   return 0;
}

// USES:
//    szAttrBuf, szRefNameBuf, szLineBuf1/2 (indirectly)
int execFileCopy(Coi *pcoi)
{__
   char *pszSrc      = pcoi->name();
   char *pszOptRoot  = pcoi->root(1); // null if not set

   cs.filesScanned++;

   // with input chaining, glblCopySrc will not be set.
   char *pszSrcRaw = pszGlblCopySrc;
   if (chain.usefiles) {
      if (cs.rootrelname)
         pszSrcRaw = pszOptRoot; // user selected relative names
      else {
         // autodetect: include source root into target name?
         if (cs.rootabsname || (pszOptRoot && !isAbsolutePath(pszOptRoot)))
            // source root is NOT absolute, or -abs specified: take it
            pszSrcRaw = str("");
         else
            // source root IS absolute (e.g. C:\\) so strip it
            pszSrcRaw = pszOptRoot; // if null, produces error below
      }
   }
   if (!pszSrcRaw) return 9+perr("copy: missing source root dir. file=%s",pszSrc);

   // expect Dst to be a directory, e.g.
   //    x:    x:/   x:/tmp   x:/tmp/
   char *pszDstRaw = pszGlblCopyDst;

   // expect Src to contain a RELATIVE path, e.g.
   //    data\tmp1.txt  data\sub\tmp2.txt
   // strip the original base path, if any
   char *pszRelSrc = relName(pszSrcRaw, pszSrc);
 
   // build full target name: d:/tmp/subdir/thefile.txt
   // sprintf(szRefNameBuf, "%s%c%s", pszDstRaw, glblPathChar, pszRelSrc);
   joinPath(szRefNameBuf, sizeof(szRefNameBuf), pszDstRaw, pszRelSrc);

   if (cs.debug)
      printf("copy.check %s => %s [root=%s]\n",pszSrc,szRefNameBuf,pszSrcRaw);

   char *pszShSrc = 0, *pszShDst = 0;
   if (filedb.canRead()) {
      // create source shadow path
      if (!joinShadowPath(szRefNameBuf2, sizeof(szRefNameBuf2), pszSrcRaw, pszRelSrc))
         pszShSrc = szRefNameBuf2;
   } else {
      // create dest shadow path
      if (!joinShadowPath(szRefNameBuf2, sizeof(szRefNameBuf2), pszDstRaw, pszRelSrc))
         pszShDst = szRefNameBuf2;
   }
 
   // prepare target directory(s), if any. first we need the full path,
   strcopy(szAttrBuf, szRefNameBuf);
   char *psz1 = strrchr(szAttrBuf, glblPathChar);
   #ifdef _WIN32
   if (!psz1) {
      // c:thefile.txt -> c:
      if ( (strlen(szAttrBuf) >= 2) && (szAttrBuf[1] == ':' ) )
         psz1 = &szAttrBuf[2];
   }
   #endif
   if (!psz1) return 9+perr("unexpected target name format: %s\n",szAttrBuf);
   *psz1 = '\0';
   // to check if it exists or not,
   if (!cs.sim && !isDir(szAttrBuf)) {
      // then we need to isolate the relative target dir path,
      sprintf(szAttrBuf, "%c%s", glblPathChar, pszRelSrc);
      psz1 = strrchr(szAttrBuf, glblPathChar);
      if (!psz1) return 9+perr("unexpected target name format: %s\n",szAttrBuf);
      *psz1 = '\0';
      // to allow better processing in createSubDirTree.
      if (createSubDirTree(pszDstRaw, szAttrBuf, pszSrcRaw))
         return 9;
   }
   // else we have some path like c:thefile.txt - no directories to create.

   // same for dest. shadow, if any
   if (filedb.canUpdate() && nGlblCopyShadows && pszShDst)
   {
      strcopy(szAttrBuf, pszShDst);
      char *psz1 = strrchr(szAttrBuf, glblPathChar);
      #ifdef _WIN2
      if (!psz1) {
         // c:thefile.txt -> c:
         if ( (strlen(szAttrBuf) >= 2) && (szAttrBuf[1] == ':' ) )
            psz1 = &szAttrBuf[2];
      }
      #endif
      if (!psz1) return 9+perr("unexpected target name format: %s\n",szAttrBuf);
      *psz1 = '\0';
      // to check if it exists or not,
      if (!cs.sim && !isDir(szAttrBuf)) {
         // then we need to isolate the relative target dir path,
         sprintf(szAttrBuf, "%czz-shadow-01%s%s", glblPathChar, glblPathStr, pszRelSrc);
         psz1 = strrchr(szAttrBuf, glblPathChar);
         if (!psz1) return 9+perr("unexpected target name format: %s\n",szAttrBuf);
         *psz1 = '\0';
         // to allow better processing in createSubDirTree.
         if (createSubDirTree(pszDstRaw, szAttrBuf, pszSrcRaw))
            return 9;
      }
   }
 
   return execFileCopySub(pszSrc, szRefNameBuf, pszShSrc, pszShDst);
}

// does NOT create target subdirs. this is expected to be done by caller.
int execFileCopySub(char *pszSrc, char *pszDst, char *pszShSrc, char *pszShDst)
{__
   mtklog(("fcopysub: %s -> %s",pszSrc,pszDst));

   char szReason[50];
   szReason[0] = '\0';

   // if we tell the filename, do we take src or dst file?
   char *pszTell = chain.usefiles ? pszDst : pszSrc;
   if (cs.listTargets) pszTell = pszDst;
 
   // check if we really need to copy

   // BEWARE OF MIXUP:
   //    sfk list -sincedir foo bar
   //       means for the user: FOO (szRefNameBuf) is the SOURCE.
   // NO problem here, because with
   //    sfk copy foo bar
   //       the pszSrc provided in here REALLY is the SOURCE.

   bool  bJustCopyTime = 0;
   bool  bSrcIsOlder = 0;
   uint nflags = 0;

   FileStat ofsSrc;
   FileStat ofsDst;
   bool  bSrcUnreadable = 0;
   if (ofsSrc.readFrom(pszSrc)) {
      // filename exists in source, but file is unreadable:
      mtklog(("copy: src unreadable"));
      if (filedb.canRead() && pszShSrc) {
         // proceed, as we may use the shadow
         bSrcUnreadable = 1; // but don't issue same error twice
      } else {
         // printf("fatal, %d %p\n", filedb.canRead(), pszShSrc);
         return 9;
      }
   }
   num nFileSize = ofsSrc.getSize();
   if (fileExists(pszDst))
   {
      if (!ofsDst.readFrom(pszDst))
      {
         bool bSameIOS = cs.syncOlder ? 0 : 1;  // same if older src?
         int ndif = ofsSrc.differs(ofsDst, bSameIOS, &bSrcIsOlder);
         if (bSrcIsOlder) nflags |= (1<<3);
         if (!ndif && !bGlblIgnoreTime) {
            // only with copy, NOT with sync it may happen
            // that src is OLDER than target, skipping copy.
            // with sync, different times ALWAYS lead to copy.
            if (cs.syncFiles && bSrcIsOlder && !cs.noinfo) {
               if (bSrcIsOlder < 2) {
                  info.setStatus("skip", pszTell, "source is older");
                  info.printLine(1<<2);
               }
               // else dst jump, don't even tell notice
            }
            else
            if (cs.verbose)
               info.print("no diff, skip: %s\n", pszTell);
            if (filedb.canUpdate())
               filedb.updateFile(pszSrc, 0, true); // true:JustConfirm
            return 0;   // skip
         }
         // differs by timestamp (src is newer). but does it really mean
         // we have to copy the whole content?
         if (ofsSrc.getSize() == ofsDst.getSize()) {
            // compare file content
            uchar abMD5Src[20];
            if (equalFileContent(pszSrc, pszDst, abMD5Src)) {
               if (bGlblIgnoreTime) {
                  if (filedb.canUpdate())
                     filedb.updateFile(pszSrc, abMD5Src);
                  return 0; // same content, skip
               }
               bJustCopyTime = 1;
            }
            else
            if (!ndif && bGlblIgnoreTime) {
               int ndif2 = ofsSrc.differs(ofsDst, 0); // NOT same if older src
               if (!ndif2 && cs.sim) {
                  // critical: have file with same size and time, but dif. content
                  // this can be reached only through -ignoretime deep verify.
                  // if in simulation, create warning-like special listing
                  pwarn("same time/size, but content diff: %s\n", pszDst);
                  // indicates corrupted file - no filedb update here.
                  cs.files++;
                  return 0;
               }
            }
            if (cs.verbose)
               info.print("[%s : differs, rc %d%s]\n", pszDst, ndif,
                  bJustCopyTime ? ", same content":", diff. content");
         } else {
            if (cs.verbose)
               info.print("[%s : differs, rc %d]\n", pszDst, ndif);
         }
         // sprintf(szReason, "%d", ndif);
      }
   }

   if (bJustCopyTime)
   {
      // this flag says that both files exist with same content.
      if (cs.sim) {
         cs.filesCloned++;
      } else {
         // copy timestamp and attributes, but not the content.
         if (ofsSrc.writeTo(pszDst, __LINE__))
            return 1; // error, skip but continue
         cs.filesCloned++;
      }

      setTextColor(nGlblTimeColor);
      info.setStatus("", pszTell, "copy time", eNoCycle);
      info.printLine(nGlblCopyStyle);
      setTextColor(-1);

      // remember src and dst for verify pass
      // glblVerifier.remember(pszSrc, pszDst);
   }
   else
   {
      // prepare copy of file
      if (filedb.canRead()) {
         // try to check source file if it's still intact
         int nvrc = filedb.verifyFile(pszSrc, pszShSrc, bSrcUnreadable);
         if (nvrc >= 9)
            return 0+perr("check failed: %s - content changed, skipping copy\n", pszSrc);
         else
         if (nvrc == 8)
            return 0+perr("%s - not found in metadb, skipping copy\n", pszSrc);
         else
         if (nvrc == 5) {
            pwarn("master file modified, using shadow: %s\n", pszShSrc);
            pszSrc = pszShSrc;
            cs.shadowFallbacks++;
            nflags |= 3; // with checksum, but shadow
         }
         else
         if (nvrc > 5) {
            // unexpected, issue general message
            return 0+perr("check failed: %s - skipping copy (%d)\n", pszSrc, nvrc);
         } else {
            // rc < 5 is just informal, e.g. time difference
            nflags |= 1; // checksum verified
         }
      }

      // copy the actual file
      bool bDone = 0;
      if (!cs.sim && bGlblUseCopyCache) {
         int lRes = glblCopyCache.process(pszSrc, pszDst, pszShDst, nflags);
         if (lRes == 0)
            bDone = 1;
         if (lRes >= 9)
            return lRes; // fatal error
      }
 
      if (!bDone)
      {
         int iSubRC = 0;
         #ifdef _WIN32
         if (!nGlblCopyShadows) {
            if (iSubRC = copyFileWin(pszSrc, pszDst, pszShDst, pGlblWorkBuf, nGlblWorkBufSize, nflags))
               return iSubRC;
         }
         else
         #endif
         if (iSubRC = copyFile(pszSrc, pszDst, pszShDst, pGlblWorkBuf, nGlblWorkBufSize, nflags))
            return iSubRC;
      }

      // count direct file size
      nGlblBytes += nFileSize;

      // count shadow size, if any
      if (   nGlblCopyShadows
          && (!nGlblShadowSizeLimit || (nFileSize < nGlblShadowSizeLimit))
         )
      {
         nGlblBytes += nFileSize;
         cs.shadowsWritten++;
      }
   }
 
   return 0;
}

// USES:
//    szAttrBuf, szRefNameBuf, szLineBuf1/2 (indirectly)
int execFileCleanup(char *pszSrc)
{__
   cs.filesScanned++;

   // expect Dst to be a directory, e.g.
   //    x:    x:/   x:/tmp   x:/tmp/
   char *pszDstRaw = pszGlblCopyDst;

   // expect Src to contain a RELATIVE path, e.g.
   //    data\tmp1.txt  data\sub\tmp2.txt
   // strip the original base path, if any
   char *pszRelSrc = relName(pszGlblCopySrc, pszSrc);
 
   // build full target name: d:/tmp/subdir/thefile.txt
   joinPath(szRefNameBuf, sizeof(szRefNameBuf), pszDstRaw, pszRelSrc);
 
   // REORDER: currently, pszSrc is the TARGET file
   char *pszDst = pszSrc;
   pszSrc = szRefNameBuf;
   // NOW, pszSrc is the copy src, pszDst is the cleanup candidate.

   bool b1 = (bool)fileExists(pszSrc);
   bool b2 = (bool)fileExists(pszDst);

   if (!b1 && b2)
   {
      // old trash file, or backsync candidate?
      num nFileAge = getFileAge(pszDst);
      int nAgeDays = nFileAge / (24 * 3600);

      if (!cs.delStaleFiles && (nAgeDays < nGlblActiveFileAgeLimit))
      {
         int nRemain = nGlblActiveFileAgeLimit - nAgeDays;
         if (nRemain < 6)
            setTextColor(nGlblErrColor);
         else
            setTextColor(nGlblWarnColor);
         if (cs.verbose)
            info.print("stale: %s / %s - %d days until deletion\n",pszDst,pszSrc,nRemain);
         else
            info.print("stale: %s - %d days until deletion\n",pszDst,nRemain);
         setTextColor(-1);
         cs.filesStale++;
      }
      else
      {
         setTextColor(nGlblWarnColor);
         if (cs.verbose)
            info.print("DEL: %s / %s",pszDst,pszSrc);
         else
            info.print("DEL: %s",pszDst);
         setTextColor(-1);
 
         // NO LINEFEED FROM HERE
         if (!cs.sim && cs.yes)
         {
            // delete primary stale file
            if (!canWriteFile(pszDst, 0))
               setWriteEnabled(pszDst);
            if (remove(pszDst)) {
               printf("\n");
               perr("failed to delete: %s", pszDst);
            } else {
               cs.filesDeleted++;
               if (filedb.canUpdate()) {
                  // remove file from filedb
                  filedb.removeFile(pszDst, 1);
               }
            }
            // delete shadow, if any
            if (nGlblCopyShadows && cs.skipOwnMetaDir && (strlen(filedb.metaDir()) > 0))
            {
               char *pszMeta = filedb.metaDir();
               if (!strstr(pszMeta, "zz-shadow-")) {
                  printf("\n"); perr("wrong metadb name: %s", pszMeta);
               } else {
                  joinPath(szRefNameBuf, sizeof(szRefNameBuf), pszMeta, pszRelSrc);
                  char *pszShadow = szRefNameBuf;
                  if (fileExists(pszShadow)) {
                     if (!canWriteFile(pszShadow, 0))
                        setWriteEnabled(pszShadow);
                     if (remove(pszShadow)) {
                        printf("\n");
                        perr("failed to delete: %s", pszShadow);
                     } else {
                        printx("<time> +shadow<def>");
                     }
                  }
               }
            }
         } else {
            cs.filesDeleted++;
         }
         // NO LINEFEED UNTIL HERE

         printf("\n");
      }
   }
   else
   if (b1 && b2)
   {
      // list touched files
      FileStat ofsSrc;
      FileStat ofsDst;
      if (ofsSrc.readFrom(pszDst))  // SWAPPED
         return 9;
      if (!ofsDst.readFrom(pszSrc)) {  // SWAPPED
         int ndif = ofsSrc.differs(ofsDst, 1); // same if older src
         if (!ndif) {
            if (cs.verbose)
               info.print("no diff, skip: %s\n", pszSrc);
            return 0;   // skip
         }
         if (cs.verbose)
            info.print("[%s : differs, rc %d]\n", pszDst, ndif);
         // the target file was changed after copy
         cs.filesNewerInDst++;
         if (bGlblShowSyncDiff)
            info.print("DIF: %s   (%s)\n",pszDst,ofsSrc.diffReason(ndif));
      }
   }
 
   return 0;
}

int execDirCleanup(char *pszSrc, FileList &oDirFiles)
{__
   // copy metadata of directory
   char *pszDstRaw = pszGlblCopyDst;

   // expect Src to contain a RELATIVE path, e.g.
   //    data\tmp1.txt  data\sub\tmp2.txt
   // strip the original base path, if any
   char *pszRelSrc = relName(pszGlblCopySrc, pszSrc);

   cs.dirsScanned++;
   sprintf(szLineBuf, "%u files %u dirs", cs.filesScanned, cs.dirsScanned);
   if (strlen(szLineBuf) > 20)
      info.setAddInfoWidth(strlen(szLineBuf));
   info.setStatus("scan ", pszRelSrc, szLineBuf);

   // build full target name: d:/tmp/subdir
   joinPath(szRefNameBuf, sizeof(szRefNameBuf), pszDstRaw, pszRelSrc);

   // strip trailing / if any
   int nRefLen = strlen(szRefNameBuf);
   if ((nRefLen > 0) && (szRefNameBuf[nRefLen-1] == glblPathChar))
      szRefNameBuf[nRefLen-1] = '\0';

   // REORDER: currently, pszSrc is the TARGET dir
   char *pszDst = pszSrc;
   pszSrc = szRefNameBuf;
   // NOW, pszSrc is the copy src, pszDst is the cleanup candidate.

   if (!isDir(pszSrc) && isDir(pszDst))
   {
      bool isEmptyDir(char *pszIn);
      if (isEmptyDir(pszDst))
      {
         setTextColor(nGlblWarnColor);
         info.print("DEL: %s\n", pszDst);
         setTextColor(-1);
         if (!cs.sim && cs.yes) {
            int nrc = rmdir(pszDst);
            if (nrc)
               perr("failed to delete: %s\n", pszDst);
            else
               cs.dirsDeleted++;
         } else {
            cs.dirsDeleted++;
         }
      }
   }

   return 0;
}

const char *szGlblPhraseData =
{
"#:sfk-phrase-db:100:\n"
"# content is converted as:\n"
"# ,  -> random selection\n"
"# \\, -> tab\n"
"# ;  -> ,\n"
"# \\; -> ;\n"
"# \\+ -> nothing\n"
"# \\n -> linefeed\n"
"# $1sym -> remember a random index in slot 1\n"
"#          for later repeat as $1sym\n"
"\n"
"$company: $namecom\\,$stradr\\,$city $statecode $zip\n"
"$person: $nameper\\,$stradr\\,$city $statecode $zip\n"
"$nameper: $name1 $name2\n"
"$name1: $preperm,$preperf\n"
"$preperm: Arthur,Alexander,Brian,Colin,Donald,Edward,Henry,\n"
"          Jack,James,Larry,Neil,Richard\n"
"$preperf: Alice,Brenda,Dora,Ellen,Grace,Helena,Ilona,Laura,\n"
"          Lena,Sandra,Susan\n"
"$name2: Smith,Jones,Harris,Young,Scott,Cole,Ellis,Porter,\n"
"          Anderson,Johnson,Peterson,Miller\n"
"$namecom: $comsyl1$comsyl2 $combra $comtype\n"
"$pvrfile: $nametv-$date-$timemin-$tvshow.mts\n"
"$tvshow:  $tvshow1,$tvshow2,$tvshow3\n"
"$tvshow1: The $nameper $tvwhat\n"
"$tvshow2: $nameper $tvwhat\n"
"$tvshow3: $newstype News\n"
"$newstype: Market,Technology,World\n"
"$tvwhat:  Show,News,Talk\n"
"$nametv:  $typetv$jointv$nameflat\n"
"$jointv:  $dig,_\n"
"$typetv:  Channel,Station,TV,News,Cable\n"
"$nameflat: $comsyl1$comsyl2\n"
"$comsyl1: Wel,Gen,Fram,Nap,Ken,Can,New,Al,Be,Dan,El\n"
"$comsyl2: ton,mond,dale,ney,kin,port,tree,way,nex,car,dyne\n"
"$cnsyl1: Che,Wo,Fi,Gu,Kan,Sel,Ben,Chong,Ching,Wing,Fon,Bun\n"
"$cnsyl2: che,wo,fi,gu,kan,sel,ben,chong,ching,wing,fon,bun\n"
"$combra: Machinery,Printing,Design,Furniture,Computers\n"
"$comtype: Inc,Ltd\n"
"$stradr: $num3 $namestr $strtype\n"
"$date: $year$month$day\n"
"$time: $hour$minsec$minsec\n"
"$timemin: $hour$minsec\n"
"$hour: 01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23\n"
"$minsec: 01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,\n"
"         21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,\n"
"         41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59\n"
"$year: 2011,2012,2013,2014\n"
"$month: 01,02,03,04,05,06,07,08,09,10,11\n"
"$day:  01,02,03,04,05,06,07,08,09,10,11,12,13,14,\n"
"       15,16,17,18,19,20,21,22,23,24,25,26,27,28\n"
"$num9: $dig1$dig$dig$dig$dig$dig$dig$dig$dig\n"
"$num8: $dig1$dig$dig$dig$dig$dig$dig$dig\n"
"$num7: $dig1$dig$dig$dig$dig$dig$dig\n"
"$num6: $dig1$dig$dig$dig$dig$dig\n"
"$num5: $dig1$dig$dig$dig$dig\n"
"$num4: $dig1$dig$dig$dig\n"
"$num3: $dig1$dig$dig\n"
"$dig1: 1,2,3,4,5,6,7,8,9\n"
"$dig: 0,1,2,3,4,5,6,7,8,9\n"
"$namestr: $comsyl1$comsyl2\n"
"$strtype: Dr,Rd\n"
"$zip: $num5\n"
"$city: London,Melville,Hertford,Denton,Framingham,Orlando,Irvine,\n"
"       Seattle,Toronto,Victoria,Portland,Wellington\n"
"$statecode: AL,MT,AK,NE,AZ,NV,AR,NH,CA,NJ,CO,NM,CT,NY,DE,NC,FL,\n"
"            ND,GA,OH,HI,OK,ID,OR,IL,PA,IN,RI,IA,SC,KS,SD,KY,TN,\n"
"            LA,TX,ME,UT,MD,VT,MA,VA,MI,WA,MN,WV,MS,WI,MO,WY\n"
"$char1: A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z\n"
"$country: USA,England,Australia,Canada,Argentina,Chile,China,\n"
"          France,Germany,Greece,Japan,Spain,Taiwan\n"
"$countrycode: US,EN,AU,CA,AR,CL,CN,\n"
"          FR,DE,GR,JP,ES,TW\n"
"\n"
"$ip4: $ip4part.$ip4part.$ip4part.$ip4part\n"
"$ip4part: 1$dig$dig\n"
"\n"
"$news: $1preperm $name2 created a new product; the $2verb $3sub with $social connectivity.\\n\n"
"       It allows to $4get $images from all $5friend\\+s around your $area live on $your $watch.\\n\n"
"       \"Everyone needs a $2verb $3sub\"; $1preperm says; \"it's the smart and social way to $4get $5friend\\+s\".\n"
"$verb: flying, rolling, jumping, hoovering\n"
"$sub: watch, rubber duck, camera, ventilator, rice cooker,\n"
"      coffee machine, toaster, paper weight, car key, remote control\n"
"$get: keep track of, share, post\n"
"$images: images, sounds, videos\n"
"$your: your, a friends\n"
"$watch: watch, tv, smartphone, tablet\n"
"$friend: bird, dog, cat, squirrel, turtle, hamster\n"
"$area: area, house, couch, toilet, fridge, car, bathroom, garage\n"
"$social: facebook, twitter, google, tumblr, whats app, instagram\n"
"\n"
};

class Phraser;

class Symbol
{
public:
   Symbol   (char *pszName, Phraser *parent);
   void     collect(char *pszContent);
   char    *name() { return szClName; }
   char    *solve(char *pout, int nmaxout, int nlevel, int istatic);
   bool     issep(char c);
   bool     ispunctortab(char c);
private:
   char     szClName[100];
   char     szClOpt[100];
   char     szClCont[1024];
   char     szClBuf[100];
   char     szClBuf2[200];
   // int      astatic[100];
   Phraser  *phraser;
};

class Phraser
{
public:
   Phraser  ();
   int     load(char *pszAll, char *pszData);
   int     load(char *pszFile);
   char    *solve(char *psz);
   int     add(Symbol *p);
   Symbol  *get(char *pszName,int *pstatic);
   void     reset();
   void     resetIndexes();
   int      astatic[1000+10];
private:
   void     fetch(char *pbuf, char *psrc, int nlen);
   char     *pszClFilename;
   char     szClBuf1[200];
   char     szClOut[10000];
   Symbol   *psym[1000];
   int     nsym;
};

static bool skipspace(char **ppsz) {
   char *psz = *ppsz;
   while (*psz && isspace(*psz))
      psz++;
   *ppsz = psz;
   return (*psz != 0);
}

static bool skipto(char **ppsz, char c) {
   char *psz = *ppsz;
   while (*psz && *psz != c)
      psz++;
   *ppsz = psz;
   return (*psz != 0);
}

Symbol::Symbol(char *pszName, Phraser *parent)
{
   memset(this,0,sizeof(*this));
   szClOpt[0] = '\0';
   if (cs.debug)
      printf(" create symbol: %s\n", pszName);
   char *pszopt = strchr(pszName, ',');
   if (pszopt) {
      strncpy(szClName, pszName, pszopt-pszName);
      szClName[pszopt-pszName] = '\0';
      strcopy(szClOpt, pszopt);
   } else {
      strcopy(szClName, pszName);
   }
   memset(szClCont, 0, sizeof(szClCont));
   phraser = parent;
}

bool Symbol::issep(char c)
{
   if (c == ',' || c== '\t')
      return 1;
   return 0;
}

bool Symbol::ispunctortab(char c)
{
   if (ispunct(c))
      return 1;
   if (c == '\t' || c == '\x01')
      return 1;
   return 0;
}

void Symbol::collect(char *pszContent)
{
   szLineBuf2[0] = '\0';
   copyFromFormText(pszContent, strlen(pszContent), szLineBuf2, MAX_LINE_LEN, 2);

   if (cs.debug)
      printf("   %s collects \"%s\"\n", szClName, szLineBuf2);

   strcat(szClCont, szLineBuf2);

   if (cs.debug)
      printf("   %s now holds \"%s\"\n", szClName, szClCont);
}

char *Symbol::solve(char *pout, int nmaxout, int nlevel, int istatic)
{
   if (cs.debug)
      printf(" %s %p solves \"%s\"\n", szClName, this, szClCont);

   char *pcont = szClCont;

   // if comma-separated phrases are given,
   // which are not escaped like \,
   bool biscsep = 0;
   char clast = 0;
   char *psz = 0;
   for (psz=pcont; *psz; psz++) {
      if (issep(*psz) == 1 && clast != '\\')
         {  biscsep=1; break; }
      clast = *psz;
   }

   if (biscsep)
   {
      // then random-select phrase

      // count phrases
      int nwords = 0;
      char *psz1 = pcont;
      for (clast=0; *psz1; psz1++) {
         if (issep(*psz1) == 1 && clast != '\\')
            nwords++;
         clast = *psz1;
      }
      nwords++;

      // select a phrase
      int itarg = 0;
      int imaxsymstat = (sizeof(phraser->astatic)/sizeof(int))-10;
      if (istatic > 0 && istatic < imaxsymstat) {
         if (phraser->astatic[istatic] < 0)
            phraser->astatic[istatic] = rand();
         itarg = phraser->astatic[istatic];
      } else {
         itarg = rand();
      }
      itarg = itarg % nwords;
      int iword = 0;
      psz1 = pcont;
      while (psz1 && *psz1)
      {
         char *psz2 = psz1;
         for (clast=0; *psz2; psz2++) {
            if (issep(*psz2) == 1 && clast != '\\')
               break;
            clast = *psz2;
         }
         if (iword == itarg) {
            mystrcopy(szClBuf2, psz1, psz2-psz1+1);
            if (cs.debug)
               printf("   sel \"%s\"\n", szClBuf2);
            pcont = szClBuf2;
            break;
         }
         iword++;
         if (issep(*psz2) == 1) psz2++;
         while (*psz2 == ' ') psz2++;
         psz1 = psz2;
      }
      if (pcont == szClCont) {
         perr("syntax error: probably too many commas in line: %s\n",szClCont);
         return 0;
      }
   }

   int iout = strlen(pout);

   if (!strchr(pcont, '$')) {
      // solve terminal
      strcat(pout, pcont);
   } else {
      // solve non-terminal
      char *psz1 = pcont;
      while (psz1 && *psz1)
      {
         char *psz2 = psz1;
         // find next sub symbol call, if any
         while (*psz2 && *psz2 != '$') psz2++;
         if (*psz2 == '$')
         {
            // flush pre-symbol content
            if (psz2 > psz1) {
               mystrcopy(szClBuf, psz1, psz2-psz1+1);
               if (cs.debug)
                  printf("   cat \"%s\"\n", szClBuf);
               strcat(pout, szClBuf);
            }
            // then solve sub symbol
            char *psz3 = psz2+1;
            while (   *psz3 && *psz3 != ' '
                   && *psz3 != '\\'
                   && !ispunctortab(*psz3)) psz3++;
            mystrcopy(szClBuf, psz2, psz3-psz2+1); // +1 for mystrcopy
            if (cs.debug)
               printf("  call \"%s\"\n", szClBuf);
            int istatic=0;
            Symbol *psub = phraser->get(szClBuf,&istatic);
            if (!psub) { perr("no such symbol: \"%s\"\n", szClBuf); return 0; }
            if (!psub->solve(pout, nmaxout, nlevel+1, istatic)) return 0;
            if (!strncmp(psz3, "\\+", 2))
               psz3 += 2;
            psz1 = psz3;
            if (cs.debug)
               printf("   now on \"%s\"\n",psz1);
            // strcat(pout, " ");
            continue;
         }
         // none found: flush rest of line
         if (cs.debug)
            printf("   cat \"%s\"\n", psz1);
         strcat(pout, psz1);
         // strcat(pout, " ");
         break;
      }
   }

   // post-process output:
   // printf("%02d appended \"%s\" at offs %d\n",nlevel,pout+iout,iout);

   // apply options, if any
   int nlen = strlen(pout);
   if (strstr(szClOpt, "upper") || strstr(szClOpt, "anycase"))
   {
      // random-vary word casing
      int ncase = 0;
      if (strstr(szClOpt, "anycase")) ncase = rand() % 4;
      if (strstr(szClOpt, "upper2"))  ncase = rand() % 2;
      // printf("%02d MIXCASE %d %c of %.30s\n",nlevel,ncase,pout[iout],pout+iout);
      int i=0;
      switch (ncase) {
         case 0: pout[iout] = toupper(pout[iout]); break;
         case 1:
            for (i=iout; i<nlen; i++)
               pout[i] = toupper(pout[i]);
            break;
         case 2: pout[iout] = tolower(pout[iout]); break;
         case 3:
            for (i=iout; i<nlen; i++)
               pout[i] = tolower(pout[i]);
            break;
         // case 4: break; // leave as it is
      }
   }

   // convert format strings
   for (psz=pout+iout; *psz; psz++) {
      char brep=0;
      if (clast == '\\')
       switch (*psz) {
         case ',' : brep=',' ; break;
         case 't' : brep='t' ; break;
         case '\t' : brep='\t' ; break;
         case 'n' : brep='n' ; break;
         case '\\': brep='\\'; break;
       }
      if (brep) {
         // standing on "," of "\,"
         psz--;
         memmove(psz, psz+1, strlen(psz+1)+1);
         clast = 0;
         *psz = brep;
      } else {
         clast = *psz;
      }
   }

   return pout;
}

Phraser::Phraser()
{
   pszClFilename = 0;
   memset(szClBuf1, 0, sizeof(szClBuf1));
   memset(psym, 0, sizeof(psym));
   nsym = 0;
   resetIndexes();
}

void Phraser::resetIndexes()
{
   int imaxsymstat=sizeof(astatic)/sizeof(int);
   for (int i=0; i<imaxsymstat; i++)
      astatic[i]=-1;
}

void Phraser::reset()
{
   for (int i=0; i<nsym; i++)
      delete psym[i];
   nsym = 0;
}

int Phraser::add(Symbol *p)
{
   if (nsym > (int)(sizeof(psym)/sizeof(Symbol*))-5)
      return 9+perr("too many symbols\n");
   psym[nsym++] = p;
   return 0;
}

Symbol *Phraser::get(char *pszNameIn,int *pstatic)
{
   char szName[200];
   strcopy(szName, pszNameIn);
   int istatic=0;
   if (isdigit(szName[1])) {
      istatic=atoi(szName+1);
      int imove=1;
      while (isdigit(szName[imove]))
         imove++;
      memmove(szName+1,szName+imove,strlen(szName+imove)+1);
      if (pstatic)
         *pstatic=istatic;
   }
   for (int i=0; i<nsym; i++) {
      if (!psym[i])
         return 0;
      if (!strcmp(psym[i]->name(), szName))
         return psym[i];
   }
   return 0;
}

void Phraser::fetch(char *pbuf, char *psrc, int nlen) {
   if (nlen > (int)sizeof(szClBuf1)-4)
      {  perr("buffer overflow.1\n"); exit(9); }
   strncpy(pbuf, psrc, nlen);
   pbuf[nlen] = '\0';
}

int Phraser::load(char *pszAll, char *pszData)
{
   char *pszSymb = 0;
   Symbol *ps = 0;
   int nstate = 1, nline = 0;
   int  iLineLen = 0;
   bool bAddLineFeed = 0;

   char *pszSrcCur = pszData;
   char *pszNext   = 0;

   while (*pszSrcCur)
   {
      if (pszAll) {
         snprintf(szLineBuf, MAX_LINE_LEN, "all: %s", pszAll);
         pszAll = 0;
      } else {
         pszNext = strchr(pszSrcCur, '\n');
         if (!pszNext)
            pszNext = pszSrcCur + strlen(pszSrcCur);
         int ilen = (int)(pszNext - pszSrcCur);
         if (ilen > MAX_LINE_LEN)
             ilen = MAX_LINE_LEN;
         memcpy(szLineBuf, pszSrcCur, ilen);
         szLineBuf[ilen] = '\0';
      }

      // symbol: word1 word2 $symbol word4
      //         word5 $symbol word6 ...
      removeCRLF(szLineBuf);
      nline++;

      if (cs.debug)
         printf("LINE \"%s\"\n", szLineBuf);

      char *psz1 = szLineBuf;

      if (szLineBuf[0]=='#' || szLineBuf[0]=='\0')
      {
         // skip
      }
      else
      while (psz1 && *psz1)
      {
         if (cs.debug)
            printf("state %d on \"%s\"\n", nstate, psz1);
         char *psz2 = psz1;
         switch (nstate)
         {
            case 1:  // expect new symbol name
               if (!skipto(&psz2, ':'))
                  return 9+perr("syntax error: missing \"symbol:\" in line %d\n", nline);
               fetch(szClBuf1, psz1, psz2-psz1);
               pszSymb = szClBuf1;
               psz1 = psz2+1;
               nstate = 2;
               break;

            case 2:  // expect content in symbol name line
               if (!skipspace(&psz2))
                  return 9+perr("syntax error: missing content after \"%s:\"\n", pszSymb);
               ps = new Symbol(pszSymb, this);
               if (add(ps)) return 9;
            case 4:
               if (!skipspace(&psz2))
                  return 9+perr("syntax error in line %d\n",nline);
               iLineLen = strlen(psz2);
               bAddLineFeed = 0;
               if (iLineLen >= 2 && strncmp(psz2+iLineLen-2, "\\n", 2) == 0) {
                  psz2[iLineLen-2] = '\0';
                  bAddLineFeed = 1;
               }
               ps->collect(psz2);
               psz1 = 0;
               nstate = 3;
               break;

            case 3:  // either additional content, or new symbol name
               if (*psz2 == ' ') {
                  // additional content
                  if (bAddLineFeed)
                     ps->collect(str("\n"));
                  else
                     ps->collect(str(" "));
                  nstate = 4;
                  continue;
               } else {
                  // new symbol name
                  nstate = 1;
                  continue;
               }
         }
      }

      if (pszNext) {
         pszSrcCur = pszNext;
         if (*pszSrcCur)
            pszSrcCur++;
      }
   }

   return 0;
}

char *Phraser::solve(char *pszName)
{
   // e.g. solving "all"
   Symbol *proot = get(pszName,0);
   if (!proot) return 0;
   szClOut[0] = '\0';
   char *pres = proot->solve(szClOut, sizeof(szClOut)-10, 0, 0);
   // convert ,, replacement code back to printable ,
   if (pres) {
      char *psz = pres;
      while ((psz = strchr(psz, 0x01)))
         *psz++ = ',';
   }
   return pres;
}

int execPhraser(char *pszAll, char *pszSrc, int iNumRec)
{
   Phraser *p = new Phraser();
   if (p->load(pszAll, (char*)pszSrc))
      return 9;

   for (int i=0; i<iNumRec; i++)
   {
      p->resetIndexes();

      char *pres = p->solve(str("all"));
      if (!pres) return 9+perr("cannot solve 'all'\n");

      if (chain.coldata) {
         if (chain.colbinary) {
            if (chain.addBinary((uchar*)pres, strlen(pres)))
               return 9;
         } else {
            if (chain.addLine(pres, str("")))
               return 9;
         }
      }
      else if (chain.colfiles) {
         Coi ocoi(pres, 0);
         if (chain.addFile(ocoi)) // is copied
            return 9+perr("out of memory");
      } else {
         printf("%s\n", pres);
      }
   }

   p->reset();
   delete p;

   return 0;
}

extern FILE *fGlblOut;

int dumpBlock(uchar *pCur, int lSize, int nmode)
{
   FILE *fout = fGlblOut;
   int i=0;
   switch (nmode)
   {
      case 2:
      {
         bool bAddPad = ((lSize & 1) != 0);
         fprintf(fout, "\t\"");
         uchar u1, u2;
         for (i=0; i<lSize; i += 2) {
            // if input has uneven size, the very last byte
            // is not read from input, but filled with dummy 0xFF.
            u1 = pCur[i+0];
            if (i < lSize-2 || !bAddPad)
               u2 = pCur[i+1];
            else
               u2 = 0xFF;
            fprintf(fout, "\\u%02x%02x", u1, u2);
         }
         fprintf(fout, "\",");
      }
         break;

      case 1:
         for (i=0; i<lSize; i++) {
            if (pCur[i])
               fprintf(fout, "0x%x,", pCur[i]);
            else
               fprintf(fout, "0,");
         }
         break;

      default:
         for (i=0; i<lSize; i++)
            fprintf(fout, "%u,", (unsigned int)pCur[i]);
         break;
   }
   fprintf(fout,"\n");
   return 0;
}

uchar *binPack(uchar *pIn, uint nInSize, ulong &rnOutSize)
{__
   ulong nOutSize = 0;
   uchar *pOut = 0;
   uchar *pMem = 0;
   uchar *pMax = pIn + nInSize;
   uchar *pCur = 0;
   uchar *pOld = 0;
   uchar *pNul = 0;

   for (uchar npass=1; npass <= 2; npass++)
   {
      if (npass == 1)
         pOut = pNul;
      else {
         pMem = new uchar[nOutSize];
         pOut = pMem;
      }

      pCur = pIn;
      pOld = pCur;

      while (pCur < pMax)
      {
         // detect repetition of patterns up to size 3
         uchar nbestsize = 0;
         uchar nbestgain = 0;
         uchar nbestrep  = 0;
         for (uchar isize = 1; isize <= 3; isize++) {
            uchar nrep  = 0;
            uchar bbail = 0;
            for (; (pCur+(nrep+1)*isize < pMax) && (nrep < 60) && !bbail; nrep++)
            {
               for (uchar i1=0; (i1<isize) && !bbail; i1++)
                  if (pCur[nrep*isize+i1] != pCur[i1])
                     bbail = 1;
               if (bbail)
                  break;
            }
            // this always results in nrep >= 1.
            uchar ngain = (nrep-1)*isize;
            if (ngain >= 3) {
               // there is a repetition, saving at least 3 bytes.
               // determine max savings accross all sizes.
               if (ngain > nbestgain) {
                  nbestgain = ngain;
                  nbestsize = isize;
                  nbestrep  = nrep;
               }
            }
         }
         // if (nbestrep > 0)
         //   printf("size %02u rep %02u gain %02u at %x\n", nbestsize, nbestrep, nbestgain, pCur-pIn);

         // if repeat pattern found,
         // OR if non-repeat exceeds maxsize
         if ( (nbestrep > 0) || ((pCur - pOld) >= 60) ) {
            // flush non-packable, if any
            if (pCur > pOld) {
               // printf("[flush non-pack %x]\n", pCur-pOld);
               uchar nDist = pCur-pOld;
               if (npass == 1) {
                  pOut++;
                  pOut += (pCur - pOld);
               } else {
                  *pOut++ = 0x00 | nDist;
                  while (pOld < pCur)
                     *pOut++ = *pOld++;
               }
               pOld  = pCur;
            }
            // flush packable, if any
            if (nbestrep > 0) {
               // printf("[pack %x %x]\n", nbestsize, nbestrep);
               if (npass == 1) {
                  pOut++;
                  pOut += nbestsize;
                  pCur += nbestsize;
               } else {
                  *pOut++ = (nbestsize << 6) | nbestrep;
                  for (uchar i1=0; i1<nbestsize; i1++)
                     *pOut++ = *pCur++;
               }
               pCur += (nbestrep-1)*nbestsize;
               pOld  = pCur;
            }
         } else {
            // count non-packable
            pCur++;
         }
      }

      // flush remainder, if any
      if (pCur > pOld) {
         // printf("[flush trailer %x]\n", pCur-pOld);
         uchar nDist = pCur-pOld;
         if (npass == 1) {
            pOut++;
            pOut += (pCur - pOld);
         } else {
            *pOut++ = 0x00 | nDist;
            while (pOld < pCur)
               *pOut++ = *pOld++;
         }
         pOld  = pCur;
      }

      if (npass == 1) {
         nOutSize = (ulong)(pOut - pNul);
         // printf("packsize %lu\n", nOutSize);
      }
   }

   rnOutSize = nOutSize;
   return pMem;
}

uchar *binUnpack(uchar *pIn, uint nInSize, ulong &rnOutSize)
{__
   ulong nOutSize = 0;
   uchar *pOut = 0;
   uchar *pMem = 0;
   uchar *pMax = pIn + nInSize;
   uchar *pCur = 0;
   uchar *pOld = 0;
   uchar *pNul = 0;

   for (uchar npass=1; npass <= 2; npass++)
   {
      if (npass == 1)
         pOut = pNul;
      else {
         pMem = new uchar[nOutSize];
         pOut = pMem;
      }

      pCur = pIn;
      pOld = pCur;

      while (pCur < pMax)
      {
         uchar ncmd = *pCur++;
         if (ncmd >= 64) {
            // unpack repeat block
            uchar nsiz = ncmd >> 6;
            uchar nrep = ncmd & 0x3F;
            // printf("[upack-rep %x %x (%x)]\n", nsiz, nrep, ncmd);
            // reproduce reference pattern nrep times
            if (npass == 1)
               pOut += nrep * nsiz;
            else
            for (; nrep > 0; nrep--)
               for (uchar i1=0; i1<nsiz; i1++)
                  *pOut++ = *(pCur+i1);
            // skip reference pattern
            pCur += nsiz;
         } else {
            // unpack skip block
            uchar nrep = ncmd;
            // printf("[upack-skip %x]\n", nrep);
            if (npass == 1) {
               pOut += nrep;
               pCur += nrep;
            }
            else
            for (; (nrep > 0) && (pCur < pMax); nrep--)
               *pOut++ = *pCur++;
         }
      }

      if (npass == 1) {
         nOutSize = (ulong)(pOut - pNul);
         // printf("unpacksize %lu\n", nOutSize);
      }
   }

   rnOutSize = nOutSize;
   return pMem;
}

int execBinToJava(uchar *pIn, int lInSize, bool bPack, char *pszNameBase, bool bClass, int nRecSize)
{__
   FILE *fout = fGlblOut;

   if (bClass)
   fprintf(fout,
      "\n"
      "import java.io.*;\n"
      "\n"
      "public class %s {\n"
      "\n"
      "\tpublic static void main(String args[]) throws Throwable {\n"
      "\t\tbyte abData[] = %s_getBlock();\n"
      "\t\tFileOutputStream fout = new FileOutputStream(args[0]);\n"
      "\t\tfout.write(abData, 0, abData.length);\n"
      "\t}\n"
      "\n"
      ,pszNameBase,pszNameBase
      );

   fprintf(fout,
      "\tpublic static int %s_BlockSize = %d;\n"
      "\tstatic String %s_RawBlock[] = {\n"
      ,pszNameBase,lInSize,pszNameBase);

   int lRemain = lInSize;
   uchar *pCur  = pIn;
   while (lRemain > nRecSize) {
      dumpBlock(pCur, nRecSize, 2);
      lRemain -= nRecSize;
      pCur += nRecSize;
   }
   if (lRemain > 0)
      dumpBlock(pCur, lRemain, 2);

   fprintf(fout, "\t};\n\n");

   char *pname=pszNameBase;
   fprintf(fout,
      "\tpublic static byte[] %s_getBlock() {\n"
      "\t   int iout=0, nblen=%s_BlockSize;\n"
      "\t   char atmp[] = new char[%d];\n"
      "\t   byte aout[] = new byte[nblen];\n"
      "\t   for (int i=0; i<%s_RawBlock.length; i++) {\n"
      "\t      String stmp = %s_RawBlock[i];\n"
      "\t      int nlen = stmp.length();\n"
      "\t      stmp.getChars(0,nlen,atmp,0);\n"
      "\t      for (int k=0; k<nlen; k++) {\n"
      "\t         char c = atmp[k];\n"
      "\t         byte bhi = (byte)(c >> 8);\n"
      "\t         byte blo = (byte)(c >> 0);\n"
      "\t         aout[iout++] = bhi;\n"
      "\t         if (iout < nblen)\n"
      "\t            aout[iout++] = blo;\n"
      "\t      }\n"
      "\t   }\n"
      "\t   return aout;\n"
      "\t}\n\n"
      ,pname,pname,nRecSize,pname,pname
      );

   if (bClass)
   fprintf(fout,
      "}\n\n"
      );

   return 0;
}

int execBinToCpp(uchar *pIn, int lInSize, bool bPack, char *pszNameBase, bool bHex)
{__
   int lOldInSize = lInSize;

   if (bPack) {
      ulong nPackSize = 0;
      // binPack alloc's mem block with packed data
      pIn = binPack(pIn, lInSize, nPackSize);
      lInSize = (int)nPackSize;
   }

   fprintf(fGlblOut,"#define %s_BLOCK_SIZE %u\n\n", pszNameBase, lOldInSize);
   fprintf(fGlblOut,"static unsigned char %s_abRawBlock[%u] = {\n", pszNameBase, lInSize);
   int lRemain = lInSize;
   uchar *pCur  = pIn;
   while (lRemain > 32) {
      dumpBlock(pCur, 32, bHex ? 1 : 0);
      lRemain -= 32;
      pCur += 32;
   }
   if (lRemain > 0)
      dumpBlock(pCur, lRemain, bHex ? 1 : 0);
   fprintf(fGlblOut,"};\n");

   if (bPack) {
fprintf(fGlblOut,
   "\n"
   "// input : target buffer and buffer size.\n"
   "//         must have size >= %s_BLOCK_SIZE.\n"
   "// result: 0 if OK, 9 on buffer overflow.\n"
   "// note  : output data is not null terminated.\n"
   "int %s_getBlock(uchar *pOut, uint nOutSize)\n",
   pszNameBase, pszNameBase
   );
fprintf(fGlblOut,
   "{\n"
   "   uchar *pCur    = %s_abRawBlock;\n"
   "   uint nInSize  = %u;\n"
   "   uchar *pMax    = pCur + nInSize;\n"
   "   uchar *pOutMax = pOut + nOutSize;\n"
   "   while (pCur < pMax)\n"
   "   {\n"
   "      uchar ncmd = *pCur++;\n"
   "      if (ncmd >= 64) {\n"
   "         uchar nsiz = ncmd >> 6;\n"
   "         uchar nrep = ncmd & 0x3F;\n"
   "         for (; nrep > 0; nrep--)\n"
   "            for (uchar i1=0; i1<nsiz; i1++) {\n"
   "               if (pOut >= pOutMax) return 9;\n"
   "               *pOut++ = *(pCur+i1);\n"
   "            }\n"
   "         pCur += nsiz;\n"
   "      } else {\n"
   "         uchar nrep = ncmd;\n"
   "         for (; (nrep > 0) && (pCur < pMax); nrep--) {\n"
   "            if (pOut >= pOutMax) return 9;\n"
   "            *pOut++ = *pCur++;\n"
   "         }\n"
   "      }\n"
   "   }\n"
   "   return 0;\n"
   "}\n",
   pszNameBase, lInSize
      );
      delete [] pIn;
   }

   return 0;
}

void printSearchReplaceCommands()
{
printx("   $see also\n"
       "      #sfk xfind<def>     search  wildcard text in   text/binary files\n"
       "      #sfk xtext<def>     search  wildcard text in   text files  only\n"
       "      #sfk xhexfind<def>  search  in text/binary with hex dump output\n"
       "      #sfk extract<def>   extract wildcard data from text/binary files\n"
       "      #sfk filter<def>    filter  and edit text with simple wildcards\n"
       "      #sfk find<def>      search  fixed    text in   text/binary files\n"
       "      #sfk ftext<def>     search  fixed    text in   text        files\n"
       "      #sfk hexfind<def>   search  fixed    text in        binary files\n"
       "      #sfk replace<def>   replace fixed    text in   text/binary files\n"
       "\n");
}

void printSFKMatchHelp(bool bRepHelp, bool bFullHelp=1)
{
printx("   $wildcards and SFK expressions\n"
       "      SFK Expressions are simple patterns containing literal text,\n"
       "      wildcards * and ? and character classes in square brackets [].\n"
       "      basically, the syntax provides extended wilcards but no\n"
       "      further logic and is not related to regular expressions.\n"
       "\n"
       "      search patterns are surrounded by a separator character which\n"
       "      can be anything not contained in the search text, like / or _\n"
       "\n");
if (bRepHelp)
printx("      $within a pattern #/fromtext/totext/<def> $the #fromtext<def> $may contain:\n");
else
printx("      $within a search pattern #/fromtext/<def> $the #fromtext<def> $may contain:\n");
printx("\n"
       "        $*<def>                       - 0 to 4000 characters in the same\n"
       "                                  text line or paragraph, i.e. all\n"
       "                                  bytes not being CR, LF or NULL.\n"
       "                                  4000 is just a default maximum\n"
       "                                  that can be changed by:\n"
       "        $[0.100000 chars]<def>        - 0 to 100000 characters in the same\n"
       "                                  text line or paragraph, i.e. the\n"
       "                                  same as * but with a larger range.\n"
       "        $?<def>                       - one character.\n"
       "        $???\x3f\x3f<def>                   - same as $[5.5 chars]<def> or $[5 chars]<def>\n"
       "        $[bytes]<def>                 - 0 to 4000 bytes (with CR,LF,NULL)\n"
       "                                  i.e. it collects stream text\n"
       "                                  across lines, even in binary data\n"
       "        $**<def>                      - the same as [bytes].\n"
       "        $[0.100 bytes]<def>           - 0 to 100 bytes\n"
       "        $[.100000 bytes]<def>         - up to 100000 bytes\n"
       "        $[1.* bytes]<def>             - 1 to default maximum bytes\n"
       "        $[30 bytes]<def>              - exactly 30 bytes\n"
       "        $[byte of aeiou]<def>         - one vocal (a OR A OR e OR ...),\n"
       "                                  case insensitive by default.\n"
       "                                  \"aeiou\" is a character list.\n"
       "        $[byte of \\\\\\x2f]<def>        - a backslash \\ or forw. slash /\n"
       "        $[bytes of \\r\\n \\t]<def>      - whitespace incl. line ends\n"
       "        $[bytes of (\\r\\n \\t)]<def>    - the same, () are optional\n"
       "        $[bytes not \\r\\n\\0]<def>      - up to 4000 bytes as long as no\n"
       "                                  CR, LF or NULL byte appears\n"
       );
printx("        $[chars]<def>                 - the same as $[bytes not \\r\\n\\0]<def>,\n"
       "                                  i.e. collect text in a line\n"
       "        $[char not ( \\t)]<def>        - same as $[byte not ( \\r\\n\\0\\t)]<def>,\n"
       "                                  everything not blanks and tabs\n"
       "        $[char not )( \\t]<def>        - not brackets, blanks and tabs,\n"
       "                                  same as $not (\\(\\) \\t)<def>\n"
       "        $[chars of a-z0-9]<def>       - means a-zA-Z0-9 as search is\n"
       "                                  case insensitive by default\n"
       "        $[chars of \\x61-\\x7A]<def>    - search a-z but not A-Z, or use\n"
       "                                  option -case for case search\n"
    // "        $[others]<def>                - all chars or bytes NOT searched\n"
    // "                                  by previous part\n"
       "        $[eol]<def>                   - end of line by characters:\n"
       "                                  CRLF or LF or CR\n"
    // "        $[start or byte of \\r\\n]<def> - start of file or CR or LF.\n"
    // "        $[end or byte of \\r\\n]<def>   - end of file or CR or LF.\n"
       "\n"
       );
printx("        $[white]<def>     = chars of (\\t )     - 0 or more whitespaces\n"
       "        $[xwhite]<def>    = bytes of (\\t \\r\\n) - same but across lines\n"
       "        $[1 white]<def>   = byte  of (\\t )     - 1 whitespace\n"
       "        $[digit]<def>     = byte  of (0-9)     - 1 digit\n"
       "        $[digits]<def>    = bytes of (0-9)     - 0 or more digits\n"
       "        $[hexdigit]<def>  = byte  of (0-9a-f)  - 1 hexadecimal digit\n"
       "        $[hexdigits]<def> = bytes of (0-9a-f)  - 0 or more hex digits\n"
       "\n"
       );
#ifdef SFK_LOR
printx("        special keywords that do not count as tokens:\n"
       "        $[keep]<def>   - search also the following text but keep it\n"
       "                   in the input data, without consuming it\n"
       "        $[ortext]<def> - foo[ortext]bar searches word foo or bar.\n"
       "                   [ortext] is allowed only between literals.\n"
       "\n"
       );
#endif // SFK_LOR
printx("        anchors that have no length of their own:\n"
       "        $[start]<def>  - start of file\n"
       "        $[end]<def>    - end of file\n"
       "        $[lstart]<def> - line start, i.e. start or CRLF or CR or LF\n"
       "        $[lend]<def>   - logical line end, i.e. eol or end of file\n"
       "\n"
       );
printx("        $how to search or replace special characters:\n"
       "        - to search or replace text containing the literal characters\n"
       "          $* ? \\ [ ]<def> then these must be escaped like #\\\\* \\? \\\\ \\[ \\]<def>\n"
       "        - $( )<def> are escaped only within character lists, like #\\( \\)<def>\n"
       "        - to search or replace the $forward slash '/'<def> type $\\x2f<def> or use\n"
       "          another char around from/to text, e.g. #_fromtext_totext_<def>\n"
       "        - parameters with #blanks and non trivial characters<def> need double\n"
       "          quotes \"\", see also \"about Shell Command Characters\" below.\n"
       "\n"
       );
printx("        $expansion priorities:<def> (highest first)\n"
       "        if two search parts are side by side, and the same input\n"
       "        character matches both, then these priorities apply:\n"
       "\n"
       "          5: start, end, lstart, lend\n"
       "          4: literal text, eol\n"
       "          3: whitelist classes: byte of, bytes of\n"
       "          2: blacklist classes: chars not, bytes not\n"
       "          1: plain wildcards: ?, *, **, byte, bytes, chars\n"
       "\n"
       "        this means in \"/[bytes]foo/\" the [bytes] will stop to collect\n"
       "        characters as soon as \"foo\" is found, as \"foo\" is a literal.\n"
       "        on same or higher priority the right side stops the left side.\n"
       "\n"
       );
if (bRepHelp)
printx("      $the #totext<def> $may contain:\n"
       "\n"
       "        $[part 1]<def>          - use first text part of the fromtext.\n"
       "                            e.g. the fromtext #/*foo[.100 chars]bar*/<def>\n"
       "                            contains parts    # 1 2         3    4 5\n"
       "        $[part1]<def>           - the same (blank is optional).\n"
       "        $[parts 1,2,3]<def>     - use parts 1, 2 and 3.\n"
       "        $[parts 1-10]<def>      - use parts 1 to 10.\n"
       "        $[strip(part1,\\0)]<def> - use part 1 but remove zero bytes.\n"
       "                            only zero bytes \"\\0\" can be removed.\n"
       "        $[file.name]<def>       - full input filename with path\n"
       "        $[file.relname]<def>    - input filename without path\n"
       "        $[file.path]<def>       - input file's path\n"
       "        $[file.base]<def>       - relname without last .extension\n"
       "        $[file.ext]<def>        - input filename extension\n"
       "        $[all]<def>             - use all parts from fromtext.\n"
       "\n"
       "        $[setvar name]...[endvar]<def> - set variable \"name\" with data\n"
       "                                   between setvar and endvar.\n"
       "        $[getvar name]<def>            - fill in data from variable \"name\"\n"
       "\n"
       "        although anchors like lstart, lend count as a separate part\n"
       "        they need NOT be specified in the totext. this means that\n"
       "        /[lstart]foo[lend]/bar/ just changes the word \"foo\".\n"
       "\n"
       );
printx("   $supported slash patterns\n"
       "      $\\t<def>    = TAB\n"
       "      $\\r<def>    = CR\n"
       "      $\\n<def>    = LF\n"
       "      $\\x00<def>  = one byte with code 00 hexadecimal\n"
       "      $\\0<def>    = short form for \\x00\n"
       "      $\\q<def>    = a double quote \"\n"
       "      $\\\\ <def>   = the backslash character \\ itself\n"
       "      $\\[<def>    = the bracket open character [\n"
       "      $\\]<def>    = the bracket close character ]\n"
       "      $\\\\*<def>    = the literal star character *\n"
       "      $\\?<def>    = the literal question mark  ?\n"
       "      $\\-<def>    = to use literal \"-\" in a command\n"
       "      Within multi line -bylist files:\n"
       "      $\\ <def>    = slash+blank is changed to a single blank\n"
       "      Only within \"char of\" or \"byte not\" lists:\n"
       "      $\\(<def>    = to use literal character \"(\"\n"
       "      $\\)<def>    = to use literal character \")\"\n"
       "\n"
       );
printx("   $SFK expression options\n"
       "      -showpart(s)  print /from/ part numbers, range statistics\n"
       "                    and expansion priority points per part.\n"
       "                    done automatically if a required /to/ text\n"
       "                    is not given with a command.\n"
       "      -showbest     if a /from/ pattern finds nothing, use this to\n"
       "                    see how many parts would match so far, and with\n"
       "                    up to how many bytes per part. anchors like [lstart]\n"
       "                    may show a non zero length when matching (CR)LF.\n"
       "      -showlist     with -bylist, show the internal joined list if\n"
       "                    commands are spread across multiple lines.\n"
       "      -showall      show all of the above.\n"
       "      -xmaxlen=n    set default maximum length for chars or bytes commands,\n"
       "                    e.g. -xmaxlen=10000 means /foo*bar/ matches with up to\n"
       "                    10000 characters between foo and bar. the default max\n"
       "                    length without this option is 4000 characters.\n"
       "\n"
       );
printx("   $performance notes\n"
       "    - always use a string literal, or single byte or char, at the start\n"
       "      of your search expressions, like in $/foo*bar/ starting with 'f'.\n"
       "      #Do not use a wildcard like * at the start like in #/*foobar/<def>\n"
       "      when searching huge input data, as your search will #slow down by\n"
       "      #factor 256.<def> Use $/[lstart]*foobar/<def> instead.\n"
       "    - the system may cache output file(s), writing to disk in background\n"
       "      after sfk has finished. subsequent batch commands may execute slower.\n"
       "\n"
       );
}

void printAboutBracketExamples()
{
printx("   $about example numbers with [brackets]\n"
       "      if you see [1] type \"sfk cmd 1\" for whole command in one line.\n"
       "\n");
}

void printXRepExamples(char *pszCmd, bool bFind, bool bRep)
{
printAboutBracketExamples();
printx("   $bad examples with corrections\n"
       "      #if input text contains:\n"
       "         bool bClFoo;\n"
       "         bool bClBar   ;\n"
       "      #sfk xfind in.txt \"/bool[xwhite]bCl*[xwhite];/\"\n"
       "         does NOT match \"bool bClFoo;\" because * eats the\n"
       "         whole input line including \";\" so no input is left\n"
       "         for \"[xwhite];\" and the whole expression fails.\n"
       "      #sfk xfind in.txt \"/bool[xwhite]bCl[* not ;][xwhite];/\"\n"
       "         does both match \"bool bClFoo;\" and \"bool bClBar   ;\".\n"
       "         this means whenever your search fails to work write\n"
       "         in detail which characters (not) to collect where.\n"
       "      #sfk xex in.txt \"/[lstart]foo/[lstart]goo/\"\n"
       "         there is no need to write an anchor like [lstart]\n"
       "         within totext as it contains no data. use instead:\n"
       "            sfk xex in.txt \"/[lstart]foo/goo/\"\n"
       "      #sfk xex in.txt \"/foo[lend]bar/goo[part2]bar/\"\n"
       "         anchors like [lend] must be at start or end of fromtext\n"
       "         and cannot be referenced within totext. use instead:\n"
       "            sfk xex in.txt \"/foo[eol]bar/goo[part2]bar/\"\n"
       "\n"
       );

printx("   $working examples\n");

if (bRep)
{
printx("      #sfk xrep mydir \"/foo*bar/\"\n"
       "         an incomplete command (missing \"totext\" part in pattern).\n"
       "         sfk shows an info text telling about part numbers\n"
       "         and runs a search for \"foo*bar\" in all files of mydir.\n"
       "         nothing is changed so far.\n"
       "      #sfk xrep mydir \"/foo*bar/[part1]goo[part3]/\"\n"
       "         same as above, but now the /fromtext/totext/ is complete.\n"
       "         again sfk runs a search for \"foo*bar\", but now it displays\n"
       "         the changed output text (totext), with everything between\n"
       "         \"foo\" and \"bar\" being changed to \"goo\". add option\n"
       "         -dumpfrom to display the original found text instead.\n"
       "      #sfk xrep -text \"/class* CFoo/[part1][part3]/\" -dir mydir -file .hpp\n"
       "         search only .hpp files within mydir, and replace for example\n"
       "         \"class IMPORT CFoo\" by \"class CFoo\".\n"
       "      #sfk xrep -pat \"/[byte not \\n][end]/[part1]\\n/\"\n"
       "       #-dir mydir -file .cpp .hpp -dumpall\n"
       "         find all .cpp or .hpp files in mydir whose last line is not\n"
       "         ending with a linefeed, and add the linefeed. to check exactly\n"
       "         what is changed dump both input and output text. [23]\n"
       "      #sfk xrep -dir mydir -file .hpp -enddir\n"
       "       #-text \"/[byte not \\n][end]/[part1]\\n/\" -dumpall\n"
       "         same as above but with dir parameters first. [25]\n"
       "      #sfk xrep io.txt \"/[lstart][20 chars]*/[part3]/\"\n"
       "         cut first 20 characters in every line of io.txt.\n"
       );
printx("      #sfk xrep io.txt \"/[lstart][9 bytes]1001*/[part2]9009[part4]/\"\n"
       "         in fixed position text file data like:\n"
       "            rec. 001:5318 aef3 2751 1001\n"
       "            rec. 002:1001 aef5 275a 1001\n"
       "            rec. 003:ef49 aef7 2763 1001\n"
       "         replace \"1001\" where it appears in columns 10 to 13,\n"
       "         in this example only the first \"1001\" in record 2.\n");
printx("      #sfk xrep in.dat \"/\\xFF\\xFE[1 byte]\\x80\\x81/\\xFF\\xFE\\x00\\x80\\x81/\"\n"
       "         replace byte sequences (not ASCII text strings) in binary data.\n"
       "         searches byte groups starting with values 0xFF 0xFE, then any\n"
       "         single byte, then 0x80 0x81, and replaces the variable byte\n"
       "         by always a binary 0x00 value.\n"
       );
}
if (bFind)
{
printx("      #sfk xfind -text \"/class [bytes]{[bytes]}/[all]\\n\\n/\"\n"
       "       #-dir mydir -file .hpp +tofile out.txt\n"
       "         collect class definitions from mydir and write output\n"
       "         indirectly (via command chaining) to out.txt [13]\n");
printx("      #sfk %s in.txt -text \"/foo*bar/\"\n"
       "         search in.txt for patterns starting with foo and ending\n"
       "         with bar, in the same line, with up to 4000 characters inbetween.\n"
       "      #sfk xhex -text \"/foo[0.100000 bytes]bar/\" -dir mydir\n"
       "         search all text and binary files of mydir for patterns of\n"
       "         foo and bar with 0 to 100000 bytes (including NULL, CR\n"
       "         and LF) inbetween and print output as hex dump.\n"
       "      #sfk %s -text \"/printf(**);/\" -dir mydir -file .cpp\n"
       "         find all printf statements in source code, including statements\n"
       "         across multiple lines.\n"
       , pszCmd, pszCmd
       );
}
}

// for filter
void printBewareWide( )
{
   printx("   $beware of Shell Command Characters.\n" // filter, wide
          "      to find or replace text containing #spaces<def> or special characters like #<>|!&?*<def>\n"
          "      you #must add quotes \"\" around parameters or the shell will #destroy your command<def>.\n"
          "      it splits the command into parts and gives SFK only one part, causing errors.\n"
          "      therefore #-replace _ _&nbsp;_<def> must be written like: #-replace \"_ _&nbsp;_\"\n"
          #ifdef _WIN32
          "      within a $.bat or .cmd file<def> the #percent %%<def> must be escaped like #%%%%<def> even\n"
          "      within quoted strings: #sfk echo -spat \"percent %%%% is a percent \\x25\"<def>\n"
          #else
          "      within a $bash batch file the #dollar $$ must<def> be escaped like #\\$$<def> even\n"
          "      within quoted strings: #sfk echo -spat \"dollar \\$$ is a dollar \\x24\"<def>\n"
          #endif
          "\n"
          );
}

// for replace, xed
void printBewareLean( )
{
   printx("   $beware of Shell Command Characters.\n" // replace, lean
          "      to find or replace text patterns containing #spaces<def> or special\n"
          "      characters like #<>|!&?*<def> you #must add quotes \"\"<def> around parameters\n"
          "      or the shell environment will #destroy your command<def>. for example,\n"
          "      pattern #/foo bar/other/<def> must be written like #\"/foo bar/other/\"\n"
          #ifdef _WIN32
          "      within a $.bat or .cmd file<def> the #percent %%<def> must be escaped like #%%%%<def>\n"
          "      even within quotes: #sfk echo -spat \"percent %%%% is a percent \\x25\"<def>\n"
          #else
          "      within a $bash batch file the #dollar $$ must<def> be escaped like #\\$$<def> even\n"
          "      within quoted strings: #sfk echo -spat \"dollar \\$$ is a dollar \\x24\"<def>\n"
          #endif
          "\n"
          );
}

extern int  nGlblConsColumns;
extern bool bGlblConsColumnsSet;

void webref(cchar *pszIn);

void printHelpText(char *pszSub, bool bhelp)
{
   if (!strncmp(pszSub, "color", 5))
   {
      printx("<exp> SFK_COLORS=off|on,err:n,warn:n,head:n,examp:n,file:n,hit:n,rep:n,pre:n\n");
      printx("<exp> SFK_COLORS=bright|dark,theme:black|theme:white\n");
      printx("\n"
             "   color identifiers are\n"
             #ifndef _WIN32
             "      def       default color (black by default)\n"
             #endif
             "      err       error   messages\n"
             "      warn      warning messages\n"
             "      head      headlines in help text\n"
             "      examp     examples  in help text\n"
             "      file      filename listings in find\n"
             #ifndef _WIN32
             "      link      symbolic link files or directories\n"
             #endif
             "      hit       text pattern hits in find and filter\n"
             "      rep       replaced patterns in filter\n"
             "      pre       line prefix symbols in find\n"
             "      time      time or low-prio status infos\n"
             "      traceinc  with -tracesel, included names\n"
             "      traceexc  with -tracesel, excluded names\n"
             "\n"
             "   color code n is a combination of these values:\n"
             "      0 = black\n"
             "      1 = bright\n"
             "      2 = red\n"
             "      4 = green\n"
             "      8 = blue\n"
             "\n"
             "   some commands like \"sfk echo\" also accept direct color names:\n"
             "   red,green,blue,yellow,cyan,magenta,default,Red,Green,Blue...\n"
             "   sfk for windows tries to autoselect color brightness if a black\n"
             "   or white shell background is found. otherwise the spelling matters:\n"
             "   red means dark red, and Red means bright red.\n"
             "   you may also set SFK_COLORS to bright or dark, or specify options\n"
             "   -bright or -dark in your command, to force all plain text colors\n"
             "   to the same brightness, regardless of spelling.\n"
             "\n"
             "   examples for color schemes:\n"
             "\n"
             );
      printx("      neutral, compatible to black and white backgrounds:\n"
             "         <exp> SFK_COLORS=head:5,examp:11,file:11,hit:5,rep:7\n"
             "\n");
      printx("      black background optimized theme:\n"
             "         <exp> SFK_COLORS=theme:black\n"
             "\n");
      printx("      white background optimized theme:\n"
             "         <exp> SFK_COLORS=theme:white\n"
             "\n");
      printx("      switch off colored output:\n"
             "         <exp> SFK_COLORS=off\n\n");
      #ifdef _WIN32
      printx("   to switch off colors per command, use general option -nocol .\n");
      #else
      printx("   by default, colors are inactive on unix, as there are some potential problems\n"
             "   depending on the background color of your shell, and if you want to post-process\n"
             "   command output. if you feel lucky, add -col in front of a command, or say\n"
             "\n"
             "      export SFK_COLORS=on,def:0      or    export SFK_COLORS=on,def:14\n"
             "      with bright shell backgrounds         with black shell backgrounds\n"
             );
      #endif

      printx("\n"
             "   to TEST current active colors, type: sfk colortest\n"
             );
   }

   if (!strncmp(pszSub, "opt", 3))
   {
      printx("$sfk general options reference%s:\n",
             bhelp ? " (type \"sfk help options\")":"");
      printx("\n"
         "   Please note: some of these options are supported only by some commands.\n"
         );
      printx("\n"
         "   $-var<def>       insert SFK variables by using ##(varname). type this\n"
         "              option directly after \"sfk\" to use it globally with all\n"
         "              commands in a chain or script. to print \"##(\" literally\n"
         "              then escape it like ####(\n"
         #ifdef _WIN32
         "   $-upat<def>      unix compatible file or text selection and patterns.\n"
         "              allows to use -subdir :tmp instead of !tmp, filter -:foo\n"
         "              instead of -!foo and run \"##file\" instead of \"$$file\",\n"
         "              to create unified .sh batch files for Windows and Linux.\n"
         "   $-upat2<def>     same as -upat but also support wildcard %% instead of *\n"
         "              you may also set this by an environment variable like:\n"
         "              <exp> SFK_CONFIG=upat2\n"
         #endif
         "   $-nosub<def>     or -norec does not include subdirectories (subfolders).\n"
         "              processing of subdirs is DEFAULT with most commands,\n"
         "              therefore you must specify -nosub to switch it off.\n"
         "   $-withsub<def>   include subdirs. is DEFAULT with most commands.\n"
         /*
         "   $-strict<def>    with run, perline, -to: produce an error if unknown\n"
         "              tokens like <run>foo are found. these must then be\n"
         "              escaped like <run><run>foo\n"
         "   $-nostrict<def>  with run, perline, -to: keep unknown tokens as is.\n"
         "              may cause script failures with future versions of sfk\n"
         "              that may add new sfk builtin tokens.\n"
         */
         "   $-verbose<def>   print additional infos while running a command.\n"
         "              helpful if a command doesn't work as expected.\n"
         "              only some commands support -verbose. try also -verbose=2.\n"
         #if (!defined(SFK_LIB5))
         "   $-nofollow<def>  or -nofo does not follow symbolic directory links.\n"
         "              this option may NOT work with older Linux versions,\n"
         "              esp. those needing the \"lib5\" binary version of sfk.\n"
         #endif
         #ifndef _WIN32
         "   $-showskip<def>  tell whenever directory contents are skipped to avoid\n"
         "              double processing caused by symbolic links.\n"
         "   $-allowdups<def> disable detection of duplicate directory contents.\n"
         "                 may cause endless recursion on links like \"X11\"->\".\"\n"
         #endif
         "   $-quiet<def>     reduce output on some commands. e.g. the find command will\n"
         "              not display the \"scan\" status info while searching files.\n"
         "   $-quiet=2<def>   reduce output even more on some commands.\n"
         #ifdef SFK_MEMTRACE
         "   $-memcheck<def>  check memory list at the end of every command\n"
         "              to detect overwrites. reduces performance.\n"
         #endif
         "   $-debug<def>     print extra program flow infos to track errors.\n"
         #ifdef SFK_MEMTRACE
         "              also activates -memcheck under Windows.\n"
         #endif
         );
  printx("   $-nohead<def>    no not list header/trailer info on some commands: the run cmd\n"
         "              will not tell \"simulating\" even if it's in simulation mode.\n"
         "   $-case<def>      activate case sensitive text comparison with some commands.\n"
         "              most text processing commands are case-insensitive by default.\n"
         "              filename comparison is always case insensitive.\n"
         "   $-hidden<def>    include hidden and system files.\n"
         "   $-nohidden<def>  exclude hidden and system files.\n"
         "   $-yes<def>       fully execute the command. some commands like \"run\" are\n"
         "              running in simulation mode by default, to avoid damage to your\n"
         "              files, as long as you're unsure which files and dirs to select.\n"
         "              as soon as you add -yes, however, everything is fully executed.\n"
      // "   $-nonames<def>   or -nofile[names] does not create :file name records when\n"
      // "              chaining text data from one command to another.\n"
         );
  printx("   $-minsize=s<def> select only files >= size, like 10b or 100k\n"
         "   $-maxsize=s<def> select only files <= size, like 10m or 4g\n"
         "              b=bytes k=kbytes m=megabytes g=gigabytes=10^9 bytes\n"
         "              K=2^10 bytes M=2^20 bytes G=2^30 bytes\n"
         "   $-weblimit=n<def>  change web access download limit to n mbytes,\n"
         "              with functions like sfk web, filter, xex. default is 10 mb.\n"
         "              you may also <exp> SFK_CONFIG=weblimit:20\n"
         "   $-webtimeout=n<def>  web access timeout in msec. default is 10000.\n" // wto.general
         "              you may also <exp> SFK_CONFIG=webtimeout:3000\n"
         "   $-headers<def>   print http headers with commands accessing the web.\n"
      // "   $-showreq<def>   print sent http request url with web commands.\n"
      // "   $-ftptimeout=n<def>  ftp access timeout in msec. default is 10000.\n"
         "   $-textfiles<def> process only text files, no binaries. -text is the same,\n"
         "              but this may interfere with some command's local -text option.\n"
         "              text/binary detection only checks the file's first 4 kbytes.\n"
         "   $-binfiles<def>  process only binary files. -bin is the same, but this may\n"
         "              interfere with some command's local -bin option.\n"
         "   $-umlauts<def>   with binary-to-text conversion, include german characters.\n"
         "   $-nocol<def>     disable all colored output. important if your shell has\n"
         "              a background color incompatible to the default color scheme,\n"
         "              or (under linux) if the sfk output text must be processed\n"
         "              further through pipelining, and needs to be stripped from\n"
         "              the color escape sequences.\n"
         "   $-col<def>       switch on colored output. \"sfk help colors\" for more.\n"
         "   $-html<def>      dump sfk help text (color control) in html format.\n"
         "              -html must be typed directly after \"sfk\".\n"
         "   $-htmlpage<def>  the same, but include a header to view it in a browser.\n"
         );
  printx("   $-sincedir<def>  or -sincedif/add/chg: compare directory tree against\n"
         "              a reference tree, process only changed or added files.\n"
         "              see \"sfk list\" for details.\n"
         "   $-tracesel<def>  give verbose infos why directories and files have been\n"
         "              selected or excluded. -tracedirs lists only directories,\n"
         "              -tracefiles lists only files.\n"
         "   $-since<def>     process only files changed on or after the supplied\n"
         "              date/timestamp. \"sfk list\" for details.\n"
         "   $-before<def>    process only files changed before that date/timestamp.\n"
         "   $-flist fn<def>  or \"-fl fn\" reads list of filenames from file fn.\n"
      // "   $-fileset<def>   use a textfile with dir- and filenames, instead of\n"
      // "              providing them as parameters. \"sfk help fileset\" for more.\n"
         "   $-spat<def>      activates interpretation of slash patterns:\n"
         "              \\t=TAB \\q=\" \\r=CR \\n=LF \\\\=\\ \\xnn=any char w/hex code nn\n"
         "              with some commands like replace, filter -form and -replace.\n"
         "   $-literal<def>   or -lit disables interpretation of wildcards * and ?\n"
         "              and slash patterns, if they were activated previously.\n"
         "   $-nospat<def>    disables only slash patterns.\n"
         );
         #ifdef _WIN32
  printx("   $-nocconv<def>   when printing output to the windows console, sfk tries\n"
         "              to convert umlaut and accent characters to display them\n"
         "              correctly with codepage 850. set -nocconv to disable this.\n"
         "              whenever output is redirected to file, no conversion is done.\n"
         "   $-cconv<def>     force codepage conversions: if command output is redirected\n"
         "              to a file, codepage conversion is disabled by default.\n"
         "              use this option to activate, e.g. when post-processing\n"
         "              sfk run output which produced filename lists.\n"
         );
         #endif
  printx("   $-noipex<def>    disable automatic IP expansion with some commands.\n");
  printx("   $-wchar<def>     activate EXPERIMENTAL utf-16 (ucs-2, wide char) decoding,\n"
         "              allowing sfk find or filter to search text in utf-16 files.\n"
         "              should not be used when (re)writing files. get more infos\n"
         "              by typing \"sfk help unicode\".\n"
         "   $-to mask<def>   specify where to write output files with some commands.\n"
         "              mask supports <run>file, <run>path, <run>base, <run>ext and more,\n"
         "              like -to outdir<sla><run>base-modified.<run>ext\n"
         "              say \"sfk run\" for a list of possible keywords.\n"
         "   $-tofile x<def>  specify a single output filename, which is taken as is\n"
         "              and not checked for any <run> patterns.\n"
         "   $-tmpdir x<def>  set directory x as temporary file directory. default is\n"
         #ifdef _WIN32
         "              to use the path specified by TEMP or TMP env variable.\n"
         #else
         "              to use the path specified by TEMP or TMP env variable,\n"
         "              or the /tmp directory, if no such variable is defined.\n"
         #endif
         "   $-showtmp<def>   tell verbosely which temporary files are created.\n"
         "   $-keeptmp<def>   do not delete the temporary files, if possible.\n"
         "   $-nowarn<def>    and -noerr, -nonote disable warn, error and note messages.\n");
  printx("   $-memlimit=n<def> set the caching memory limit to n mbytes (default=%d).\n"
         "              used if a function needs to load whole files into memory.\n"
         ,(int)(nGlblMemLimit / 1048576));
         #ifdef VFILEBASE
  printx("              if zip etc. archive processing is very slow, it may be caused by\n"
         "              a cache overflow. try to increase the -memlimit then.\n"
         "              if you think sfk uses too much memory while processing files,\n"
         "              try to reduce -memlimit (values below 200 are not recommended).\n"
         "              you may also set SFK_CONFIG (see end of this text).\n"
         "   $-cachestat<def> tell amount of memory used by archive file cache.\n"
         "   $-nocache<def>   disable the disk cache (for network files).\n"
         );
         #endif // VFILEBASE
  printx("   $-exectime<def>  tell command execution time at program end.\n");
         #ifdef _WIN32
  printx("   $-noesckey<def>  disable stop by escape key. (windows only)\n");
         #endif
  printx("\n"
         "   $shell return code handling and error processing:\n"
         "\n"
         "   $-showrc<def>    print sfk return code at program end. may not print anything\n"
         "              in case of fatal errors, like wrong syntax (usually rc 9).\n"
         "   $-exterr<def>    in case of operating system related errors like file access,\n"
         "              prints extended error information, if available.\n"
         "   $-waitonerr<def> wait for user input on every error.\n"
         "   $-waitonend<def> wait for user input at program end.\n"
         "   $-stoponerr<def> stop directory tree processing on first unreadable file.\n"
         "              default is to process as many files as possible, skipping\n"
         "              unreadable files and directories.\n"
         "   $-rcfromerr<def> some commands like filter, find, hexfind tell by shell rc\n"
         "              that something was found. by default, skipped errors like\n"
         "              unreadable files do NOT change this rc. with -rcfromerr,\n"
         "              skipped errors do override the resulting shell rc.\n"
         "   $-echoonerr<def> echo whole command to stderr when an error occurs.\n"
         "              see also the SFK_CONFIG setting \"echoonstart\" below.\n"
         "\n"
         "   to experiment with the above options, try \"sfk errortest\".\n"
         "\n");

  printx("   $command local versus global scope:\n"
         "\n"
         "      within a command chain, many options have an effect only locally\n"
         "      with the command where they are specified, e.g. in\n"
         "\n"
         "         #sfk filt x.txt -case -high red FooCase +filt -high blue TheBar\n"
         "\n"
         "      the \"-case\" is valid only for the first filter command.\n"
         "      but the following options can also be used globally, if specified\n"
         "      directly after \"sfk\":\n"
         "\n"
         "         $-nohead -noinfo -nofile -case -literal -spat\n"
         "\n"
         "      for example, in\n"
         "\n"
         "         #sfk -case filt x.txt -high red FooCase +filt -high blue TheBar\n"
         "\n"
         "      the \"-case\" is valid for ALL commands in the command chain.\n"
         "\n"
         );

  printx("   $environment configuration:\n"
         "\n"
         "      $<exp> SFK_CONFIG=columns:n,active-file-age:n,memlimit:n,...\n"
         "        columns:\n"
         "          sfk (for windows) tries to autodetect the no. of console columns,\n"
         "          but you may also set this value through this config parm.\n");
  printx("        active-file-age:n\n"
         "          some functions need to tell if a file is 'recently edited' or rather\n"
         "          old and inactive. by default, files > 30 days of age are considered\n"
         "          non-active. reconfigure the no. of days threshold here.\n"
         "        memlimit:\n"
         "          set memory limit to n mbytes.\n"
         "        echoonstart:\n"
         "          echo the whole sfk command on start, to stderr.\n"
         "        echoonerr:\n"
         "          echo the whole sfk command on errors, to stderr.\n"
         "        tmpdir:path\n"
         "          set folder for temporary files, used by some commands.\n"
         #ifdef _WIN32
         "          e.g. set SFK_CONFIG=tmpdir:d:\\tmp,memlimit:500\n"
         #else
         "          e.g. set SFK_CONFIG=tmpdir:~/mytmp,memlimit:500\n"
         #endif
         "\n"
         );
         if (bGlblIgnore3600)
            printx("   info: files with a time difference of 1 hour AND an age > %d days\n"
                   "         are skipped by some commands, e.g. list -sincedir.\n\n", nGlblActiveFileAgeLimit);

         if (nGlblActiveFileAgeLimit != 30)
            printx("   info: active file age limit is currently set to %d days.\n", nGlblActiveFileAgeLimit);

         #ifdef _WIN32
         if (glblWildChar != '*')
         #else
         if (glblWildChar != '%')
         #endif
         {
            setTextColor(nGlblWarnColor);
            printx("   info: wildcard star '*' is currently configured as %c\n", glblWildChar);
            setTextColor(-1);
         }

  printx("      $<exp> SFK_ZIP_EXT=\".foo .bar .myext\"\n"
         "        set additional, user defined zip file extensions. in this example,\n"
         "        files ending with .foo, .bar or .myext are also treated like zip files.\n"
         "        for the list of default extensions, look above at the -arc option.\n"
         "\n");
 
         if (bGlblConsColumnsSet)
            printx("   sfk currently uses %d console columns for output with some commands.\n", nGlblConsColumns);
   }

   if (!strncmp(pszSub, "sel", 3))
   {
  printx("$sfk file selection reference%s:\n"
         "\n"
         "   $default principles of most sfk commands:\n"
         "\n"
         "      - subdirectory (subfolder) processing is done by default.\n"
         "      - filename comparison is case insensitive.\n"
         "      - hidden and system files are not processed,\n"
         "        except for some commands like copy.\n"
         "      - symbolic links are followed.\n"
         "\n"
         "        type \"sfk help options\" on how to change that.\n"
         "\n"
         "   $how to select directories and contained filenames:\n"
         "\n"
         "   sfk provides many ways of specifying which files you want to process,\n"
         "   from very simple but unflexible to very detailed.\n"
         "\n",
         bhelp ? " (type \"sfk help select\")":""
         );
  printx("   $1. short format file selection:\n"
         "\n"
         "      $dirname [filemask1] [filemask2] [<not>fileexcludemask] [...]\n"
         "\n"
         "      this format supports ONE directory name, followed by many file masks.\n"
         "      it can be used with most commands processing directory trees.\n"
         "\n"
         "      example:\n"
         "\n"
         "      #sfk list mydir foo bar .txt .zip <not>-tmp\n"
         "         selects all files\n"
         "         - in directory mydir and all its subdirectories\n"
         "         - having foo OR bar in their filename (no * required)\n"
         "         - OR which are ending with .txt OR .zip (no *.txt required)\n"
         "         - but not having -tmp in their filename\n"
         "\n"
         "      supported by commands:\n"
         "         list, select, stat, run, detab, scantab, hexdump and some more.\n"
         "\n"
         );
  printx("   $2. long format file selection:\n"
         "\n"
         "      $-dir root1 [root2] [<wild>pathmask<wild>] [...] [-file mask1 [mask2] [...]]\n"
         "         $[-dir root3 root4 <not>direxcludemask -file mask3 <not>xmask4] [...]\n"
         "\n"
         "      this format supports\n"
         "\n"
         "      - several root directory sets, starting with -dir, each of them\n"
         "        containing many directories, path masks or dir exclusion masks.\n"
         "        a path mask is an expression in a directory set containing a\n"
         "        wildcard character \"<wild>\". a dir exclusion mask is started\n"
         "        by <not> and may be surrounded by <sla> to select exact dir names.\n"
         "\n"
         "      - a file mask set per root directory set, starting with -file.\n"
         "        this may also contain file exclusions starting with <not>\n"
         "\n"
         "      supported by:\n"
         "         nearly every command than can process file sets.\n"
         "\n");
  printx("      $to select all dirs of current dir except something:\n"
         "      #-dir . <not>foo       <def>-> exclude subdirs like *foo*\n"
         "      #-dir . <not>.foo      <def>-> exclude with extension .foo\n"
         "      #-dir . <not><sla>foo      <def>-> exclude starting with foo\n"
         "      #-dir . <not>foo<sla>      <def>-> exclude ending with foo\n"
         "      #-dir . <not><sla>foo<sla>     <def>-> exclude exactly foo\n"
         "      #-dir . <not><sla>foo<sla>bar<sla> <def>-> exclude subdir combi\n"
         "      #-dir . <not><wild>.foo<wild>    <def>-> exclude with .foo anywhere\n"
         "\n"
         "      $to select only sub dirs of current dir with something:\n"
         "\n"
         "      using wide sub dir expressions:\n"
         "      #-dir . -subdir foo       <def>-> include paths having *foo*\n"
         "      #-dir . -subdir <sla>foo      <def>-> include paths having *<sla>foo\n"
         "      #-dir . -subdir foo<sla>      <def>-> include paths having *foo\n"
         "      #-dir . -subdir <sla>foo<sla>     <def>-> include paths exactly foo\n"
         "      #-dir . -subdir .foo      <def>-> include with extension .foo\n"
         "      #-dir . -subdir <sla>foo<sla>bar<sla> <def>-> include subdir combi\n"
         "      instead of -subdir, you may also type just -sub\n"
         "\n"
         "      using compact sub dir expressions:\n"
         "      #-dir . <wild>foo<wild>      <def>-> include paths having *foo*\n"
         "      #-dir . <wild><sla>foo      <def>-> include paths having <sla>foo\n"
         "      #-dir . <wild>foo<sla>      <def>-> include paths having foo<sla>\n"
         "      #-dir . <wild><sla>foo<sla>     <def>-> include paths exactly foo\n"
         "      #-dir . <wild>.foo      <def>-> include with extension .foo\n"
         "      #-dir . <wild><sla>foo<sla>bar<sla> <def>-> include subdir combi\n"
         "\n"
         "      $exclusion by filename:\n"
         "      #-file <not>foo        <def>-> exclude all files like *foo*\n"
         "      #-file <not><sla>foo       <def>-> exclude starting with foo\n"
         "      #-file <not>foo<sla>       <def>-> exclude ending with foo\n"
         "      #-file <not><sla>foo<sla>      <def>-> exclude exactly foo\n"
         "      #-file <not>.foo       <def>-> exclude extension foo\n"
         "\n"
         "      $inclusion by filename:\n"
         "      #-file foo         <def>-> include all files like *foo*\n"
         "      #-file <sla>foo        <def>-> include starting with foo\n"
         "      #-file foo<sla>        <def>-> include ending with foo\n"
         "      #-file <sla>foo<sla>       <def>-> include exactly foo\n"
         "      #-file .foo .bar   <def>-> select .foo and .bar files\n"
         "\n"
         "      $examples\n"
         "\n"
         "      #sfk scantab -dir mydir1 mydir2 <wild>include<wild> -file foo bar .hpp\n"
         "         scans all files for TAB characters\n"
         "         - in directory mydir1 and all its subdirectories\n"
         "           AND\n"
         "         - in directory mydir2 and all its subdirectories\n"
         "           IF\n"
         "           - 1. the file path contains the word \"include\",\n"
         "             e.g. mydir1\\core\\include\\foosys.hpp\n"
         "           - 2. the filename contains foo OR bar\n"
         "           - 3. or the filename ends with .hpp\n"
         "\n"
         "      #sfk scantab -dir mydir1 <not>include -file <not>.tmp <not>.save\n"
         "         scans all files for TAB characters in folder mydir1,\n"
         "         excluding all sub dirs having \"include\" in their name,\n"
         "         and excluding all .tmp and .save files.\n"
         "\n"
         "      #sfk list -dir source include -subdir save <not>.svn -file .bak\n"
         "         list .bak files from directory trees source and include,\n"
         "         within in sub directories having \"save\" in their name,\n"
         "         excluding sub directories ending with \".svn\".\n"
         "\n"
         "      #sfk list -dir source include <wild>save <not>.svn -file .bak\n"
         "         the same as above, written in compact subdir format:\n"
         "         subdir inclusion masks require a wildcard <wild> anywhere\n"
         "         to make it clear they're no root directories.\n"
         "         subdir exclusion masks can stay as they are.\n"
         "\n"
         );
  printx("   $3. single parameter file set selection:\n"
         "\n"
         "      some commands like find, filter or tail do not accept the full\n"
         "      short format, but only a single file or dir parameter, as it\n"
         "      would get too complicated mixing the short format with local\n"
         "      options. find more on that in the command's local help.\n"
         "\n"
         );
  printx("   $4. passing filename lists in command chains:\n"
         "\n"
         "      instead of selecting files in the current command, you may use\n"
         "      a filename list created by a previous command, for example:\n"
         "\n"
         "      #sfk select mydir .txt +detab=3\n"
         "         selects all .txt files from directory mydir, then passes\n"
         "         this file list to detab, where the files are detabbed.\n"
         "\n"
         "      command chaining is more intuitive, as you can play around\n"
         "      with different file sets before executing actual changes\n"
         "      on the selected files.\n"
         "\n"
         "      #sfk filter names.txt +texttofilenames +list -late\n"
         "         provided that names.txt contains a list of filenames,\n"
         "         this command chain lists the most recent of these files.\n"
         "         note that in this case, it is unclear if to pass\n"
         "         - the filename \"names.txt\" or\n"
         "         - the line contents from within names.txt\n"
         "         as filenames to \"list\", therefore we need to insert\n"
         "         +texttofilenames or +ttf to enforce a conversion.\n"
         "\n"
         "      supported by:\n"
         "         some commands. check each command's local help for more.\n"
         "\n"
         );
  printx("   $see also\n"
         "      #sfk help options<def>  general options for most commands.\n"
         "      #sfk list<def>          for more file selection examples.\n"
         );
   }

   if (!strcmp(pszSub, "chain"))
   {
      printx("$sfk command chaining reference%s:\n",
             bhelp ? " (type \"sfk help chain\")":"");
      printx("\n"
         "   several commands can be combined in a so-called \"command chain\".\n"
         "   this is done by appending command names prefixed by \"+\", for example:\n"
         "\n"
         "   #sfk list docs .txt +ffilter -+foo\n"
         "      \"list\" produces a filename list and passes this to \"filefilter\".\n"
         "      ffilter reads the contents of these files, looking for the word \"foo\".\n"
         "\n"
         "   $chain data types\n"
         "      three types of data can be passed from one command to another:\n"
         "\n"
         "         #- filename lists.\n"
         "         #- plain text records (lines).\n"
         "         #- stream text or binary data.\n"
         "\n"
         "      output is dependent on command. for example, sfk select produces\n"
         "      filename lists, sfk filter makes plain text records, xex/xed can\n"
         "      produce streams of text or binary data.\n"
         "\n"
         "   $chain data type conversion\n"
         "      vice versa, some commands accept filenames, or text input, or even both.\n"
         "      depending on what you want to do, it may be necessary to convert between\n"
         "      this types of data. this can be done by the keywords:\n"
         "\n"
         "         #+texttofilenames<def> or #+ttf<def>\n"
         "         #+filenamestotext<def> or #+ftt<def>\n"
         "\n"
         "      however, most sfk commands try to do such conversions automatically.\n"
         "\n"
         "   $using chain data between commands\n"
      // "      #sfk cmd1 ... +to cmd2<def>     must pass data to cmd2. use with +call\n"
      // "                                and +end where it is unclear if the next\n"
      // "                                command may need the chain data.\n"
         "      #sfk cmd1 ... +then cmd2<def>   does not pass any data to cmd2,\n"
         "                                prints cmd1 output to terminal.\n"
         "      #sfk ... +toterm<def>           dumps current chain content to terminal.\n"
         "      #sfk ... +tofile outfile<def>   dumps chain content to file outfile.\n"
         "      #sfk ... +tovoid +cmd2<def>     does not pass any data to cmd2,\n"
         "                                drops cmd1 chain text silently.\n"
         "      in all cases, the chain is cleared. if another command is following,\n"
         "      it will receive no input from the chain.\n"
         "\n"
         "   $using chain data with call / label / end\n"
         "      #sfk ... +call myfunc<def>      passes no chain data into myfunc\n"
         "      #sfk ... +tcall myfunc<def>     passes text data into myfunc\n"
         "      #sfk ... +fcall myfunc<def>     passes filenames into myfunc\n"
         "      #sfk label ... +end<def>        returns no chain data\n"
         "      #sfk label ... +tend<def>       returns text data\n"
         "      #sfk label ... +fend<def>       returns a filename list\n"
         "\n"
         "   $scope and lifetime of options\n"
         "      most options are valid only for the command where they are specified.\n"
         "      if another command follows in the chain, the option is reset.\n"
         "      but some options may also be specified on a global scope.\n"
         "      read more on that under \"$sfk help options<def>\".\n"
         "\n"
         /*
         "   $tracing a data flow within a script\n"
         "      set global option $-iotrace<def> like:\n"
         "\n"
         "         #sfk -iotrace script myfile.bat -from begin<def>\n"
         "\n"
         "      which produces a mixed command output and iotrace.\n"
         "      to get only the clean iotrace without command output use\n"
         "\n"
         #ifdef _WIN32
         "         #myfile.bat >nul\n"
         #else
         "         #myfile.bat >/dev/null\n"
         #endif
         "\n"
         "      as iotrace goes to stderr instead of normal output.\n"
         "\n"
         "      if iotrace tells \"=> send to +cmd\" and you don't want\n"
         "      data being passed to that command, but instead want it\n"
         "      printed on terminal, use \"+then cmd\" in the chain.\n"
         "\n"
         */
         "   $more in the SFK Book\n"
         "      the #SFK Book<def> contains long examples with input,\n"
         "      output, script and detailed command explanations.\n"
         "      type \"#sfk book<def>\" for more.\n"
         "\n"
         "   $see also\n"
         "      #sfk batch<def>     create an example script\n"
         "      #sfk help var<def>  how to use sfk variables\n"
         "      #sfk script<def>    about sfk scripting\n"
         "      #sfk call<def>      calling a function in a script\n"
         "      #sfk label<def>     possible options with label\n"
         "      #sfk if<def>        conditional execution\n"
         "      #sfk goto<def>      jump to a local label\n"
         );
   }

   if (!strncmp(pszSub, "var", 3))
   {
  printx("$sfk parameters and variables support\n"
         "\n"
         "   $sfk script parameters\n"
         "\n"
         "      -  look like #%%1 %%2 %%3<def> to #%%9<def>,\n"
         "         or with sfk for windows also like #$$1 $$2 $$3<def>.\n"
         "\n"
         "      -  are used with sfk #script<def> and #call / label<def>.\n"
         "\n"
         "      -  are passed into the script or label command chain\n"
         "         wherein they are never changed.\n"
         "\n");
  webref("helpvar");
  printx("      $example:\n"
         "         $--- file filt.bat begin ---\n"
         "         sfk #script<def> %%~f0 -from begin %%*\n"
         "         GOTO end\n"
         "         sfk #label<def> begin\n"
         "            +filter %%1 %%2\n"
         "            +end\n"
         "         :end\n"
         "         $--- file filt.bat end ---\n"
         "         typing \"#filt.bat in.txt -+foo<def>\" will run sfk filter\n"
         "         using the parameters \"in.txt\" and \"-+foo\".\n"
         "         under windows %%~f0 is the absolute batch filename\n"
         "         itself including extension .bat or .cmd.\n"
         "\n");
  printx("   $sfk global variables\n"
         "\n"
         "      -  are set like:\n"
         "         sfk #setvar<def> myvar=\"the test text\" ...\n"
         "         sfk echo foo #+setvar<def> myvar ...\n"
         "         sfk xed in.txt \"/foo*bar/#[setvar myvar][part2][endvar]<def>/\" ...\n"
         "\n"
         "      -  are used by further commands in the chain like:\n"
         "         sfk ... #+getvar myvar\n"
         "         sfk ... +echo -var \"using <examp>##(myvar)<def>\"\n"
         "         sfk ... +xed \"_<foo>*</foo>_[part1]#[getvar myvar]<def>[part3]_\"\n"
         "         $note:<def>\n"
         "           to read or use variable contents by a pattern <examp>##(name)\n"
         "           option #-var<def> must be given. this is to avoid unwanted\n"
         "           side effects with commands that get \"##(\" in their\n"
         "           input files or input text streams.\n"
         "\n"
         "      -  allowed variable names:\n"
         "         must start with a-z, then a-z0-9_\n"
         "\n"
         "      $examples:\n"
         "         #sfk setvar file=in.txt +filter -var \"##(file)\" -+foo\n"
         "            runs sfk filter, giving the input filename by variable.\n"
         "         #sfk xex in.txt \"/foo=*/[setvar fooval][part2][endvar]/\"\n"
         "          #+echo -var \"foo is: ##(fooval)\"\n"
         "            extract foo=(any text) from in.txt, place the found\n"
         "            text into variable fooval, then print it. [19]\n"
         "\n");
  printx("   $environment variable access\n"
         "\n"
         "      can be done like ##(env.varname). varname is case\n"
         "      insensitive under windows and uses case on linux.\n"
         "\n"
         "      $example:\n"
         "         sfk -var echo \"tmp contains: ##(env.TMP)\"\n"
         "\n"
         );
  printx("   $sfk local command variables\n"
         "\n"
         "      -  are created directly from input text\n"
         "         produced by a previous command in the command chain\n"
         "\n"
         "      -  are suppported only within some commands like\n"
         "         #sfk run \"... <run>text ....\"\n"
         "            runs an external program once for every input line.\n"
         "         #sfk perline \"... <run>text ...\"\n"
         "            runs sfk internal commands once for every input line.\n"
         "         #sfk filter -tabform \"... <run>col1 ... <run>col2 ...\"\n"
         "            splits text lines by TAB char, allowing reformatting.\n"
         "         type #sfk run<def>, #sfk perline<def> etc. for further infos.\n"
         "\n"
         );
  printx("   $sfk variable functions\n"
         "\n"
         "      when reading variable text like ##(varname) some extra\n"
         "      functions can be applied using ##(func(varname,...)).\n"
         "      available functions are:\n"
         "\n"
         "      $strpos(v,'text')<def>        get index of text within v\n"
         "      $strpos(v,-case 'text')<def>  same, case sensitive\n"
         "      $strpos(v,-spat '\\x20')<def>  using slash patterns\n"
         "      $strrpos(v,'text')<def>       search from right side\n"
         "      $substr(v,o[,l])<def>         substring from offset o length l.\n"
         "                              use negative o from right side.\n"
         "      $[l/r]trim(v)<def>            strip whitespace at sides\n"
         "      $lpad(v,n)<def>               fill left side up to n chars\n"
         "      $rpad(v,n)<def>               fill right side up to n chars\n"
         "      $isset(v)<def>                tells 1 if v is set, else 0\n"
         "      $strlen(v)<def>               number of characters in v\n"
         "\n"
         "      $examples:\n"
         "      #sfk -var setvar a=\"foo bar\"\n"
         "         #+echo \"##(substr(a,4,3))\"<def>    - prints 'bar'\n"
         "         #+echo \"##(strpos(a,'bar'))\"<def>  - prints '4'\n"
         "      #sfk -var setvar a=\"foo\"\n"
         "         #+echo \"##(lpad(a,6))\"<def>        - prints '   foo'\n"
         "\n"
         );
   }

   if (!strcmp(pszSub, "shell"))
   {
      printx(
         "$Configure the windows Command Prompt this way:\n"
         "\n"
         "  1. create a shell shortcut on your desktop:\n"
         "     - Start/Programs/Accessories/Command Prompt,\n"
         "       right mouse button, select Copy.\n"
         "     - go to an empty place on the desktop.\n"
         "     - select Paste.\n"
         "\n"
         "  2. on the new desktop shortcut,\n"
         "     - right mouse button, select Properties.\n"
         "\n"
         "  3. in the Command Prompt Properties, set\n"
         "     - #Options: activate QuickEdit and Insert mode\n"
         "     - #Font   : select 8 x 12\n"
         "     - #Layout : Screen buffer size: Width 160, Height 3000\n"
         "       #         Window size       : Width 160, Height   30\n"
         "\n"
         "  4. close Properties by clicking OK.\n"
         "\n"
         "  5. double-click on the Command Prompt icon to open a shell.\n"
         "\n"
         "$Now you have a well configured power shell:\n"
         "\n"
         "   - any command output is remembered #up to 3000 lines<def>.\n"
         "\n"
         "   - you may select command output anytime with left mouse button,\n"
         "     then click right button #to copy to clipboard<def>.\n"
         "     right click again to #paste clipboard as a command<def>.\n"
         "\n"
         "   - to #pause<def> a program that prints output to the screen,\n"
         "     do a #dummy-select<def> of text with the left mouse button.\n"
         "     to continue program execution, press right button, or enter.\n"
         "\n"
         "$Automatic Command Completion\n"
         "\n"
         "   Question: #how do you enter the directory VeryMuchToTypeFooBarSystem ?\n"
         "\n"
         "   Answer 1: type \"cd verymuchtotypefoobarsystem\"\n"
         "\n"
         "             this is actually what most users do, and it's a waste of time.\n"
         "\n"
         "   Answer 2: #type \"cd very\" and then press the TAB key.\n"
         "\n"
         "             since Windows XP, command completion is default.\n"
         "\n"
         "   Under Win98 and Win2k, completion it is NOT default. As a workaround,\n"
         "   you may type \"cd very*\", or run regedit and set the registry key value\n"
         "   HKEY_CURRENT_USER\\Software\\Microsoft\\Command Processor\\CompletionChar to 9.\n"
         );
   }

   if (!strcmp(pszSub, "pat"))
   {
      printx("$sfk wildcards and text patterns%s:\n",
             bhelp ? " (type \"sfk help patterns\")":"");
      printx("\n"
         "   $available wildcards:\n"
         "      * = any number of characters.\n"
         "      ? = a single character.\n"
         "\n"
         "   $available slash patterns:\n"
         "      \\t   = TAB\n"
         "      \\q   = double quote \"\n"
         "      \\r   = carriage return\n"
         "      \\n   = linefeed\n"
         "      \\xnn = any character with hexadecimal value nn,\n"
         "             e.g. \\x09 is the same as \\t (TAB)\n"
         "      \\\\   = the backslash \\ itself\n"
         "      \\\\*   = the star '*' itself     [only with some commands]\n"
         "      \\?   = quotation mark '?'      [only with some commands]\n"
         "\n"
         "   $support by commands:\n"
         "\n"
         "      if any command supports slash patterns,\n"
         "\n"
         "      - they are not active by default, except for commands\n"
         "        starting with \"x\" that use SFK Expressions.\n"
         "\n"
         "      - to use, say -spat directly after the command name:\n"
         "        #sfk echo -spat \"three\\tlittle\\ttabs\\t.\"\n"
         "        prints: #three   little  tabs    .\n"
         "\n"
         "      - to activate slash patterns globally over multiple commands\n"
         "        of a command chain, say -spat directly after \"sfk\":\n"
         "        #sfk -spat echo \"two\\ttabs\" +filter -rep \"x\\tx_x\"\n"
         "        prints: #two_tabs\n"
         "\n"
         "      if any command supports wildcards,\n"
         "\n"
         "      - they are active by default.\n"
         "\n"
         "      - they can be deactivated by option -literal or -lit,\n"
         "        if you need to find/replace '*' or '?' characters themselves:\n"
         "        #sfk echo \"*** ok ***\" +filter -lit -rep \"_*_=_\"\n"
         "        prints: #=== ok ===\n"
         "\n"
         "      - to deactivate globally over multiple commands of a chain,\n"
         "        say -literal directly after \"sfk\":\n"
         "        #sfk -literal echo \"*** ok ???\" +filter -lit -rep \"_?_!_\"\n"
         "        prints: #*** ok !!!\n"
         "\n"
         "      - another way to find/replace '*' or '?' is to say -spat\n"
         "        and then to use \\\\* and \\? patterns:\n"
         "        #sfk echo \"*** ok ***\" +filter -spat -rep \"_\\\\*_=_\"\n"
         "        prints: #=== ok ===\n"
         "\n"
         "      further reading:\n"
         "\n"
         "         $sfk help options<def> - general options reference\n"
         "         $sfk help chain<def>   - about command chaining\n"
         );
   }

   if (!strcmp(pszSub, "faq"))
   {
      printx(
"start of filename comparison: use \"\\pattern\". see also \"name start\"\n"
"traveling, walking subdirectories or subfolders: is default. type \"sfk help select\"\n"
"find in text files: \"sfk find\", \"sfk hexfind\", \"sfk filter\"\n"
"find text, data in binary files, binaries: \"sfk find\", \"sfk hexfind\"\n"
"find same, identical, duplicate files: \"sfk dupfind\"\n"
"compare directories, folders, differences: \"sfk list\" with -sincedir option\n"
"find different files, differences: \"sfk md5check\", \"sfk list\" with -sincedir\n"
"list, find newest, oldest, latest files of dir: \"sfk list\" with -late, -old\n"
"list, find most recent files of dir: \"sfk list\" with -late, -old\n"
"list, sort, order dir files by date, timestamp: \"sfk list\" with -late, -old\n"
"list, find largest, biggest, smallest dir files: \"sfk list\" with -big, -small\n"
"list, find files changed today, since a date: \"sfk list\" with -since\n"
"sort dir contents by date, time, size: \"sfk list\" with -late, -big\n"
"symbolic links: no option under windows. under linux (not lib5) see \"sfk help opt\"\n"
"regular expressions: not supported, but see \"sfk help patterns\"\n"
"list, show files, directory tree size, largest dirtree: see \"sfk stat\"\n"
"split text lines, column data by characters: \"sfk filter\" with -sep, -form\n"
"extract, remove text blocks between marker lines: \"sfk filter\" with -inc, -cut\n"
"create, verify md5sum, md5 checksum for dir, files: \"sfk md5gento\", \"sfk md5check\", \"sfk md5\"\n"
"convert binary to c++, cpp, java sourcecode: \"sfk bin-to-src\"\n"
"split large text or binary files: \"sfk split\"\n"
"transfer files from windows host to linux vmware: \"sfk ftpserv\", \"sfk ftp\"\n"
"find, where are classes inside, within jar files tree: \"sfk list\" with -arc\n"
"all class packages in jar dirs: \"sfk list\" with -arc\n"
"list, get all files in jars in all dirs: \"sfk list -arc . .jar\"\n"
"find, replace words in text, binary files: \"sfk replace\", \"sfk filter\"\n"
"find, replace hex pattern in binary files: \"sfk hexfind\", \"sfk replace\"\n"
"patch binary file contents: \"sfk replace\"\n"
"convert text file, dos, windows, linux crlf line endings, format: \"sfk addcr\", \"sfk remcr\"\n"
"replace, add, remove, strip, convert text file crlf line endings: \"sfk addcr\", \"sfk remcr\"\n"
"find, print, read first, last lines of text files: \"sfk head\", \"sfk tail\"\n"
"print, read head or tail of files: \"sfk head\", \"sfk tail\"\n"
"find command, cmd, bat, exe file in path: \"sfk pathfind\"\n"
"remove, replace tabs by spaces in text file lines: \"sfk detab\"\n"
"insert, remove text in files: \"sfk replace\", \"sfk filter\" with -write\n"
"find, list files in a dir sorted by size, time: \"sfk list\" with -big, -late\n"
"copy content, extract, view text of a binary file: \"sfk partcopy\", \"sfk strings\"\n"
"run user defined command, processing many files: \"sfk run\"\n"
"run a command on each file, line of file: \"sfk run\", \"sfk filter thefile.txt +run \"mycmd <run>text\"\"\n"
"replace, remove spaces in filenames, dir names: \"sfk deblank\"\n"
"join, add text, binary files: \"sfk snapto\", \"sfk join\"\n"
"adding delay, pause to command file: \"sfk sleep\", \"sfk pause\"\n"
"set, create, define alias for .cmd, .bat, command path in shell: \"sfk alias\"\n"
"delete .bak, .tmp, temporary files: \"sfk sel . .bak +del\"\n"
"convert binary file to text, source code: \"sfk hexdump\", \"sfk bin-to-src\"\n"
"hex to byte, convert hex dump, file into binary file: \"sfk hextobin\"\n"
"count files in dir tree: \"sfk list ... +count\"\n"
"create text file from dir listing: \"sfk list ... +tofile\"\n"
"create large text, binary file for tests: \"sfk make-random-file\"\n"
"delete files by extension: \"sfk del mydir .ext\"\n"
"trace, hexdump, dump TCP data, browser connection: \"sfk tcpdump\"\n"
"tcpdump of http request in plain text: \"sfk tcpdump\" with -flat\n"
"echo staying on same line, without lf: \"sfk echo\" with -noline\n"
"shell echo with colored words in red, green, blue: \"sfk echo\"\n"
"open, read text from clipboard: \"sfk fromclip\"\n"
"file copy to clipboard: \"sfk filter ... +toclip\"\n");
printx(
"find unprintable, nonprintable characters : \"sfk hexfind\" with -bin\n"
"find duplicate lines in a text file: \"sfk count\" with -samelines\n"
"find data, hex numbers in binary files: \"sfk hexfind\"\n"
"find, replace text with wildcards: \"sfk filter\"\n"
"find, get, list files matching patterns: \"sfk list\"\n"
"cut, remove, filter empty, blank lines from text files: \"sfk filter\" with -no-blank-lines\n"
"replace any, accent, umlaut characters in text files: \"sfk replace\"\n"
"check, find dependencies of binaries, executables files: \"sfk deplist\"\n"
"find, list number of files in a directory: \"sfk list mydir +count\"\n"
"add current, any dir to a file list: \"sfk list . >>myfilelist.txt\"\n"
"strip, skip text file lines by filter, markers: \"sfk filter\" with -!mypattern or -cut\n"
"cut, strip, exclude lines by words from text files: \"sfk filter\" with -!word1 -!word2\n"
"list files of dir needing no wildcard: \"sfk list mydir *foo*\" == \"sfk list mydir foo\"\n"
"write shell script with command chaining: \"sfk script\", \"sfk samp\"\n"
#ifdef _WIN32
"to create multi line commands, use ^ at the end of .bat lines, or \"sfk script\"\n"
#else
"to create multi line commands, use \"sfk script\"\n"
#endif
"if content(s) are too large to load, see -memlimit under \"sfk help opt\"\n"
"replace colors in text lines: \"sfk filter\" with -highlight\n"
"jpeg, jpg, png image processing, conversion: \"sfk samp javaimg\", \"sfk samp phpimg\""
 " or google for imagemagick.\n"
"all zip tar gz bz2 file extensions recognized by sfk: type \"sfk help opt\"\n"
"process files changed from, until a date: see option -since and -before\n"
      );
#ifdef _WIN32
      printx(
"print, get, dump clipboard contents: \"sfk fromclip\"\n"
      );
#endif
   }
}

int copyFormStr(char *pszDst, int nMaxDst, char *pszSrc, int nSrcLen, uint nflags=0);

// variable functions.
// input must be writeable.
char *SFKMapArgs::eval(char *pszExp)
{
   char szLitBuf[200];
   szLitBuf[0] = '\0';

   // parse generics
   char *pfunc = pszExp;
   char *pnext = pfunc;
   for (; *pnext!=0 && *pnext!='('; pnext++);
   if (!*pnext) return 0;
   *pnext++ = '\0';

   char *pvarn = pnext;
   for (; *pnext!=0 && *pnext!=',' && *pnext!=')'; pnext++);
   if (!*pnext) return 0;
   char csep = *pnext; // , or )
   *pnext++ = '\0';

   char *pvart = (char*)sfkgetvar(pvarn, 0);
   if (!pvart && strcmp(pfunc,"isset"))
   {
      pinf("undefined variable: %s\n", pvarn);
      return 0;
   }

   char *pres = 0;
   int   nres = 0;

   // isset(foo)
   if (!strcmp(pfunc, "isset"))
   {
      if (csep != ')') return 0;

      if (pvart)
         strcpy(szClEvalOut, "1");
      else
         strcpy(szClEvalOut, "0");

      return szClEvalOut;
      // NO fall through
   }

   // strlen(foo)
   if (!strcmp(pfunc, "strlen"))
   {
      if (csep != ')') return 0;

      snprintf(szClEvalOut, sizeof(szClEvalOut)-10,
         "%lu", (unsigned long)strlen(pvart));

      return szClEvalOut;
      // NO fall through
   }

   // strpos(foo,'bar')
   // strpos(foo,-spat '\x20')
   // strpos(foo,-case 'Bar')
   if (   !strcmp(pfunc, "strpos")
       || !strcmp(pfunc, "strrpos")
      )
   {
      if (csep != ',') return 0;

      bool bcase = 0;
      bool bspat = 0;
      bool brite = strcmp(pfunc, "strrpos") ? 0 : 1;

      while (1)
      {
         if (strBegins(pnext, "-case ")) {
            pnext += 6;
            bcase = 1;
         }
         else if (strBegins(pnext, "-spat ")) {
            pnext += 6;
            bspat = 1;
         }
         else break;
      }

      char *plitst = pnext;
      if (*plitst!='\'') return 0;
      plitst++;
      pnext = plitst;
      for (; *pnext!=0 && *pnext!='\''; pnext++);
      if (!*pnext) return 0;
      *pnext++ = '\0';
      if (*pnext!=')') return 0;

      if (bspat) {
         if (copyFormStr(szLitBuf, sizeof(szLitBuf)-10, plitst, strlen(plitst), 2))
            return 0;
         plitst = szLitBuf;
      }

      int ipos   = -1;
      char *phit = 0;
      if (brite)
         phit = bcase ? mystrrstr(pvart, plitst) : mystrristr(pvart, plitst);
      else
         phit = bcase ? strstr(pvart, plitst) : mystrstri(pvart, plitst);
      if (phit)
          ipos   = (int)(phit-pvart);
      sprintf(szClEvalOut, "%d", ipos);
      return szClEvalOut;
   }

   // substr(foo,3[,2])
   if (!strcmp(pfunc, "substr"))
   {
      if (csep != ',') return 0;

      char *poff = pnext;
      for (; *pnext!=0 && *pnext!=',' && *pnext!=')'; pnext++);
      if (!*pnext) return 0;
      bool ball = (*pnext==')' ? 1 : 0);
      *pnext++ = '\0';
      int ioff = atoi(poff);
      int ntxt = strlen(pvart);
      if (ioff < 0) {
         ioff = ntxt + ioff;
         if (ioff < 0) return 0;
      }
      if (ioff > ntxt) return 0;

      int ilen = 0;
      if (ball) {
         ilen = strlen(pvart+ioff);
      } else {
         char *plen = pnext;
         for (; *pnext!=0 && *pnext!=')'; pnext++);
         if (!*pnext) return 0;
         *pnext++ = '\0';
         ilen = atoi(plen);
      }

      nres = ilen;
      pres = pvart+ioff;
      // fall through
   }

   // trim(foo)
   // ltrim(foo)
   // rtrim(foo)
   if (   !strcmp(pfunc, "trim")
       || !strcmp(pfunc, "ltrim")
       || !strcmp(pfunc, "rtrim")
      )
   {
      if (csep != ')') return 0;

      bool bleft = 0;
      bool brite = 0;
      if (!strcmp(pfunc, "trim"))
         { bleft = brite = 1; }
      if (!strcmp(pfunc, "ltrim"))
         { bleft = 1; }
      if (!strcmp(pfunc, "rtrim"))
         { brite = 1; }

      char *pleft = pvart;
      char *prite = pvart+strlen(pvart);

      if (bleft) {
         while (*pleft==' ' || *pleft=='\t')
            pleft++;
      }
      if (brite) {
         while (prite > pleft && (prite[-1]== ' ' || prite[-1]=='\t'))
            prite--;
      }

      nres = prite - pleft;
      pres = pleft;
      // fall through
   }

   // lpad(foo,10)   "    text"
   // rpad(foo,10)   "text    "
   if (   !strcmp(pfunc, "lpad")
       || !strcmp(pfunc, "rpad")
      )
   {
      bool brite = strcmp(pfunc, "rpad") ? 0 : 1;
      if (csep != ',') return 0;

      char *ppad = pnext;
      for (; *pnext!=0 && *pnext!=')'; pnext++);
      if (!*pnext) return 0;
      *pnext++ = '\0';
      int ipad = atoi(ppad);
      int apad = abs(ipad);
      int ntxt = strlen(pvart);
      int idif = apad - ntxt;

      if (idif <= 0) {
         // nothing to pad
         nres = ntxt;
         pres = pvart;
      } else {
         // must fit into szClEvalOut
         if (ipad+10 > sizeof(szClEvalOut)) return 0;
   
         char *pdst = szClEvalOut;
         if (!brite) {
            for (; idif > 0; idif--)
               *pdst++ = ' ';
         }
         while (*pvart)
            *pdst++ = *pvart++;
         if (brite) {
            for (; idif > 0; idif--)
               *pdst++ = ' ';
         }
         *pdst = '\0';

         return szClEvalOut;
         // NO fall through
      }
   }

   if (pres)
   {
      if (nres+10 < sizeof(szClEvalOut)) {
         if (nres) memcpy(szClEvalOut, pres, nres);
         szClEvalOut[nres] = '\0';
         return szClEvalOut;
      }
      pszClEvalOut = new char[nres+4];
      if (!pszClEvalOut) return 0;
      if (nres) memcpy(pszClEvalOut, pres, nres);
      pszClEvalOut[nres] = '\0';
      return pszClEvalOut;
   }

   return 0;
}

#endif // USE_SFK_BASE

#endif // SFK_JUST_OSE







// --- xfind ose begin ---
#if defined(SFK_JUST_OSE)

int dumpWithContext(
   uchar *aContext,
   int    iCtxIdx,
   int    iCtxUsed,
    uchar *pHitOut,
    int    iHitOut,
     char *pHitAtt,  
   uchar  *pPostCur,
   uchar  *pPostMax,
   bool    bFirstHit,
   bool    bToOutFile,
   bool    bIsBinaryData,
   bool    bMatchedUntilEOL
 )
{
   if (!aContext || iCtxIdx<0 || iCtxUsed<0)
      return -1;
   if (!pHitOut  || iHitOut<0)
      return -2;
   if (!pPostCur || !pPostMax || pPostCur>pPostMax)
      return -3+perr("int. #215141,%p,%p,%d",pPostCur,pPostMax,(int)(pPostMax-pPostCur));
   int  imaxbuf = iGlblDumpBufSize / 2;
   int  imaxcur = imaxbuf - 2000;
   char *atxt = (char*)pGlblDumpBuf;
   char *aatt = (char*)pGlblDumpBuf + imaxbuf;
   int  itxt = 0;
   pGlblDumpBuf[iGlblDumpBufSize] = 1;
   int iPostMax = (int)(pPostMax - pPostCur);
   int iPre  = mymin(iCtxUsed, cs.contextchars);
   int iCur  = mymin(iHitOut , imaxcur);
   int iPost = mymin(iPostMax, cs.contextchars);
   if (bIsBinaryData) {
      if (cs.contextlines < 2) {
         iPre   = mymin(iPre , 40);
         iPost  = mymin(iPost, 40);
      } else {
         int iLines = cs.contextlines-1;
         iPre   = mymin(iPre , 40+80*iLines);
         iPost  = mymin(iPost, 40+80*iLines);
      }
   }
   bool bToBinary = chain.coldata && chain.colbinary;
   if (cs.contextlines > 0)
   {
      int iPreLines = 0;
      int ictx = iCtxIdx;
      for (int i=0; i<iPre; i++) {
         ictx = ictx ? ictx-1 : SFK_CTX_MASK;
         char c = aContext[ictx & SFK_CTX_MASK];
         if (c == '\n') {
            iPreLines++;
            if (iPreLines >= cs.contextlines) {
               ictx = (ictx+1) & SFK_CTX_MASK;
               iPre = i;
               break;
            }
         }
      }
      for (int i=0; i<iPre; i++) {
         atxt[itxt] = aContext[ictx & SFK_CTX_MASK];
         aatt[itxt] = ' ';
         ictx = (ictx+1) & SFK_CTX_MASK;
         itxt++;
      }
   }
   char c = '\0';
   for (int i=0; i<iCur; i++)
   {
      c = (char)pHitOut[i];
      atxt[itxt] = c;
      char catt = pHitAtt ? pHitAtt[i] : 'i';
      if (cs.contextlines > 0 && catt == ' ')
         catt = 'a';
      aatt[itxt] = catt;
      itxt++;
   }
   if (iCur < iHitOut)
   {
      strcpy(atxt+itxt, "[...]");
      strcpy(aatt+itxt, "wwwww");
      itxt += 5;
   }
   int iPostConsumed = 0;
   if (cs.contextlines > 0)
   {
      int iPostLines = bMatchedUntilEOL ? 1 : 0;
      if (iPostLines < cs.contextlines)
      for (int i=0; i<iPost; i++)
      {
         c = (char)pPostCur[i];
         atxt[itxt] = c;
         aatt[itxt] = ' ';
         itxt++;
         iPostConsumed++;
         if (c == '\n') {
            iPostLines++;
            if (iPostLines >= cs.contextlines)
               break;
         }
      }
   }
   if (c != '\n') {
      atxt[itxt] = '\n';
      aatt[itxt] = ' ';
      itxt++;
   }
   atxt[itxt] = '\0';
   aatt[itxt] = '\0';
   if (pGlblDumpBuf[iGlblDumpBufSize] != 1) {
      perr("buffer overflow in dumpcontext (%d,%d)", pGlblDumpBuf[imaxbuf],imaxbuf);
      pGlblDumpBuf[iGlblDumpBufSize] = '\0';
   }
   char *pSrcCur = (char*)atxt;
   char *pSrcMax = (char*)atxt+itxt;
   char *pAttCur = (char*)aatt;
   int  iMaxCols = MAX_LINE_LEN;
   if (cs.indent > 0 && cs.indent + 32 < nGlblConsColumns)
        iMaxCols = (nGlblConsColumns - 2) - cs.indent;
   uchar cSrc = 0;
   char  cAtt = 0;
   while (pSrcCur < pSrcMax)
   {
      int iDst = 0;
      if (cs.indent > 0 && cs.indent < 20)
      {
         memset(szLineBuf, ' ', cs.indent);
         memset(szAttrBuf, ' ', cs.indent);
         iDst = cs.indent;
      }
      while (pSrcCur < pSrcMax && iDst<iMaxCols)
      {
         cSrc = (uchar)*pSrcCur++;
         cAtt = *pAttCur++;
         #ifdef _WIN32
         if (cSrc == '\r')
            continue;
         #endif
         if (cSrc == 0) {
            if (!cs.placeholder)
               continue;
            cSrc = cs.placeholder;
            cAtt = 't';
         }
         if (cs.rawterm==0 && cSrc<32) {
            switch (cSrc) {
               case '\t':
               case '\n':
               case 0x1B:
                  break;
               default:
                  if (!cs.placeholder)
                     continue;
                  cSrc = cs.placeholder;
                  cAtt = 't';
                  break;
            }
         }
         if (cSrc == '\n')
            break;
         szLineBuf[iDst] = (char)cSrc;
         szAttrBuf[iDst] = (char)cAtt;
         iDst++;
      }
      szLineBuf[iDst] = '\0';
      szAttrBuf[iDst] = '\0';
      if (!cs.justrc)
      {
         if (bToOutFile) {
            if (cSrc=='\n') strcat(szLineBuf, cs.szeol);
            if (addToExtractOutFile((uchar*)szLineBuf, strlen(szLineBuf)))
               return -4;
         } else if (bToBinary) {
            if (cSrc=='\n') strcat(szLineBuf, cs.szeol);
            if (chain.addBinary((uchar*)szLineBuf, strlen(szLineBuf)))
               return -5;
         }
         else
         if (cs.litattr) {
            if (chain.coldata)
               chain.addLine(szLineBuf, szAttrBuf, 0);
            else
               printColorText(szLineBuf, szAttrBuf, 1);
         } else {
            chain.print("%s", szLineBuf);
         }
      }
   }
   return iPostConsumed;
}
void dumpPure(uchar *pDstText, int nDstLen, char *pDstAttr)
{
   char *pDmpCur = (char*)pDstText;
   char *pDmpMax = (char*)pDmpCur+nDstLen;
   char *pAttCur = (char*)pDstAttr; 
   int   iMaxAtt = pAttCur ? strlen(pAttCur) : 0;
   while (pDmpCur < pDmpMax)
   {
      int iCopy = pDmpMax - pDmpCur;
      if (iCopy > MAX_LINE_LEN)
          iCopy = MAX_LINE_LEN;
      int iDst=0;
      for (int iSrc=0; iSrc<iCopy; iSrc++)
      {
         uchar cSrc = (uchar)pDmpCur[iSrc];
         char  cAtt = (iSrc < iMaxAtt) ? pAttCur[iSrc] : ' ';
         #ifdef _WIN32
         if (cSrc == '\r')
            continue;
         #endif
         if (cSrc == 0) {
            if (cs.placeholder)
               cSrc = cs.placeholder;
            else
               continue;
         }
         if (cs.rawterm==0 && cSrc<32) {
            switch (cSrc) {
               case '\t':
               case '\n':
               case 0x1B:
                  break;
               default:
                  if (cs.placeholder) {
                     cSrc = cs.placeholder;
                     break;
                  }
                  continue;
            }
         }
         szLineBuf[iDst] = (char)cSrc;
         szAttrBuf[iDst] = (char)cAtt;
         iDst++;
      }
      szLineBuf[iDst] = '\0';
      szAttrBuf[iDst] = '\0';
      if (iDst > 0) {
         if (cs.litattr) {
            if (chain.coldata)
               chain.addLine(szLineBuf, szAttrBuf, 1);
            else
               printColorText(szLineBuf, szAttrBuf, 0);
         } else {
            chain.print("%s", szLineBuf);
         }
      }
      pDmpCur += iCopy;
   }
}
static uchar aContext[SFK_CTX_SIZE+100];
int execXFind(Coi *pcoi, char *pszOptOutFile)
{__
   int  iRC = 0;
   num  nFileSize     = 0;
   num  nInBufferSize = cs.recordsize * 2;
   uchar *pInBuffer   = 0;
   num  nInputUsed    = 0;
   num  nTotalRead    = 0;
   num  nTotalWritten = 0;
   bool bFileChanged  = 0;
   num  nFound        = 0;
   num  nBlockStartInFile = 0;
   int  nPerc=0, nLastPerc=0;
   bool bTold=0, bFileTold=0, bFirstHit=1;
   num  nLastDumpOff  = -1;
   int  iContextIdx   =  0;
   int  iContextUsed  =  0;
   bool bRepDump      = cs.repDump;
   bool bWithContext  = cs.contextlines || cs.indent || cs.szseparator[0];
   bool bSameLengthAndFile = 0;
   bool bRepeatRun    = 0;
   char szFileHead[SFK_MAX_PATH+100];
   mclear(aContext);
   szFileHead[0] = '\0';
   if (cs.usefilehead) {
      char *pmask = cs.szfilehead;
      if (cs.filesChg==0) {
         if (!strncmp(pmask, "\r\n", 2)) pmask += 2;
         else
         if (pmask[0] == '\n') pmask++;
      }
      snprintf(szFileHead, sizeof(szFileHead)-10, pmask, pcoi->name());
   } else {
      bFileTold=1;
   }
   if (cs.debug)
      printf("execReplaceNew: %s\n", pcoi->name());
   if (cs.recordsize < 1)
      return 9+perr("wrong recordsize value");
   char *pszFile = pcoi->name();
   if (!pcoi->existsFile())
      return 1+pwarn("unable to read: %s - skipping\n", pszFile);
   {
      nFileSize = pcoi->getSize();
      if (nFileSize < 0)
         return 1+pwarn("unable to read: %s - skipping\n", pszFile);
      if (nFileSize == 0) {
         if (!cs.xtext && !cs.hexfind)
            pwarn("empty file: %s - skipping\n", pszFile);
         return 0;
      }
   }
   FileInfo finf;
   if (finf.init(pszFile, 56)) return 9;
   Coi *pOutCoi = 0;
   for (int i5=0; i5<nBinRepExp; i5++)
   {
      apRepFlags[i5] &= (0xFF ^ (1 << 1));
      apRepOffs[i5] = 0;
   }
   uchar abProbe[10];
   uchar abStartMap[256+10];
   mclear(abStartMap);
   {
      mclear(abProbe);
      if (cs.xpat)
      {
         if (!apRepObj)
            return 9+perr("int. #2168312");
         for (int iPat=0; iPat<nBinRepExp; iPat++)
         {
            SFKMatch *pObj = &apRepObj[iPat];
            for (int iCode=0; iCode<256; iCode++)
               abStartMap[iCode] |= pObj->aClHeadMatch[iCode];
         }
      }
      else
      {
         for (int iCode=0; iCode<256; iCode++)
         {
            abProbe[0] = (uchar)iCode;
            for (int iPat=0; iPat<nBinRepExp; iPat++)
            {
               uchar *pPatText = apRepSrcExp[iPat];
               int   nPatLen   = apRepSrcLen[iPat];
               int   nPatFlags = apRepFlags[iPat];
               bool   bUseCase = (nPatFlags & (1<<2)) ? 1 : 0;
               if (nPatLen < 1) continue;
               #ifdef WITH_CASE_XNN
               uchar *pBit     = apRepSrcBit[iPat];
               if (!sfkmemcmp2(pPatText, abProbe, 1, bUseCase, pBit))
                  abStartMap[iCode & 0xFFU] = 1;
               #else
               if (!sfkmemcmp(pPatText, abProbe, 1, bUseCase))
                  abStartMap[iCode & 0xFFU] = 1;
               #endif
            }
         }
      }
   }
   info.setStatus(cs.extract ? "read":"repl", pcoi->name());
 do 
 {
   if (!(pInBuffer = new uchar[nInBufferSize+1024]))
      { perr("out of memory, record size too large"); iRC=1; break; }
   memset(pInBuffer, 0, nInBufferSize+1024);
   {
      if (pcoi->open("rb")) {
         perr("cannot open: %s - skipping", pszFile);
         iRC=1;
         break;
      }
   }
   int  bStart      = 1;
   int  bLineStart  = 1;
   int  bLastRecord = 0;
   bool bStop = false;
   bool bEOF = false;
   bool bBinaryFile = 0;
   bool bAllThrough = 0;
   while (!bStop)
   {
      if (userInterrupt())
         { pinf("interrupted by user.\n"); iRC=2; break; }
      if (nInputUsed <= 0 && bEOF)
         break;
      num nInBufferRemainSpace = nInBufferSize - nInputUsed;
      if (nInBufferRemainSpace > 0)
      {
         num nBlockSize = pcoi->read(pInBuffer+nInputUsed, nInBufferRemainSpace);
         if (nBlockSize <= 0)
            bEOF = true;
         else {
            nInputUsed += nBlockSize;
            nTotalRead += nBlockSize;
            if (bStart && !bBinaryFile) {
               if (memchr(pInBuffer, '\0', nInputUsed))
                  bBinaryFile = 1;
            }
         }
      }
      bLastRecord = (nTotalRead >= nFileSize) ? 1 : 0;
      num nSearchRange = cs.recordsize;
      if (nInputUsed < nSearchRange)
         nSearchRange  = nInputUsed;
      uchar *pCopyFrom = pInBuffer; 
      uchar *pSrcCur   = pInBuffer; 
      uchar *pSrcMax   = pInBuffer + nSearchRange;
      uchar *pEndMax   = pInBuffer + nInputUsed;
      bool bCurrentBlockChanged = 0;
      while (!bStop && (pSrcCur <= pSrcMax))
      {
         if (pSrcCur == pSrcMax) {
            if (!bLastRecord)
               break;
         }
         else
         if (!bStart) {
            if (!abStartMap[*pSrcCur]) {
               if (bRepDump) {
                  aContext[iContextIdx & SFK_CTX_MASK] = *pSrcCur;
                  iContextIdx = (iContextIdx+1) & SFK_CTX_MASK;
                  iContextUsed++;
               }
               pSrcCur++;
               continue;
            }
         }
         num nCmpRemain = pEndMax - pSrcCur;
         int iStepped = 0;
         if (!bAllThrough)
         for (int iPat=0; iPat<nBinRepExp; iPat++)
         {
            int nPatLen = apRepSrcLen[iPat];
            if (cs.xpat == 0 && nPatLen > nCmpRemain)
               continue;
            uchar *pPatText = apRepSrcExp[iPat];
            int   nPatFlags = apRepFlags[iPat];
            bool   bUseCase = (nPatFlags & (1<<2)) ? 1 : 0;
            bool   bMatch   = false;
            #ifdef WITH_CASE_XNN
            uchar *pBit     = apRepSrcBit[iPat];
            #endif
            int voff=0;
            if (cs.xpat) {
               SFKMatch *pObj = &apRepObj[iPat];
               nPatLen = nCmpRemain;
               if (!pObj->matches(pSrcCur, nPatLen, bStart, &bLineStart, bLastRecord)) {
                  bMatch = true; 
                  voff=pObj->viewOffset();
               }
            }
            else
            {
               #ifdef WITH_CASE_XNN
               if (!sfkmemcmp2(pSrcCur, pPatText, nPatLen, bUseCase, pBit))
                  bMatch = true;
               #else
               if (!sfkmemcmp(pSrcCur, pPatText, nPatLen, bUseCase))
                  bMatch = true;
               #endif
            }
            if (!bMatch)
               continue;
            uchar *pDstText = apRepDstExp[iPat];
            int   nDstLen   = apRepDstLen[iPat];
            char  *pDstAttr = 0;
            bool bOutHeadDone = 0;
            bool bOutDataDone = 0;
            bool bDumpToText  = (cs.dumpfrom==0 && (nPatFlags & (1 << 3))!=0);
            bool bDumpSingle  = (nPatFlags & (1 << 4)) ? 1 : 0;
            bool bDumpFromText= cs.dumpboth || (bDumpToText ? 0 : 1);
            if (cs.xpat)
            {
               SFKMatch *pObj = &apRepObj[iPat];
               int iSubRC = 0;
               if (!(pDstText = pObj->renderOutput(nDstLen, iSubRC)))
                  { bStop=true; iRC=9; break; }
               pDstAttr = pObj->outAttr();
               if (!cs.sim && cs.extract) {
                  if (pszOptOutFile) {
                     if (provideExtractOutFile(pszOptOutFile))
                        { bStop=true; iRC=9; break; }
                     if (!bFileTold) {
                        bFileTold = 1;
                        if (!cs.nonames)
                           addToExtractOutFile((uchar*)szFileHead, strlen(szFileHead));
                     }
                     bOutHeadDone = 1;
                     if (bWithContext) {
                        if (!bFirstHit && cs.szseparator[0])
                           addToExtractOutFile((uchar*)cs.szseparator, strlen(cs.szseparator));
                     } else {
                        if (addToExtractOutFile(pDstText, nDstLen))
                           { bStop=true; iRC=9; break; }
                        bOutDataDone = 1;
                     }
                  } else if (chain.coldata) {
                     if (chain.colbinary) {
                        if (!bFileTold) {
                           bFileTold = 1;
                           if (!cs.nonames)
                              chain.addBinary((uchar*)szFileHead, strlen(szFileHead));
                        }
                        bOutHeadDone = 1;
                        if (bWithContext) {
                           if (!bFirstHit && cs.szseparator[0])
                              chain.addBinary((uchar*)cs.szseparator, strlen(cs.szseparator));
                        } else {
                           if (chain.addBinary(pDstText, nDstLen))
                              { bStop=true; iRC=9; break; }
                           bOutDataDone = 1;
                        }
                     }
                  }
               }
            }
            if ((cs.verbose >= 2) && nDstLen && !(nPatFlags & (1<<0))) {
               printf("replace @%s: %.*s -> %.*s\n", numtohex(nBlockStartInFile+(pSrcCur-pInBuffer),10),
                  nPatLen, pSrcCur, nDstLen, pDstText);
            }
            if (cs.useJustNames) 
            {
               if (!bFileTold) {
                  bFileTold = 1;
                  if (chain.coldata) {
                     sprintf(szLineBuf3, "%s", pcoi->name());
                     setattr(szAttrBuf3, 'f', strlen(szLineBuf3)+2, MAX_LINE_LEN);
                     chain.addLine(szLineBuf3, szAttrBuf3);
                  } else {
                     info.print("%s\n", pcoi->name());
                  }
               }
            }
            else
            if (cs.xtext && !bOutDataDone)
            {
               if (!bOutHeadDone)
               {
                  if (!bFileTold) {
                     bFileTold = 1;
                     if (!cs.justrc) chain.print('f', 4, "%s", szFileHead);
                  }
                  if (!bFirstHit && cs.szseparator[0]) {
                     if (!cs.justrc) chain.print('t', 4, "%s", cs.szseparator);
                  }
               }
               if (bWithContext)
               {
                  int iPostConsumed = dumpWithContext(
                     aContext,iContextIdx,iContextUsed,
                     pDstText,nDstLen,pDstAttr,
                     pSrcCur+nPatLen,pEndMax,
                     bFirstHit,
                     pszOptOutFile ? 1 : 0,
                     bBinaryFile,
                     bLineStart
                     );
                  if (iPostConsumed < 0)
                     { perr("error %d on output", iPostConsumed); bStop=true; iRC=9; break; }
                  iContextIdx = 0;
                  iContextUsed = 0;
                  nPatLen += iPostConsumed;
               }
               else
               {
                  dumpPure(pDstText,nDstLen,pDstAttr);
               }
               bFirstHit = 0;
            }
            else
            if ((bRepDump || bDumpSingle) && !bOutDataDone)
            {
               num nctx    = nGlblDumpCtx;
               num nAlign0 = bGlblHexDumpWide ? 16 :  8;
               num nAlign1 = bGlblHexDumpWide ? 32+nctx : 16+nctx;
               num nAlign2 = bGlblHexDumpWide ? 48+nctx : 18+nctx;
               num nHitRaw = pSrcCur + voff - pInBuffer;
               num nHitLow = nHitRaw;
               num nHitHi  = nHitLow + (nPatLen-voff);
               if (nHitLow > nAlign1) nHitLow -= nAlign1; else nHitLow = 0;
               if (nHitHi  < (nInputUsed - nAlign2)) {
                  nHitHi += nAlign2;
                  num nDiff = nHitHi-nHitLow;
                  nDiff = ((num)(nDiff / nAlign0)) * nAlign0; 
                  nHitHi = nHitLow + nDiff;
               } else {
                  nHitHi = nInputUsed;
               }
               num nDumpLen = nHitHi-nHitLow;
               if (cs.maxdump)
                  nDumpLen = mymin(cs.maxdump,nDumpLen);
               {
                  int iHiOff=-1,iHiLen=-1;
                  iHiOff = (int)(nHitRaw - nHitLow);
                  iHiLen = nPatLen-voff;
                  num nListOff = nBlockStartInFile + nHitLow;
                  if (bTold) { bTold=0; finf.printBlankLine(78); }
                  char szOffBuf1[60]; szOffBuf1[0] = '\0';
                  char szOffBuf5[60]; szOffBuf5[0] = '\0';
                  char szOffBuf2[60]; szOffBuf2[0] = '\0';
                  char szOffBuf3[60]; szOffBuf3[0] = '\0';
                  char szOffBuf6[60]; szOffBuf6[0] = '\0';
                  num nAbsOff = nHitRaw + nBlockStartInFile;
                  if (!cs.fullheader) {
                     sprintf(szOffBuf1, "at offset 0x%s", numtohex(nAbsOff));
                  } else {
                     sprintf(szOffBuf1, "at offset %s", numtoa(nAbsOff));
                     sprintf(szOffBuf5, "0x%s", numtohex(nAbsOff));
                  }
                  if (cs.reldist && nLastDumpOff >= 0) {
                     int nRelOff = (int)(nAbsOff - nLastDumpOff);
                     sprintf(szOffBuf2, " reldist %u (0x%x)", nRelOff, nRelOff);
                  }
                  if (cs.xpat != 0 && nPatLen > 0) {
                     if (nPatFlags & (1 << 3)) {
                        int nLenDiff = nDstLen-nPatLen;
                        sprintf(szOffBuf3, " len %u/%u/%+d", nPatLen, nDstLen, nLenDiff);
                        sprintf(szOffBuf6, " 0x%s", numtohex(nPatLen));
                     } else {
                        sprintf(szOffBuf3, " len %u", nPatLen);
                        sprintf(szOffBuf6, " 0x%s", numtohex(nPatLen));
                     }
                  }
                  if (!cs.nonames && !cs.justrc) {
                     if (cs.astext) {
                        if (!bFileTold) {
                           bFileTold = 1;
                           chain.print('f', 1, "%s",pszFile);
                        }
                     } else {
                        if (!cs.fullheader)
                           chain.print('f', 1, "%s : %s %s%s%s",pszFile,(cs.sim||cs.extract)?"hit":"change",
                              szOffBuf1,szOffBuf2,szOffBuf3);
                        else
                           chain.print('f', 1, "%s : %s %s%s%s (%s%s)",pszFile,(cs.sim||cs.extract)?"hit":"change",
                              szOffBuf1,szOffBuf2,szOffBuf3,szOffBuf5,szOffBuf6);
                     }
                  }
                  if (cs.astext) {
                     if (!cs.justrc) {
                        if (cs.dumpboth) {
                           chain.print(' ', 4, "FROM: %.*s", (int)iHiLen, pInBuffer+nHitRaw);
                           chain.print('a', 4, "TO  : %.*s", (int)nDstLen, pDstText);
                        } else {
                           if (bDumpFromText)
                              chain.print("%s%.*s", cs.noind ? "" : "   ", (int)iHiLen, pInBuffer+nHitRaw);
                           if (cs.dumpboth)
                              dumpFromToSeparator();
                           if (bDumpToText)
                              chain.print("%s%.*s", cs.noind ? "" : "   ", (int)nDstLen, pDstText);
                        }
                     }
                  } else if (!cs.justrc) {
                     if (bDumpFromText)
                        execHexdump(0, pInBuffer+nHitLow, nDumpLen, iHiOff, iHiLen, 0, nListOff);
                     if (cs.dumpboth)
                        dumpFromToSeparator();
                     if (bDumpToText)
                        dumpRepOut(pInBuffer+nHitLow, nDumpLen, iHiOff, iHiLen, pDstText, nDstLen, nListOff);
                  }
                  nLastDumpOff = nAbsOff;
               }
            }  
            iContextUsed = 0;
            bFileChanged = 1;
            nFound++;
            apRepFlags[iPat] |= (1 << 1);
            if (cs.extract)
            { }
            else
            if (bSameLengthAndFile)
            {
               if (!cs.sim && !cs.extract) {
                  if (nPatLen != nDstLen)
                     { perr("int. #21211502"); iRC=9; bStop=true; break; }
                  memcpy(pSrcCur, pDstText, nPatLen);
                  bCurrentBlockChanged = 1;
               }
            }
            if (nPatLen == 0)
               continue;
            if (pSrcCur[nPatLen-1] == '\n')
               bLineStart = 1;
            else
               bLineStart = 0;
            iStepped += nPatLen;
            pSrcCur  += nPatLen;
            pCopyFrom = pSrcCur;
            bStart = 0;
            if (cs.useFirstHitOnly) {
               if (!cs.sim && !cs.extract)
                  bAllThrough=true; 
               else
                  bStop=true;
            }
            break;
         }  
         bStart = 0;
         if (pSrcCur == pSrcMax)
            break;   
         if (!iStepped)
         {
            if (*pSrcCur == '\n')
               bLineStart = 1;
            else
               bLineStart = 0;
            if (bRepDump) {
               aContext[iContextIdx & SFK_CTX_MASK] = *pSrcCur;
               iContextIdx = (iContextIdx+1) & SFK_CTX_MASK;
               iContextUsed++;
            }
            pSrcCur++;
         }
      }  
      pCopyFrom = pSrcCur;
      num nConsumed = pCopyFrom - pInBuffer;
      num nRemain   = nInputUsed - nConsumed;
      if (nRemain < 0)
         { perr("int. #21211501 (%ld)", (long)nRemain); iRC=9; bStop=true; break; }
      if (nRemain > 0)
         memmove(pInBuffer, pCopyFrom, nRemain); 
      nInputUsed = nRemain;
      nBlockStartInFile += nConsumed;
      if (bSameLengthAndFile != 0 && cs.maxscan != 0 && nBlockStartInFile >= cs.maxscan)
         { bStop=true; break; }
      nPerc = (int)(nTotalRead * 100 / (nFileSize ? nFileSize : 1));
      if (   cs.quiet==0 && pcoi->isHttp()==0
          && nPerc!=nLastPerc && finf.timeToTell()!=0
         )
      {
         info.print("%02d%% %s%s : %s %s \r",nPerc,finf.prefix(),finf.shortName(),numtoa(nFound),
            (cs.sim||cs.extract)?"hits":"changes");
         bTold = 1;
         nLastPerc = nPerc;
      }
   }  
   cs.files++; 
 }
 while (0); 
   if (pcoi->isFileOpen())
      pcoi->close();
   if (bFileChanged && !bRepeatRun) {
      if (chain.colfiles)
         chain.addFile(pOutCoi ? *pOutCoi : *pcoi);
      cs.filesChg++;
   }
   if (pInBuffer)
      delete [] pInBuffer;
   if (bTold)
      info.clear();
   perFileExtractOutCleanup();
   int nTotPats = nBinRepExp;
   int nHitPats = 0;
   for (int i2=0; i2<nBinRepExp; i2++)
   {
      if (apRepFlags[i2] & (1 << 1))
         nHitPats++;
      else
      if (cs.verbose)
      {
         if (cs.xpat) {
            info.print("%s : pattern not found: %s\n",pszFile,apRepObj[i2].fromText());
         }
         else
         {
            bool bPlainText = apRepFlags[i2] & (1 << 0) ? 0 : 1;
            uchar *pBin = apRepSrcExp[i2];
            if (bPlainText)
               for (int i9=0; i9<apRepSrcLen[i2]; i9++)
                  if (!isprint(pBin[i9]))
                     bPlainText=0;
            info.print("%s : pattern not found: ",pszFile);
            if (!bPlainText) {
               info.print("hex ");
               for (int i9=0; i9<apRepSrcLen[i2]; i9++)
                  info.print("%02X",pBin[i9]);
               info.print(" text ");
               for (int i9=0; i9<apRepSrcLen[i2]; i9++)
                  if (isprint(pBin[i9]))
                     info.print("%c",pBin[i9]);
                  else
                     info.print(".");
               info.print("\n");
            } else {
               info.print("%s\n",pBin);
            }
         }
      }
   }
   int nNotPats = nTotPats - nHitPats;
   if (cs.dostat || cs.verbose)
   {
      if (!nHitPats && !cs.verbose)
      { } 
      else
      {
         cchar *pszPre   = finf.prefix();
         cchar *pszShort = finf.shortName();
         num   nSizeDiff = nTotalWritten - nFileSize;
         const char *pszSign = (nSizeDiff > 0) ? "+":"";
         char szNumBuf[100];
         info.print("[%s/%d/%d] %s%s",  
            numtoa(nFound,3,szNumBuf),
            (int)nHitPats,(int)nNotPats,pszPre,pszShort);
         if (   !cs.extract && !cs.xtext && !cs.hexfind
             && !bSameLengthAndFile && nSizeDiff)
         {
            setTextColor(nGlblTimeColor);
            info.print("   %s%s bytes\n",pszSign,numtoa(nSizeDiff));
            setTextColor(-1);
         } else {
            info.print("   \n");
         }
      }
   }
   return iRC;
}
#endif // defined(SFK_JUST_OSE)
// --- xfind ose end ---

