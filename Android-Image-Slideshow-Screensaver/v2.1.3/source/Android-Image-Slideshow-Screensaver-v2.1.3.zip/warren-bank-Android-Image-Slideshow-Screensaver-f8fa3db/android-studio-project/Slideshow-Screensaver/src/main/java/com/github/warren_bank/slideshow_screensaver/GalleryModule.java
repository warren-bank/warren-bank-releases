package com.github.warren_bank.slideshow_screensaver;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/** Ensures that Glide's generated API is created for the Gallery sample. */
@GlideModule
public final class GalleryModule extends AppGlideModule {
  // Intentionally empty.
}
