package com.github.warren_bank.webcast.webview;

public class BrowserWebViewClient extends BrowserWebViewClient_AdBlock {
    public BrowserWebViewClient(BrowserActivity browserActivity) {
        super(browserActivity);
    }
}
