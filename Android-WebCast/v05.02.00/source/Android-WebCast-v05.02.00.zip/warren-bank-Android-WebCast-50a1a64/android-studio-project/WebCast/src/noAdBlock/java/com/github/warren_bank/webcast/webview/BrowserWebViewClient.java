package com.github.warren_bank.webcast.webview;

public class BrowserWebViewClient extends BrowserWebViewClient_VideoDetector {
    public BrowserWebViewClient(BrowserActivity browserActivity) {
        super(browserActivity);
    }
}
