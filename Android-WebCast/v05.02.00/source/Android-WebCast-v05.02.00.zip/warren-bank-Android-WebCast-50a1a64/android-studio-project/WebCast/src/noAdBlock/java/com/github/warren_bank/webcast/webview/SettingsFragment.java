package com.github.warren_bank.webcast.webview;

public class SettingsFragment extends SettingsFragment_Base {}
