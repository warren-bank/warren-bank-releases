# Limbo Emulator (QEMU) for Android
#
# For APK Downloads, Guides, and Help visit the Limbo Wiki:
# https://github.com/limboemu/limbo/wiki

Limbo is a QEMU-based emulator for Android supports emulation for these architectures:
	x86/x86_64
	ARM/ARM64
	PowerPC/PowerPC64
	Sparc

For developers read file README.developers for instructions on how to compile on your own
	and other useful information.
