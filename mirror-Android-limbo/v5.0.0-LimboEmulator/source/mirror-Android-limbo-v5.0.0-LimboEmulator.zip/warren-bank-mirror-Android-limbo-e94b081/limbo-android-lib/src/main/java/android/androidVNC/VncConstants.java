package android.androidVNC;

/**
 * Keys for intent values
 */
public class VncConstants {
	public static final String CONNECTION = "android.androidVNC.CONNECTION";
}
