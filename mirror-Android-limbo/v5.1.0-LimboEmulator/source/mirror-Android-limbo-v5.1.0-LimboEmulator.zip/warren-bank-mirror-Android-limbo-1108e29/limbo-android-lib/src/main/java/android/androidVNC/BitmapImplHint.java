package android.androidVNC;

public class BitmapImplHint {
	public static final long AUTO = 0L;
	public static final long FULL = 1L;
	public static final long TILE = 2L;
}
