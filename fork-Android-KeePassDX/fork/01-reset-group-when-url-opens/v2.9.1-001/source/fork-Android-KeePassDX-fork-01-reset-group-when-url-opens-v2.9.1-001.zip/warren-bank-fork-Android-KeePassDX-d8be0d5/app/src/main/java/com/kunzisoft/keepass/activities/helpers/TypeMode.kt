package com.kunzisoft.keepass.activities.helpers

enum class TypeMode {
    DEFAULT, MAGIKEYBOARD, AUTOFILL
}