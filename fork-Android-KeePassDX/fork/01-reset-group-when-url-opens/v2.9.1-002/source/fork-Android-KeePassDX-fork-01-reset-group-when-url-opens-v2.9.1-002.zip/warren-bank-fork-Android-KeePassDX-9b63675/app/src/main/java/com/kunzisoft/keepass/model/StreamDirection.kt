package com.kunzisoft.keepass.model

enum class StreamDirection {
    UPLOAD, DOWNLOAD
}