package com.kunzisoft.keepass.activities.helpers

enum class SpecialMode {
    DEFAULT,
    SEARCH,
    SAVE,
    SELECTION,
    REGISTRATION;
}