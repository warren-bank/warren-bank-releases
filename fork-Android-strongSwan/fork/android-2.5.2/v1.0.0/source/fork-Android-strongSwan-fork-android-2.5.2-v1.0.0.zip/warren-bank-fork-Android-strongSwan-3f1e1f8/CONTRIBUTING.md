Please refer to the [developer documentation](https://docs.strongswan.org/docs/5.9/devs/devs.html)
in our documentation for details regarding **code style** and
[**contribution requirements**](https://docs.strongswan.org/docs/5.9/devs/contributions.html).
