package com.github.warren_bank.filterablerecyclerview;

public interface FilterableListItemOnClickListener {
    void onFilterableListItemClick(FilterableListItem item);
}
