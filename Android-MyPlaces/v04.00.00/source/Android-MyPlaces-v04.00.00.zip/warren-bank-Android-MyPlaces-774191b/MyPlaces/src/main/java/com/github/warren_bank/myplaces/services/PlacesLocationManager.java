package com.github.warren_bank.myplaces.services;

import com.github.warren_bank.myplaces.models.WaypointListItem;

import com.github.warren_bank.filterablerecyclerview.FilterableListItem;
import com.github.warren_bank.filterablerecyclerview.FilterableAdapter;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;

import java.util.Collections;
import java.util.List;

public class PlacesLocationManager {
    private Context                     context;
    private LocationManager             locationManager;
    private List<FilterableListItem>    unfilteredList;
    private FilterableAdapter           recyclerFilterableAdapter;
    private PlacesLocationListener      places_locationListener;
    private int                         interval;

    private class PlacesLocationListener implements LocationListener {
        @Override
        public void onLocationChanged(Location location) {
            PlacesLocationManager.this.calculateDistance(location);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }           
    }

    public PlacesLocationManager(
        Context                     context,
        List<FilterableListItem>    unfilteredList,
        FilterableAdapter           recyclerFilterableAdapter
    ) {
        this.context                   = context;
        this.locationManager           = (LocationManager)context.getSystemService(Context.LOCATION_SERVICE);
        this.unfilteredList            = unfilteredList;
        this.recyclerFilterableAdapter = recyclerFilterableAdapter;
        this.places_locationListener   = new PlacesLocationListener();
        this.interval                  = 0;
    }

    public void setInterval(int seconds) {
        if (interval != seconds) {
            clearInterval();

            // sanity checks
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                if (!locationManager.isLocationEnabled()) return;
            }
            if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) return;

            interval = seconds;

            long minTime      = seconds * 1000;  // milliseconds
            float minDistance = 1.5f;            // 1.5 meters is about 5 ft
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                minTime,
                minDistance,
                places_locationListener
            );
        }
    }

    public void clearInterval() {
        if (interval != 0) {
            locationManager.removeUpdates(places_locationListener);
            interval = 0;
        }
    }

    public void refresh() {
        // sanity checks
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            if (!locationManager.isLocationEnabled()) return;
        }
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) return;

        locationManager.requestSingleUpdate(
            LocationManager.GPS_PROVIDER,
            places_locationListener,
            null
        );
    }

    protected void calculateDistance(Location location) {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(final Void ... params) {

                for (int i=0; i < unfilteredList.size(); i++) {
                    WaypointListItem point = (WaypointListItem) unfilteredList.get(i);
                    point.updateDistance(location);
                }

                Collections.sort(unfilteredList, WaypointListItem.distanceOrderComparator);
                return null;
            }
 
            @Override
            protected void onPostExecute(final Void result) {
                recyclerFilterableAdapter.notifyDataSetChanged();
            }
        }.execute();
    }
}
