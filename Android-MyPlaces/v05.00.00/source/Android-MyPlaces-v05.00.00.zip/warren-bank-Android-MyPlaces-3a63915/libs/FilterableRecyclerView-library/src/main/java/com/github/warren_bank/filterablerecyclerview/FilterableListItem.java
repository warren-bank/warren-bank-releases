package com.github.warren_bank.filterablerecyclerview;

public interface FilterableListItem {
    String getFilterableValue();
}
