#### Bookmarks:

* [canonical] [2livewatch.blogspot.com](https://web.archive.org/web/*/http://2livewatch.blogspot.com/*)
  - [CNN](https://2livewatch.blogspot.com/2012/07/cnn-2.html)
  - [MSNBC](https://2livewatch.blogspot.com/2012/07/msncb.html)
  - [Fox News](https://2livewatch.blogspot.com/2016/07/foxnews.html)

* [mirror] [ufreetv.com](http://ufreetv.com/foxnews-cnn-msnbc-live-stream.html)
  - [MSNBC](http://ufreetv.com/msnbc.html)
  - [Fox News](http://ufreetv.com/foxnews.html)

#### notes:

* _ok.ru_ URLs for the embedded iframes on these sites appear to be updated daily
* _ufreetv.com_ includes a collection of streams that originate from various sources
  - streams that currently mirror _ok.ru_ could change source at any time
