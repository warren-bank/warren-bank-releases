### [Arconai TV](https://github.com/warren-bank/crx-Arconai-TV)

Route video stream through [HLS-Proxy](https://github.com/warren-bank/HLS-Proxy) and transfer to player on [WebCast-Reloaded](https://github.com/warren-bank/crx-webcast-reloaded) [external website](https://warren-bank.github.io/crx-webcast-reloaded/external_website/index.html).

#### Summary:

Chromium browser extension:
* works on pages that are hosted at: [`arconaitv.us/*`](https://www.arconaitv.us/)

#### Legal:

* copyright: [Warren Bank](https://github.com/warren-bank)
* license: [GPL-2.0](https://www.gnu.org/licenses/old-licenses/gpl-2.0.txt)
