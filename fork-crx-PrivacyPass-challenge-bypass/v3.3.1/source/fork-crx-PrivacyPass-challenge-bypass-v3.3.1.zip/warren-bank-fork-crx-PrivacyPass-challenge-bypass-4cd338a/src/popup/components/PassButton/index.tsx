import React, { useState } from 'react';

import styles from './styles.module.scss';

export function PassButton(props: Props): JSX.Element {
    const [mouseover, setMouseover] = useState(false);

    function onEnter() {
        setMouseover(true);
    }

    function onLeave() {
        setMouseover(false);
    }

    const element = mouseover ? chrome.i18n.getMessage('ctaGetMorePasses') : props.children;

    return (
        <div
            className={styles.button}
            onClick={props.onClick}
            onMouseEnter={onEnter}
            onMouseLeave={onLeave}
        >
            <div className={styles.content}>{element}</div>
            <div className={styles.value}>{props.value}</div>
        </div>
    );
}

interface Props {
    value: number;
    children: string;
    onClick?: () => void;
}
