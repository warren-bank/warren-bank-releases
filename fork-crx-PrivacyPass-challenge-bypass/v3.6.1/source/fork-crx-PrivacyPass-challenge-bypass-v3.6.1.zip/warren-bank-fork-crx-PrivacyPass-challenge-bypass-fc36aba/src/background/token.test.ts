import Token from './token';

test('Construct a token', () => {
    new Token();
});
