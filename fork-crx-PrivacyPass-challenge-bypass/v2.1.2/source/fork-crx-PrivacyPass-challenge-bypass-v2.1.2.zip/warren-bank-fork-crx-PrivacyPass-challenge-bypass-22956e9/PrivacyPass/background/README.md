### forked from:

* privacypass/challenge-bypass-extension
  - [git repo](https://github.com/privacypass/challenge-bypass-extension)
  - [release for v2.0.9](https://github.com/privacypass/challenge-bypass-extension/releases/tag/v2.0.9)

### dependencies:

* asn1-parser
  - [npm](https://www.npmjs.com/package/asn1-parser)
  - [git repo](https://git.coolaj86.com/coolaj86/asn1-parser.js/)
  - [release for v1.1.8](https://git.coolaj86.com/coolaj86/asn1-parser.js/src/tag/v1.1.8/asn1-parser.js)
* ~~sjcl~~
  - [npm](https://www.npmjs.com/package/sjcl)
  - [git repo](https://github.com/bitwiseshiftleft/sjcl)
  - [release for v1.0.8](https://github.com/bitwiseshiftleft/sjcl/blob/1.0.8/sjcl.js)
    * issue:
      - official builds are not configured to include _ecc.js_
* @warren-bank/sjcl
  - [npm](https://www.npmjs.com/package/@warren-bank/sjcl)
  - [git repo](https://github.com/warren-bank/fork-sjcl-full)
  - [release for v1.0.8-full](https://github.com/warren-bank/fork-sjcl-full/blob/1.0.8-full/sjcl.js)
