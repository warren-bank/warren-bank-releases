declare module '*.json';
declare module '*.scss';
declare module '*.svg';
