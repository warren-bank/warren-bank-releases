# Snapdrop & PairDrop for Android
<img align="right" src="android-studio-project/snapdrop/src/main/res/mipmap-xxxhdpi/ic_launcher.png"></img>

**Snapdrop & PairDrop for Android** is an android client for the free and open source local file sharing solution https://snapdrop.net/. 

>[!TIP]
>Do you also sometimes have the problem that you just need to quickly transfer a file from your phone to the PC?
>
> - USB? - Old fashioned!
> - Bluetooth? - Too much cumbersome and slow!
> - E-mail? - Please not another email I write to myself!
> - Snapdrop!

Snapdrop is a local file sharing solution which completely works in your browser. A bit like Apple's Airdrop, but not only for Apple devices. Windows, Linux, Android, IPhone, Mac - no problem at all!

However, even if it theoretically would fully work in your browser and you don't have to install anything, you will love this app if you want to use Snapdrop more often in your daily life. Thanks to perfect integration into the Android operating system, files are sent even faster. Directly from within other apps you can select Snapdrop to share with. Thanks to its radical simplicity, "Snapdrop for Android" makes the everyday life of hundreds of users easier. As an open source project we don't have any commercial interests but want to make the world a little bit better. Join and convince yourself!

## Where can I download the app?
**Snapdrop for Android** is available on [Google Play](https://play.google.com/store/apps/details?id=com.fmsys.snapdrop). For more advanced users, you can download the app via [F-Droid](https://f-droid.org/en/packages/com.fmsys.snapdrop/) as well. 
<p align="center">
  <a href="https://play.google.com/store/apps/details?id=com.fmsys.snapdrop">
    <img height="100" alt="Get it on Google Play" src="https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png">
  </a>
  <a href="https://f-droid.org/en/packages/com.fmsys.snapdrop/">
    <img height="100" alt="Get it on F-Droid" src="https://fdroid.gitlab.io/artwork/badge/get-it-on.png">
  </a>
</p>

## Screenshots
<img src="https://raw.githubusercontent.com/fm-sys/snapdrop-android/master/fastlane/metadata/android/en-US/images/featureGraphic.png" width="43.3%"></img> 
<img src="https://raw.githubusercontent.com/fm-sys/snapdrop-android/master/fastlane/metadata/android/en-US/images/phoneScreenshots/1.png" width="10%"></img> 
<img src="https://raw.githubusercontent.com/fm-sys/snapdrop-android/master/fastlane/metadata/android/en-US/images/phoneScreenshots/2.png" width="10%"></img> 
<img src="https://raw.githubusercontent.com/fm-sys/snapdrop-android/master/fastlane/metadata/android/en-US/images/phoneScreenshots/3.png" width="10%"></img> 
<img src="https://raw.githubusercontent.com/fm-sys/snapdrop-android/master/fastlane/metadata/android/en-US/images/phoneScreenshots/4.png" width="10%"></img> 
<img src="https://raw.githubusercontent.com/fm-sys/snapdrop-android/master/fastlane/metadata/android/en-US/images/phoneScreenshots/5.png" width="10%"></img> 

## Other software
### Other Snapdrop software
- Firefox Add-on for desktop platforms: [Pairdrop Web Extension](https://github.com/ueen/PairdropWebExtension)
- And for sure, PairDrop directly inside the browser - just use it everywhere: https://pairdrop.net/
- And for sure, Snapdrop directly inside the browser - just use it everywhere: https://snapdrop.net/
- Serverless snapdrop desktop app: https://github.com/JustSch/node-snapdrop-electron

### Alternatives
- Apple Airdrop (Mac and IOS only, plus an unofficial [open source implementation](https://github.com/seemoo-lab/opendrop) for Linux) 
- Google Nearby Share (Android, Chrome OS and [Windows](https://www.android.com/better-together/nearby-share-app/), plus an unofficial [macOS client](https://github.com/grishka/NearDrop))
- Windows Nearby Sharing (Windows only, there is a [FLOSS implementation](https://github.com/ShortDevelopment/Nearby-Sharing-Windows) for android)
- Link to Windows (Your Android phone will be mounted as storage directly in your Windows file explorer, [read more](https://blogs.windows.com/windows-insider/2024/07/25/ability-to-access-your-android-phone-in-file-explorer-begins-rolling-out-to-windows-insiders/))
