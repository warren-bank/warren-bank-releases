package com.github.warren_bank.rtsp_screencaster.utils;

import android.content.Context;

public class ResourceUtils {

  public static int getInteger(Context context, int id) {
    return context.getResources().getInteger(id);
  }

}
