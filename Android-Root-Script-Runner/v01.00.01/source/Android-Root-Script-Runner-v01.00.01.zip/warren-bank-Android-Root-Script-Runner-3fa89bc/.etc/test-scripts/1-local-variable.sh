foo='bar'
echo "hello ${foo}"
