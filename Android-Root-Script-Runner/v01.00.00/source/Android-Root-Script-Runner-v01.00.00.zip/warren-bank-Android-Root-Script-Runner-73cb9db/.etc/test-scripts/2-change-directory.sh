cd /sdcard
ls -la .
