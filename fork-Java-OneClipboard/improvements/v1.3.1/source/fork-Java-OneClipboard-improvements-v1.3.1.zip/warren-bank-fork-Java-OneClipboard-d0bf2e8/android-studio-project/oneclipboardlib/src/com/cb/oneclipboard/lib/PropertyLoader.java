package com.cb.oneclipboard.lib;

import java.util.Properties;

public interface PropertyLoader {
  public void load(Properties properties, String fileName);
}
