package com.cb.oneclipboard.lib;

public enum MessageType {
  REGISTER,
  CLIPBOARD_TEXT,
  PING,
  ;
}
