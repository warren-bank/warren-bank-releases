package com.cb.oneclipboard.desktop;

public class ApplicationConstants {
  public enum Property {
    LOGIN,
    LOGOUT,
    STOP,
    START,
    ;
  }
}
