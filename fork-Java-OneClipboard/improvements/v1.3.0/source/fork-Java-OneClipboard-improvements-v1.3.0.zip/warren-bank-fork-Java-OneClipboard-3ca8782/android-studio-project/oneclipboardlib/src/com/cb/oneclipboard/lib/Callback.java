package com.cb.oneclipboard.lib;

public interface Callback {
  public void execute(Object object);
}
