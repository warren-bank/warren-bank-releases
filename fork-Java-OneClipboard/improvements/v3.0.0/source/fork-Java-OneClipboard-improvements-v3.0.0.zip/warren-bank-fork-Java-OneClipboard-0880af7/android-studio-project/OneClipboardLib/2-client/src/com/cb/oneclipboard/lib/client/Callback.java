package com.cb.oneclipboard.lib.client;

public interface Callback {
  public void execute(Object object);
}
