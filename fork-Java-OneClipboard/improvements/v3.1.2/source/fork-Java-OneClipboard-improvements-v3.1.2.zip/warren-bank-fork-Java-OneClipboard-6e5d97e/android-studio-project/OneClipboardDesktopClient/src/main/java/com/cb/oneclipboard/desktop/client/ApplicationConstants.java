package com.cb.oneclipboard.desktop.client;

public class ApplicationConstants {
  public enum Property {
    LOGIN,
    LOGOUT,
    STOP,
    START,
    ;
  }
}
