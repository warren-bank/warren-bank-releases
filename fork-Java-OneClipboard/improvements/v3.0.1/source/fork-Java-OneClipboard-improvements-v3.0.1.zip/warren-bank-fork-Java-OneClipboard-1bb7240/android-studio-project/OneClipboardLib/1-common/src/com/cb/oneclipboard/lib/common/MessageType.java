package com.cb.oneclipboard.lib.common;

public enum MessageType {
  REGISTER,
  CLIPBOARD_TEXT,
  PING,
  DISCONNECT,
  ;
}
