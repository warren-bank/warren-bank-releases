package com.cb.oneclipboard.lib.desktop;

import java.util.Properties;

public interface PropertyLoader {
  public void load(Properties properties, String fileName);
}
