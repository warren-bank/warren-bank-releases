### [Android ExoPlayer demos](https://github.com/warren-bank/Android-ExoPlayer-demos)

#### what:

* [ExoPlayer r2.11.3 demos](https://github.com/google/ExoPlayer/tree/r2.11.3/demos)

#### why:

* remove dependency on ExoPlayer source code
* attach release builds of APKs to tagged [releases](https://github.com/warren-bank/Android-ExoPlayer-demos/releases)
