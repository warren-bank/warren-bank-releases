### [Android ExoPlayer demos](https://github.com/warren-bank/Android-ExoPlayer-demos)

#### what:

* [ExoPlayer r2.14.0 demos](https://github.com/google/ExoPlayer/tree/r2.14.0/demos)
* minimal barebones RTSP demo
  - to illustrate ExoPlayer [issue 8994](https://github.com/google/ExoPlayer/issues/8994)

#### why:

* remove dependency on ExoPlayer source code
* attach release builds of APKs to tagged [releases](https://github.com/warren-bank/Android-ExoPlayer-demos/releases)
