export GIT_EXTERNAL_DIFF=

git request-pull -p 2e7eafdb38d86f760d43934d65b799ad885840a6 https://github.com/warren-bank/moz-prefbar.git submenu_persistence >'../format-patch/00-b. pull request.txt'

git format-patch --text -o '../format-patch' --numbered-files --suffix=.txt -n -M --no-attach --no-thread --no-binary 2e7eafdb38d86f760d43934d65b799ad885840a6..0076e28ac7fd86073d9530af32d0851f18545b89
