pref("extensions.prefbar.show_in_popups", true);
pref("extensions.prefbar.slimbuttons", true);
pref("extensions.prefbar.visualize_unchecked", false);
pref("extensions.prefbar.hktoggle", "][][VK_F8");
pref("extensions.prefbar.website_import", true);
pref("extensions.prefbar.website_import.whitelist", "prefbar.tuxfamily.org");
pref("extensions.prefbar.plugintoggle.mode", 0);
