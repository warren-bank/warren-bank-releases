PhpMyAdmin
==========

* username = root
* password = [none]

- - - - -

WordPress
=========

* username = admin
* password = admin
* email    = admin@librivox.org.test
