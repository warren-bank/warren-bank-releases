pref('extensions.HTTP_Archive_Viewer.validate_json',					true);
pref('extensions.HTTP_Archive_Viewer.show_timeline',					true);
pref('extensions.HTTP_Archive_Viewer.show_stats',						true);
pref('extensions.HTTP_Archive_Viewer.expand_all_pages',					false);
pref('extensions.HTTP_Archive_Viewer.expand_first_page',				true);
pref('extensions.HTTP_Archive_Viewer.request_list.visible_columns',		"url,status,size,timeline");
pref('extensions.HTTP_Archive_Viewer.request_list.phase_interval',		4000);
pref('extensions.HTTP_Archive_Viewer.request_body.html_preview_height',	100);
