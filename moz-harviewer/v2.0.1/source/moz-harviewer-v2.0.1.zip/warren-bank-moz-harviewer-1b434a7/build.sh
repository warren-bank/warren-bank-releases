zip -r HTTP-Archive-Viewer.xpi chrome.manifest install.rdf LICENSE README.md chrome components defaults
