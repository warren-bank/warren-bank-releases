#!/usr/bin/env bash

# ----------------------------------
# deactivate the virtual environment
# ----------------------------------
deactivate
