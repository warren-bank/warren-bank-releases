package com.github.warren_bank.webmonkey;

public interface IBrowser {
  public String getCurrentUrl();
  public void setCurrentUrl(String url);
}
