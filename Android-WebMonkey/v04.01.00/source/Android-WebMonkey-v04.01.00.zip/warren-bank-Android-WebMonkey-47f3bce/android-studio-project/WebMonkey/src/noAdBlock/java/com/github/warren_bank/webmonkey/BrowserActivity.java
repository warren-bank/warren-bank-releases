package com.github.warren_bank.webmonkey;

public class BrowserActivity extends BrowserActivity_Base {}
