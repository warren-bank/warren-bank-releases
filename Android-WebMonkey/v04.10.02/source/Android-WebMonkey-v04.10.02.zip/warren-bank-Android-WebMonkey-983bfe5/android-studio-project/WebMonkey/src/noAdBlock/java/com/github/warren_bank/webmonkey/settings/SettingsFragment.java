package com.github.warren_bank.webmonkey.settings;

public class SettingsFragment extends SettingsFragment_Base {}
