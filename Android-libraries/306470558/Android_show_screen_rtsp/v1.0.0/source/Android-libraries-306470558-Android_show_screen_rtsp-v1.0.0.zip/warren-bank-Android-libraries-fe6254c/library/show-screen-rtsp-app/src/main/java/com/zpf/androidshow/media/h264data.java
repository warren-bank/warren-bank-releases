package com.zpf.androidshow.media;

/**
 * Created by user111 on 2018/3/14.
 */

public class h264data {

    public byte[] data;

    public int type;

    public long ts;
}
