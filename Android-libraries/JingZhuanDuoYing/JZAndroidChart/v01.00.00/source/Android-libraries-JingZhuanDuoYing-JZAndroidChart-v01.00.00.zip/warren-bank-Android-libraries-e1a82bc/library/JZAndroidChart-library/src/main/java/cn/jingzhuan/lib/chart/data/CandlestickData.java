package cn.jingzhuan.lib.chart.data;

/**
 * Created by donglua on 8/29/17.
 */

public class CandlestickData extends ChartData<CandlestickDataSet> {

}
