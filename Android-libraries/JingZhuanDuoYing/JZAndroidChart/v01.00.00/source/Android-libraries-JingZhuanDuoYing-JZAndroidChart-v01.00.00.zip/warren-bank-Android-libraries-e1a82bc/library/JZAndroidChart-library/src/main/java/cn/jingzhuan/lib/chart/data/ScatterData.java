package cn.jingzhuan.lib.chart.data;

/**
 * Created by donglua on 10/19/17.
 */

public class ScatterData extends ChartData<ScatterDataSet> {

}
