package cn.jingzhuan.lib.chart;

/**
 * Created by Donglua on 17/7/17.
 */

public class AxisAutoValues {
    public float[] values = new float[]{};
    public int number;
    public int decimals;
}
