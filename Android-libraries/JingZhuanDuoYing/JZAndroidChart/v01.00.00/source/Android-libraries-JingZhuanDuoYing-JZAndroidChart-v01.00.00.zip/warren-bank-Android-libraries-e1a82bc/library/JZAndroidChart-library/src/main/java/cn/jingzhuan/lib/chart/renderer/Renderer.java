package cn.jingzhuan.lib.chart.renderer;

import android.graphics.Canvas;

/**
 * Created by Donglua on 17/7/17.
 */

public interface Renderer {

    void renderer(Canvas canvas);
}
