package cn.jingzhuan.lib.chart.component;

/**
 * Created by Donglua on 17/8/2.
 */

public interface Component {

    void setEnable(boolean enable);

    boolean isEnable();
}
