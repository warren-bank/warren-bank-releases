package cn.jingzhuan.lib.chart2.demo;

import android.support.multidex.MultiDexApplication;

/**
 * Application
 * Created by donglua on 12/27/17.
 */

public class App extends MultiDexApplication {


}
