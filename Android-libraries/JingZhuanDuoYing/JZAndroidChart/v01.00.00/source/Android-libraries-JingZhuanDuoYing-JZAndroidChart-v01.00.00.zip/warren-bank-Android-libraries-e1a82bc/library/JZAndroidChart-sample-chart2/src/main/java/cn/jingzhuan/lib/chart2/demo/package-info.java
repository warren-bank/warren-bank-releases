@EpoxyDataBindingLayouts({
    R.layout.layout_desc_text,
})
@PackageModelViewConfig(
    rClass = R.class
)

package cn.jingzhuan.lib.chart2.demo;

import com.airbnb.epoxy.EpoxyDataBindingLayouts;
import com.airbnb.epoxy.PackageModelViewConfig;
