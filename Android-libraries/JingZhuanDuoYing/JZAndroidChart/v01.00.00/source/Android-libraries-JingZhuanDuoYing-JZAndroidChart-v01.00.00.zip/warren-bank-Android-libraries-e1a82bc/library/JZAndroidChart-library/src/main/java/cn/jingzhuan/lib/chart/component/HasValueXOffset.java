package cn.jingzhuan.lib.chart.component;

/**
 * Created by donglua on 11/22/17.
 */

public interface HasValueXOffset {

  float getStartXOffset();
  float getEndXOffset();

  void setStartXOffset(float startXOffset);
  void setEndXOffset(float endXOffset);

}
