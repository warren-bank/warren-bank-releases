package cn.jingzhuan.lib.chart.data;

/**
 * Created by Donglua on 17/8/8.
 */

public interface ValueFormatter {

    String format(float value, int index);

}
