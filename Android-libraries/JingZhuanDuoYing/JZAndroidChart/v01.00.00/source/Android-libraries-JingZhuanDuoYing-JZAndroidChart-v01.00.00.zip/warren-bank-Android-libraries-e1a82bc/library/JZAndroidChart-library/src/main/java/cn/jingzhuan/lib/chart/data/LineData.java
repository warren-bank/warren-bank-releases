package cn.jingzhuan.lib.chart.data;

/**
 * Created by Donglua on 17/8/2.
 */

public class LineData extends ChartData<LineDataSet> {

}
