package cn.jingzhuan.lib.chart.demo;

import android.app.Application;

/**
 * Application
 * Created by donglua on 12/27/17.
 */

public class App extends Application {


}
