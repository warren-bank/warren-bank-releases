@EpoxyDataBindingLayouts({
    R.layout.layout_desc_text,
})
@PackageModelViewConfig(
    rClass = R.class
)

package cn.jingzhuan.lib.chart.demo;

import com.airbnb.epoxy.EpoxyDataBindingLayouts;
import com.airbnb.epoxy.PackageModelViewConfig;
