package jp.meridiani.apps.wificonnect;

public class Constants {
  public static final String ACTION_TIMEOUT   = "jp.meridiani.apps.wificonnect.action.TIMEOUT";
  public static final String BUNDLE_AP_SSID   = "jp.meridiani.apps.wificonnect.extra.STRING_AP_SSID";
  public static final String BUNDLE_SHOWTOAST = "jp.meridiani.apps.wificonnect.extra.BOOLEAN_SHOWTOAST";
  public static final String BUNDLE_SSID      = "jp.meridiani.apps.wificonnect.extra.STRING_SSID";
  public static final String BUNDLE_NETWORKID = "jp.meridiani.apps.wificonnect.extra.INTEGER_NETWORKID";
}
