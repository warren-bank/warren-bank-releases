package com.github.dinceruur.androidfft.InterFace;

public interface InterFaceDataListener {
    void notifySensorChanged();
}
