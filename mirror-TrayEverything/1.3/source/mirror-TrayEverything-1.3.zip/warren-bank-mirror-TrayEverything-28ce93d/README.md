TrayEverything
==============

Put every window in the system tray (very old software!)


### Binaries

[![Build Status](https://travis-ci.org/maxgalbu/TrayEverything.svg?branch=master)](https://travis-ci.org/maxgalbu/TrayEverything)

http://dl.bintray.com/maxgalbu/TrayEverything/TrayEverything-current.zip

### Screenshots

![Image](../master/screenshots/trayev.png?raw=true)
![Image](../master/screenshots/trayev2.png?raw=true)
