* allow build from windows
* fix app not working under windows 8
* fix transparency not readable on white background
* fix filenames and icons not detected (ex: sublime text)
