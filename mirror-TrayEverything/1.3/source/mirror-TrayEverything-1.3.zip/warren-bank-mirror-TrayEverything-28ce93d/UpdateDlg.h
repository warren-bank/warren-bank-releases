void Updates_Check(HWND hwnd, BOOL silent = FALSE);
BOOL CALLBACK UpdateDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
