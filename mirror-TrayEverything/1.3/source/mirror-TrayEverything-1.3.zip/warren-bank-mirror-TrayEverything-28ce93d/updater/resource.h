#define IDI_UPDATER             1

#define IDD_UPDATERDLG			9001
#define IDC_UPDATERICON         101
