# Mattermost Desktop Configuration Guides

Please refer to [the Custom Build Configuration section of the Desktop App Deployment Guide](https://docs.mattermost.com/deployment/desktop-app-deployment.html#custom-build-configuration).
