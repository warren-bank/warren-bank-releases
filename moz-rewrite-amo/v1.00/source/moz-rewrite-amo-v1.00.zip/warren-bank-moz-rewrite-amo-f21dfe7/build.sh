zip -r moz-safe-rewrite.xpi chrome.manifest install.rdf LICENSE README.md chrome components defaults
