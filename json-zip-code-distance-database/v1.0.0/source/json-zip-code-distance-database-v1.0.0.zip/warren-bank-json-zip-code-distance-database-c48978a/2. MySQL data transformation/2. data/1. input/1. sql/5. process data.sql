USE `zipcode_spatial_relations`;

CALL geodist_generator(100);
