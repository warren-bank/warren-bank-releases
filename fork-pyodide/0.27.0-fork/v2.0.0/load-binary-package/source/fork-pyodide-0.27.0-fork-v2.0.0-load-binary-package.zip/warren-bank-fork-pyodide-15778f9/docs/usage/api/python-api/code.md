# pyodide.code

```{eval-rst}
.. currentmodule:: pyodide.code

.. automodule:: pyodide.code
   :members:
   :autosummary:
   :autosummary-no-nesting:
```
