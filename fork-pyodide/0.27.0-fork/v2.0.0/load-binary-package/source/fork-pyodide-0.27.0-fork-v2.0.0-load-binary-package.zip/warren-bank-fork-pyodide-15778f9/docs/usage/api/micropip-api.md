```{eval-rst}
:orphan:
```

# Micropip API

The Micropip API documentation was moved to [micropip.pyodide.org](https://micropip.pyodide.org/en/stable/project/api.html).
