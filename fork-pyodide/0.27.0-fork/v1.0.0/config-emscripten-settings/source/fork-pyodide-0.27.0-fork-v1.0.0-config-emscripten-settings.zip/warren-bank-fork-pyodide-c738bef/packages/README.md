# Pyodide packages

This folder contains the list of packages built in pyodide.

Packages are built with the Python build system
using the `pyodide build-recipes` command.
See the [documentation](https://pyodide.org/en/stable/development/new-packages.html) for more details.
