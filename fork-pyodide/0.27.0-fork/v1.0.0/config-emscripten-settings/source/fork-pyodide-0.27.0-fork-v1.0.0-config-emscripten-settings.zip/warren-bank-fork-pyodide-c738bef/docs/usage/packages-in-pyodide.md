(packages-in-pyodide)=

# Packages built in Pyodide

This is the list of Python packages included with the current version of
Pyodide. These packages can be loaded with {js:func}`pyodide.loadPackage` or
{py:func}`micropip.install`. See {ref}`loading_packages` for information about
loading packages. Pure Python packages with wheels on PyPI can be loaded
directly from PyPI with {py:func}`micropip.install`.

```{eval-rst}
.. pyodide-package-list :: packages
```
